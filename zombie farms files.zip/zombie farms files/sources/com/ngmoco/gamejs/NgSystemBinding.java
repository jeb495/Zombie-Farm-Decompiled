package com.ngmoco.gamejs;

import android.content.Context;
import android.content.Intent;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import org.json.JSONException;
import org.json.JSONObject;

public class NgSystemBinding {
    /* JADX WARN: Type inference failed for: r2v0, types: [android.content.Context, com.ngmoco.gamejs.activity.GameJSActivity, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    public static void processOneAction(JSONObject parsed) throws JSONException {
        ?? activity = GameJSActivity.getActivity();
        String name = parsed.getString(NgSystemBindingService.EXTRA_NAME);
        int callbackId = parsed.getInt(NgSystemBindingService.EXTRA_CALLBACK_ID);
        Intent intent = new Intent((Context) activity, NgSystemBindingService.class);
        intent.putExtra(NgSystemBindingService.EXTRA_NAME, name);
        intent.putExtra(NgSystemBindingService.EXTRA_CALLBACK_ID, callbackId);
        if (parsed.has(NgSystemBindingService.EXTRA_CONTINUE_ID)) {
            intent.putExtra(NgSystemBindingService.EXTRA_CONTINUE_ID, parsed.getInt(NgSystemBindingService.EXTRA_CONTINUE_ID));
        }
        activity.startService(intent);
    }
}
