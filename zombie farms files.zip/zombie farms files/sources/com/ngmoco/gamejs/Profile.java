package com.ngmoco.gamejs;

import java.util.HashMap;
import java.util.Vector;

public class Profile {
    private static final int FRAMES_SAMPLES = 100;
    private static HashMap<String, Phases> Pfiles = new HashMap<>();
    private static final String TAG = "Profiler";
    private static int sCFrame = 1;

    private static class Phases {
        Vector<Long> samples = new Vector<>();
        long start = System.currentTimeMillis();

        Phases() {
        }
    }

    public static void start(String what) {
        Phases p = Pfiles.get(what);
        if (p == null) {
            Pfiles.put(what, new Phases());
        } else {
            p.start = System.currentTimeMillis();
        }
    }

    public static void end(String what) {
        Phases p = Pfiles.get(what);
        if (p == null) {
            Log.e(TAG, "WTF are you doing, there is no profile for item " + what);
        } else {
            p.samples.add(Long.valueOf(System.currentTimeMillis() - p.start));
        }
    }

    public static void out() {
        if (sCFrame == 100) {
            Long[] blank = new Long[0];
            for (String key : Pfiles.keySet()) {
                Vector<Long> samples = Pfiles.get(key).samples;
                handleProfile(key, (Long[]) samples.toArray(blank));
                samples.clear();
            }
            sCFrame = 0;
        }
        sCFrame++;
    }

    private static void handleProfile(String name, Long[] items) {
        int total = 0;
        int num = items.length;
        for (Long l : items) {
            total = (int) (((long) total) + l.longValue());
        }
        Log.i(TAG, String.format("Item '%s': total %dms running at %fHz, average %fms per %d frames, and %fms per %d iterations.", name, Integer.valueOf(total), Float.valueOf(((float) num) / (((float) total) / 1000.0f)), Float.valueOf(((float) total) / 100.0f), 100, Float.valueOf(((float) total) / ((float) num)), Integer.valueOf(num)));
    }
}
