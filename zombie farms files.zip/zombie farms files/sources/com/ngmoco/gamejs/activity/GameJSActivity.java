package com.ngmoco.gamejs.activity;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.webkit.CookieSyncManager;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.NgSensor;
import com.ngmoco.gamejs.NotificationEmitter;
import com.ngmoco.gamejs.SplashScreen;
import com.ngmoco.gamejs.TrackingReceiver;
import com.ngmoco.gamejs.gl.GameJSView;
import com.ngmoco.gamejs.iab.ResponseHandler;
import com.ngmoco.gamejs.ngiab.BillingService;
import com.ngmoco.gamejs.ngiab.NgPurchaseObserver;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.FontManager;
import com.tapjoy.TapjoyConstants;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GameJSActivity extends JSActivity {
    public static final int DIALOG_LOAD_PROGRESS_ID = 0;
    public static final String MY_PACKAGE_NAME = GameJSActivity.class.getPackage().getName();
    private static final String TAG = "GameJSActivity";
    public static BillingService gBillingService = null;
    private static String mApk;
    private static String mBundleGame;
    private static String mBundleServer;
    private static String mGame;
    private static String mProductName;
    private static String mSandboxRoot;
    private static String mSourceAppID;
    private static String mStartingServer;
    public static boolean mSuiciding;
    protected static GameJSActivity sActivity;
    private String mBoot = null;
    private String mBootServer = null;
    private DisplayMetrics mDisplayMetrics;
    IntentFilter mEjectIntentFilter;
    BroadcastReceiver mEjectReceiver = new BroadcastReceiver() {
        /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass1 */

        public void onReceive(Context context, Intent intent) {
            Log.d(GameJSActivity.TAG, "Media Ejecting, attempting to close open files.");
            NgJNI.closeFiles();
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setCancelable(false).setNegativeButton(GameJSActivity.this.getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
                /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass1.AnonymousClass1 */

                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                    System.exit(0);
                }
            });
            AlertDialog error = builder.create();
            error.setMessage(GameJSActivity.this.getString(R.string.usb_not_ready_dialog_msg));
            if (!GameJSActivity.mSuiciding) {
                error.show();
            }
            GameJSActivity.mSuiciding = true;
            GameJSActivity.this.mErrors = true;
        }
    };
    private Set<String> mGalaxySModels;
    private String mIntentAction = ASConstants.kEmptyString;
    private String mIntentUrl = ASConstants.kEmptyString;
    private NgPurchaseObserver mObserver;
    private boolean mStarted = false;
    private boolean mStarting = false;
    private Views mViews;

    static class Views {
        private AlertDialog mErrorDialog;

        Views() {
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for r9v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: package-private */
    public boolean noSDCardMounted() {
        String state = Environment.getExternalStorageState();
        if ("mounted".equals(state)) {
            return true;
        }
        if ("removed".equals(state)) {
            Log.d(TAG, "Media was removed");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false).setNegativeButton(getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
                /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass2 */

                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                    System.exit(0);
                }
            });
            AlertDialog error = builder.create();
            error.setMessage(getString(R.string.usb_not_present_dialog_msg));
            if (!mSuiciding) {
                error.show();
            }
            mSuiciding = true;
            this.mErrors = true;
            return false;
        }
        Log.d(TAG, "Media is not ready for use: " + state);
        AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
        builder2.setCancelable(false).setNegativeButton(getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass3 */

            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                System.exit(0);
            }
        });
        AlertDialog error2 = builder2.create();
        error2.setMessage(getString(R.string.usb_not_ready_dialog_msg));
        if (!mSuiciding) {
            error2.show();
        }
        mSuiciding = true;
        this.mErrors = true;
        return false;
    }

    /* JADX DEBUG: Multi-variable search result rejected for r6v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: package-private */
    public boolean isGalaxySEclair() {
        if (Build.VERSION.SDK_INT < 8) {
            if (this.mGalaxySModels == null) {
                this.mGalaxySModels = new HashSet();
                this.mGalaxySModels.add("GT-I9000");
                this.mGalaxySModels.add("SGH-T959");
                this.mGalaxySModels.add("SGH-T959V");
                this.mGalaxySModels.add("SGH-I897");
                this.mGalaxySModels.add("SPH-D700");
                this.mGalaxySModels.add("SCH-I500");
                this.mGalaxySModels.add("SCH-I400");
                this.mGalaxySModels.add("SGH-I896");
                this.mGalaxySModels.add("GT-I9000M");
                this.mGalaxySModels.add("SGH-T959");
                this.mGalaxySModels.add("SGH-T959D");
                this.mGalaxySModels.add("GT-I9000T");
                this.mGalaxySModels.add("GT-I9000B");
                this.mGalaxySModels.add("SHW-M110S");
                this.mGalaxySModels.add("SHW-M130L");
                this.mGalaxySModels.add("SHW-M130K");
                this.mGalaxySModels.add("SCH-I909");
                this.mGalaxySModels.add("GT-I9008");
                this.mGalaxySModels.add("GT-I9088");
                this.mGalaxySModels.add("OMAP_SS");
                this.mGalaxySModels.add("SC-02B");
            }
            if (this.mGalaxySModels.contains(Build.MODEL)) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setCancelable(false).setNegativeButton(getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
                    /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass4 */

                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        System.exit(0);
                    }
                });
                AlertDialog error = builder.create();
                error.setTitle(R.string.unable_to_load_msg);
                error.setMessage(getString(R.string.please_update_msg));
                error.show();
                mSuiciding = true;
                this.mErrors = true;
                return true;
            }
        }
        return false;
    }

    /* JADX DEBUG: Multi-variable search result rejected for r17v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.activity.JSActivity
    public synchronized void onCreate(Bundle icicle) {
        Log.d(TAG, "@@@ GameJSActivity.onCreate +");
        super.onCreate(icicle);
        Log.e(TAG, "ngCore Activity Created");
        if (noSDCardMounted()) {
            if (gBillingService == null) {
                gBillingService = new BillingService();
                Log.d(TAG, "@@@ GameJSActivity.onCreate after new BillingService");
                gBillingService.setContext(this);
            }
            this.mObserver = new NgPurchaseObserver(this, new Handler());
            ResponseHandler.register(this.mObserver);
            mApk = getApplication().getPackageCodePath();
            this.mDisplayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(this.mDisplayMetrics);
            Log.d(TAG, String.format("display metrics width=%d, height=%d", Integer.valueOf(this.mDisplayMetrics.widthPixels), Integer.valueOf(this.mDisplayMetrics.heightPixels)));
            getWindow().setBackgroundDrawable(null);
            String game = null;
            String server = null;
            String sourceAppID = null;
            JSONObject jExtras = new JSONObject();
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                game = extras.getString(getString(R.string._gameKey));
                server = extras.getString(getString(R.string._serverKey));
                sourceAppID = extras.getString(getString(R.string._appidKey));
                this.mBoot = extras.getString("NgBootGame_US");
                this.mBootServer = extras.getString("NgBootServer_US");
                Log.e(TAG, "Received dynamic game " + game + " and server " + server + " and sourceAppID " + sourceAppID);
                for (String item : extras.keySet()) {
                    Object valOpaque = extras.get(item);
                    String val = valOpaque != null ? valOpaque.toString() : null;
                    if (val != null && val.length() > 0) {
                        try {
                            jExtras.put(item, val);
                            if (item.equalsIgnoreCase("nativeLog")) {
                                Log.enabled = val.equalsIgnoreCase("true");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
                Log.e(TAG, "Sending JSON: " + jExtras.toString());
            }
            Log.enabled = Log.enabled || NgJNI.isDebug();
            mBundleGame = getString(R.string.NgStartingGame);
            mBundleServer = getString(R.string.NgStartingServer);
            mProductName = getString(R.string.productName);
            if (game == null) {
                game = mBundleGame;
            }
            if (server == null) {
                server = mBundleServer;
            }
            try {
                jExtras.put("NgStartingGame", mBundleGame);
                jExtras.put("NgStartingServer", mBundleServer);
                jExtras.put("productName", mProductName);
                if (this.mBoot != null) {
                    jExtras.put("NgBootGame_US", this.mBoot);
                }
                if (this.mBootServer != null) {
                    jExtras.put("NgBootServer_US", this.mBootServer);
                }
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
            NgJNI.setBootParams(jExtras.toString());
            mSandboxRoot = ASConstants.kEmptyString;
            mGame = game;
            mStartingServer = server;
            mSourceAppID = sourceAppID;
            Log.d(TAG, "Using game " + mGame + " and server " + mStartingServer);
            this.mViews = new Views();
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false).setNegativeButton(getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
                /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass5 */

                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                    GameJSActivity.this.finish();
                }
            });
            this.mViews.mErrorDialog = builder.create();
            CookieSyncManager.createInstance(this);
            setVolumeControlStream(3);
            this.mEjectIntentFilter = new IntentFilter("android.intent.action.MEDIA_EJECT");
            this.mEjectIntentFilter.addDataScheme("file");
            registerReceiver(this.mEjectReceiver, this.mEjectIntentFilter);
            this.mErrors = false;
        }
        Log.d(TAG, "@@@ GameJSActivity.onCreate -");
    }

    /* JADX DEBUG: Multi-variable search result rejected for r5v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    public void showSDCardFullDialog() {
        Log.d(TAG, "showSDCardFullDialog");
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false).setNegativeButton(getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass6 */

            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                System.exit(0);
            }
        });
        AlertDialog error = builder.create();
        error.setMessage(getString(R.string.sd_card_full_dialog_message));
        if (!mSuiciding) {
            error.show();
        }
        mSuiciding = true;
    }

    @Override // com.ngmoco.gamejs.activity.JSActivity
    public void onDestroy() {
        stopSession();
        Log.d(TAG, "onDestroy() from GameJSActivity");
        if (gBillingService != null) {
            gBillingService.unbind();
        }
        sActivity = null;
        super.onDestroy();
        NgJNI.endJNI();
    }

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.activity.JSActivity
    public void onResume() {
        final String cpackage;
        Log.d(TAG, "onResume  from GameJSActivity");
        Log.d(TAG, "@@@ GameJSActivity.onResume +");
        if (!this.mStarted && noSDCardMounted() && !isGalaxySEclair()) {
            boolean z = this.mStarting;
            this.mStarting = true;
            if (z) {
                super.onResume();
                return;
            } else {
                startEngine();
                handleIntent(getIntent());
            }
        }
        SplashScreen.onResume();
        if (this.mErrors || !noSDCardMounted() || isGalaxySEclair()) {
            super.onResume();
        } else {
            setVolumeControlStream(3);
            registerReceiver(this.mEjectReceiver, this.mEjectIntentFilter);
            super.onResume();
            NgJNI.onResume();
            String callingPackage = getCallingPackage();
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                String callingPackageInExtra = extras.getString("callingPackage");
                if (callingPackage == null && callingPackageInExtra != null) {
                    callingPackage = callingPackageInExtra;
                }
            }
            NgJNI.setCallingPackage(callingPackage);
            final Uri uri = getIntent().getData();
            if (!(uri == null && callingPackage == null)) {
                if (callingPackage == null) {
                    cpackage = ASConstants.kEmptyString;
                } else {
                    cpackage = callingPackage;
                }
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass7 */

                    public void run() {
                        NgJNI.resumedFromOthers(uri == null ? ASConstants.kEmptyString : uri.toString(), cpackage);
                    }
                });
            }
            CookieSyncManager.getInstance().startSync();
        }
        Log.d(TAG, "@@@ GameJSActivity.onResume -");
    }

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.activity.JSActivity
    public void onPause() {
        Log.d(TAG, "onPause from GameJSActivity");
        if (this.mErrors || !this.mStarted) {
            super.onPause();
            if (!this.mStarting) {
                System.exit(0);
                return;
            }
            return;
        }
        super.onPause();
        NgJNI.onPause();
        unregisterReceiver(this.mEjectReceiver);
        CookieSyncManager.getInstance().stopSync();
    }

    @Override // com.ngmoco.gamejs.activity.JSActivity
    public void onBackPressed() {
        super.onBackPressed();
    }

    public AlertDialog getErrorDialog() {
        return this.mViews.mErrorDialog;
    }

    public static String getGame() {
        return mGame;
    }

    public static void setSandboxRoot(String sandboxRoot) {
        mSandboxRoot = sandboxRoot;
    }

    public static String getSandboxRoot() {
        return mSandboxRoot;
    }

    public static String getServer() {
        return mStartingServer;
    }

    private String getUniqueID() {
        String telephonyId = ((TelephonyManager) getSystemService("phone")).getDeviceId();
        if (telephonyId != null) {
            return telephonyId;
        }
        String wifiId = ((WifiManager) getSystemService("wifi")).getConnectionInfo().getMacAddress();
        if (wifiId != null) {
            return wifiId;
        }
        Log.e(TAG, "Device has no Telephony or Wifi id");
        return new String("DEAD-BEEF");
    }

    private long getMemory() {
        try {
            Scanner sc = new Scanner(new BufferedReader(new FileReader("/proc/meminfo"), 64).readLine());
            sc.next();
            long memTotal = (long) sc.nextInt();
            switch (sc.next().charAt(0)) {
                case Commands.CommandIDs.show /*{ENCODED_INT: 71}*/:
                case Commands.CommandIDs.setDarkStyle /*{ENCODED_INT: 103}*/:
                    return memTotal * 1024 * 1024 * 1024;
                case 'K':
                case Commands.CommandIDs.setScrollable /*{ENCODED_INT: 107}*/:
                    return memTotal * 1024;
                case Commands.CommandIDs.stopLoading /*{ENCODED_INT: 77}*/:
                case Commands.CommandIDs.addAnnotation /*{ENCODED_INT: 109}*/:
                    return memTotal * 1024 * 1024;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return 268435456;
    }

    private boolean hasTheWifis() {
        NetworkInfo mWifi = ((ConnectivityManager) getSystemService("connectivity")).getNetworkInfo(1);
        if (mWifi == null || !mWifi.isAvailable()) {
            return false;
        }
        return true;
    }

    private boolean hasWwan() {
        NetworkInfo mWwan = ((ConnectivityManager) getSystemService("connectivity")).getNetworkInfo(0);
        if (mWwan == null || !mWwan.isAvailable()) {
            return false;
        }
        return true;
    }

    private boolean hasHardKeyboard() {
        return getResources().getConfiguration().keyboard == 2;
    }

    private boolean hasGps() {
        return ((LocationManager) getSystemService("location")).getProvider("gps") != null;
    }

    private String getSignatures() {
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 64);
            String sigs = ASConstants.kEmptyString;
            Signature[] arr$ = packageInfo.signatures;
            for (int i$ = 0; i$ < arr$.length; i$++) {
                sigs = (sigs + arr$[i$].toCharsString()) + ",";
            }
            return sigs;
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    private void setDistributionName(String distributionName) {
        File f = new File(getRepo() + "/distributionName");
        if (f.exists()) {
            Log.d(TAG, "distributionName already set. Will not override");
            return;
        }
        try {
            new File(getRepo()).mkdirs();
            f.createNewFile();
            FileWriter fw = new FileWriter(f);
            fw.write(distributionName);
            fw.close();
        } catch (Exception ex) {
            Log.e(TAG, "Failed to write distribution name.");
            ex.printStackTrace();
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for r9v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    private String getAccounts() {
        StringBuilder ret = new StringBuilder();
        ret.append('[');
        Account[] accounts = AccountManager.get(this).getAccounts();
        for (Account account : accounts) {
            ret.append("{\"");
            ret.append(account.type);
            ret.append("\":\"");
            ret.append(account.name);
            ret.append("\"},");
        }
        int len = ret.length();
        if (len <= 1) {
            return "[]";
        }
        ret.setCharAt(len - 1, ']');
        return ret.toString();
    }

    private String getInstallReferrer() {
        String installReferrer = TrackingReceiver.getInstallReferrer(getActivity().getApplicationContext());
        if (installReferrer == null) {
            return ASConstants.kEmptyString;
        }
        return installReferrer;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private JSONObject getCapabilities() {
        JSONObject joe = new JSONObject();
        try {
            String carrier = ((TelephonyManager) getSystemService("phone")).getNetworkOperatorName();
            if (carrier.length() == 0) {
                carrier = "unknown";
            }
            joe.put("boot", this.mBoot);
            joe.put("bootServer", this.mBootServer);
            joe.put("bundleGame", mBundleGame);
            joe.put("bundleServer", mBundleServer);
            joe.put("startingServer", mStartingServer);
            joe.put("carrier", carrier);
            joe.put("bundleIdentifier", getApplication().getPackageName());
            Application app = getApplication();
            try {
                joe.put("applicationVersion", app.getPackageManager().getPackageInfo(app.getPackageName(), 0).versionName);
            } catch (Exception e) {
                joe.put("applicationVersion", "ERROR GETTING VERSION");
            }
            joe.put("uniqueId", getUniqueID());
            joe.put("lifetimeName", Settings.Secure.getString(getContentResolver(), TapjoyConstants.TJC_ANDROID_ID));
            joe.put("hasWifi", hasTheWifis());
            joe.put("physicalMemory", getMemory());
            joe.put("hasHwKeyboard", hasHardKeyboard());
            joe.put("hasCompass", NgSensor.hasCompass());
            joe.put("hasGyro", NgSensor.hasGyro());
            joe.put("hasWwan", hasWwan());
            joe.put("hasGps", hasGps());
            joe.put("deviceName", Build.MODEL);
            joe.put("platformOsVersion", Build.VERSION.RELEASE);
            joe.put("hasAccel", NgSensor.hasAccel());
            joe.put("language", Locale.getDefault().getLanguage());
            joe.put("hasBackButton", true);
            joe.put("installReferrer", getInstallReferrer());
            joe.put("_accts", getAccounts());
            joe.put("intentUrl", this.mIntentUrl);
            joe.put("intentAction", this.mIntentAction);
            joe.put("locale", Locale.getDefault().toString());
            joe.put("screenUnits", Float.toString(this.mDisplayMetrics.density));
            joe.put("screenPixelUnits", Float.toString(this.mDisplayMetrics.density));
            if (this.mDisplayMetrics.widthPixels > this.mDisplayMetrics.heightPixels) {
                joe.put("screenWidth", this.mDisplayMetrics.heightPixels);
                joe.put("screenHeight", this.mDisplayMetrics.widthPixels);
            } else {
                joe.put("screenWidth", this.mDisplayMetrics.widthPixels);
                joe.put("screenHeight", this.mDisplayMetrics.heightPixels);
            }
            joe.put("statusBarHeight", Math.floor(((double) this.mDisplayMetrics.density) * 25.0d));
            joe.put("availableFonts", new JSONArray((Collection) FontManager.availableSystemFonts()));
            joe.put("autorotateDisabled", Boolean.valueOf(Settings.System.getInt(getContentResolver(), "accelerometer_rotation", 1) == 0));
            if (mSourceAppID != null) {
                joe.put("sourceAppID", mSourceAppID);
            }
            String binaryDistributionName = getString(R.string.distribution_name);
            if (!(binaryDistributionName == null || binaryDistributionName.length() == 0)) {
                joe.put("binaryDistributionName", binaryDistributionName);
            }
            joe.put("appSignature", getSignatures());
            TelephonyManager tm = (TelephonyManager) getSystemService("phone");
            if (tm != null) {
                String simCountryCode = tm.getSimCountryIso();
                if (!(simCountryCode == null || simCountryCode.length() == 0)) {
                    joe.put("simCountryCode", simCountryCode);
                }
                String netCountryCode = tm.getNetworkCountryIso();
                if (!(netCountryCode == null || netCountryCode.length() == 0)) {
                    joe.put("networkCountryCode", netCountryCode);
                }
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        }
        return joe;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private String getAppInfo() {
        StringBuilder ret = new StringBuilder("[\"");
        ret.append(getFilesDir().getAbsolutePath());
        ret.append("\",\"");
        ret.append(getRepo());
        ret.append("\",\"");
        ret.append(getApplicationContext().getPackageName());
        ret.append("\"]");
        Log.d(TAG, ret.toString());
        return ret.toString();
    }

    private void startEngine() {
        Log.d(TAG, "Starting game " + mGame + " and server " + mStartingServer);
        try {
            new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/.ngmoco").mkdirs();
        } catch (Exception e) {
        }
        setDistributionName(getActivity().getString(R.string.distribution_name));
        this.mGLView = new GameJSView(this);
        NgEngine.getInstance().registerGLView(this.mGLView);
        new Thread(new Runnable() {
            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass8 */

            public void run() {
                Log.d(GameJSActivity.TAG, "@@@ GameJSActivity.startEngine thread run +");
                if (!NgJNI.beginJNI(GameJSActivity.mStartingServer, GameJSActivity.mGame, GameJSActivity.mApk, GameJSActivity.this.getAppInfo(), GameJSActivity.this.getCapabilities(), GameJSActivity.this.doFirstLaunchActions())) {
                    Log.d(GameJSActivity.TAG, "@@@ GameJSActivity.startEngine beginJNI failed. Initialization process halted");
                    return;
                }
                GameJSActivity.this.verifyBoot();
                Log.d(GameJSActivity.TAG, "@@@ GameJSActivity.startEngine after NgJNI.beginJNI");
                try {
                    NetworkInfo ni = ((ConnectivityManager) GameJSActivity.this.getSystemService("connectivity")).getActiveNetworkInfo();
                    int status = 0;
                    if (ni != null && ni.isAvailable()) {
                        status = ni.getType() == 0 ? 1 : 2;
                    }
                    NgJNI.onConnectivityChanged(status);
                } catch (Exception e) {
                    Log.e(GameJSActivity.TAG, "Failed to set initial connectivity: " + e.getMessage());
                }
                Log.d(GameJSActivity.TAG, "Starting an application thread in engine start");
                GameJSActivity.this.mGLView.startThread();
                GameJSActivity.this.mGLView.onResumeTick();
                GameJSActivity.this.mStarted = true;
                GameJSActivity.this.checkBinaryUpdate();
                Log.d(GameJSActivity.TAG, "@@@ GameJSActivity.startEngine thread run -");
                NgJNI.startWorkerThread();
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void checkBinaryUpdate() {
        new Thread(new Runnable() {
            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass9 */

            public void run() {
                if (NgJNI.needBinaryUpdate()) {
                    GameJSActivity.this.runOnUiThread(new Runnable() {
                        /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass9.AnonymousClass1 */

                        /* JADX WARN: Type inference failed for: r2v1, types: [android.content.Context, com.ngmoco.gamejs.activity.GameJSActivity] */
                        /* JADX WARNING: Unknown variable types count: 1 */
                        public void run() {
                            AlertDialog.Builder builder = new AlertDialog.Builder(this);
                            builder.setCancelable(false).setNegativeButton(this.getString(R.string.update_quit), new DialogInterface.OnClickListener() {
                                /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass9.AnonymousClass1.AnonymousClass2 */

                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    System.exit(0);
                                }
                            }).setPositiveButton(this.getString(R.string.update_get), new DialogInterface.OnClickListener() {
                                /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass9.AnonymousClass1.AnonymousClass1 */

                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    GameJSActivity.this.launchActivity("market://details?id=" + GameJSActivity.this.getApplication().getPackageName(), ASConstants.kEmptyString);
                                    System.exit(0);
                                }
                            });
                            AlertDialog error = builder.create();
                            error.setMessage(this.getString(R.string.update_message));
                            error.setTitle(R.string.update_title);
                            error.show();
                        }
                    });
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void verifyBoot() {
        new Thread(new Runnable() {
            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass10 */

            public void run() {
                if (!NgJNI.validBoot()) {
                    GameJSActivity.this.runOnUiThread(new Runnable() {
                        /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass10.AnonymousClass1 */

                        public void run() {
                            NgJNI.showNetworkError();
                        }
                    });
                    Log.e(GameJSActivity.TAG, "Monkey son the louis!");
                    return;
                }
                Log.e(GameJSActivity.TAG, "Verifimication complete, Monkey.");
            }
        }).start();
    }

    private void handleIntent(final Intent intent) {
        if (intent != null) {
            setIntent(intent);
            if ((intent.getFlags() & 1048576) == 0) {
                JSONObject joe = null;
                final Bundle extras = intent.getExtras();
                if (extras != null) {
                    JSONObject joe2 = new JSONObject();
                    Set<String> keySet = extras.keySet();
                    if (keySet != null) {
                        for (String s : keySet) {
                            try {
                                if (s.equalsIgnoreCase("profile_start")) {
                                    Debug.startMethodTracing(extras.getString(s));
                                } else if (s.equalsIgnoreCase("profile_stop")) {
                                    Debug.stopMethodTracing();
                                } else {
                                    joe2.put(s, extras.get(s));
                                }
                            } catch (JSONException e) {
                                Log.d(TAG, "Failed to transfer intent key: " + s);
                            }
                        }
                    }
                    if (extras.containsKey("payload") || extras.containsKey("type")) {
                        NgEngine.getInstance().queueEvent(new Runnable() {
                            /* class com.ngmoco.gamejs.activity.GameJSActivity.AnonymousClass11 */

                            public void run() {
                                String payload = extras.getString("payload");
                                if (payload != null) {
                                    NgJNI.onPushNotification(payload);
                                }
                                NotificationEmitter.notificationOccurred(intent, true);
                            }
                        });
                    } else {
                        NgJNI.gotIntentToEmit(intent.getAction() != null ? intent.getAction() : ASConstants.kEmptyString, joe2 != null ? joe2.toString() : "{}");
                    }
                } else {
                    NgJNI.gotIntentToEmit(intent.getAction() != null ? intent.getAction() : ASConstants.kEmptyString, 0 != 0 ? joe.toString() : "{}");
                }
                String actionStr = intent.getAction();
                if (actionStr != null) {
                    this.mIntentAction = actionStr;
                }
                String dstr = intent.getDataString();
                if (dstr != null) {
                    this.mIntentUrl = dstr;
                }
            }
        }
    }

    public void onNewIntent(Intent intent) {
        Log.d(TAG, "onNewIntent - Intent: " + intent.toString());
        handleIntent(intent);
    }

    public GameJSActivity() {
        sActivity = this;
        NgJNI.setActivity(this);
    }

    public static GameJSActivity getActivity() {
        return sActivity;
    }

    /* access modifiers changed from: protected */
    public Dialog onCreateDialog(int id) {
        return null;
    }
}
