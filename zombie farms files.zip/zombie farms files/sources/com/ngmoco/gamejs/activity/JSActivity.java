package com.ngmoco.gamejs.activity;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.VideoView;
import com.android.adsymp.core.ASConstants;
import com.google.android.maps.MapActivity;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.mobclix.android.sdk.Mobclix;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgAudio;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.NgMediaSource;
import com.ngmoco.gamejs.NgMusic;
import com.ngmoco.gamejs.NgOrientation;
import com.ngmoco.gamejs.NgSensor;
import com.ngmoco.gamejs.SplashScreen;
import com.ngmoco.gamejs.TrackingReceiver;
import com.ngmoco.gamejs.gl.GameJSView;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.ImagePicker;
import com.ngmoco.gamejs.ui.JSGLAdapter;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import com.ngmoco.gamejs.ui.Utils;
import com.ngmoco.gamejs.ui.widgets.UILayout;
import java.net.URISyntaxException;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

public class JSActivity extends MapActivity implements UILayout.Root.OnSizeListener {
    private static final String BOOT_ORIENTATION_KEY = "ngcore-boot-orientation";
    private static final int CAPTURE_IMAGE_REQUEST_CODE = 3;
    public static final String EXPIRES = "expires_in";
    private static final int IMAGE_REQUEST_CODE = 2;
    public static final String SPLASH_STRING = "splash_url";
    private static final String TAG = "JSActivity";
    public static final String TOKEN = "access_token";
    private static int bootOrientation = -1;
    private static boolean firstResume = true;
    static int mCount = 0;
    private static final String sSSO_MATCH = "sso_auth";
    private static final int sSSO_REQUEST_CODE = 1;
    private String mAD_ID;
    private NgAudio mAudio;
    private int mCoreInterfaceOrientation = -1;
    protected boolean mErrors = false;
    private String mExpire;
    protected GameJSView mGLView;
    protected Handler mHandler;
    private int mHeight;
    private boolean mPaused;
    private UILayout mRootLayout;
    private NgSensor mSensor;
    private int mSystemOrientation = -1;
    private String mToken;
    private int mWidth;
    private TrackingReceiver trackingReceiver = null;

    public NgSensor getSensor() {
        return this.mSensor;
    }

    public GameJSView getGLView() {
        return this.mGLView;
    }

    public UILayout getRootLayout() {
        return this.mRootLayout;
    }

    /* access modifiers changed from: protected */
    public boolean isRouteDisplayed() {
        return false;
    }

    public void addRoot() {
        setContentView(R.layout.jskit);
        this.mRootLayout = (UILayout) findViewById(R.id.rootLayout);
        ((UILayout.Root) this.mRootLayout).setOnSizeListener(this);
        SplashScreen.start(this, getString(R.string.NgStartingGame).length() == 0);
    }

    /* JADX DEBUG: Multi-variable search result rejected for r10v0, resolved type: com.ngmoco.gamejs.activity.JSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        boolean succeeded = false;
        int count = 0;
        while (!succeeded) {
            try {
                JSActivity.super.onCreate(savedInstanceState);
                succeeded = true;
            } catch (Exception e) {
                count++;
                String desc = "Excepted " + count + " time(s) in MapActivity.onCreate on " + Build.MODEL + ". " + getIntent().toUri(1);
                if (count >= 3) {
                    throw new Error(desc, e);
                }
                Log.e(TAG, desc);
            }
        }
        NgOrientation.init(this);
        if (savedInstanceState != null && savedInstanceState.containsKey(BOOT_ORIENTATION_KEY)) {
            int savedBootOrientation = savedInstanceState.getInt(BOOT_ORIENTATION_KEY, -1);
            if (savedBootOrientation > -1) {
                NgOrientation.setOrientation(savedBootOrientation);
            }
        } else if (bootOrientation > -1) {
            NgOrientation.setOrientation(bootOrientation);
        } else {
            bootOrientation = NgOrientation.getInterfaceOrientation();
        }
        NgJNI.loadNgGame();
        new AsyncTask<Void, Void, Void>() {
            /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass1 */

            /* access modifiers changed from: protected */
            public Void doInBackground(Void... params) {
                return null;
            }
        };
        this.trackingReceiver = new TrackingReceiver();
        this.trackingReceiver.sendTrackingOnLaunch(this, getIntent());
        this.trackingReceiver.startSession(this, getIntent());
        addRoot();
        this.mPaused = true;
        Utils.init(this);
        NgMediaSource.init(this);
        this.mAudio = new NgAudio(this);
        this.mHandler = new Handler();
        ImagePicker.getInstance().setActivity(this);
        this.mSensor = new NgSensor(this);
    }

    /* access modifiers changed from: protected */
    public void onSaveInstanceState(Bundle outState) {
        if (bootOrientation > -1) {
            outState.putInt(BOOT_ORIENTATION_KEY, bootOrientation);
        }
        JSActivity.super.onSaveInstanceState(outState);
    }

    /* access modifiers changed from: protected */
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        if (savedInstanceState != null && savedInstanceState.containsKey(BOOT_ORIENTATION_KEY)) {
            NgOrientation.setOrientation(savedInstanceState.getInt(BOOT_ORIENTATION_KEY));
        } else if (bootOrientation > -1) {
            NgOrientation.setOrientation(bootOrientation);
        }
        JSActivity.super.onRestoreInstanceState(savedInstanceState);
    }

    public boolean isPaused() {
        return this.mPaused;
    }

    public boolean doFirstLaunchActions() {
        SharedPreferences prefs = getApplicationContext().getSharedPreferences("com.mobage", 0);
        if (prefs.getBoolean("JSActivity_first_launch", false)) {
            return false;
        }
        prefs.edit().putBoolean("JSActivity_first_launch", true).commit();
        return true;
    }

    private void updateAudioState(boolean losingFocus) {
        if (NgJNI.isGamePaused()) {
            return;
        }
        if (this.mAudio.isSuspend()) {
            if (!losingFocus && hasWindowFocus()) {
                this.mAudio.suspend(false);
                NgMusic.resumeMusic();
            }
        } else if (losingFocus || !hasWindowFocus()) {
            this.mAudio.suspend(true);
            NgMusic.pauseUserMusic();
            NgMusic.suspendMusic();
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        JSActivity.super.onResume();
        if (!this.mErrors) {
            Log.d(TAG, "Resume called from JSActivity");
            updateAudioState(false);
            this.mSensor.resume();
            if (firstResume) {
                firstResume = false;
            } else {
                setRequestedOrientation(NgOrientation.getInterfaceOrientation());
            }
            JSGLAdapter glView = JSGLAdapter.getInstance();
            if (glView != null) {
                glView.resume();
            } else {
                Log.d(TAG, "No glView available");
            }
            this.mPaused = false;
        }
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        JSActivity.super.onWindowFocusChanged(hasFocus);
        updateAudioState(!hasFocus);
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        if (!this.mErrors) {
            JSActivity.super.onPause();
            JSGLAdapter glView = JSGLAdapter.getInstance();
            if (glView != null) {
                glView.pause();
            } else {
                Log.d(TAG, "No glView available");
            }
            this.mSensor.pause();
            updateAudioState(true);
            Commands.onPause();
            this.mPaused = true;
            return;
        }
        JSActivity.super.onPause();
    }

    /* JADX DEBUG: Multi-variable search result rejected for r1v0, resolved type: com.ngmoco.gamejs.activity.JSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* access modifiers changed from: protected */
    public void stopSession() {
        if (this.trackingReceiver != null) {
            this.trackingReceiver.stopSession(this);
            this.trackingReceiver = null;
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        Commands.onDestroy();
        this.mAudio.kill();
        reset();
        stopSession();
        JSActivity.super.onDestroy();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass2 */

            public void run() {
                NgJNI.keyEvent(1, 0, 82);
            }
        });
        return false;
    }

    public void reset() {
        try {
            JSGLAdapter.clearInstance();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case Commands.CommandIDs.setBasicAuthCredentials /*{ENCODED_INT: 82}*/:
                if (!NgJNI.jsKeyHandling()) {
                    return true;
                }
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass3 */

                    public void run() {
                        NgJNI.keyEvent(1, 0, 82);
                    }
                });
                return true;
            case Commands.CommandIDs.setRightImage /*{ENCODED_INT: 83}*/:
            default:
                return JSActivity.super.onKeyDown(keyCode, event);
            case Commands.CommandIDs.setRightImageBorder /*{ENCODED_INT: 84}*/:
                return true;
        }
    }

    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (keyCode != 4) {
            return JSActivity.super.onKeyLongPress(keyCode, event);
        }
        if (NgJNI.jsKeyHandling()) {
            Vibrator v = (Vibrator) getSystemService("vibrator");
            if (v != null) {
                v.vibrate(30);
            }
            NgEngine.getInstance().queueEvent(new Runnable() {
                /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass4 */

                public void run() {
                    NgJNI.keyEvent(1, 0, 84);
                }
            });
        }
        return true;
    }

    public void onBackPressed() {
        if (!videoStopped()) {
            if (NgJNI.jsKeyHandling()) {
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass5 */

                    public void run() {
                        NgJNI.keyEvent(1, 0, 4);
                    }
                });
            } else {
                JSActivity.super.onBackPressed();
            }
        }
    }

    private boolean videoStopped() {
        View v = getCurrentFocus();
        if (v == null || v != SplashScreen.getVideoView()) {
            return false;
        }
        ((VideoView) v).seekTo(((VideoView) v).getDuration());
        return true;
    }

    public void gameProcStart() {
        if (this.mGLView != null) {
            this.mGLView.stopGL();
        }
        NgJNI.onLayoutChanged(this.mWidth, this.mHeight);
    }

    public void privProcStart() {
        NgJNI.onLayoutChanged(this.mWidth, this.mHeight);
    }

    /* JADX DEBUG: Multi-variable search result rejected for r2v0, resolved type: com.ngmoco.gamejs.activity.JSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    public void handleGameAdID(String handleGameAdID) {
        this.mAD_ID = handleGameAdID;
        runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass6 */

            public void run() {
                try {
                    Log.d(JSActivity.TAG, "Handling Game AD ID set to be :" + JSActivity.this.mAD_ID);
                    Mobclix.onCreateWithApplicationId(this, JSActivity.this.mAD_ID);
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        });
    }

    public void setGLDebug(boolean val) {
        Log.d(TAG, "Setting gl threading to :" + val);
        this.mGLView.setGLThreadingLog(val);
    }

    public void onBackPressedSuperClass() {
        Log.d(TAG, "onBackPressedSuperClass() from JSActivity, exiting immediately");
        Log.d(TAG, "If you have a problem about this, you can take it up with JMarr and Steve D");
        finish();
    }

    public void launchActivity(String action, String extras) {
        Intent intent;
        Log.d(TAG, "Starting activity with intent " + action);
        if (action.startsWith("http://") || action.startsWith("market://")) {
            intent = new Intent("android.intent.action.VIEW", Uri.parse(action));
        } else {
            intent = new Intent(action);
        }
        if (extras.length() != 0) {
            try {
                JSONObject joe = new JSONObject(extras);
                if (joe.has("packageName")) {
                    intent.setPackage(joe.optString("packageName", null));
                    joe.remove("packageName");
                }
                Iterator<?> i = joe.keys();
                Log.d(TAG, "puting extras " + extras);
                while (i.hasNext()) {
                    String key = i.next();
                    Object val = joe.get(key);
                    if (val.getClass() == String.class) {
                        intent.putExtra(key, (String) val);
                        Log.d(TAG, "put String extra " + val);
                    } else {
                        Log.d(TAG, "found class " + val.getClass().getCanonicalName() + " assuming int.");
                        intent.putExtra(key, joe.getInt(key));
                        Log.d(TAG, "put int extra " + val);
                    }
                }
                startActivity(intent);
            } catch (JSONException e) {
                e.printStackTrace();
                startActivity(intent);
            } catch (ActivityNotFoundException e2) {
                e2.printStackTrace();
            }
        } else {
            startActivity(intent);
        }
    }

    public boolean launchURL(String uri) {
        if (uri.indexOf(sSSO_MATCH) != -1) {
            return launchByNames(uri);
        }
        return launchByURI(uri);
    }

    private boolean launchByNames(String uriString) {
        Uri uri = Uri.parse(uriString);
        String packageName = uri.getQueryParameter("packageName");
        String className = uri.getQueryParameter("className");
        if (packageName == null || className == null) {
            return false;
        }
        Intent intent = new Intent();
        intent.setClassName(packageName, className);
        intent.putExtra("uri", uriString);
        try {
            startActivityForResult(intent, 1);
            return true;
        } catch (ActivityNotFoundException e) {
            Log.e(TAG, "launchByNames failed");
            return false;
        }
    }

    private boolean launchByURI(String uri) {
        try {
            Intent intent = Intent.parseUri(uri, 0);
            intent.setAction("android.intent.action.VIEW");
            try {
                startActivity(intent);
                return true;
            } catch (ActivityNotFoundException e) {
                return false;
            }
        } catch (URISyntaxException e2) {
            return false;
        }
    }

    public void launchGallery() {
        startActivityForResult(new Intent("android.intent.action.PICK", MediaStore.Images.Media.INTERNAL_CONTENT_URI), 2);
    }

    public void launchCamera() {
        startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), 3);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode != -1) {
                return;
            }
            if (data.getStringExtra(JSWebViewAdapter.Events.ERROR) != null) {
                Log.e(TAG, "got an error");
                return;
            }
            this.mToken = data.getStringExtra(TOKEN);
            this.mExpire = data.getStringExtra(EXPIRES);
        } else if (requestCode == 2) {
            Bitmap bmp = null;
            int errorCode = 1;
            if (resultCode == -1) {
                Uri selectedImage = data.getData();
                String[] filePathColumn = {"_data"};
                Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                if (cursor != null) {
                    try {
                        cursor.moveToFirst();
                        String filePath = cursor.getString(cursor.getColumnIndex(filePathColumn[0]));
                        cursor.close();
                        bmp = ImagePicker.decodeFile(filePath);
                        if (bmp != null) {
                            errorCode = 0;
                        }
                    } catch (Exception e) {
                    } catch (Error e2) {
                        errorCode = 2;
                    }
                } else if (selectedImage != null && selectedImage.isAbsolute()) {
                    ImagePicker.getInstance().onImagePicked(selectedImage.toString(), 0);
                    return;
                }
            }
            ImagePicker.getInstance().onImagePicked(bmp, errorCode);
        } else if (requestCode != 3) {
        } else {
            if (resultCode != -1 || data == null || data.getExtras() == null) {
                ImagePicker.getInstance().onImagePicked((Bitmap) null, 1);
                return;
            }
            ImagePicker.getInstance().onImagePicked((Bitmap) data.getExtras().get(ASConstants.kASResponseKeyData), 0);
        }
    }

    public Handler getHandler() {
        return this.mHandler;
    }

    public String getRepo() {
        return Environment.getExternalStorageDirectory().getAbsolutePath() + getString(R.string.gameDirectory);
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == 24) {
            this.mAudio.setRingerMode(2);
        }
        return JSActivity.super.dispatchKeyEvent(event);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout.Root.OnSizeListener
    public void onSizeChanged(final int w, final int h, int oldW, int oldH) {
        this.mWidth = w;
        this.mHeight = h;
        if (JSGLAdapter.getInstance() != null) {
            JSGLAdapter.getInstance().onScreenSizeChanged(w, h);
        }
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass7 */

            public void run() {
                NgJNI.onLayoutChanged(w, h);
            }
        });
    }

    public void launchService(String action, String extras) {
        Log.d(TAG, "Starting activity with intent " + action);
        Intent intent = new Intent(action);
        if (extras != null && extras.length() > 0) {
            try {
                JSONObject joe = new JSONObject(extras);
                if (joe.has("packageName")) {
                    intent.setPackage(joe.optString("packageName", null));
                    joe.remove("packageName");
                }
                Iterator<?> i = joe.keys();
                Log.d(TAG, "puting extras " + extras);
                while (i.hasNext()) {
                    String key = i.next();
                    Object val = joe.get(key);
                    if (val.getClass() == String.class) {
                        intent.putExtra(key, (String) val);
                        Log.d(TAG, "put String extra " + val);
                    } else {
                        Log.d(TAG, "found class " + val.getClass().getCanonicalName() + " assuming int.");
                        intent.putExtra(key, joe.getInt(key));
                        Log.d(TAG, "put int extra " + val);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        startService(intent);
    }

    private boolean isConfigurationMismatch() {
        switch (this.mSystemOrientation) {
            case 0:
                return true;
            case 1:
                return this.mCoreInterfaceOrientation == 0 || this.mCoreInterfaceOrientation == 8;
            case 2:
                return this.mCoreInterfaceOrientation == 1 || this.mCoreInterfaceOrientation == 9;
            case 3:
                return false;
            default:
                return false;
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        int i;
        int i2 = 4;
        JSActivity.super.onConfigurationChanged(newConfig);
        this.mSystemOrientation = newConfig.orientation;
        if ((!this.mPaused || Build.VERSION.SDK_INT != 11) && Build.VERSION.SDK_INT != 12) {
            boolean configMismatch = isConfigurationMismatch();
            UILayout rootLayout = getRootLayout();
            if (configMismatch) {
                i = 4;
            } else {
                i = 0;
            }
            rootLayout.setVisibility(i);
            if (this.mGLView != null) {
                GameJSView gameJSView = this.mGLView;
                if (!configMismatch) {
                    i2 = 0;
                }
                gameJSView.setVisibility(i2);
            }
        }
    }

    public void setRequestedOrientation(int requestedOrientation) {
        this.mCoreInterfaceOrientation = requestedOrientation;
        JSActivity.super.setRequestedOrientation(requestedOrientation);
        final UILayout root = getRootLayout();
        if (!isConfigurationMismatch() && root != null) {
            runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.activity.JSActivity.AnonymousClass8 */

                public void run() {
                    root.setVisibility(0);
                    if (JSActivity.this.mGLView != null) {
                        JSActivity.this.mGLView.setVisibility(0);
                    }
                }
            });
        }
    }
}
