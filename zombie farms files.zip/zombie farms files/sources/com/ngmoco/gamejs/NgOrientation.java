package com.ngmoco.gamejs;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.Display;
import android.view.OrientationEventListener;
import android.view.WindowManager;

public class NgOrientation extends OrientationEventListener {
    public static final String TAG = "NgOrientation";
    static final int THRESHOLD = 20;
    static final int THR_LANDSCAPE_LEFT = 270;
    static final int THR_LANDSCAPE_RIGHT = 90;
    static final int THR_PORTRAIT_UPSIDEDOWN = 180;
    private static NgOrientation sInstance;
    private static int sNaturalOrientationOffset = 0;
    private int currentOrientation = -1;
    private int lastInterfaceOrientation = -1;

    public static final class Orientation {
        static final int LANDSCAPE_LEFT = 0;
        static final int LANDSCAPE_RIGHT = 8;
        static final int PORTRAIT = 1;
        static final int PORTRAIT_UPSIDEDOWN = 9;
        static final int UNKNOWN = -1;
    }

    public static native void interfaceOrientationChanged(int i);

    public static native void orientationChanged(int i);

    public static void init(Context context) {
        boolean looksLikeLandscape;
        int i = THR_LANDSCAPE_LEFT;
        if (sInstance == null) {
            sInstance = new NgOrientation(context, 3);
        }
        Display display = ((WindowManager) context.getSystemService("window")).getDefaultDisplay();
        if (Build.VERSION.SDK_INT < 8) {
            switch (display.getOrientation()) {
                case 0:
                    sInstance.lastInterfaceOrientation = 1;
                    break;
                case 1:
                    sInstance.lastInterfaceOrientation = 8;
                    break;
                default:
                    sInstance.lastInterfaceOrientation = 1;
                    break;
            }
        } else {
            if (display.getWidth() > display.getHeight()) {
                looksLikeLandscape = true;
            } else {
                looksLikeLandscape = false;
            }
            switch (display.getRotation()) {
                case 0:
                case 2:
                    if (!looksLikeLandscape) {
                        i = 0;
                    }
                    sNaturalOrientationOffset = i;
                    break;
                case 1:
                case 3:
                    sNaturalOrientationOffset = looksLikeLandscape ? 0 : THR_LANDSCAPE_LEFT;
                    break;
            }
            int orientation = -1;
            switch (display.getRotation()) {
                case 0:
                    if (!looksLikeLandscape) {
                        orientation = 1;
                        break;
                    } else {
                        orientation = 0;
                        break;
                    }
                case 1:
                    if (!looksLikeLandscape) {
                        orientation = 8;
                        break;
                    } else {
                        orientation = 1;
                        break;
                    }
                case 2:
                    if (!looksLikeLandscape) {
                        orientation = 9;
                        break;
                    } else {
                        orientation = 8;
                        break;
                    }
                case 3:
                    if (!looksLikeLandscape) {
                        orientation = 0;
                        break;
                    } else {
                        orientation = 9;
                        break;
                    }
            }
            sInstance.lastInterfaceOrientation = orientation;
        }
        switch (((Activity) context).getRequestedOrientation()) {
            case 0:
                sInstance.lastInterfaceOrientation = 0;
                return;
            case 1:
                sInstance.lastInterfaceOrientation = 1;
                return;
            case 8:
                sInstance.lastInterfaceOrientation = 8;
                return;
            case 9:
                sInstance.lastInterfaceOrientation = 9;
                return;
            default:
                return;
        }
    }

    NgOrientation(Context context, int rate) {
        super(context, rate);
    }

    public void onOrientationChanged(int orientation) {
        int nextOrientation;
        if (orientation == -1) {
            orientationChanged(-1);
            return;
        }
        int orientation2 = (sNaturalOrientationOffset + orientation) % 360;
        if (orientation2 < 20 || orientation2 > 340) {
            nextOrientation = 1;
        } else if (orientation2 > 250 && orientation2 < 290) {
            nextOrientation = 0;
        } else if (orientation2 > 160 && orientation2 < 200) {
            nextOrientation = 9;
        } else if (orientation2 <= 70 || orientation2 >= 110) {
            nextOrientation = this.currentOrientation;
        } else {
            nextOrientation = 8;
        }
        if (this.currentOrientation != nextOrientation) {
            orientationChanged(nextOrientation);
            this.currentOrientation = nextOrientation;
        }
    }

    public static void start() {
        sInstance.enable();
    }

    public static void stop() {
        sInstance.disable();
    }

    public static void setOrientation(int orientation) {
        NgJNI.setOrientation(orientation);
    }

    public static int getDeviceOrientation() {
        return sInstance.currentOrientation;
    }

    public static int getInterfaceOrientation() {
        Log.d(TAG, String.format("getLastInterfaceOrientation:%d", Integer.valueOf(sInstance.lastInterfaceOrientation)));
        return sInstance.lastInterfaceOrientation;
    }

    public static void changeInterfaceOrientation(int orientation) {
        Log.d(TAG, String.format("changeInterfaceOrientation to:%d", Integer.valueOf(orientation)));
        sInstance.lastInterfaceOrientation = orientation;
        try {
            interfaceOrientationChanged(orientation);
        } catch (Throwable th) {
        }
    }
}
