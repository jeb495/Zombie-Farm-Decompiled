package com.ngmoco.gamejs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class DownloadCompleteReceiver extends BroadcastReceiver {
    private static final String downloadDescription = "com.ngmoco.gamehubmobage";

    public void onReceive(Context context, Intent intent) {
    }
}
