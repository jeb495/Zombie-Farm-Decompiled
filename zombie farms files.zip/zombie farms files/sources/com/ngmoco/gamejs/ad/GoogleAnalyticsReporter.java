package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import com.google.android.apps.analytics.AnalyticsReceiver;
import com.google.android.apps.analytics.GoogleAnalyticsTracker;
import com.ngmoco.gamejs.Log;

public final class GoogleAnalyticsReporter implements Advertiser, InstallReporter, SessionReporter {
    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void start(Context context) {
        GoogleAnalyticsTracker.getInstance().startNewSession("UA-25218684-1", context);
        Log.d(getClass().getSimpleName(), "Session started.");
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void stop(Context context) {
        GoogleAnalyticsTracker.getInstance().stopSession();
        Log.d(getClass().getSimpleName(), "Session stopped.");
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void sendEvent(String event) {
    }

    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(Context context, Intent intent) {
        new AnalyticsReceiver().onReceive(context, intent);
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
