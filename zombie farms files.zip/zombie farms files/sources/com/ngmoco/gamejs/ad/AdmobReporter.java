package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import com.google.ads.InstallReceiver;

public final class AdmobReporter implements Advertiser, InstallReporter {
    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(Context context, Intent intent) {
        new InstallReceiver().onReceive(context, intent);
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
