package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.provider.Settings;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.Log;
import com.tapjoy.TapjoyConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

/* compiled from: InMobiReporter */
final class InMobiAndroidTrackerHTTPRequest {
    private static final String platform = "android";
    private static final String urlString = "http://ma.mkhoj.com/downloads/trackerV1?";
    private final String advertiserId;
    private final String deviceId = getDeviceId();
    private final Context mContext;
    private final String packageIdentifier = this.mContext.getPackageName();

    public InMobiAndroidTrackerHTTPRequest(Context ctx, String advertiserId2) {
        this.mContext = ctx;
        this.advertiserId = advertiserId2;
    }

    public boolean setupConnection() {
        boolean response = false;
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL("http://ma.mkhoj.com/downloads/trackerV1?adv_id=" + this.advertiserId + "&udid=" + this.deviceId + "&app_id=" + this.packageIdentifier + "&platform=" + "android" + "&timestamp=" + "'" + new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date()).replace(" ", "%20") + "'").openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setConnectTimeout(30000);
            connection.setReadTimeout(30000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            if (connection.getResponseCode() == 200) {
                Log.v("InMobiValue", "response is OK" + reader);
                response = false;
                try {
                    XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                    factory.setNamespaceAware(true);
                    XmlPullParser xpp = factory.newPullParser();
                    xpp.setInput(reader);
                    String tag = null;
                    for (int eventType = xpp.getEventType(); eventType != 1; eventType = xpp.next()) {
                        if (eventType == 0) {
                            Log.w("InMobiValue", "Start document");
                        } else if (eventType == 1) {
                            Log.w("InMobiValue", "End document");
                        } else if (eventType == 2) {
                            tag = xpp.getName();
                            Log.w("InMobiValue", "Start tag: " + xpp.getName());
                        } else if (eventType == 3) {
                            Log.w("InMobiValue", "End tag: " + tag);
                        } else if (eventType == 4) {
                            String status = xpp.getText();
                            if (tag.equals("status") && status.equals("true")) {
                                response = true;
                            }
                            Log.w("InMobiValue", "text: " + status);
                        }
                    }
                } catch (XmlPullParserException parseException) {
                    parseException.printStackTrace();
                }
            } else {
                Log.v("InMobiValue", "response is " + connection.getResponseMessage());
            }
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
        return response;
    }

    private String getDeviceId() {
        String deviceId2 = null;
        try {
            deviceId2 = Settings.Secure.getString(this.mContext.getApplicationContext().getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        } catch (Exception e) {
        }
        if (deviceId2 != null) {
            return deviceId2;
        }
        try {
            return Settings.System.getString(this.mContext.getApplicationContext().getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        } catch (Exception e2) {
            return ASConstants.kEmptyString;
        }
    }
}
