package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;

public final class GreyStripeReporter extends AsyncTrackingReporter implements LaunchReporter {
    private static final String appIdForMobage = "100003588";
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
        String appId2 = context.getString(R.string._GreystripeAppId);
        if (appId2 == null) {
            appId2 = appIdForMobage;
        }
        this.appId = appId2;
        this.postUrl = String.format("http://ads2.greystripe.com/AdBridgeServer/track.htm?did=%s&appid=%s&action=dl", this.uniqueId, this.appId);
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getDefaultUniqueId(Context context) {
        String uid = super.getDefaultUniqueId(context);
        if (!uid.equals(ASConstants.kEmptyString)) {
            return uid.replace("\\W", ASConstants.kEmptyString);
        }
        return uid;
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        sendTracking();
    }
}
