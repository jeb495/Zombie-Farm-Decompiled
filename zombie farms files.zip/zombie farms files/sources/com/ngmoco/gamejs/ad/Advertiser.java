package com.ngmoco.gamejs.ad;

import android.content.Context;

public interface Advertiser {
    void configure(Context context);
}
