package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.ngmoco.gamejs.Log;

public final class JumpTapReporter extends AsyncTrackingReporter implements LaunchReporter {
    private static final String eventType = "Download";
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
        this.uniqueId = getAndroidId(context);
        this.appId = context.getPackageName();
        Log.d("JumptapReceiver", "uniqueId=" + this.uniqueId + ", packageName=" + this.appId);
        this.postUrl = String.format("http://a.jumptap.com/a/conversion?hid=%s&app=%s&event=%s", this.uniqueId, this.appId, eventType);
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        sendTracking();
    }
}
