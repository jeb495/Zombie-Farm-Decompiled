package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.tapjoy.TapjoyConnect;
import com.tapjoy.TapjoyReferralTracker;

public final class TapjoyReporter implements Advertiser, InstallReporter, SessionReporter {
    String appId;
    String secret;

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = context.getString(R.string._TapjoyAppId);
        this.secret = context.getString(R.string._TapjoySecret);
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void start(Context context) {
        if (this.appId.length() != 0) {
            Log.d(getClass().getName(), "sending a request to TapJoy: appId=" + this.appId);
            TapjoyConnect.requestTapjoyConnect(context.getApplicationContext(), this.appId, this.secret);
        }
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void stop(Context context) {
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void sendEvent(String event) {
    }

    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(Context context, Intent intent) {
        new TapjoyReferralTracker().onReceive(context, intent);
    }

    public static void sendActionEvent(String actionId) {
        TapjoyConnect tapjoyConnect = TapjoyConnect.getTapjoyConnectInstance();
        if (tapjoyConnect != null) {
            Log.d("TapjoyReporter", "sending actionComplete: " + actionId);
            tapjoyConnect.actionComplete(actionId);
        }
    }
}
