package com.ngmoco.gamejs.ad;

import android.app.Activity;
import android.content.Context;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.w3i.advertiser.W3iAdvertiser;
import com.w3i.advertiser.W3iConnect;

public class W3iReporter implements LaunchReporter, Advertiser, W3iAdvertiser {
    private int appId;

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = Integer.parseInt(context.getString(R.string._ad_W3iAppId));
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        Activity activity = (Activity) context;
        if (activity == null) {
            Log.e(getClass().getSimpleName(), "W3iReporter requires valid activity");
        } else {
            new W3iConnect(activity, true, this).appWasRun(this.appId);
        }
    }

    @Override // com.w3i.advertiser.W3iAdvertiser
    public void onActionComplete(Boolean success) {
        if (success.booleanValue()) {
            Log.d(getClass().getSimpleName(), "W3i request succeeded.");
        } else {
            Log.d(getClass().getSimpleName(), "W3i request failed.");
        }
    }
}
