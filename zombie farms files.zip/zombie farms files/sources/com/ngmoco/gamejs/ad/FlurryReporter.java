package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.flurry.android.FlurryAgent;
import com.mobage.ww.a465.zombiefarm_android.R;

public final class FlurryReporter implements Advertiser, SessionReporter {
    private String appId;

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void start(Context context) {
        FlurryAgent.onStartSession(context, this.appId);
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void stop(Context context) {
        FlurryAgent.onEndSession(context);
    }

    @Override // com.ngmoco.gamejs.ad.SessionReporter
    public void sendEvent(String event) {
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = context.getString(R.string._ad_FlurryAppId);
    }
}
