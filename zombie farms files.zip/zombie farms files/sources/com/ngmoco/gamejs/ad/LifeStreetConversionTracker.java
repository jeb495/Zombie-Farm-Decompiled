package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.os.AsyncTask;
import com.ngmoco.gamejs.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/* compiled from: LifeStreetReporter */
class LifeStreetConversionTracker extends AsyncTask<String, String, String> {
    private static final String CONVERSION_PARAM_REFERRER = "referrer";
    private static final String INSTALLATION = "LSM_CONVERSION_COOKIE";
    private static final String LSM_CONVERSION_URL = "http://mobile.lfstmedia.com/android01/install";
    public static final String LSM_DEBUG_TAG = "LSMDEBUG";
    private static final String RESULT_ERROR = "ERROR";
    private static final String RESULT_OK = "OK";
    private final Context context;

    public LifeStreetConversionTracker(Context context2) {
        this.context = context2;
    }

    /* access modifiers changed from: protected */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x011a, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x011b, code lost:
        com.ngmoco.gamejs.Log.e(com.ngmoco.gamejs.ad.LifeStreetConversionTracker.LSM_DEBUG_TAG, "URL is incorrect", r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x0126, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0127, code lost:
        com.ngmoco.gamejs.Log.e(com.ngmoco.gamejs.ad.LifeStreetConversionTracker.LSM_DEBUG_TAG, "Write to file error", r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x012f, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x0130, code lost:
        com.ngmoco.gamejs.Log.e(com.ngmoco.gamejs.ad.LifeStreetConversionTracker.LSM_DEBUG_TAG, "Wrong URL: " + r9, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0149, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x014a, code lost:
        com.ngmoco.gamejs.Log.e(com.ngmoco.gamejs.ad.LifeStreetConversionTracker.LSM_DEBUG_TAG, "ClientProtocolException", r0);
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x011a A[ExcHandler: UnsupportedEncodingException (r0v3 'e' java.io.UnsupportedEncodingException A[CUSTOM_DECLARE]), Splitter:B:17:0x004a] */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x012f A[ExcHandler: URISyntaxException (r0v2 'e' java.net.URISyntaxException A[CUSTOM_DECLARE]), PHI: r9 
      PHI: (r9v1 'uriStr' java.lang.String) = (r9v0 'uriStr' java.lang.String), (r9v3 'uriStr' java.lang.String) binds: [B:17:0x004a, B:22:0x00f6] A[DONT_GENERATE, DONT_INLINE], Splitter:B:17:0x004a] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0149 A[ExcHandler: ClientProtocolException (r0v1 'e' org.apache.http.client.ClientProtocolException A[CUSTOM_DECLARE]), Splitter:B:17:0x004a] */
    public String doInBackground(String... params) {
        Log.d(LSM_DEBUG_TAG, "ConversionTracker.doConversion");
        File installationCookieFile = new File(this.context.getFilesDir(), INSTALLATION);
        if (installationCookieFile.exists()) {
            Log.i(LSM_DEBUG_TAG, "The conversion tracking cookie file already exist. Exit.");
            return RESULT_OK;
        }
        String referrerStr = null;
        if (params != null && params.length > 0) {
            referrerStr = params[0];
        }
        if (!validateReferrer(referrerStr)) {
            String referrerStrLogs = getReferrerFromLogs();
            if (validateReferrer(referrerStrLogs)) {
                referrerStr = referrerStrLogs;
            }
        }
        String uriStr = LSM_CONVERSION_URL;
        if (referrerStr == null || referrerStr.length() <= 0) {
            Log.w(LSM_DEBUG_TAG, "The referrer string is empty");
        } else {
            try {
                uriStr = (uriStr + "?package=" + URLEncoder.encode(this.context.getPackageName(), "UTF-8")) + "&referrer=" + URLEncoder.encode(referrerStr, "UTF-8");
                HttpClient httpClient = new DefaultHttpClient();
                HttpGet httpGet = new HttpGet();
                httpGet.setURI(new URI(uriStr));
                Log.d(LSM_DEBUG_TAG, "Request URL: " + uriStr);
                HttpResponse httpResponse = httpClient.execute(httpGet);
                String httpResponseStatus = "Response HTTP Code: " + httpResponse.getStatusLine().getStatusCode() + ", Message: " + httpResponse.getStatusLine().getReasonPhrase();
                if (httpResponse.getStatusLine().getStatusCode() != 200) {
                    Log.e(LSM_DEBUG_TAG, httpResponseStatus);
                } else {
                    Log.d(LSM_DEBUG_TAG, httpResponseStatus);
                }
                if (httpResponse != null) {
                    if (httpResponse.getStatusLine() != null && httpResponse.getStatusLine().getStatusCode() == 200) {
                        writeInstallationFile(installationCookieFile);
                        Log.i(LSM_DEBUG_TAG, "The conversion cookie file has been created");
                    }
                }
                return RESULT_OK;
            } catch (UnsupportedEncodingException e) {
            } catch (URISyntaxException e2) {
            } catch (ClientProtocolException e3) {
            } catch (IOException e4) {
                Log.e(LSM_DEBUG_TAG, "IOException", e4);
            }
        }
        return RESULT_ERROR;
    }

    private boolean validateReferrer(String referrerStr) {
        if (referrerStr != null && Pattern.compile("(lsm=\\[.*\\])|(lsm%(25)*3D%(25)*5B.*%(25)*5D)", 2).matcher(referrerStr).find()) {
            return true;
        }
        Log.i(LSM_DEBUG_TAG, "VALIDATOR: The referrer string '" + referrerStr + "' is invalid");
        return false;
    }

    private String getReferrerFromLogs() {
        String[] commandLine = {"logcat", "-d", "ActivityManager:I"};
        String lastReferrer = null;
        Pattern pattern = Pattern.compile("(?:act=android.intent.action.VIEW).*(?:http://market.android.com/details|market://details).*(?:id=" + this.context.getPackageName() + ")" + ".*" + "referrer=([^&\\s]+)", 2);
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(commandLine).getInputStream()));
            while (true) {
                String line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    lastReferrer = matcher.group(1);
                }
            }
        } catch (IOException e) {
        }
        Log.i(LSM_DEBUG_TAG, "Last referrer: " + lastReferrer);
        return lastReferrer;
    }

    private static void writeInstallationFile(File installation) throws IOException {
        FileOutputStream out = new FileOutputStream(installation);
        out.write(UUID.randomUUID().toString().getBytes());
        out.close();
    }
}
