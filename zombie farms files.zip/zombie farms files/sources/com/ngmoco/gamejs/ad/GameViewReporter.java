package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.telephony.TelephonyManager;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;

public final class GameViewReporter extends AsyncTrackingReporter implements LaunchReporter {
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
        this.appId = context.getString(R.string._GameViewAppId);
        this.uniqueId = getDeviceId(context);
        this.postUrl = String.format("http://gameviewoffers.appspot.com/rtrack_direct?udid=%s&offer_id=%s", this.uniqueId, this.appId);
    }

    public boolean isEnabled() {
        return this.appId.length() != 0;
    }

    private String getDeviceId(Context context) {
        String telephonyId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        return telephonyId == null ? ASConstants.kEmptyString : telephonyId;
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        sendTracking();
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }
}
