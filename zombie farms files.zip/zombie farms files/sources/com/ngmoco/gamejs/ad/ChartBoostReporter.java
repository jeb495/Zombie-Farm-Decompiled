package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.os.Looper;
import com.chartboost.sdk.ChartBoost;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;

public final class ChartBoostReporter implements Advertiser, LaunchReporter {
    String appId;
    String appSignature;

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        Log.d(getClass().getSimpleName(), "sending ChartBoost ping");
        final ChartBoost chartBoost = ChartBoost.getSharedChartBoost();
        chartBoost.setContext(context);
        chartBoost.setAppId(this.appId);
        chartBoost.setAppSignature(this.appSignature);
        new Thread() {
            /* class com.ngmoco.gamejs.ad.ChartBoostReporter.AnonymousClass1 */

            public void run() {
                Looper.prepare();
                chartBoost.install();
                Log.d(getClass().getSimpleName(), "done ChartBoost ping");
            }
        }.start();
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = context.getString(R.string._ad_ChartBoostAppId);
        this.appSignature = context.getString(R.string._ad_ChartBoostAppSignature);
    }
}
