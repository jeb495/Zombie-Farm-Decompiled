package com.ngmoco.gamejs.ad;

import android.content.Context;

public interface SessionReporter extends Advertiser {
    void sendEvent(String str);

    void start(Context context);

    void stop(Context context);
}
