package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.g6pay.sdk.G6Pay;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;

public final class G6PayReporter implements Advertiser, LaunchReporter {
    String appId;
    String secretKey;

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = context.getString(R.string._G6PayAppId);
        this.secretKey = context.getString(R.string._G6PaySecret);
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        Log.d(getClass().getName(), "sending a request to G6Pay");
        G6Pay.getG6PayInstance(context.getApplicationContext(), this.appId, this.secretKey).installConfirm();
    }
}
