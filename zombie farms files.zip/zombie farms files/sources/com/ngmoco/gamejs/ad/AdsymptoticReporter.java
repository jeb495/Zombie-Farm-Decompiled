package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.os.Looper;
import com.android.adsymp.core.ASConstants;
import com.android.adsymp.data.ASConversionTracking;

public final class AdsymptoticReporter implements Advertiser, LaunchReporter {
    private static final String PARTNER_ID = "10054";
    private static final String PARTNER_SIGN = "f97bc60d8d363af3213703ac2a8c983d";

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(final Context context) {
        final ASConversionTracking convTracking = new ASConversionTracking();
        convTracking.addPostDataWithKey(ASConstants.kASPostFieldPublisherId, PARTNER_ID);
        convTracking.addPostDataWithKey(ASConstants.kASPostFieldPublisherSignature, PARTNER_SIGN);
        convTracking.addPostDataWithKey(ASConstants.kASPostFieldAppId, context.getPackageName());
        new Thread() {
            /* class com.ngmoco.gamejs.ad.AdsymptoticReporter.AnonymousClass1 */

            public void run() {
                Looper.prepare();
                convTracking.post(context);
            }
        }.start();
    }
}
