package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.android.adsymp.core.ASConstants;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class MojivaReporter extends AsyncTrackingReporter implements LaunchReporter {
    private static final String advertiserId = "31352";
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.appId = context.getPackageName();
        this.uniqueId = getDeviceId(context);
        this.postUrl = String.format("http://www.mojiva.com/appconversion.php?udid=%s&advertiser_id=%s&group_code=%s", this.uniqueId, advertiserId, this.appId);
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }

    public String getDeviceId(Context context) {
        String androidId = getAndroidId(context);
        if (androidId == null) {
            return ASConstants.kEmptyString;
        }
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.reset();
            try {
                String udid = new BigInteger(1, md.digest(androidId.getBytes("UTF-8"))).toString(16);
                while (udid.length() < 32) {
                    udid = "0" + udid;
                }
                return udid;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return ASConstants.kEmptyString;
            }
        } catch (NoSuchAlgorithmException e2) {
            e2.printStackTrace();
            return ASConstants.kEmptyString;
        }
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        if (getAndroidId(context) != null) {
            sendTracking();
        }
    }
}
