package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import com.ngmoco.gamejs.Log;
import com.tapjoy.TapjoyConstants;
import java.util.Observable;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public abstract class AsyncTrackingReporter extends Observable implements Advertiser {
    private static String mUniqueID;
    private Thread makePostBack = new Thread() {
        /* class com.ngmoco.gamejs.ad.AsyncTrackingReporter.AnonymousClass1 */

        public void run() {
            try {
                HttpResponse response = new DefaultHttpClient().execute(new HttpGet(AsyncTrackingReporter.this.postUrl));
                AsyncTrackingReporter.this.setChanged();
                AsyncTrackingReporter.this.notifyObservers(response);
            } catch (Exception e) {
                Log.w(getClass().getName(), "download tracking failed for url: " + AsyncTrackingReporter.this.postUrl + ", error:" + e);
                AsyncTrackingReporter.this.setChanged();
                AsyncTrackingReporter.this.notifyObservers(e);
            }
        }
    };
    protected String postUrl;
    protected String uniqueId;

    public abstract String getAppId();

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        this.uniqueId = getDefaultUniqueId(context);
    }

    public synchronized String getDefaultUniqueId(Context context) {
        if (mUniqueID == null) {
            String telephonyId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
            if (telephonyId == null) {
                telephonyId = getAndroidId(context);
            }
            mUniqueID = telephonyId;
        }
        return mUniqueID;
    }

    public String getUniqueId() {
        return this.uniqueId;
    }

    public String getAndroidId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
    }

    public String getPostUrl() {
        return this.postUrl;
    }

    public void sendTracking() {
        Log.d(getClass().getName(), "send tracking with url:" + this.postUrl);
        this.makePostBack.start();
    }
}
