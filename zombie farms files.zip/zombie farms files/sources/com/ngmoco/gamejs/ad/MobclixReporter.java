package com.ngmoco.gamejs.ad;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

public final class MobclixReporter implements Advertiser, InstallReporter {
    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(final Context context, final Intent intent) {
        if (context instanceof Activity) {
            ((Activity) context).runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.ad.MobclixReporter.AnonymousClass1 */

                public void run() {
                    try {
                        new MobclixReceiver().onReceive(context, intent);
                    } catch (Throwable t) {
                        t.printStackTrace();
                    }
                }
            });
        } else {
            new MobclixReceiver().onReceive(context, intent);
        }
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
