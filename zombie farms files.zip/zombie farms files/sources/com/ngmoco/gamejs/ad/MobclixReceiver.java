package com.ngmoco.gamejs.ad;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import com.android.adsymp.core.ASConstants;
import com.tapjoy.TapjoyConstants;
import java.net.URLEncoder;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/* compiled from: MobclixReporter */
class MobclixReceiver extends BroadcastReceiver {
    public String androidId = "0";
    public String deviceId = "0";
    private Thread makePostBack = new Thread() {
        /* class com.ngmoco.gamejs.ad.MobclixReceiver.AnonymousClass1 */

        public void run() {
            try {
                new DefaultHttpClient().execute(new HttpGet(MobclixReceiver.this.postBackUrl));
            } catch (Exception e) {
            }
        }
    };
    public String postBackUrl = ASConstants.kEmptyString;

    MobclixReceiver() {
    }

    public void onReceive(Context context, Intent intent) {
        String referrer;
        String packageName;
        try {
            referrer = intent.getStringExtra("referrer");
            if (referrer == null || referrer == ASConstants.kEmptyString) {
                referrer = "null_referrer_found";
            }
        } catch (Exception e) {
            referrer = "exception_found_retrieving_referrer";
        }
        try {
            this.deviceId = ((TelephonyManager) context.getSystemService("phone")).getDeviceId();
        } catch (Exception e2) {
            this.deviceId = "0";
        }
        try {
            this.androidId = Settings.Secure.getString(context.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        } catch (Exception e3) {
            this.androidId = "0";
        }
        Package packageObj = getClass().getPackage();
        if (packageObj == null) {
            packageName = "null_package";
        } else {
            packageName = packageObj.getName();
        }
        this.postBackUrl = "http://track-m.mobclix.com/ads/receiver.php?referrer=" + URLEncoder.encode(referrer) + "&package=" + URLEncoder.encode(packageName) + "&deviceid=" + URLEncoder.encode(this.deviceId) + "&androidid=" + URLEncoder.encode(this.androidId);
        this.makePostBack.start();
    }
}
