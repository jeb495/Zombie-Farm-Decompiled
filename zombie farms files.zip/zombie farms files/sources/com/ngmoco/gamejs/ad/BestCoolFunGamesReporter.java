package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.bestcoolfungames.adsclient.BCFGAds;

public final class BestCoolFunGamesReporter implements Advertiser, LaunchReporter {
    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        BCFGAds.registerInstall(context.getApplicationContext());
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
