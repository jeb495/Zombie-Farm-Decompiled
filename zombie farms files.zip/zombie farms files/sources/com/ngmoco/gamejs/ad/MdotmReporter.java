package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import com.android.adsymp.core.ASConstants;
import java.net.URLEncoder;

public final class MdotmReporter extends AsyncTrackingReporter implements InstallReporter {
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }

    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(Context context, Intent intent) {
        String referrer = intent.hasExtra("referrer") ? intent.getStringExtra("referrer") : null;
        if (referrer == null) {
            referrer = "exception_found_retrieving_referrer";
        }
        this.appId = URLEncoder.encode(context.getPackageName());
        if (referrer == null || referrer == ASConstants.kEmptyString) {
            referrer = "null_referrer_found";
        }
        this.postUrl = "http://ads.mdotm.com/ads/receiver.php?referrer=" + URLEncoder.encode(referrer) + "&package=" + this.appId + "&deviceid=" + URLEncoder.encode(this.uniqueId) + "&androidid=" + URLEncoder.encode(getAndroidId(context));
        sendTracking();
    }
}
