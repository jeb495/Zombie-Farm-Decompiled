package com.ngmoco.gamejs.ad;

import android.content.Context;

public interface LaunchReporter extends Advertiser {
    void sendTrackingOnLaunch(Context context);
}
