package com.ngmoco.gamejs.ad;

import android.content.Context;
import com.millennialmedia.android.MMAdView;
import com.mobage.ww.a465.zombiefarm_android.R;

public final class MillennialReporter implements LaunchReporter {
    private String appId;

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        String appIdInResource = context.getString(R.string._MillenialAppId);
        if (appIdInResource == null) {
            appIdInResource = "17330";
        }
        this.appId = appIdInResource;
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        MMAdView.startConversionTrackerWithGoalId(context, this.appId);
    }
}
