package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import com.fiksu.asotracking.InstallTracking;

public final class FiksuReporter implements Advertiser, InstallReporter {
    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(Context context, Intent intent) {
        new InstallTracking().onReceive(context, intent);
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
