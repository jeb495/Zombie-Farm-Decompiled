package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.Commands;
import com.sponsorpay.sdk.android.advertiser.SponsorPayAdvertiser;

public final class SponsorPayReporter implements Advertiser, LaunchReporter {
    private static final String keyName = "SPONSORPAY_APP_ID";

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        SponsorPayAdvertiser.register(context.getApplicationContext());
    }

    public static boolean isEnabled(Context context) {
        PackageManager manager = context.getPackageManager();
        if (manager == null) {
            return false;
        }
        try {
            ApplicationInfo info = manager.getApplicationInfo(context.getPackageName(), Commands.CommandIDs.setVisibleInOrientations);
            if (info == null || info.metaData == null) {
                return false;
            }
            int appIdInt = info.metaData.getInt(keyName);
            String appId = appIdInt > 0 ? ASConstants.kEmptyString + appIdInt : info.metaData.getString(keyName);
            if (appId == null || appId.trim().equalsIgnoreCase(ASConstants.kEmptyString)) {
                return false;
            }
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("SponsorPayReporter", "Can't find android manifest file");
            return false;
        }
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
