package com.ngmoco.gamejs.ad;

import android.app.Activity;
import android.content.Context;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import com.LeadboltAdvertiser.LBTracker;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;

public final class LeadboltReporter implements Advertiser, LaunchReporter {
    private String trackId;
    private String trackSecretKey;

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        Activity activity = (Activity) context;
        if (activity == null) {
            Log.e(getClass().getSimpleName(), "cannot cast to Activity from this context");
            return;
        }
        setCredentialByLocation(context, context.getString(R.string._ad_LeadBoltIntAppId), context.getString(R.string._ad_LeadBoltIntSecret), context.getString(R.string._ad_LeadBoltUSAppId), context.getString(R.string._ad_LeadBoltUSSecret));
        new LBTracker(activity, this.trackId, this.trackSecretKey).loadTracker();
    }

    /* access modifiers changed from: package-private */
    public void setCredentialByLocation(Context context, String trackIdInt, String trackSecretKeyInt, String trackIdUS, String trackSecretKeyUS) {
        String countryCode = ASConstants.kEmptyString;
        try {
            Location last = ((LocationManager) context.getSystemService("location")).getLastKnownLocation("network");
            countryCode = new Geocoder(context.getApplicationContext()).getFromLocation(last.getLatitude(), last.getLongitude(), 1).get(0).getCountryCode();
        } catch (Exception e) {
        }
        if (countryCode.equals("US")) {
            Log.d(getClass().getSimpleName(), "we are in the USA");
            this.trackId = trackIdUS;
            this.trackSecretKey = trackSecretKeyUS;
            return;
        }
        Log.d(getClass().getSimpleName(), "we are the international citizens");
        this.trackId = trackIdInt;
        this.trackSecretKey = trackSecretKeyInt;
    }
}
