package com.ngmoco.gamejs.ad;

import android.content.Context;

public final class AdfonicReporter extends AsyncTrackingReporter implements LaunchReporter {
    String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
        this.appId = context.getApplicationContext().getPackageName();
        this.postUrl = String.format("http://adfonic.net/is/%s/%s", this.appId, getAndroidId(context));
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        sendTracking();
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }
}
