package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;

public interface InstallReporter extends Advertiser {
    void sendTrackingOnInstall(Context context, Intent intent);
}
