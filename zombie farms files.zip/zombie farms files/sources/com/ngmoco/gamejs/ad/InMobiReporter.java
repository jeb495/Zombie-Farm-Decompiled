package com.ngmoco.gamejs.ad;

import android.content.Context;
import android.content.Intent;
import java.util.Observable;

public final class InMobiReporter extends Observable implements Advertiser, InstallReporter {
    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(final Context context, Intent intent) {
        new Thread() {
            /* class com.ngmoco.gamejs.ad.InMobiReporter.AnonymousClass1 */

            public void run() {
                boolean response = new InMobiAndroidTrackerHTTPRequest(context, "4028cb9730567f6d01306cce9be407c8").setupConnection();
                InMobiReporter.this.setChanged();
                InMobiReporter.this.notifyObservers(Boolean.valueOf(response));
            }
        }.start();
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
