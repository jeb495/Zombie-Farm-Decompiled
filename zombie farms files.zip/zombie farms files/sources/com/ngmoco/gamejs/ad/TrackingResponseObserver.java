package com.ngmoco.gamejs.ad;

import com.ngmoco.gamejs.Log;
import java.util.Observable;
import java.util.Observer;
import org.apache.http.HttpResponse;
import org.apache.http.impl.client.BasicResponseHandler;

public class TrackingResponseObserver implements Observer {
    private Exception exception = null;
    private HttpResponse response = null;
    private final int timeout = 5;

    public void update(Observable observable, Object data) {
        try {
            this.response = (HttpResponse) data;
        } catch (ClassCastException e) {
            try {
                this.exception = (Exception) data;
            } catch (ClassCastException e2) {
            }
        }
    }

    public boolean waitForResponse() {
        InterruptedException e;
        int count = 0;
        while (!didFinished()) {
            try {
                count++;
                if (count > 50) {
                    return false;
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e2) {
                    e = e2;
                    Log.e(getClass().getSimpleName(), e.getMessage());
                    return false;
                }
            } catch (InterruptedException e3) {
                e = e3;
                Log.e(getClass().getSimpleName(), e.getMessage());
                return false;
            }
        }
        return true;
    }

    private boolean didFinished() {
        return (this.response == null && this.exception == null) ? false : true;
    }

    public String getResult() {
        if (this.response == null) {
            return null;
        }
        try {
            return new BasicResponseHandler().handleResponse(this.response);
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public HttpResponse getResponse() {
        return this.response;
    }

    public Exception getException() {
        return this.exception;
    }
}
