package com.ngmoco.gamejs.ad;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

public final class LifeStreetReporter implements Advertiser, InstallReporter {
    @Override // com.ngmoco.gamejs.ad.InstallReporter
    public void sendTrackingOnInstall(final Context context, final Intent intent) {
        if (intent.hasExtra("referrer")) {
            if (context instanceof Activity) {
                ((Activity) context).runOnUiThread(new Runnable() {
                    /* class com.ngmoco.gamejs.ad.LifeStreetReporter.AnonymousClass1 */

                    public void run() {
                        try {
                            new LifeStreetConversionTracker(context).execute(intent.getStringExtra("referrer"));
                        } catch (Throwable t) {
                            t.printStackTrace();
                        }
                    }
                });
                return;
            }
            new LifeStreetConversionTracker(context).execute(intent.getStringExtra("referrer"));
        }
    }

    @Override // com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
    }
}
