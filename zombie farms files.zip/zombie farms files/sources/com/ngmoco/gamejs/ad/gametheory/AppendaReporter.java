package com.ngmoco.gamejs.ad.gametheory;

import android.content.Context;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.ad.AsyncTrackingReporter;
import com.ngmoco.gamejs.ad.LaunchReporter;

public final class AppendaReporter extends AsyncTrackingReporter implements LaunchReporter {
    private String appId;

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter, com.ngmoco.gamejs.ad.Advertiser
    public void configure(Context context) {
        super.configure(context);
        this.appId = context.getString(R.string._ad_GameTheory_AppendaAppId);
        this.postUrl = "http://appenda.com/notify/pb.php?did=" + getDefaultUniqueId(context) + "&oid=" + this.appId;
    }

    @Override // com.ngmoco.gamejs.ad.AsyncTrackingReporter
    public String getAppId() {
        return this.appId;
    }

    @Override // com.ngmoco.gamejs.ad.LaunchReporter
    public void sendTrackingOnLaunch(Context context) {
        sendTracking();
    }
}
