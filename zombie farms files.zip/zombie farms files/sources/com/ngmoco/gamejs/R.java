package com.ngmoco.gamejs;

public final class R {

    public static final class anim {
        public static final int slide_in_right = 2130968576;
        public static final int slide_out_left = 2130968577;
    }

    public static final class attr {
    }

    public static final class drawable {
        public static final int blank = 2130837504;
        public static final int firstframe = 2130837505;
        public static final int gamesplash = 2130837506;
        public static final int icon = 2130837507;
        public static final int largeicon = 2130837508;
        public static final int lp_dialog_background = 2130837509;
        public static final int mobicon = 2130837510;
    }

    public static final class id {
        public static final int BootProgress = 2131099649;
        public static final int BootProgressArea = 2131099651;
        public static final int layout = 2131099656;
        public static final int notification_image = 2131099657;
        public static final int notification_text = 2131099660;
        public static final int notification_time = 2131099659;
        public static final int notification_title = 2131099658;
        public static final int rootLayout = 2131099648;
        public static final int splashbg = 2131099650;
        public static final int startup_progressbar = 2131099655;
        public static final int startup_spinner = 2131099654;
        public static final int startup_text = 2131099652;
        public static final int startup_text_ellipsis = 2131099653;
        public static final int top_layout = 2131099661;
    }

    public static final class layout {
        public static final int jskit = 2130903040;
        public static final int notification_largeicon = 2130903041;
        public static final int notification_normal = 2130903042;
    }

    public static final class string {
        public static final int NgBootServer = 2131034114;
        public static final int NgIntentAction = 2131034118;
        public static final int NgStartingGame = 2131034113;
        public static final int NgStartingServer = 2131034112;
        public static final int _G6PayAppId = 2131034127;
        public static final int _G6PaySecret = 2131034128;
        public static final int _GameViewAppId = 2131034129;
        public static final int _GreystripeAppId = 2131034124;
        public static final int _InMobiAdvId = 2131034150;
        public static final int _InMobiAppId = 2131034151;
        public static final int _MdotMAdvId = 2131034148;
        public static final int _MdotMAppId = 2131034149;
        public static final int _MillenialAppId = 2131034123;
        public static final int _PlayhavenAppId = 2131034146;
        public static final int _PlayhavenSecret = 2131034147;
        public static final int _SponsorPayAppId = 2131034153;
        public static final int _TapjoyAppId = 2131034125;
        public static final int _TapjoySecret = 2131034126;
        public static final int _ad_AppRedeemAppId = 2131034160;
        public static final int _ad_AppRedeemAppSecretA = 2131034161;
        public static final int _ad_AppRedeemAppSecretB = 2131034162;
        public static final int _ad_AppRedeemAppSecretC = 2131034163;
        public static final int _ad_AppRedeemAppSecretD = 2131034164;
        public static final int _ad_ChartBoostAppId = 2131034154;
        public static final int _ad_ChartBoostAppSignature = 2131034155;
        public static final int _ad_FlurryAppId = 2131034137;
        public static final int _ad_GameTheory_AppendaAppId = 2131034144;
        public static final int _ad_GameTheory_OfferLabsAppId = 2131034145;
        public static final int _ad_LeadBoltIntAppId = 2131034156;
        public static final int _ad_LeadBoltIntSecret = 2131034157;
        public static final int _ad_LeadBoltUSAppId = 2131034158;
        public static final int _ad_LeadBoltUSSecret = 2131034159;
        public static final int _ad_W3iAppId = 2131034138;
        public static final int _ad_use_Adfonic = 2131034136;
        public static final int _ad_use_Admob = 2131034134;
        public static final int _ad_use_Adsymptotic = 2131034140;
        public static final int _ad_use_BestCoolFunGames = 2131034141;
        public static final int _ad_use_Fiksu = 2131034142;
        public static final int _ad_use_GoogleAnalytics = 2131034135;
        public static final int _ad_use_InMobi = 2131034133;
        public static final int _ad_use_JumpTap = 2131034131;
        public static final int _ad_use_LifeStreet = 2131034139;
        public static final int _ad_use_MdotM = 2131034130;
        public static final int _ad_use_Mobclix = 2131034143;
        public static final int _ad_use_Mojiva = 2131034132;
        public static final int _ad_use_TapIt = 2131034152;
        public static final int _appidKey = 2131034122;
        public static final int _gameKey = 2131034120;
        public static final int _serverKey = 2131034121;
        public static final int c2dm_sender_id = 2131034203;
        public static final int can_not_download_msg = 2131034187;
        public static final int distribution_name = 2131034169;
        public static final int download_complete_msg = 2131034183;
        public static final int download_failed_msg = 2131034184;
        public static final int downloading_wait_msg = 2131034182;
        public static final int edit_text_done = 2131034192;
        public static final int edit_text_go = 2131034194;
        public static final int edit_text_next = 2131034193;
        public static final int edit_text_return = 2131034191;
        public static final int edit_text_search = 2131034197;
        public static final int edit_text_send = 2131034195;
        public static final int edit_text_submit = 2131034196;
        public static final int err_dialog_default_msg_format = 2131034171;
        public static final int err_dialog_dismiss_button = 2131034170;
        public static final int gameDirectory = 2131034168;
        public static final int gamejs_name = 2131034166;
        public static final int google_maps_api_key = 2131034190;
        public static final int initialization_text = 2131034188;
        public static final int initialization_text_lastchar = 2131034189;
        public static final int jsLog = 2131034116;
        public static final int mobage = 2131034174;
        public static final int nativeLog = 2131034115;
        public static final int network_failure_msg = 2131034185;
        public static final int notification_title = 2131034167;
        public static final int please_update_msg = 2131034201;
        public static final int preparing_format = 2131034202;
        public static final int productName = 2131034119;
        public static final int progress_dialog_msg = 2131034173;
        public static final int progress_dialog_title = 2131034172;
        public static final int resume_text = 2131034198;
        public static final int resume_text_lastchar = 2131034199;
        public static final int sd_card_full_dialog_message = 2131034181;
        public static final int timingLog = 2131034117;
        public static final int unable_to_load_msg = 2131034200;
        public static final int update_get = 2131034177;
        public static final int update_message = 2131034176;
        public static final int update_quit = 2131034178;
        public static final int update_title = 2131034175;
        public static final int usb_not_present_dialog_msg = 2131034180;
        public static final int usb_not_ready_dialog_msg = 2131034179;
        public static final int useOpenSL = 2131034165;
        public static final int working_connection_msg = 2131034186;
    }

    public static final class style {
        public static final int LoadProgressDialog = 2131165185;
        public static final int LoadProgressDialogAnimation = 2131165187;
        public static final int LoadProgressDialog_Text = 2131165186;
        public static final int NewDialog = 2131165184;
        public static final int Theme_CoreSplash = 2131165189;
        public static final int Theme_NoBackground = 2131165188;
    }
}
