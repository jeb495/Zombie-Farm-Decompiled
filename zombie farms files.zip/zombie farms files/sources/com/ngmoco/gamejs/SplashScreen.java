package com.ngmoco.gamejs;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.activity.JSActivity;
import com.ngmoco.gamejs.ui.JSWindowLayerAdapter;
import com.ngmoco.gamejs.ui.RelativeLayoutForSplash;
import com.ngmoco.gamejs.ui.widgets.UIImageDrawable;
import com.ngmoco.gamejs.ui.widgets.UILayout;
import com.ngmoco.gamejs.ui.widgets.UIProgressBar;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class SplashScreen implements MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener {
    private static final String TAG = "SplashScreen";
    private static final String VIDEO_DIRECTORY = "splashvideos";
    static int currentResourceId = 0;
    private static boolean sGameIsStarting = false;
    private static SplashScreen sInstance;
    private static boolean sPrivIsStarting = false;
    private JSActivity mActivity;
    private TextView mEllipsisText;
    private View mFirstFrame;
    private boolean mIsMobage;
    private int mKeepSplashOnScreen = 0;
    private UIProgressBar mProgress;
    private ProgressBar mProgressBar;
    private ViewGroup mProgressGroup;
    private ProgressBar mProgressSpinner;
    private View mSplashBackground;
    private ViewGroup mSplashRoot;
    private RelativeLayoutForSplash mSplashVideoGroup;
    private TextView mStartupText;
    private VideoView mVideoView;

    private SplashScreen() {
    }

    private static SplashScreen getInstance() {
        if (sInstance == null) {
            sInstance = new SplashScreen();
        }
        return sInstance;
    }

    public static void start(JSActivity jsActivity, boolean isMobage) {
        SplashScreen instance = getInstance();
        instance.configure(jsActivity, isMobage);
        new JSWindowLayerAdapter.SplashWrapper(instance.mSplashRoot);
        instance.configureBackground();
    }

    public static void procWillStart(int procId) {
        if (procId == -1) {
            if (sInstance != null) {
                sInstance.mKeepSplashOnScreen = 0;
            }
            sPrivIsStarting = true;
            return;
        }
        sGameIsStarting = true;
    }

    public static void procDidStart(int procId) {
        if (procId == -1 && sPrivIsStarting) {
            sPrivIsStarting = false;
        } else if (procId == -2 && sGameIsStarting) {
            sGameIsStarting = false;
        } else {
            return;
        }
        if (sInstance != null) {
            sInstance.removeIfUnused();
        }
    }

    public static void setProgressText(String text) {
        getInstance()._setProgressText(text);
    }

    public static void setProgressDoneBooting() {
    }

    public static Bitmap getMobageIconBitmap() {
        return BitmapFactory.decodeResource(getInstance().mActivity.getResources(), R.drawable.mobicon);
    }

    public static void setSplashVisible(boolean visible) {
        if (visible) {
            if (sInstance != null) {
                sInstance.mKeepSplashOnScreen++;
            }
            getInstance()._show();
        } else if (sInstance != null) {
            SplashScreen splashScreen = sInstance;
            splashScreen.mKeepSplashOnScreen--;
            if (sInstance.mKeepSplashOnScreen <= 0) {
                sInstance.mKeepSplashOnScreen = 0;
                procDidStart(-1);
                sInstance.removeIfUnused();
            }
        }
    }

    public static void setUpdateProgress(float progress) {
        getInstance()._setUpdateProgress(progress);
    }

    public static void setUpdateProgressVisible(boolean visible) {
        getInstance()._setUpdateProgressVisible(visible);
    }

    public static void setUpdateProgressBounds(int x, int y, int w, int h) {
        getInstance()._setUpdateProgressBounds(x, y, w, h);
    }

    public static VideoView getVideoView() {
        if (sInstance != null) {
            return sInstance.mVideoView;
        }
        return null;
    }

    public static void onResume() {
        getInstance().configureBackground();
    }

    public static void setUpdateProgressBar(UIProgressBar bar, boolean use) {
        getInstance()._setUpdateProgressBar(bar, use);
    }

    public static void showForGLResume() {
        setUpdateProgress(-1.0f);
        getInstance().configureBackground();
        sGameIsStarting = true;
        getInstance()._show();
    }

    public void onCompletion(MediaPlayer mp) {
        removeVideo();
    }

    public void onPrepared(MediaPlayer mp) {
        if (this.mVideoView != null) {
            this.mVideoView.start();
            removeFirstFrame(false);
        }
    }

    public boolean onError(MediaPlayer mp, int what, int extra) {
        removeFirstFrame(true);
        removeVideo();
        return true;
    }

    private void configure(JSActivity activity, boolean isMobage) {
        this.mActivity = activity;
        this.mIsMobage = isMobage;
        this.mSplashRoot = (ViewGroup) activity.findViewById(R.id.BootProgress);
        this.mSplashRoot = (ViewGroup) activity.findViewById(R.id.BootProgress);
        this.mProgressGroup = (ViewGroup) activity.findViewById(R.id.BootProgressArea);
        this.mProgressSpinner = (ProgressBar) activity.findViewById(R.id.startup_spinner);
        this.mProgressBar = (ProgressBar) activity.findViewById(R.id.startup_progressbar);
        this.mSplashBackground = activity.findViewById(R.id.splashbg);
        this.mStartupText = (TextView) this.mActivity.findViewById(R.id.startup_text);
        this.mEllipsisText = (TextView) this.mActivity.findViewById(R.id.startup_text_ellipsis);
    }

    private int configureBackground() {
        int id;
        String action = this.mActivity.getIntent().getAction();
        int resId = R.drawable.firstframe;
        if (!this.mIsMobage && action != null && ((action.contentEquals("android.intent.action.MAIN") || action.endsWith("PLAY")) && (id = this.mActivity.getResources().getIdentifier("gamesplash", "drawable", this.mActivity.getPackageName())) != 0)) {
            resId = id;
        }
        _useSplashResource(resId);
        return resId;
    }

    private void _setProgressText(final String text) {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass1 */

            public void run() {
                if (SplashScreen.this.mEllipsisText != null) {
                    if (SplashScreen.this.mStartupText != null) {
                        SplashScreen.this.crossFade(SplashScreen.this.mStartupText, text.substring(0, text.length() - 1));
                    }
                    SplashScreen.this.crossFade(SplashScreen.this.mEllipsisText, text.substring(text.length() - 1));
                } else if (SplashScreen.this.mStartupText != null) {
                    SplashScreen.this.crossFade(SplashScreen.this.mStartupText, text);
                }
            }
        });
    }

    private void _show() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass2 */

            public void run() {
                if (SplashScreen.this.mSplashRoot.getParent() == null) {
                    if (Build.VERSION.SDK_INT < 8) {
                        SplashScreen.this._recreateSpinner();
                    }
                    SplashScreen.this.mActivity.getRootLayout().addView(SplashScreen.this.mSplashRoot);
                }
            }
        });
    }

    /* JADX WARN: Type inference failed for: r2v3, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Unknown variable types count: 1 */
    private void _recreateSpinner() {
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(3, R.id.startup_text);
        layoutParams.addRule(14, 1);
        this.mProgressGroup.removeView(this.mProgressSpinner);
        this.mProgressSpinner = new ProgressBar(this.mActivity, null, 16842873);
        this.mProgressSpinner.setId(R.id.startup_spinner);
        this.mProgressGroup.addView(this.mProgressSpinner, layoutParams);
    }

    private void _setUpdateProgress(float progress) {
        boolean z;
        int i;
        int i2 = 4;
        boolean z2 = true;
        if (this.mProgressBar != null || this.mProgress != null) {
            boolean indeterminate = progress < 0.0f;
            try {
                if (this.mProgress != null && !indeterminate) {
                    this.mProgress.setValue(progress);
                }
                if (this.mProgressSpinner.getVisibility() == 0) {
                    z = true;
                } else {
                    z = false;
                }
                if (indeterminate != z) {
                    ProgressBar progressBar = this.mProgressSpinner;
                    if (indeterminate) {
                        i = 0;
                    } else {
                        i = 4;
                    }
                    progressBar.setVisibility(i);
                }
                if (this.mProgressBar != null) {
                    if (!indeterminate) {
                        this.mProgressBar.setProgress((int) (((float) this.mProgressBar.getMax()) * progress));
                    }
                    if (this.mProgressBar.getVisibility() != 4) {
                        z2 = false;
                    }
                    if (indeterminate != z2) {
                        ProgressBar progressBar2 = this.mProgressBar;
                        if (!indeterminate) {
                            i2 = 0;
                        }
                        progressBar2.setVisibility(i2);
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "failed in setting progress: " + e.getMessage());
            }
        }
    }

    private void _setUpdateProgressBounds(int x, int y, int w, int h) {
        if (this.mProgress != null) {
            try {
                this.mProgress.setOrigin(x, y);
                this.mProgress.setSize(w, h);
            } catch (Exception e) {
                Log.e(TAG, "failed in setting progress: " + e.getMessage());
            }
        }
    }

    private void _setUpdateProgressVisible(boolean visible) {
        if (this.mProgressGroup != null) {
            try {
                if (visible == (this.mProgressGroup.getParent() == this.mSplashRoot)) {
                    return;
                }
                if (visible) {
                    AlphaAnimation inAnim = new AlphaAnimation(0.0f, 1.0f);
                    inAnim.setDuration(400);
                    this.mProgressGroup.setAnimation(inAnim);
                    this.mSplashRoot.addView(this.mProgressGroup);
                    inAnim.start();
                    return;
                }
                AlphaAnimation outAnim = new AlphaAnimation(1.0f, 0.0f);
                outAnim.setAnimationListener(new Animation.AnimationListener() {
                    /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass3 */

                    public void onAnimationStart(Animation animation) {
                    }

                    public void onAnimationRepeat(Animation animation) {
                    }

                    public void onAnimationEnd(Animation animation) {
                        SplashScreen.this.mSplashRoot.removeView(SplashScreen.this.mProgressGroup);
                    }
                });
                outAnim.setDuration(400);
                this.mProgressGroup.setAnimation(outAnim);
                outAnim.start();
            } catch (Exception e) {
                Log.e(TAG, "failed in setting progress: " + e.getMessage());
            }
        }
    }

    private void _useSplashResource(int resourceID) {
        if (this.mSplashBackground.getBackground() == null || currentResourceId != resourceID) {
            currentResourceId = resourceID;
            Drawable d = this.mActivity.getResources().getDrawable(resourceID);
            if (d instanceof NinePatchDrawable) {
                this.mActivity.getWindowManager().getDefaultDisplay().getMetrics(new DisplayMetrics());
                NinePatchDrawable ninePatchDrawable = (NinePatchDrawable) d;
                Log.d(TAG, "Got 9-patch drawable");
                this.mSplashBackground.setBackgroundDrawable(d);
            } else if (d instanceof BitmapDrawable) {
                Log.d(TAG, "Got bitmap drawable");
                UIImageDrawable newDrawable = new UIImageDrawable(this.mSplashBackground, null);
                newDrawable.setBitmapForState(0, ((BitmapDrawable) d).getBitmap());
                newDrawable.setFit(2);
                newDrawable.setGravity(0.5f, 0.1f);
                this.mSplashBackground.setBackgroundDrawable(newDrawable);
            }
            this.mSplashBackground.requestLayout();
        }
    }

    private void _setUpdateProgressBar(UIProgressBar bar, boolean use) {
        if (use) {
            this.mProgress = bar;
        } else if (this.mProgress == bar) {
            this.mProgress = null;
        }
        NgJNI.setHasCustomProgressBar(this.mProgress != null);
    }

    private void removeIfUnused() {
        if (!sPrivIsStarting && !sGameIsStarting && this.mKeepSplashOnScreen <= 0) {
            Log.d(TAG, "Removing Splash");
            this.mActivity.runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass4 */

                public void run() {
                    try {
                        UILayout rootLayout = SplashScreen.this.mActivity.getRootLayout();
                        if (SplashScreen.this.mSplashRoot.getParent() == rootLayout) {
                            JSWindowLayerAdapter.removeChild(SplashScreen.this.mSplashRoot);
                        }
                        rootLayout.removeView(SplashScreen.this.mProgress);
                        SplashScreen.this.mSplashBackground.setBackgroundDrawable(null);
                    } catch (Exception e) {
                    }
                }
            });
        }
    }

    /* JADX WARN: Type inference failed for: r3v4, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Unknown variable types count: 1 */
    private void crossFade(final TextView view, final String newText) {
        boolean skipOut;
        if (view.getVisibility() != 0 || this.mSplashRoot.getParent() == null) {
            view.setText(newText);
            return;
        }
        if (view.getText() == null || view.getText().length() == 0) {
            skipOut = true;
        } else {
            skipOut = false;
        }
        Animation outAnim = AnimationUtils.makeOutAnimation(this.mActivity, false);
        outAnim.setAnimationListener(new Animation.AnimationListener() {
            /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass5 */

            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }

            /* JADX WARN: Type inference failed for: r1v2, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
            /* JADX WARNING: Unknown variable types count: 1 */
            public void onAnimationEnd(Animation animation) {
                view.setText(newText);
                Animation inAnim = AnimationUtils.makeInAnimation(SplashScreen.this.mActivity, false);
                inAnim.setInterpolator(new DecelerateInterpolator());
                inAnim.setDuration(200);
                view.setAnimation(inAnim);
                inAnim.start();
            }
        });
        outAnim.setInterpolator(new AccelerateInterpolator());
        outAnim.setDuration(skipOut ? 0 : 200);
        outAnim.start();
        view.setAnimation(outAnim);
        view.invalidate();
    }

    /* JADX WARN: Type inference failed for: r8v8, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARN: Type inference failed for: r8v17, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARN: Type inference failed for: r8v20, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 3 */
    private void addVideoSplash() {
        int videoWidth;
        int videoHeight;
        DisplayMetrics metrics = new DisplayMetrics();
        this.mActivity.getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int screenSize = this.mActivity.getResources().getConfiguration().screenLayout;
        if ((screenSize & 15) == 4) {
            videoWidth = 640;
            videoHeight = 240;
        } else if ((screenSize & 15) == 3) {
            videoWidth = ASConstants.kASOverlayDefaultHeight;
            videoHeight = 180;
        } else if (metrics.densityDpi == 320) {
            videoWidth = 640;
            videoHeight = 240;
        } else if (metrics.densityDpi == 240) {
            videoWidth = ASConstants.kASOverlayDefaultHeight;
            videoHeight = 180;
        } else if (metrics.densityDpi == 160) {
            videoWidth = ASConstants.kASOverlayDefaultWidth;
            videoHeight = 180;
        } else if (metrics.densityDpi == 120) {
            videoWidth = 240;
            videoHeight = 180;
        } else {
            return;
        }
        String videoFileName = "video_" + videoWidth + ".mp4";
        if (copyVideoFileToSD(videoFileName)) {
            this.mVideoView = new VideoView(this.mActivity);
            this.mVideoView.setVideoPath(this.mActivity.getRepo() + "/" + VIDEO_DIRECTORY + "/" + videoFileName);
            RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(videoWidth, videoHeight);
            lp.addRule(13);
            this.mVideoView.setLayoutParams(lp);
            this.mVideoView.setDrawingCacheQuality(1048576);
            this.mVideoView.setOnCompletionListener(this);
            this.mVideoView.setOnPreparedListener(this);
            this.mVideoView.setOnErrorListener(this);
            this.mSplashVideoGroup = new RelativeLayoutForSplash(this.mActivity);
            this.mSplashVideoGroup.setBackgroundColor(-1);
            this.mSplashVideoGroup.addView(this.mVideoView);
            UILayout rootLayout = this.mActivity.getRootLayout();
            rootLayout.addView(this.mSplashVideoGroup, new ViewGroup.LayoutParams(-1, -1));
            this.mFirstFrame = new View(this.mActivity);
            this.mFirstFrame.setBackgroundResource(R.drawable.firstframe);
            rootLayout.addView(this.mFirstFrame);
        }
    }

    private boolean copyVideoFileToSD(String videoFileName) {
        if (new File(this.mActivity.getRepo() + "/" + VIDEO_DIRECTORY).mkdirs()) {
            try {
                new File(this.mActivity.getRepo() + "/.new").createNewFile();
            } catch (IOException e) {
            }
        }
        try {
            BufferedInputStream fis = new BufferedInputStream(this.mActivity.getAssets().open("splashvideos/" + videoFileName), 102400);
            try {
                BufferedOutputStream fos = new BufferedOutputStream(new FileOutputStream(new File(this.mActivity.getRepo() + "/" + VIDEO_DIRECTORY + "/" + videoFileName)), 102400);
                byte[] buffer = new byte[4096];
                while (true) {
                    try {
                        int numRead = fis.read(buffer, 0, 4096);
                        if (numRead == -1) {
                            fos.close();
                            fis.close();
                            return true;
                        }
                        fos.write(buffer, 0, numRead);
                    } catch (IOException e2) {
                        Log.e(TAG, "copying failed: " + e2.getMessage());
                        return false;
                    }
                }
            } catch (FileNotFoundException e3) {
                return false;
            }
        } catch (IOException e4) {
            return false;
        }
    }

    private void removeVideo() {
        this.mSplashVideoGroup.setVisibility(8);
        this.mActivity.getHandler().postDelayed(new Runnable() {
            /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass6 */

            public void run() {
                SplashScreen.this.mActivity.getRootLayout().removeView(SplashScreen.this.mSplashVideoGroup);
            }
        }, 1000);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void removeFirstFrame(boolean immediately) {
        final UILayout rootLayout = this.mActivity.getRootLayout();
        if (immediately) {
            rootLayout.removeView(this.mFirstFrame);
        } else if (this.mVideoView.getCurrentPosition() > 50) {
            this.mActivity.getHandler().postDelayed(new Runnable() {
                /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass7 */

                public void run() {
                    rootLayout.removeView(SplashScreen.this.mFirstFrame);
                }
            }, 100);
        } else {
            this.mActivity.getHandler().postDelayed(new Runnable() {
                /* class com.ngmoco.gamejs.SplashScreen.AnonymousClass8 */

                public void run() {
                    SplashScreen.this.removeFirstFrame(false);
                }
            }, 20);
        }
    }
}
