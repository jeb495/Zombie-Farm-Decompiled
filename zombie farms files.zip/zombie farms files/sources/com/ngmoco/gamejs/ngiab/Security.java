package com.ngmoco.gamejs.ngiab;

import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.iab.Security;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

public class Security extends com.ngmoco.gamejs.iab.Security {
    private static final String TAG = "ngiab.Security";
    private static Stack<Long> sUnusedNonces = new Stack<>();

    public static void setKnownNonces(HashSet<Long> nonces) {
        Iterator<Long> iter = nonces.iterator();
        while (iter.hasNext()) {
            sUnusedNonces.push(iter.next());
        }
    }

    private static void loadMoreNonces() {
        GameJSActivity.getActivity();
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.ngiab.Security.AnonymousClass1 */

            public void run() {
                NgJNI.onPurchaseEvent("morenonces", ASConstants.kEmptyString, ASConstants.kEmptyString);
            }
        });
    }

    public static long generateNonce() {
        if (sUnusedNonces.size() < 1) {
            Log.e(TAG, "Nonce pool has no available nonces");
            loadMoreNonces();
            return -1;
        }
        long nonce = sUnusedNonces.pop().longValue();
        addToKnownNonces(nonce);
        Log.d(TAG, "Nonce pool has " + sUnusedNonces.size() + " nonces");
        if (sUnusedNonces.size() >= 5) {
            return nonce;
        }
        loadMoreNonces();
        return nonce;
    }

    public static void addToKnownNonces(long nonce) {
        sKnownNonces.add(Long.valueOf(nonce));
    }

    public static ArrayList<Security.VerifiedPurchase> verifyPurchase(String signedData, String signature) {
        return com.ngmoco.gamejs.iab.Security.verifyPurchase(signedData, null);
    }
}
