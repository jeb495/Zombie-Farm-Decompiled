package com.ngmoco.gamejs.ngiab;

import android.app.Activity;
import android.os.Handler;
import com.ngmoco.gamejs.iab.BillingService;
import com.ngmoco.gamejs.iab.Consts;
import com.ngmoco.gamejs.iab.PurchaseObserver;

public class NgPurchaseObserver extends PurchaseObserver {
    public NgPurchaseObserver(Activity activity, Handler handler) {
        super(activity, handler);
    }

    @Override // com.ngmoco.gamejs.iab.PurchaseObserver
    public void onBillingSupported(boolean supported) {
    }

    @Override // com.ngmoco.gamejs.iab.PurchaseObserver
    public void onPurchaseStateChange(Consts.PurchaseState purchaseState, String itemId, int quantity, long purchaseTime, String developerPayload) {
    }

    @Override // com.ngmoco.gamejs.iab.PurchaseObserver
    public void onRequestPurchaseResponse(BillingService.RequestPurchase request, Consts.ResponseCode responseCode) {
    }

    @Override // com.ngmoco.gamejs.iab.PurchaseObserver
    public void onRestoreTransactionsResponse(BillingService.RestoreTransactions request, Consts.ResponseCode responseCode) {
    }
}
