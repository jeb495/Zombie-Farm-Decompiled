package com.ngmoco.gamejs.ngiab;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.iab.BillingService;
import com.ngmoco.gamejs.iab.Consts;
import com.ngmoco.gamejs.iab.ResponseHandler;
import com.ngmoco.gamejs.iab.Security;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class BillingService extends com.ngmoco.gamejs.iab.BillingService {
    private static final String TAG = "ngiab.BillingService";
    private static HashMap notifyToStartId = new HashMap();
    private Handler mHandler = new Handler();

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.iab.BillingService
    public void checkResponseCode(long requestId, Consts.ResponseCode responseCode) {
        BillingService.BillingRequest request = (BillingService.BillingRequest) mSentRequests.get(Long.valueOf(requestId));
        super.checkResponseCode(requestId, responseCode);
        if (request != null && responseCode != Consts.ResponseCode.RESULT_OK) {
            String err = "failed:" + responseCode.toString();
            if (responseCode == Consts.ResponseCode.RESULT_USER_CANCELED) {
                err = "cancelled";
            }
            postPurchaseEvent(err, ASConstants.kEmptyString, ASConstants.kEmptyString);
        }
    }

    @Override // com.ngmoco.gamejs.iab.BillingService
    public void onStart(Intent intent, int startId) {
        Log.i(TAG, "Received start id " + startId + ": " + intent);
        if (intent == null) {
            Log.w(TAG, "Stopping self service as null intent was received.");
            stopSelf();
            return;
        }
        super.onStart(intent, startId);
    }

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.iab.BillingService
    public void purchaseStateChanged(int startId, String signedData, String signature) {
        Log.i(TAG, "purchaseStateChanged called back with data: " + signedData);
        postPurchaseEvent(ASConstants.kEmptyString, signedData, signature);
        ArrayList<Security.VerifiedPurchase> purchases = Security.verifyPurchase(signedData, signature);
        if (purchases != null) {
            Iterator i$ = purchases.iterator();
            while (i$.hasNext()) {
                Security.VerifiedPurchase vp = i$.next();
                if (vp.notificationId != null) {
                    notifyToStartId.put(new String(vp.notificationId), new Integer(startId));
                }
            }
            super.purchaseStateChanged(startId, signedData, signature);
        }
    }

    public boolean checkBillingSupported(Runnable runOnSupported, Runnable runOnUnsupported) {
        return new BillingService.CheckBillingSupported(this, runOnSupported, runOnUnsupported) {
            /* class com.ngmoco.gamejs.ngiab.BillingService.AnonymousClass1 */
            final /* synthetic */ Runnable val$runOnSupported;
            final /* synthetic */ Runnable val$runOnUnsupported;

            {
                this.val$runOnSupported = r3;
                this.val$runOnUnsupported = r4;
                x0.getClass();
            }

            /* access modifiers changed from: protected */
            @Override // com.ngmoco.gamejs.iab.BillingService.BillingRequest, com.ngmoco.gamejs.iab.BillingService.CheckBillingSupported
            public long run() throws RemoteException {
                try {
                    Bundle response = BillingService.mService.sendBillingRequest(makeRequestBundle("CHECK_BILLING_SUPPORTED"));
                    if (response != null) {
                        boolean billingSupported = response.getInt(Consts.BILLING_RESPONSE_RESPONSE_CODE) == Consts.ResponseCode.RESULT_OK.ordinal();
                        ResponseHandler.checkBillingSupportedResponse(billingSupported);
                        if (billingSupported) {
                            this.val$runOnSupported.run();
                        } else {
                            this.val$runOnUnsupported.run();
                        }
                    }
                } catch (Exception e) {
                    if (e.getMessage() != null) {
                        Log.e(BillingService.TAG, e.getMessage());
                    } else {
                        Log.e(BillingService.TAG, e.toString());
                    }
                }
                return Consts.BILLING_RESPONSE_INVALID_REQUEST_ID;
            }
        }.runRequest();
    }

    private void postPurchaseEvent(final String err, final String data, final String verificationToken) {
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.ngiab.BillingService.AnonymousClass2 */

            public void run() {
                NgJNI.onPurchaseEvent(err, data, verificationToken);
            }
        });
    }

    public void sendOrderProcessedAck(String id) {
        if (id.length() > 0) {
            String[] notifyIds = {id};
            if (notifyToStartId.containsKey(id)) {
                notifyToStartId.remove(id);
                confirmNotifications(((Integer) notifyToStartId.get(id)).intValue(), notifyIds);
                return;
            }
            confirmNotifications(1, notifyIds);
        }
    }
}
