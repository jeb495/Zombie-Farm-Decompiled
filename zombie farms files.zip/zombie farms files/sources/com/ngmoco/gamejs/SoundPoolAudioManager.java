package com.ngmoco.gamejs;

import android.content.Context;
import android.media.SoundPool;
import java.io.IOException;
import java.util.HashMap;
import java.util.ListIterator;

/* access modifiers changed from: package-private */
/* compiled from: NgAudio */
public class SoundPoolAudioManager {
    private static final String TAG = "SoundPoolAudioManager";
    private static final int maxStreams = 8;
    private static int sAudioCount = 0;
    private static int s_sound_count = 0;
    private boolean resetting = false;
    private SoundPool soundPool = new SoundPool(8, 3, 0);
    private HashMap<Integer, NgSoundResource> soundResources = new HashMap<>();
    private HashMap<Integer, NgSound> sounds = new HashMap<>();

    public static native void playCompleted(int i);

    public SoundPool getSoundPool() {
        return this.soundPool;
    }

    public SoundPoolAudioManager(Context context) {
    }

    public synchronized void reset() {
        this.resetting = true;
        for (NgSoundResource resource : this.soundResources.values()) {
            resource.unload(this.soundPool);
        }
        this.soundResources.clear();
        this.sounds.clear();
        this.soundPool.release();
        this.soundPool = new SoundPool(8, 3, 0);
        sAudioCount = 0;
        s_sound_count = 0;
        this.resetting = false;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x001e, code lost:
        if (r4 == false) goto L_0x002d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:12:0x0024, code lost:
        if (r1.isPlaying() == false) goto L_0x0012;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0026, code lost:
        r1.tryPause();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0031, code lost:
        if (r1.isPaused() == false) goto L_0x0012;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0033, code lost:
        r1.tryPlay();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0008, code lost:
        r0 = r3.sounds.values().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0016, code lost:
        if (r0.hasNext() == false) goto L_0x0006;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0018, code lost:
        r1 = r0.next();
     */
    public void suspend(boolean toSuspend) {
        synchronized (this) {
            if (this.resetting) {
            }
        }
    }

    public int createSound(int streamID) {
        if (streamID == -1) {
            Log.e(TAG, "Exceeded maximum number of sounds");
            return -1;
        }
        NgSoundResource resource = this.soundResources.get(Integer.valueOf(streamID));
        if (resource != null) {
            int i = s_sound_count;
            s_sound_count = i + 1;
            NgSound sound = new NgSound(resource, i);
            if (registSound(sound, streamID)) {
                return sound.id;
            }
            return -1;
        }
        Log.e(TAG, "No resource found for this Id");
        return -1;
    }

    public void deleteSound(int soundID) {
        NgSound sound = this.sounds.get(Integer.valueOf(soundID));
        if (sound != null) {
            sound.resource.removeSound(sound);
            this.sounds.remove(new Integer(soundID));
        }
    }

    public synchronized int load(NgMediaSource source) {
        int i = -1;
        synchronized (this) {
            if (sAudioCount >= 255) {
                Log.d(TAG, "Exceeded max audio limit.. blocked");
            } else {
                try {
                    NgSoundResource resource = new NgSoundResource(source, this.soundPool);
                    if (resource != null) {
                        this.soundResources.put(Integer.valueOf(resource.getId()), resource);
                        sAudioCount++;
                        i = resource.getId();
                    }
                } catch (IOException ex) {
                    Log.e(TAG, "Failed in loading sound resource: " + ex.getMessage());
                }
            }
        }
        return i;
    }

    public void unload(int streamID) {
        if (streamID == -1) {
            Log.e(TAG, "unload Exceeded maximum number of sounds");
        } else if (this.soundResources.isEmpty()) {
            Log.v(TAG, "sound resource is already unloaded");
        } else {
            NgSoundResource resource = this.soundResources.get(Integer.valueOf(streamID));
            ListIterator<NgSound> iter = resource.getSounds().listIterator();
            while (iter.hasNext()) {
                do {
                } while (this.sounds.values().remove(iter.next()));
            }
            resource.unload(this.soundPool);
            this.soundResources.remove(Integer.valueOf(streamID));
        }
    }

    public int play(int soundID) {
        NgSound sound = soundForID(soundID);
        if (sound == null) {
            Log.e(TAG, "NgSound is not created yet");
            return -1;
        } else if (sound.isPaused() || sound.isPreparing()) {
            sound.resume();
            return 0;
        } else {
            if (!sound.isPreparing()) {
                sound.tryStop();
            }
            if (sound.tryPlay()) {
                return 0;
            }
            Log.e(TAG, String.format("tryPlay: failed in playing soundID=%d", Integer.valueOf(soundID)));
            return -1;
        }
    }

    public boolean isPlaying(int soundID) {
        NgSound sound = soundForID(soundID);
        if (sound == null) {
            Log.e(TAG, "NgSound is not created yet");
            return false;
        } else if (sound.isPlaying() || sound.isPreparing()) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isFinished(int soundID) {
        NgSound sound = soundForID(soundID);
        if (sound != null) {
            return sound.isFinished();
        }
        Log.e(TAG, "NgSound is not created yet");
        return false;
    }

    public void stop(int soundID) {
        NgSound sound = soundForID(soundID);
        if (sound != null) {
            sound.tryStop();
        }
    }

    public void pause(int soundID) {
        NgSound sound = soundForID(soundID);
        if (sound != null) {
            sound.tryPause();
        }
    }

    public void setSoundVolume(int soundID, float volume) {
        NgSound sound = soundForID(soundID);
        if (sound != null) {
            sound.trySetVolume(volume);
        }
    }

    public void setLoops(int soundID, boolean loops) {
        NgSound sound = soundForID(soundID);
        if (sound != null) {
            sound.setLoops(loops);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0008, code lost:
        r0 = r3.sounds.values().iterator();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0016, code lost:
        if (r0.hasNext() == false) goto L_0x0006;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0018, code lost:
        r0.next().update();
     */
    public void update() {
        synchronized (this) {
            if (this.resetting) {
            }
        }
    }

    private boolean registSound(NgSound sound, int streamID) {
        this.sounds.put(Integer.valueOf(sound.id), sound);
        NgSoundResource resource = this.soundResources.get(Integer.valueOf(streamID));
        if (resource == null) {
            Log.d(TAG, "cannot regist the sound: sound playback count reached the maximum.");
            return false;
        }
        resource.addSound(sound);
        return true;
    }

    private NgSound soundForID(int soundID) {
        return this.sounds.get(Integer.valueOf(soundID));
    }
}
