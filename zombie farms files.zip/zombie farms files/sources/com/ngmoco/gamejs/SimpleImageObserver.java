package com.ngmoco.gamejs;

import android.graphics.Bitmap;

public interface SimpleImageObserver {

    public static class States {
        public static final int ERROR = -255;
        public static final int LOADED = 2;
        public static final int LOADING = 1;
        public static final int NOT_LOADED = 0;
        public static final int UNLOADED = -1;
    }

    void imageLoadFailed(String str, int i, String str2);

    void setImage(String str, Bitmap bitmap);
}
