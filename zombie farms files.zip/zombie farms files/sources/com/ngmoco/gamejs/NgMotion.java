package com.ngmoco.gamejs;

import android.util.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import java.util.Observable;
import java.util.Observer;

/* access modifiers changed from: package-private */
/* compiled from: NgJNI */
public class NgMotion {
    private static String TAG = "NgMotion";
    private static Observer sAccelListener = new Observer() {
        /* class com.ngmoco.gamejs.NgMotion.AnonymousClass1 */

        public void update(Observable o, Object arg) {
            try {
                final Object accel = (float[]) arg;
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgMotion.AnonymousClass1.AnonymousClass1 */

                    public void run() {
                        NgJNI.accel(accel[0], accel[1], accel[2]);
                    }
                });
            } catch (ClassCastException e) {
                Log.e(NgMotion.TAG, "invalid accel");
            }
        }
    };
    private static GameJSActivity sActivity;
    private static Observer sGyroListener = new Observer() {
        /* class com.ngmoco.gamejs.NgMotion.AnonymousClass2 */

        public void update(Observable o, Object arg) {
            try {
                final Object gyro = (float[]) arg;
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgMotion.AnonymousClass2.AnonymousClass1 */

                    public void run() {
                        NgJNI.gyro(gyro[0], gyro[1], gyro[2]);
                    }
                });
            } catch (ClassCastException e) {
                Log.e(NgMotion.TAG, "invalid gyro");
            }
        }
    };
    private static Observer sMagneticListener = new Observer() {
        /* class com.ngmoco.gamejs.NgMotion.AnonymousClass3 */

        public void update(Observable o, Object arg) {
            try {
                final float mag = ((Float) arg).floatValue();
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgMotion.AnonymousClass3.AnonymousClass1 */

                    public void run() {
                        NgJNI.magnetic(mag, mag, mag);
                    }
                });
            } catch (ClassCastException e) {
            }
        }
    };

    NgMotion() {
    }

    static void setActivity(GameJSActivity activity) {
        sActivity = activity;
    }

    public static void startAccelerometer() {
        sActivity.getSensor().addAccelObserver(sAccelListener);
    }

    public static void stopAccelerometer() {
        sActivity.getSensor().removeAccelObserver(sAccelListener);
    }

    public static void startGyroscope() {
        sActivity.getSensor().addGyroObserver(sGyroListener);
    }

    public static void stopGyroscope() {
        sActivity.getSensor().removeGyroObserver(sGyroListener);
    }

    public static void startMagnetic() {
        sActivity.getSensor().addMagneticObserver(sMagneticListener);
    }

    public static void stopMagnetic() {
        sActivity.getSensor().removeMagneticObserver(sMagneticListener);
    }
}
