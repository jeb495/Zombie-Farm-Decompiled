package com.ngmoco.gamejs;

import android.media.MediaPlayer;
import java.io.IOException;

/* compiled from: NgMusic */
class NgMusicPlayer {
    public static final String TAG = "NgMusicPlayer";
    private boolean loaded;
    private MediaPlayer mediaPlayer = new MediaPlayer();
    private boolean paused;
    private boolean playing;
    private NgMediaSource source;
    private boolean toLoop = true;

    NgMusicPlayer() {
        this.mediaPlayer.setLooping(this.toLoop);
        this.loaded = false;
        this.paused = false;
        this.playing = false;
    }

    public void reset() {
        try {
            this.mediaPlayer.reset();
            this.mediaPlayer.setLooping(this.toLoop);
            this.loaded = false;
            this.paused = false;
            this.playing = false;
        } catch (Exception e) {
            Log.e(TAG, "failed in reset: " + e.getMessage());
        }
    }

    public void play() throws IllegalArgumentException, IllegalStateException {
        try {
            this.mediaPlayer.start();
            this.paused = false;
            this.playing = true;
        } catch (Exception e) {
            Log.e(TAG, "failed in playing music: " + e.getMessage());
        }
    }

    public void stop() throws IOException {
        if (this.paused || this.playing) {
            try {
                this.mediaPlayer.stop();
                reset();
                this.source.setSource(this.mediaPlayer);
                this.mediaPlayer.prepare();
                this.loaded = true;
            } catch (Exception e) {
                Log.e(TAG, "failed in stop: " + e.getMessage());
            }
        }
    }

    public void suspend() {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
        }
    }

    public void pause() {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.pause();
            this.paused = true;
        }
    }

    public void resume() {
        if (this.loaded && this.playing && !this.paused) {
            this.mediaPlayer.start();
            this.paused = false;
            this.playing = true;
        }
    }

    public void setLoop(boolean toLoop2) {
        this.toLoop = toLoop2;
        this.mediaPlayer.setLooping(toLoop2);
    }

    public void setSource(NgMediaSource newSource) throws IOException {
        if (this.mediaPlayer.isPlaying()) {
            this.mediaPlayer.stop();
        }
        reset();
        if (this.source != null) {
            this.source.close();
        }
        this.source = newSource;
        try {
            this.source.setSource(this.mediaPlayer);
            this.mediaPlayer.prepare();
            this.loaded = true;
        } catch (Exception e) {
            Log.e(TAG, "failed in resetting: " + e.getMessage());
        }
    }

    public void setVolume(float volume) {
        this.mediaPlayer.setVolume(volume, volume);
    }

    public int getCurrentPosition() {
        return this.mediaPlayer.getCurrentPosition();
    }
}
