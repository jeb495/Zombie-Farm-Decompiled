package com.ngmoco.gamejs.iab;

import android.text.TextUtils;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.iab.Consts;
import com.ngmoco.util.Base64;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Security {
    private static final String KEY_FACTORY_ALGORITHM = "RSA";
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String SIGNATURE_ALGORITHM = "SHA1withRSA";
    private static final String TAG = "Security";
    protected static HashSet<Long> sKnownNonces = new HashSet<>();

    public static class VerifiedPurchase {
        public String developerPayload;
        public String notificationId;
        public String orderId;
        public String productId;
        public Consts.PurchaseState purchaseState;
        public long purchaseTime;

        public VerifiedPurchase(Consts.PurchaseState purchaseState2, String notificationId2, String productId2, String orderId2, long purchaseTime2, String developerPayload2) {
            this.purchaseState = purchaseState2;
            this.notificationId = notificationId2;
            this.productId = productId2;
            this.orderId = orderId2;
            this.purchaseTime = purchaseTime2;
            this.developerPayload = developerPayload2;
        }
    }

    public static long generateNonce() {
        long nonce = RANDOM.nextLong();
        sKnownNonces.add(Long.valueOf(nonce));
        return nonce;
    }

    public static void removeNonce(long nonce) {
        sKnownNonces.remove(Long.valueOf(nonce));
    }

    public static boolean isNonceKnown(long nonce) {
        return sKnownNonces.contains(Long.valueOf(nonce));
    }

    public static ArrayList<VerifiedPurchase> verifyPurchase(String signedData, String signature) {
        if (signedData == null) {
            Log.e(TAG, "data is null");
            return null;
        }
        boolean verified = true;
        if (TextUtils.isEmpty(signature) || (verified = verify(generatePublicKey("your public key here"), signedData, signature))) {
            int numTransactions = 0;
            try {
                JSONObject jObject = new JSONObject(signedData);
                long nonce = jObject.optLong("nonce");
                JSONArray jTransactionsArray = jObject.optJSONArray("orders");
                if (jTransactionsArray != null) {
                    numTransactions = jTransactionsArray.length();
                }
                if (!isNonceKnown(nonce)) {
                    Log.w(TAG, "Nonce not found: " + nonce);
                    return null;
                }
                ArrayList<VerifiedPurchase> purchases = new ArrayList<>();
                for (int i = 0; i < numTransactions; i++) {
                    try {
                        JSONObject jElement = jTransactionsArray.getJSONObject(i);
                        Consts.PurchaseState purchaseState = Consts.PurchaseState.valueOf(jElement.getInt("purchaseState"));
                        String productId = jElement.getString("productId");
                        jElement.getString("packageName");
                        long purchaseTime = jElement.getLong("purchaseTime");
                        String orderId = jElement.optString("orderId", ASConstants.kEmptyString);
                        String notifyId = null;
                        if (jElement.has("notificationId")) {
                            notifyId = jElement.getString("notificationId");
                        }
                        String developerPayload = jElement.optString("developerPayload", null);
                        if (purchaseState != Consts.PurchaseState.PURCHASED || verified) {
                            purchases.add(new VerifiedPurchase(purchaseState, notifyId, productId, orderId, purchaseTime, developerPayload));
                        }
                    } catch (JSONException e) {
                        Log.e(TAG, "JSON exception: ", e);
                        return null;
                    }
                }
                removeNonce(nonce);
                return purchases;
            } catch (JSONException e2) {
                return null;
            }
        } else {
            Log.w(TAG, "signature does not match data.");
            return null;
        }
    }

    public static PublicKey generatePublicKey(String encodedPublicKey) {
        try {
            return KeyFactory.getInstance(KEY_FACTORY_ALGORITHM).generatePublic(new X509EncodedKeySpec(Base64.decode(encodedPublicKey, 0)));
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } catch (InvalidKeySpecException e2) {
            Log.e(TAG, "Invalid key specification.");
            throw new IllegalArgumentException(e2);
        }
    }

    public static boolean verify(PublicKey publicKey, String signedData, String signature) {
        try {
            Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
            sig.initVerify(publicKey);
            sig.update(signedData.getBytes());
            if (sig.verify(Base64.decode(signature, 0))) {
                return true;
            }
            Log.e(TAG, "Signature verification failed.");
            return false;
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "NoSuchAlgorithmException.");
            return false;
        } catch (InvalidKeyException e2) {
            Log.e(TAG, "Invalid key specification.");
            return false;
        } catch (SignatureException e3) {
            Log.e(TAG, "Signature exception.");
            return false;
        }
    }
}
