package com.ngmoco.gamejs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class LocalNotificationDatabase {
    private static final String DATABASE_CREATE = "CREATE TABLE notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,notificationId TEXT NOT NULL,notificationPayload TEXT NOT NULL,notificationTime NUMBER NOT NULL);";
    private static final String DATABASE_NAME = "notifications.db";
    private static final int DATABASE_VERSION = 1;
    private static final String KEY_ROWID = "id";
    private static final String NOTIFICATION_ID = "notificationId";
    private static final String NOTIFICATION_PAYLOAD = "notificationPayload";
    private static final String NOTIFICATION_TIME = "notificationTime";
    private static final String SEQUENCE_CREATE = "CREATE TABLE idSequence(id INTEGER PRIMARY KEY AUTOINCREMENT,notificationId INTEGER NOT NULL);";
    private static final String SEQUENCE_NAME = "idSequence";
    private static final String TABLE_NAME = "notifications";
    private static final String TAG = "LocalNotificationsDatabase";
    private Context context;
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    /* access modifiers changed from: private */
    public static class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context) {
            super(context, LocalNotificationDatabase.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        }

        public void onCreate(SQLiteDatabase database) {
            database.execSQL(LocalNotificationDatabase.DATABASE_CREATE);
            database.execSQL(LocalNotificationDatabase.SEQUENCE_CREATE);
        }

        public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
            Log.w(LocalNotificationDatabase.TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
            database.execSQL("DROP TABLE IF EXISTS notifications");
            database.execSQL("DROP TABLE IF EXISTS CREATE TABLE idSequence(id INTEGER PRIMARY KEY AUTOINCREMENT,notificationId INTEGER NOT NULL);");
            onCreate(database);
        }
    }

    public LocalNotificationDatabase(Context context2) {
        this.context = context2;
    }

    public boolean open() throws SQLException {
        this.dbHelper = new DatabaseHelper(this.context);
        this.db = this.dbHelper.getWritableDatabase();
        return true;
    }

    public void close() {
        if (this.dbHelper != null) {
            this.dbHelper.close();
        }
    }

    public void upgrade(int oldVersion, int newVersion) {
        this.dbHelper.onUpgrade(this.db, oldVersion, newVersion);
        open();
    }

    private int getNext() {
        Cursor c = this.db.rawQuery("SELECT notificationId FROM idSequence", null);
        if (c == null) {
            return -1;
        }
        int maxId = 2;
        c.moveToFirst();
        if (c.getCount() > 0) {
            maxId = c.getInt(0);
        }
        c.close();
        ContentValues values = createSequenceContentValues(maxId + 1);
        if (maxId == 2) {
            if (this.db.insert(SEQUENCE_NAME, null, values) == -1) {
                return -1;
            }
            return maxId;
        } else if (((long) this.db.update(SEQUENCE_NAME, values, "notificationId=" + maxId, null)) == -1) {
            return -1;
        } else {
            return maxId;
        }
    }

    public String insert(int procId, String payload, int time) {
        int nextInternalId = getNext();
        if (nextInternalId == -1) {
            return null;
        }
        String notificationId = procId + "_" + nextInternalId;
        if (this.db.insert(TABLE_NAME, null, createContentValues(notificationId, payload, time)) == -1) {
            return null;
        }
        return notificationId;
    }

    public void deleteNotification(String notificationId) {
        this.db.delete(TABLE_NAME, "notificationId LIKE '" + notificationId + "'", null);
    }

    public void deleteAllNotifications(int procId) {
        this.db.delete(TABLE_NAME, "notificationId LIKE '" + procId + "%'", null);
    }

    public Cursor getAllNotifications(int procId) {
        Cursor cursor = this.db.rawQuery("SELECT notificationId,notificationPayload,notificationTime FROM notifications WHERE notificationId LIKE '" + procId + "%'", null);
        if (cursor == null) {
            return null;
        }
        if (cursor.moveToFirst()) {
            return cursor;
        }
        cursor.close();
        return null;
    }

    private ContentValues createSequenceContentValues(int id) {
        ContentValues values = new ContentValues();
        values.put(NOTIFICATION_ID, Integer.valueOf(id));
        return values;
    }

    private ContentValues createContentValues(String id, String payload, int time) {
        ContentValues values = new ContentValues();
        values.put(NOTIFICATION_ID, id);
        values.put(NOTIFICATION_PAYLOAD, payload);
        values.put(NOTIFICATION_TIME, Integer.valueOf(time));
        return values;
    }
}
