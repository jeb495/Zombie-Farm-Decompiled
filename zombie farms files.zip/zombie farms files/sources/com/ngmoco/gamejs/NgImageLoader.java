package com.ngmoco.gamejs;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class NgImageLoader {
    private static final String TAG = "NgImageLoader";

    public static Bitmap loadBitmap(String url) {
        try {
            URL newurl = new URL(url);
            return BitmapFactory.decodeStream(newurl.openConnection().getInputStream(), null, new BitmapFactory.Options());
        } catch (MalformedURLException e) {
            Log.e(TAG, "Could not load Bitmap from: " + url);
            e.printStackTrace();
            return null;
        } catch (IOException e2) {
            Log.e(TAG, "Could not load Bitmap from: " + url);
            e2.printStackTrace();
            return null;
        }
    }

    public static long getLengthURL(String url) {
        try {
            return (long) new URL(url).openConnection().getContentLength();
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return 0;
        } catch (IOException e2) {
            e2.printStackTrace();
            return 0;
        }
    }
}
