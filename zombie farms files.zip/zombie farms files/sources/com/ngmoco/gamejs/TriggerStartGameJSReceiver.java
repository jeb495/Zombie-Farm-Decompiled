package com.ngmoco.gamejs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.ngmoco.marketingapp.PackageApplication;

public class TriggerStartGameJSReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.ngmoco.gamejs.START_GAMEJS")) {
            Intent gameIntent = new Intent(context, PackageApplication.class);
            gameIntent.addFlags(268435456);
            context.startActivity(gameIntent);
        }
    }
}
