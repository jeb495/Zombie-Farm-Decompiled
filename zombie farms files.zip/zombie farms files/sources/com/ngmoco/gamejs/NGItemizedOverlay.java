package com.ngmoco.gamejs;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;
import com.ngmoco.gamejs.ui.widgets.UIAnnotation;
import com.ngmoco.gamejs.ui.widgets.UIAnnotationDrawable;
import com.ngmoco.gamejs.ui.widgets.UIImageDrawable;
import java.util.ArrayList;

public class NGItemizedOverlay extends ItemizedOverlay<UIAnnotation> {
    private UIAnnotation currentFocus = null;
    private ArrayList<UIAnnotation> overlays = new ArrayList<>();

    public /* bridge */ /* synthetic */ void setFocus(OverlayItem x0) {
        setFocus((UIAnnotation) ((UIAnnotation) x0));
    }

    public NGItemizedOverlay(UIImageDrawable defaultMarker, Context context) {
        super((Drawable) null);
        populate();
        setOnFocusChangeListener(new ItemizedOverlay.OnFocusChangeListener() {
            /* class com.ngmoco.gamejs.NGItemizedOverlay.AnonymousClass1 */

            public void onFocusChanged(ItemizedOverlay overlay, OverlayItem newFocus) {
                NGItemizedOverlay.this.setFocus((UIAnnotation) ((UIAnnotation) newFocus));
            }
        });
    }

    public void addOverlays(UIAnnotation overlay) {
        this.overlays.add(overlay);
        setLastFocusedIndex(-1);
        populate();
    }

    public void removeOverlays(UIAnnotation overlay) {
        this.overlays.remove(overlay);
        setLastFocusedIndex(-1);
        populate();
    }

    /* access modifiers changed from: protected */
    public UIAnnotation createItem(int i) {
        return this.overlays.get(i);
    }

    public int size() {
        return this.overlays.size();
    }

    public ArrayList<UIAnnotation> getOverlays() {
        return this.overlays;
    }

    public void setFocus(UIAnnotation item) {
        if (this.currentFocus != null) {
            this.currentFocus.lostFocus();
        }
        this.currentFocus = item;
        if (this.currentFocus != null) {
            this.currentFocus.gotFocus();
        }
        NGItemizedOverlay.super.setFocus(item);
    }

    public void draw(Canvas canvas, MapView mapView, boolean shadow) {
        Projection pj = mapView.getProjection();
        Point curScreenCoords = new Point();
        for (int i = 0; i < size(); i++) {
            UIAnnotation mapAnnotation = getItem(getIndexToDraw(i));
            if (mapAnnotation != getFocus()) {
                canvas.save();
                pj.toPixels(mapAnnotation.getCoordinate(), curScreenCoords);
                canvas.translate((float) curScreenCoords.x, (float) curScreenCoords.y);
                ((UIAnnotationDrawable) mapAnnotation.getMarker(0)).draw(canvas);
                canvas.restore();
            }
        }
        if (getFocus() != null) {
            UIAnnotation mapAnnotation2 = getFocus();
            canvas.save();
            pj.toPixels(mapAnnotation2.getCoordinate(), curScreenCoords);
            canvas.translate((float) curScreenCoords.x, (float) curScreenCoords.y);
            ((UIAnnotationDrawable) mapAnnotation2.getMarker(0)).draw(canvas);
            canvas.restore();
        }
    }
}
