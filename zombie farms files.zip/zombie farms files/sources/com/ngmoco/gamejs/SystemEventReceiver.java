package com.ngmoco.gamejs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.activity.GameJSActivity;

public class SystemEventReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String intentAction = intent.getAction() != null ? intent.getAction() : ASConstants.kEmptyString;
        String stopIntentName = context.getPackageName() + ".STOP";
        if (intentAction.equals("android.media.RINGER_MODE_CHANGED")) {
            if (NgAudio.getInstance() != null) {
                NgAudio.getInstance().setRingerMode(intent.getIntExtra("android.media.EXTRA_RINGER_MODE", -1));
            }
        } else if (intentAction.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
            NetworkInfo ni = (NetworkInfo) intent.getParcelableExtra("networkInfo");
            final int status = 0;
            if (ni.isAvailable()) {
                status = ni.getType() == 0 ? 1 : 2;
            }
            try {
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.SystemEventReceiver.AnonymousClass1 */

                    public void run() {
                        NgJNI.onConnectivityChanged(status);
                    }
                });
            } catch (RuntimeException e) {
            }
        } else if (intentAction.equals(stopIntentName)) {
            Log.w("SystemEventReceiver", "Received intent to STOP. Doing so!");
            GameJSActivity activity = GameJSActivity.getActivity();
            if (activity != null) {
                activity.finish();
                return;
            }
        } else if (intent.getExtras() != null && intent.getExtras().containsKey(NotificationEmitter.LOCAL_NOTIFICATION_TAG)) {
            NotificationEmitter.handleFiredLocal(intent, context);
        }
        if (isOrderedBroadcast()) {
            setResult(-1, null, null);
        }
    }
}
