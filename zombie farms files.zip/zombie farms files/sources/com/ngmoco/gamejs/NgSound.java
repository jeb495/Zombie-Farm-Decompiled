package com.ngmoco.gamejs;

import android.media.SoundPool;
import java.util.concurrent.ConcurrentLinkedQueue;

/* access modifiers changed from: package-private */
/* compiled from: NgAudio */
public class NgSound {
    private static final int MAX_TRY_COUNT = 1024;
    private static final String TAG = "NgSound";
    private static final int YET = 0;
    private long elapsed;
    public final int id;
    private boolean isLoop;
    private long lastChecked;
    private float lastVolume;
    private int playID;
    public final NgSoundResource resource;
    private ConcurrentLinkedQueue<Runnable> runQueue;
    private State state = State.INITIAL;
    private int tryCount;

    /* access modifiers changed from: private */
    /* compiled from: NgAudio */
    public enum State {
        INITIAL,
        PREPARING,
        PLAYING,
        PAUSED,
        FINISHED
    }

    NgSound(NgSoundResource resource2, int id2) {
        this.resource = resource2;
        this.id = id2;
        this.tryCount = 0;
        this.playID = 0;
        this.lastVolume = 1.0f;
        this.isLoop = false;
        this.elapsed = 0;
        this.runQueue = new ConcurrentLinkedQueue<>();
    }

    public void setLoops(boolean loops) {
        this.isLoop = loops;
    }

    public boolean isPreparing() {
        return this.state == State.PREPARING;
    }

    public boolean tryPlay() {
        int i;
        if (NgAudio.getInstance().isSuspend()) {
            tryPause();
            return false;
        }
        this.state = State.PREPARING;
        SoundPool sp = NgAudio.getSoundPool();
        int id2 = this.resource.getId();
        float f = this.lastVolume;
        float f2 = this.lastVolume;
        if (this.isLoop) {
            i = -1;
        } else {
            i = 0;
        }
        this.playID = sp.play(id2, f, f2, 0, i, 1.0f);
        if (this.playID == 0) {
            int i2 = this.tryCount;
            this.tryCount = i2 + 1;
            if (i2 <= MAX_TRY_COUNT) {
                return false;
            }
            Log.e(TAG, String.format("NgSound: failed to play streamID=%d", Integer.valueOf(this.resource.getId())));
            return false;
        }
        this.state = State.PLAYING;
        this.elapsed = 0;
        this.lastChecked = System.currentTimeMillis();
        return true;
    }

    public void trySetVolume(float volume) {
        if (isPreparing()) {
            addSetVolume(volume);
            return;
        }
        NgAudio.getSoundPool().setVolume(this.playID, volume, volume);
        this.lastVolume = volume;
    }

    public void tryStop() {
        if (isPreparing()) {
            addStop();
            return;
        }
        NgAudio.getSoundPool().stop(this.playID);
        this.elapsed = 0;
        this.state = State.FINISHED;
    }

    public void tryPause() {
        if (isPreparing()) {
            addPause();
            return;
        }
        NgAudio.getSoundPool().pause(this.playID);
        this.state = State.PAUSED;
    }

    public void resume() {
        if (isPreparing()) {
            addResume();
            return;
        }
        this.lastChecked = System.currentTimeMillis();
        NgAudio.getSoundPool().resume(this.playID);
        this.state = State.PLAYING;
    }

    public void update() {
        if (this.state != State.INITIAL) {
            if (!isPreparing() || tryPlay()) {
                while (true) {
                    Runnable r = this.runQueue.poll();
                    if (r == null) {
                        break;
                    }
                    r.run();
                }
                if (this.state == State.PLAYING) {
                    long now = System.currentTimeMillis();
                    this.elapsed += now - this.lastChecked;
                    this.lastChecked = now;
                    if (this.elapsed > ((long) this.resource.getDuration())) {
                        this.state = State.FINISHED;
                        SoundPoolAudioManager.playCompleted(this.id);
                    }
                }
            }
        }
    }

    public void addCommand(Runnable cmd) {
        this.runQueue.add(cmd);
    }

    public void addSetVolume(final float vol) {
        addCommand(new Runnable() {
            /* class com.ngmoco.gamejs.NgSound.AnonymousClass1 */

            public void run() {
                NgAudio.getSoundPool().setVolume(NgSound.this.playID, vol, vol);
                NgSound.this.lastVolume = vol;
            }
        });
    }

    public void addStop() {
        addCommand(new Runnable() {
            /* class com.ngmoco.gamejs.NgSound.AnonymousClass2 */

            public void run() {
                NgAudio.getSoundPool().stop(NgSound.this.playID);
                NgSound.this.state = State.FINISHED;
            }
        });
    }

    public void addPause() {
        addCommand(new Runnable() {
            /* class com.ngmoco.gamejs.NgSound.AnonymousClass3 */

            public void run() {
                NgAudio.getSoundPool().pause(NgSound.this.playID);
                NgSound.this.state = State.PAUSED;
            }
        });
    }

    public void addResume() {
        addCommand(new Runnable() {
            /* class com.ngmoco.gamejs.NgSound.AnonymousClass4 */

            public void run() {
                NgAudio.getSoundPool().resume(NgSound.this.playID);
                NgSound.this.state = State.PLAYING;
            }
        });
    }

    public boolean isPaused() {
        return this.state == State.PAUSED;
    }

    public boolean isPlaying() {
        return this.state == State.PLAYING;
    }

    public boolean isFinished() {
        return this.state == State.FINISHED;
    }
}
