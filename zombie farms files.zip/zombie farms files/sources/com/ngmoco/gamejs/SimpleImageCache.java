package com.ngmoco.gamejs;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.ngmoco.gamejs.ui.Commands;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.net.ConnectException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpResponseException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class SimpleImageCache implements Handler.Callback {
    private static final String TAG = "SimpleImageCache";
    private final int MSG_NOTIFY = 1;
    private final int NUM_THREADS = 2;
    private final HashSet<String> mActiveRequests = new HashSet<>();
    private final ScheduledThreadPoolExecutor mExecutor = new ScheduledThreadPoolExecutor(2);
    private final HashMap<String, HashSet<WeakReference<SimpleImageObserver>>> mImageObservers = new HashMap<>();
    private final HashMap<String, SoftReference<Bitmap>> mImageRefs = new HashMap<>();
    private String mManifestRoot;
    private boolean mNotifyingObservers = false;
    private final HashSet<Bitmap> mPendingBitmaps = new HashSet<>();
    private ArrayList<PendingRemoval> mPendingRemovals = new ArrayList<>();
    private String mRoot;
    private final Handler mUILocalHandler = new Handler(Looper.getMainLooper(), this);

    /* access modifiers changed from: private */
    public class PendingRemoval {
        SimpleImageObserver mObserver;
        String mURL;

        public PendingRemoval(SimpleImageObserver observer, String url) {
            this.mObserver = observer;
            this.mURL = url;
        }
    }

    private void _addObserver(SimpleImageObserver observer, String relativeUrl) {
        HashSet<WeakReference<SimpleImageObserver>> bucket = this.mImageObservers.get(relativeUrl);
        if (!this.mImageObservers.containsKey(relativeUrl)) {
            bucket = new HashSet<>();
            this.mImageObservers.put(relativeUrl, bucket);
        } else {
            Iterator i$ = bucket.iterator();
            while (i$.hasNext()) {
                if (i$.next().get() == observer) {
                    return;
                }
            }
        }
        bucket.add(new WeakReference<>(observer));
    }

    public void removeObserver(SimpleImageObserver observer, String relativeUrl) {
        if (!this.mNotifyingObservers) {
            HashSet<WeakReference<SimpleImageObserver>> bucket = this.mImageObservers.get(relativeUrl);
            if (bucket != null) {
                Iterator<WeakReference<SimpleImageObserver>> iterator = bucket.iterator();
                while (iterator.hasNext()) {
                    SimpleImageObserver anObserver = iterator.next().get();
                    if (anObserver == null || anObserver == observer) {
                        iterator.remove();
                    }
                }
                return;
            }
            return;
        }
        this.mPendingRemovals.add(new PendingRemoval(observer, relativeUrl));
    }

    public void removeObserver(SimpleImageObserver observer) {
        if (!this.mNotifyingObservers) {
            for (HashSet<WeakReference<SimpleImageObserver>> hashSet : this.mImageObservers.values()) {
                Iterator<WeakReference<SimpleImageObserver>> iterator = hashSet.iterator();
                while (iterator.hasNext()) {
                    SimpleImageObserver anObserver = iterator.next().get();
                    if (anObserver == null || anObserver == observer) {
                        iterator.remove();
                    }
                }
            }
            return;
        }
        this.mPendingRemovals.add(new PendingRemoval(observer, null));
    }

    private void notifyObservers(String relativeUrl, int errorCode, String errorMessage) {
        SoftReference<Bitmap> imgRef = this.mImageRefs.get(relativeUrl);
        Bitmap bitmapData = imgRef == null ? null : imgRef.get();
        if (bitmapData == null && errorCode == 0) {
            errorCode = -1;
            errorMessage = "Unknown error loading image";
        }
        HashSet<WeakReference<SimpleImageObserver>> bucket = this.mImageObservers.get(relativeUrl);
        if (bucket != null) {
            this.mNotifyingObservers = true;
            Iterator<WeakReference<SimpleImageObserver>> iterator = bucket.iterator();
            while (iterator.hasNext()) {
                SimpleImageObserver observer = iterator.next().get();
                if (observer == null) {
                    iterator.remove();
                } else if (errorCode == 0) {
                    observer.setImage(relativeUrl, bitmapData);
                } else {
                    observer.imageLoadFailed(relativeUrl, errorCode, errorMessage);
                }
            }
            this.mNotifyingObservers = false;
            if (!this.mPendingRemovals.isEmpty()) {
                Iterator i$ = this.mPendingRemovals.iterator();
                while (i$.hasNext()) {
                    PendingRemoval p = i$.next();
                    if (p.mURL != null) {
                        removeObserver(p.mObserver, p.mURL);
                    } else {
                        removeObserver(p.mObserver);
                    }
                }
                this.mPendingRemovals.clear();
            }
        }
        this.mPendingBitmaps.remove(bitmapData);
        this.mActiveRequests.remove(relativeUrl);
    }

    public boolean handleMessage(Message m) {
        if (m.what != 1) {
            return false;
        }
        ImageNotificationPack pack = (ImageNotificationPack) m.obj;
        notifyObservers(pack.url, pack.errorCode, pack.errorMessage);
        return true;
    }

    private static class ImageNotificationPack {
        public int errorCode;
        public String errorMessage;
        public String url;

        public ImageNotificationPack(String url2, int errorCode2, String errorMessage2) {
            this.url = url2;
            this.errorCode = errorCode2;
            this.errorMessage = errorMessage2;
        }
    }

    public void addObserver(SimpleImageObserver observer, final String imageURL) {
        boolean isRelative;
        String localURL;
        String localURL2;
        boolean isLocal = false;
        SoftReference<Bitmap> aRef = this.mImageRefs.get(imageURL);
        _addObserver(observer, imageURL);
        if (aRef != null) {
            if (aRef.get() != null) {
                observer.setImage(imageURL, aRef.get());
            } else {
                this.mImageRefs.remove(imageURL);
                aRef = null;
            }
        }
        if (!imageURL.contains("://")) {
            isRelative = true;
        } else {
            isRelative = false;
        }
        if (isRelative || imageURL.startsWith("file://")) {
            isLocal = true;
        }
        if (aRef == null && !this.mActiveRequests.contains(imageURL)) {
            if (isLocal) {
                if (this.mRoot != null) {
                    if (isRelative) {
                        try {
                            localURL2 = composeURL("file://" + this.mRoot, imageURL);
                        } catch (ImageLoadException e) {
                            if (e.getErrorCode() != -2) {
                                notifyObservers(imageURL, e.getErrorCode(), e.getMessage());
                                return;
                            }
                        }
                    } else {
                        localURL2 = imageURL;
                    }
                    this.mImageRefs.put(imageURL, new SoftReference<>(fetchBitmap(localURL2)));
                    notifyObservers(imageURL, 0, null);
                    return;
                }
                if (isRelative) {
                    try {
                        localURL = composeURL("file://" + this.mManifestRoot, imageURL);
                    } catch (ImageLoadException e2) {
                        notifyObservers(imageURL, e2.getErrorCode(), e2.getMessage());
                        return;
                    }
                } else {
                    localURL = imageURL;
                }
                this.mImageRefs.put(imageURL, new SoftReference<>(fetchBitmap(localURL)));
                notifyObservers(imageURL, 0, null);
                return;
            }
            this.mActiveRequests.add(imageURL);
            this.mExecutor.execute(new Runnable() {
                /* class com.ngmoco.gamejs.SimpleImageCache.AnonymousClass1 */

                public void run() {
                    ImageNotificationPack pack = new ImageNotificationPack(imageURL, 0, null);
                    try {
                        Bitmap bm = SimpleImageCache.this.fetchBitmap(imageURL);
                        SimpleImageCache.this.mPendingBitmaps.add(bm);
                        SimpleImageCache.this.mImageRefs.put(imageURL, new SoftReference<>(bm));
                    } catch (ImageLoadException e) {
                        Log.e("Image Loader", "Failed: " + e.toString());
                        pack.errorCode = e.getErrorCode();
                        pack.errorMessage = e.getMessage();
                    } finally {
                        SimpleImageCache.this.mUILocalHandler.obtainMessage(1, pack).sendToTarget();
                    }
                }
            });
        }
    }

    private String composeURL(String base, String path) {
        if (base.endsWith("/")) {
            base = base.substring(0, base.length() - 1);
        }
        if (path.startsWith("/")) {
            return base + path;
        }
        return base + "/" + path;
    }

    /* access modifiers changed from: private */
    public static class ImageLoadException extends Exception {
        private int mErrorCode;

        ImageLoadException(String message, int errorCode, Throwable cause) {
            super(message, cause);
            this.mErrorCode = errorCode;
        }

        public int getErrorCode() {
            return this.mErrorCode;
        }
    }

    public Bitmap fetchBitmap(String url) throws ImageLoadException {
        InputStream is;
        Log.v(TAG, "Fetching image at " + url);
        try {
            URL aURL = new URL(url);
            if (aURL.getProtocol().toLowerCase().startsWith("http")) {
                HttpResponse response = new DefaultHttpClient().execute(new HttpGet(url));
                if (response.getStatusLine().getStatusCode() != 200) {
                    throw new HttpResponseException(response.getStatusLine().getStatusCode(), response.getStatusLine().getReasonPhrase());
                }
                is = response.getEntity().getContent();
            } else {
                URLConnection conn = aURL.openConnection();
                conn.connect();
                is = NgEngine.openProtectedStream(conn.getInputStream());
            }
            Bitmap bm = BitmapFactory.decodeStream(is);
            if (Commands.isProfilingEnabled() && bm != null) {
                int bpp = 4;
                switch (AnonymousClass2.$SwitchMap$android$graphics$Bitmap$Config[bm.getConfig().ordinal()]) {
                    case 1:
                        bpp = 1;
                        break;
                    case 2:
                    case 3:
                        bpp = 2;
                        break;
                }
                Log.d("IMAGE CACHE", "***&&&*** LOADED BITMAP: " + url);
                Log.d("IMAGE CACHE", "***&&&***  " + bpp + "bpp, " + bm.getWidth() + " x " + bm.getHeight() + ", " + new DecimalFormat("###,###,###,###").format((long) (bm.getWidth() * bpp * bm.getHeight())) + " bytes");
            }
            this.mActiveRequests.remove(url);
            if (bm != null) {
                return bm;
            }
            throw new ImageLoadException("Could not decode image: " + url, -5, null);
        } catch (FileNotFoundException e) {
            throw new ImageLoadException(e.getMessage(), -2, e);
        } catch (ConnectException e2) {
            throw new ImageLoadException(e2.getMessage(), -4, e2);
        } catch (OutOfMemoryError e3) {
            throw new ImageLoadException(e3.getMessage(), -3, e3);
        } catch (HttpResponseException e4) {
            throw new ImageLoadException(e4.getMessage(), e4.getStatusCode(), e4);
        } catch (Throwable th) {
            this.mActiveRequests.remove(url);
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    /* renamed from: com.ngmoco.gamejs.SimpleImageCache$2  reason: invalid class name */
    public static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$android$graphics$Bitmap$Config = new int[Bitmap.Config.values().length];

        static {
            try {
                $SwitchMap$android$graphics$Bitmap$Config[Bitmap.Config.ALPHA_8.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$android$graphics$Bitmap$Config[Bitmap.Config.ARGB_4444.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$android$graphics$Bitmap$Config[Bitmap.Config.RGB_565.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public SimpleImageCache(String root, String manifestRoot) {
        this.mRoot = root;
        this.mManifestRoot = manifestRoot;
    }
}
