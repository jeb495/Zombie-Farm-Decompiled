package com.ngmoco.gamejs;

import android.media.MediaPlayer;
import android.media.SoundPool;
import java.io.IOException;
import java.util.ArrayList;

/* access modifiers changed from: package-private */
/* compiled from: NgAudio */
public class NgSoundResource {
    private static final String TAG = "NgSound";
    private final int duration;
    private final int id;
    private ArrayList<NgSound> sounds = new ArrayList<>();
    private NgMediaSource source;

    NgSoundResource(NgMediaSource source2, SoundPool soundPool) throws IOException {
        this.id = source2.load(soundPool, 1);
        this.source = source2;
        int streamId = 0;
        while (streamId == 0) {
            streamId = soundPool.play(this.id, 0.0f, 0.0f, 0, 0, 1.0f);
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
        }
        soundPool.stop(streamId);
        MediaPlayer mediaPlayer = new MediaPlayer();
        source2.setSource(mediaPlayer);
        mediaPlayer.prepare();
        mediaPlayer.setLooping(false);
        this.duration = mediaPlayer.getDuration();
        mediaPlayer.release();
    }

    public final ArrayList<NgSound> getSounds() {
        return this.sounds;
    }

    public final int getId() {
        return this.id;
    }

    public final int getDuration() {
        return this.duration;
    }

    public void unload(SoundPool soundPool) {
        soundPool.unload(this.id);
        this.sounds.clear();
        try {
            this.source.close();
        } catch (IOException e) {
            Log.e(TAG, "failed to close source file: " + e.getMessage());
        }
    }

    public void addSound(NgSound sound) {
        this.sounds.add(sound);
    }

    public void removeSound(NgSound sound) {
        this.sounds.remove(sound);
    }
}
