package com.ngmoco.gamejs;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Debug;
import android.os.Process;
import android.os.Vibrator;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.ad.TapjoyReporter;
import com.ngmoco.gamejs.gl.GameJSView;
import com.ngmoco.gamejs.ngiab.Security;
import com.ngmoco.gamejs.ui.Commands;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashSet;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NgJNI {
    public static final int KEY_DOWN = 1;
    public static final int KEY_UP = 0;
    public static final int MODIFIER_ALT = 2;
    public static final int MODIFIER_ALT_LEFT = 4;
    public static final int MODIFIER_ALT_RIGHT = 8;
    public static final int MODIFIER_NONE = 0;
    public static final int MODIFIER_SHIFT = 16;
    public static final int MODIFIER_SHIFT_LEFT = 32;
    public static final int MODIFIER_SHIFT_RIGHT = 64;
    public static final int MODIFIER_SYMBOL = 1;
    static boolean SDCardFull = false;
    static final String TAG = "NgJNI";
    private static final int UNBUNDLING = 0;
    private static final int UNBUNDLING_COMPLETE = 1;
    static boolean bStarted = false;
    static String callingPackage;
    public static boolean mGLRunning = false;
    private static boolean mGamePaused = false;
    private static GameJSActivity sActivity;
    private static serviceToUse service = serviceToUse.IAB;

    private enum serviceToUse {
        IAB,
        BOKU
    }

    public static native void accel(float f, float f2, float f3);

    private static native void clockTick();

    public static native void closeFiles();

    public static native void decryptInPlace(int i, byte[] bArr, int i2, int i3);

    public static native void eglContextFinish();

    public static native void eglContextStart();

    public static native int getProtectionHeaderMaxLength();

    public static native int getProtectionMethod(byte[] bArr, int i, int[] iArr);

    public static native boolean glTick();

    public static native void gotApplicationSignatures(String str, int i);

    public static native void gotCallingPackage(String str, int i);

    public static native void gotIntentToEmit(String str, String str2);

    public static native void gyro(float f, float f2, float f3);

    public static native void handleSystemBindingEvent(String str);

    public static native void handleUIEvent(int i, String str);

    public static native void idle();

    private static native void initGL(int i, int i2);

    public static native boolean isDebug();

    public static native boolean jsKeepEngineRunning();

    public static native boolean jsKeyHandling();

    public static native void keyEvent(int i, int i2, int i3);

    public static native void magnetic(float f, float f2, float f3);

    public static native boolean needBinaryUpdate();

    public static native void nextUserUpdate();

    public static native void onBackPressed();

    public static native void onConnectivityChanged(int i);

    public static native void onLayoutChanged(int i, int i2);

    public static native void onPurchaseEvent(String str, String str2, String str3);

    public static native void onPushNotification(String str);

    private static native void pause();

    public static native void pauseGL();

    public static native void pauseGLRendering();

    public static native String readStringFromFile(String str);

    /* access modifiers changed from: private */
    public static native void resume();

    public static native void resumeGL();

    public static native void resumeGLRendering();

    public static native void resumedFromOthers(String str, String str2);

    private static native void setAPILevel(int i);

    public static native void setBootParams(String str);

    public static native void setGLExtensions(String str);

    public static native void setHasCustomProgressBar(boolean z);

    private static native boolean start(String str, String str2, String str3, String str4, String str5, boolean z);

    public static native void startWorker();

    private static native void stop();

    public static native void touch(int i, int i2, int i3, int i4);

    public static native void uiTick();

    public static native void updateGL(int i, int i2);

    public static native boolean validBoot();

    public static void setActivity(GameJSActivity activity) {
        sActivity = activity;
        NgMotion.setActivity(activity);
    }

    public static synchronized void loadNgGame() {
        synchronized (NgJNI.class) {
            try {
                System.loadLibrary("nggame");
            } catch (Error e) {
                throw new Error("Error loading " + System.mapLibraryName("nggame") + " on " + Build.MODEL, e);
            }
        }
    }

    public static void handleBack() {
        Log.d(TAG, "handleBack()");
        if (sActivity != null) {
            sActivity.getGLView().quitApplication();
        }
    }

    public static void enteredBootPhase(int phase) {
        switch (phase) {
            case 0:
                Log.d(TAG, "@@@ NgJNI enteredBootPhase initializing");
                SplashScreen.setProgressText(sActivity.getString(R.string.initialization_text) + sActivity.getString(R.string.initialization_text_lastchar));
                return;
            case 1:
                Log.d(TAG, "@@@ NgJNI enteredBootPhase preparing");
                SplashScreen.setProgressText(String.format(sActivity.getString(R.string.preparing_format), sActivity.getString(R.string.productName)));
                return;
            default:
                Log.e(TAG, "Unknown boot phase entered: " + phase);
                return;
        }
    }

    public static void startingGameProc() {
        Log.d(TAG, "native called starting game proc");
        mGLRunning = true;
        sActivity.gameProcStart();
    }

    public static void startingPrivProc() {
        Log.d(TAG, "native called starting privileged proc");
        sActivity.privProcStart();
    }

    public static void handleGameAdID(String GameAdID) {
        Log.d(TAG, "handleGameAdID()");
        sActivity.handleGameAdID(GameAdID);
    }

    public static void handleGLPause(boolean val) {
        GameJSView gv;
        if (mGLRunning == val) {
            mGLRunning = !val;
            NgEngine.getInstance().setGameRenderingPause(val);
            if (mGLRunning && sActivity != null && (gv = sActivity.getGLView()) != null) {
                gv.onJSResume();
            }
        }
    }

    public static boolean isGamePaused() {
        return mGamePaused;
    }

    public static void handleGamePause(boolean val) {
        Log.d(TAG, "Handle game pause" + val);
        mGamePaused = val;
    }

    public static void setGLDebug(boolean val) {
        Log.d(TAG, "setGLDebug");
        sActivity.setGLDebug(val);
    }

    public static void setOrientation(int orientation) {
        sActivity.setRequestedOrientation(orientation);
        NgOrientation.changeInterfaceOrientation(orientation);
    }

    public static int getWindowWidth() {
        try {
            return sActivity.getRootLayout().getWidth();
        } catch (Throwable th) {
            return -1;
        }
    }

    public static int getWindowHeight() {
        try {
            return sActivity.getRootLayout().getHeight();
        } catch (Throwable th) {
            return -1;
        }
    }

    public static void setGame(int procId, String game) {
        boolean z = false;
        Log.v(TAG, "Java Got game " + game + ". I mean java *received* the game. Java does not have game.");
        if (procId == -2) {
            SplashScreen.setProgressDoneBooting();
            mGLRunning = false;
        }
        SplashScreen.procWillStart(procId);
        Commands instance = Commands.getInstance(procId);
        if (procId == -1) {
            z = true;
        }
        instance.setGame(z, sActivity.getRepo(), game);
        GameJSActivity.setSandboxRoot(sActivity.getRepo() + "/" + game);
    }

    public static void launchActivity(String action, String extras) {
        sActivity.launchActivity(action, extras);
    }

    public static void launchService(String intent, String extras) {
        if (sActivity != null) {
            sActivity.launchService(intent, extras);
        }
    }

    /* JADX WARN: Type inference failed for: r1v2, types: [android.content.Context, com.ngmoco.gamejs.activity.GameJSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    public static void createShortcut(String name, String url, String icon_path) {
        Intent intentInvokedByShortcut = new Intent("android.intent.action.VIEW", Uri.parse(url));
        Log.i(TAG, "Shortcut.createShortcut called " + name + "," + url + "," + icon_path);
        createShortcut(sActivity, name, intentInvokedByShortcut, icon_path, null);
    }

    public static void createShortcut(Context c, String name, Intent intentInvokedByShortcut, String icon_path, Bitmap icon_bitmap) {
        Bitmap iconBitmap;
        if (icon_path.length() == 0) {
            if (icon_bitmap == null) {
                iconBitmap = SplashScreen.getMobageIconBitmap();
            } else {
                iconBitmap = icon_bitmap;
            }
            if (iconBitmap == null) {
                Log.e(TAG, "Could not get mobageicon bitmap from resources");
                return;
            }
        } else {
            iconBitmap = BitmapFactory.decodeFile(icon_path);
            if (iconBitmap == null) {
                Log.e(TAG, "Cannot decode icon file: " + icon_path);
                return;
            }
        }
        Intent intentToDeleteShortcut = new Intent();
        intentToDeleteShortcut.putExtra("android.intent.extra.shortcut.NAME", name);
        intentToDeleteShortcut.putExtra("android.intent.extra.shortcut.INTENT", intentInvokedByShortcut);
        intentToDeleteShortcut.setAction("com.android.launcher.action.UNINSTALL_SHORTCUT");
        c.sendBroadcast(intentToDeleteShortcut);
        Intent intentToCreateShortcut = new Intent();
        intentToCreateShortcut.putExtra("android.intent.extra.shortcut.INTENT", intentInvokedByShortcut);
        intentToCreateShortcut.putExtra("android.intent.extra.shortcut.NAME", name);
        intentToCreateShortcut.putExtra("android.intent.extra.shortcut.ICON", iconBitmap);
        intentToCreateShortcut.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
        c.sendBroadcast(intentToCreateShortcut);
    }

    public static void setProgressText(String text) {
        SplashScreen.setProgressText(text);
    }

    public static void setSplashVisible(int visible) {
        SplashScreen.setSplashVisible(visible != 0);
    }

    public static void setUpdateProgress(final float progress) {
        if (sActivity != null) {
            sActivity.runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass1 */

                public void run() {
                    SplashScreen.setUpdateProgress(progress);
                }
            });
        }
    }

    public static void setUpdateProgressVisible(int visible) {
        final boolean visibleFinal = visible != 0;
        try {
            sActivity.runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass2 */

                public void run() {
                    SplashScreen.setUpdateProgressVisible(visibleFinal);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "setUpdateProgressVisible exception", e);
        }
    }

    public static void setUpdateProgressBounds(final int x, final int y, final int w, final int h) {
        try {
            sActivity.runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass3 */

                public void run() {
                    SplashScreen.setUpdateProgressBounds(x, y, w, h);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "setUpdateProgressBounds exception", e);
        }
    }

    public static void showSDCardFullDialog() {
        try {
            SDCardFull = true;
            sActivity.runOnUiThread(new Runnable() {
                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass4 */

                public void run() {
                    NgJNI.sActivity.showSDCardFullDialog();
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "showSDCardFullDialog exception", e);
        }
    }

    public static boolean canLaunchURL(String uri) {
        try {
            if (sActivity.getPackageManager().resolveActivity(Intent.parseUri(uri, 0), 0) != null) {
                return true;
            }
            return false;
        } catch (URISyntaxException e) {
            return false;
        }
    }

    public static boolean launchURL(String url) {
        return sActivity.launchURL(url);
    }

    public static void getAppSignatures(String packageName, int callbackID) {
        try {
            PackageInfo packageInfo = sActivity.getPackageManager().getPackageInfo(packageName, 64);
            StringBuffer sigs = new StringBuffer();
            for (int i = 0; i < packageInfo.signatures.length; i++) {
                sigs.append(packageInfo.signatures[i].toCharsString());
                if (i < packageInfo.signatures.length - 1) {
                    sigs.append(",");
                }
            }
            gotApplicationSignatures(sigs.toString(), callbackID);
        } catch (PackageManager.NameNotFoundException e) {
            gotApplicationSignatures(ASConstants.kEmptyString, callbackID);
        }
    }

    public static void setCallingPackage(String packageName) {
        callingPackage = packageName;
    }

    public static void getCallingPackage(int callbackID) {
        gotCallingPackage(callingPackage == null ? ASConstants.kEmptyString : callingPackage, callbackID);
    }

    public static boolean getIsServiceRunning(int serviceEnum) {
        if (sActivity != null) {
            String className = IPCEmitter.getServiceClassName(serviceEnum);
            for (ActivityManager.RunningServiceInfo service2 : ((ActivityManager) sActivity.getApplicationContext().getSystemService("activity")).getRunningServices(100)) {
                if (service2.service.getClassName().equals(className)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static void pushPendingSystemBinding(String jsonStr) {
        if (jsonStr == null || jsonStr.length() < 1) {
            Log.e("NgJNI:PushPendingSystemBinding", "Null or Empty String.");
            return;
        }
        try {
            JSONObject parsed = new JSONObject(jsonStr);
            NgSystemBinding.processOneAction(parsed);
            Log.d("NgJNI:PushPendingSystemBinding", parsed.toString(3));
        } catch (JSONException e) {
            Log.e("NgJNI:PushPendingSystemBinding", "JSON error with " + jsonStr, e);
        }
    }

    public static void enableDownloadWakeLock() {
        Log.d(TAG, "enableDownloadWakeLock");
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass5 */

            public void run() {
                NgJNI.sActivity.getWindow().addFlags(Commands.CommandIDs.setVisibleInOrientations);
            }
        });
    }

    public static void disableDownloadWakeLock() {
        Log.d(TAG, "disableDownloadWakeLock");
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass6 */

            public void run() {
                NgJNI.sActivity.getWindow().clearFlags(Commands.CommandIDs.setVisibleInOrientations);
            }
        });
    }

    public static void showNetworkError() {
        final GameJSActivity x = GameJSActivity.getActivity();
        x.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass7 */

            /* JADX WARN: Type inference failed for: r2v0, types: [android.content.Context, com.ngmoco.gamejs.activity.GameJSActivity] */
            /* JADX WARNING: Unknown variable types count: 1 */
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(x);
                builder.setCancelable(false).setNegativeButton(x.getString(R.string.err_dialog_dismiss_button), new DialogInterface.OnClickListener() {
                    /* class com.ngmoco.gamejs.NgJNI.AnonymousClass7.AnonymousClass1 */

                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        System.exit(0);
                    }
                });
                AlertDialog error = builder.create();
                error.setMessage(x.getString(R.string.working_connection_msg));
                error.show();
            }
        });
    }

    public static void requestPurchase(final String productId) {
        if (productId == null || productId.length() < 1) {
            Log.e("NgJNI:requestPurchase", "Null or Empty productId String.");
            return;
        }
        Log.d(TAG, "requestPurchase with product ID: " + productId);
        final Runnable rous = new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass8 */

            public void run() {
                final String jsonstr = "{\"productId\": \"" + productId + "\"}";
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgJNI.AnonymousClass8.AnonymousClass1 */

                    public void run() {
                        NgJNI.onPurchaseEvent("failed:payments_not_supported", jsonstr, ASConstants.kEmptyString);
                    }
                });
            }
        };
        final Runnable ros = new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass9 */

            public void run() {
                NgJNI.sActivity.runOnUiThread(new Runnable() {
                    /* class com.ngmoco.gamejs.NgJNI.AnonymousClass9.AnonymousClass1 */

                    public void run() {
                        boolean requestOK = false;
                        if (productId != null) {
                            requestOK = GameJSActivity.gBillingService.requestPurchase(productId, null);
                        }
                        if (!requestOK) {
                            final String jsonstr = "{\"productId\": \"" + productId + "\"}";
                            Log.e(NgJNI.TAG, "BillingService.requestPurchase request creation failed");
                            NgEngine.getInstance().queueEvent(new Runnable() {
                                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass9.AnonymousClass1.AnonymousClass1 */

                                public void run() {
                                    NgJNI.onPurchaseEvent("failed:internal_error", jsonstr, ASConstants.kEmptyString);
                                }
                            });
                        }
                    }
                });
            }
        };
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass10 */

            public void run() {
                if (!GameJSActivity.gBillingService.checkBillingSupported(ros, rous)) {
                    final String jsonstr = "{\"productId\": \"" + productId + "\"}";
                    Log.e(NgJNI.TAG, "BillingService.checkBillingSupported request creation failed");
                    NgEngine.getInstance().queueEvent(new Runnable() {
                        /* class com.ngmoco.gamejs.NgJNI.AnonymousClass10.AnonymousClass1 */

                        public void run() {
                            NgJNI.onPurchaseEvent("failed:internal_error", jsonstr, ASConstants.kEmptyString);
                        }
                    });
                }
            }
        });
    }

    public static void requestPurchase2(String productId, String options) {
        requestPurchase(productId);
    }

    public static void setService(serviceToUse param) {
        service = param;
    }

    public static void iabInitService() {
        final Runnable rous = new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass11 */

            public void run() {
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgJNI.AnonymousClass11.AnonymousClass1 */

                    public void run() {
                        NgJNI.onPurchaseEvent("failed:payments_not_supported", ASConstants.kEmptyString, ASConstants.kEmptyString);
                    }
                });
            }
        };
        final Runnable ros = new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass12 */

            public void run() {
                Log.d(NgJNI.TAG, "iabInitService called back success");
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.NgJNI.AnonymousClass12.AnonymousClass1 */

                    public void run() {
                        NgJNI.onPurchaseEvent("initcheckdone", ASConstants.kEmptyString, ASConstants.kEmptyString);
                    }
                });
            }
        };
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass13 */

            public void run() {
                if (!GameJSActivity.gBillingService.checkBillingSupported(ros, rous)) {
                    Log.e(NgJNI.TAG, "BillingService.checkBillingSupported request creation failed");
                    NgEngine.getInstance().queueEvent(new Runnable() {
                        /* class com.ngmoco.gamejs.NgJNI.AnonymousClass13.AnonymousClass1 */

                        public void run() {
                            NgJNI.onPurchaseEvent("failed:internal_error", ASConstants.kEmptyString, ASConstants.kEmptyString);
                        }
                    });
                }
            }
        });
    }

    public static void sendOrderProcessedAck(final String id) {
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass14 */

            public void run() {
                GameJSActivity.gBillingService.sendOrderProcessedAck(id);
            }
        });
    }

    public static void iabInitService2(String options) {
        try {
            new JSONObject(options).getString("service");
        } catch (JSONException e) {
            Log.e("NgJNI:requestPurchase", "Error parsing JSON: " + e);
        }
        iabInitService();
    }

    public static void iabNoncePool(String nonceJson) {
        try {
            JSONArray nonceArray = new JSONArray(nonceJson);
            HashSet<Long> nonces = new HashSet<>();
            for (int i = 0; i < nonceArray.length(); i++) {
                long nonce = nonceArray.getLong(i);
                if (nonce > 0) {
                    nonces.add(Long.valueOf(nonce));
                }
            }
            Security.setKnownNonces(nonces);
        } catch (JSONException e) {
            Log.e(TAG, "iabNoncePool json exception: " + nonceJson);
        }
    }

    public static void scheduleLocalNotification(final String jsonstr, final int time, final int procId, final int callbackId) {
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass15 */

            public void run() {
                NotificationEmitter.scheduleLocal(jsonstr, time, procId, callbackId, NgJNI.sActivity);
            }
        });
    }

    public static void cancelAllLocalScheduledNotifications(final int procId) {
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass16 */

            public void run() {
                NotificationEmitter.cancelAllScheduledLocal(procId, NgJNI.sActivity);
            }
        });
    }

    public static void cancelScheduledLocalNotification(final String id) {
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass17 */

            public void run() {
                NotificationEmitter.cancelScheduledLocal(id, NgJNI.sActivity);
            }
        });
    }

    public static void getAllScheduledLocalNotifications(final int procId, final int callbackId) {
        sActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgJNI.AnonymousClass18 */

            public void run() {
                NotificationEmitter.getAllScheduledLocal(procId, callbackId, NgJNI.sActivity);
            }
        });
    }

    public static String getMemoryInfo(boolean common, boolean raw) {
        JSONException e;
        JSONObject obj = new JSONObject();
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        ((ActivityManager) sActivity.getSystemService("activity")).getMemoryInfo(memoryInfo);
        int pid = Process.myPid();
        String statm = ASConstants.kEmptyString;
        int virtualSize = 0;
        int residentSize = 0;
        try {
            statm = new BufferedReader(new FileReader("/proc/" + pid + "/statm"), 64).readLine();
            String[] rows = statm.split(" ");
            virtualSize = Integer.parseInt(rows[0]) * 4096;
            residentSize = Integer.parseInt(rows[1]) * 4096;
        } catch (IOException e2) {
            Log.e(TAG, "getMemoryInfo: failed to read /proc/pid/statm", e2);
        } catch (NumberFormatException e3) {
            Log.e(TAG, "getMemoryInfo: failed to parse /proc/pid/statm", e3);
        }
        if (common) {
            try {
                obj.put("totalFreeMemory", memoryInfo.availMem);
                obj.put("virtualSize", virtualSize);
                obj.put("residentSize", residentSize);
            } catch (JSONException e4) {
                e = e4;
                Log.e(TAG, "getMemoryInfo: failed to create json", e);
                return obj.toString();
            }
        }
        if (raw) {
            JSONObject rawObj = new JSONObject();
            try {
                obj.put("rawValues", rawObj);
                JSONObject hostObj = new JSONObject();
                hostObj.put("availMem", memoryInfo.availMem);
                hostObj.put("lowMemory", memoryInfo.lowMemory);
                hostObj.put("threshold", memoryInfo.threshold);
                rawObj.put("ActivityManager.getMemoryInfo", hostObj);
                rawObj.put("/proc/pid/statm", statm);
                Debug.MemoryInfo mi = new Debug.MemoryInfo();
                Debug.getMemoryInfo(mi);
                JSONObject miObj = new JSONObject();
                miObj.put("dalvikPss", mi.dalvikPss);
                miObj.put("dalvikPrivateDirty", mi.dalvikPrivateDirty);
                miObj.put("dalvikSharedDirty", mi.dalvikSharedDirty);
                miObj.put("nativePss", mi.nativePss);
                miObj.put("nativePrivateDirty", mi.nativePrivateDirty);
                miObj.put("nativeSharedDirty", mi.nativeSharedDirty);
                miObj.put("otherPss", mi.otherPss);
                miObj.put("otherPrivateDirty", mi.otherPrivateDirty);
                miObj.put("otherSharedDirty", mi.otherSharedDirty);
                rawObj.put("ActivityManager.getProcessMemoryInfo", miObj);
            } catch (JSONException e5) {
                e = e5;
                Log.e(TAG, "getMemoryInfo: failed to create json", e);
                return obj.toString();
            }
        }
        return obj.toString();
    }

    public static boolean beginJNI(String server, String entry, String apk, String info, JSONObject joe, boolean firstRun) {
        bStarted = start(server, entry, apk, info, joe.toString(), firstRun);
        Log.d(TAG, "Android APILevel = " + Build.VERSION.SDK_INT);
        setAPILevel(Build.VERSION.SDK_INT);
        if (!bStarted && !SDCardFull) {
            showNetworkError();
        }
        return bStarted;
    }

    public static void onPause() {
        NgEngine.getInstance().onPauseTick();
    }

    public static void pauseProcedure() {
        Commands.frameWillStart();
        pause();
        uiTick();
        Commands.frameFinished();
    }

    public static void onResume() {
        NgEngine.getInstance().onResumeTick();
        if (bStarted) {
            NgEngine.getInstance().queueEvent(new Runnable() {
                /* class com.ngmoco.gamejs.NgJNI.AnonymousClass19 */

                public void run() {
                    NgJNI.resume();
                }
            });
        }
    }

    public static void killActivity() {
        sActivity.finish();
    }

    public static void endJNI() {
        bStarted = false;
        stop();
    }

    public static void bgMe() {
        GameJSActivity.getActivity().moveTaskToBack(true);
    }

    public static synchronized void doClockTick() {
        synchronized (NgJNI.class) {
            Commands.frameWillStart();
            clockTick();
            Commands.frameFinished();
        }
    }

    public static void startWorkerThread() {
        Process.setThreadPriority(10);
        startWorker();
    }

    public static synchronized void doInitGL(int width, int height) {
        synchronized (NgJNI.class) {
            initGL(width, height);
        }
    }

    public static void startAccelerometer() {
        NgMotion.startAccelerometer();
    }

    public static void stopAccelerometer() {
        NgMotion.stopAccelerometer();
    }

    public static void startGyroscope() {
        NgMotion.startGyroscope();
    }

    public static void stopGyroscope() {
        NgMotion.stopGyroscope();
    }

    public static void startMagnetic() {
        NgMotion.startMagnetic();
    }

    public static void stopMagnetic() {
        NgMotion.stopMagnetic();
    }

    public static void adTapjoySendActionComplete(String actionId) {
        Log.d(TAG, "adTapjoySendActionComplete: " + actionId);
        TapjoyReporter.sendActionEvent(actionId);
    }

    public static void vibrate() {
        ((Vibrator) sActivity.getSystemService("vibrator")).vibrate(400);
    }
}
