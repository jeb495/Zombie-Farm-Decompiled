package com.ngmoco.gamejs;

import java.util.Observable;

/* compiled from: NgSensor */
class AccelObservable extends Observable {
    AccelObservable() {
    }

    public void setAccel() {
        setChanged();
    }
}
