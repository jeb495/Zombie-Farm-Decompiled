package com.ngmoco.gamejs;

public class Log {
    public static boolean enabled = false;

    public static void toggle(boolean bEnabled) {
        enabled = bEnabled;
    }

    public static void v(String tag, String string) {
        if (enabled) {
            android.util.Log.v(tag, string);
        }
    }

    public static void e(String tag, String string) {
        if (enabled) {
            android.util.Log.e(tag, string);
        }
    }

    public static void d(String tag, String string) {
        if (enabled) {
            android.util.Log.d(tag, string);
        }
    }

    public static void i(String tag, String string) {
        if (enabled) {
            android.util.Log.i(tag, string);
        }
    }

    public static void w(String tag, String string) {
        if (enabled) {
            android.util.Log.w(tag, string);
        }
    }

    public static void e(String tag, String string, Exception e) {
        if (enabled) {
            android.util.Log.e(tag, string, e);
        }
    }
}
