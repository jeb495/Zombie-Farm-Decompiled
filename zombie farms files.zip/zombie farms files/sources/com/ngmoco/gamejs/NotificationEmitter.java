package com.ngmoco.gamejs;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.RemoteViews;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.marketingapp.PackageApplication;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class NotificationEmitter {
    private static final int GAME_NOTIFICATION_ID = 20;
    private static final String ID = "id";
    public static final String LOCAL_NOTIFICATION_TAG = "localNotificationTag";
    private static final int MOBAGE_NOTIFICATION_ID = 2;
    private static final int NOTIFICATION_ID = 1;
    private static final String PAYLOAD = "payload";
    private static final int PRIV_NOTIFICATION_ID = 10;
    public static final String STYLE_LARGEICON = "largeIcon";
    public static final String STYLE_NORMAL = "normal";
    private static final String TAG = "NotificationEmitter";
    private static final String TIME = "time";
    public static final String TYPE = "type";
    public static final int TYPE_LOCAL = 0;
    public static final int TYPE_REMOTE = 1;

    public static native void didGetAllLocalNotifications(int i, int i2, String str);

    public static native boolean didReceiveNotification(int i, boolean z, String str);

    public static native void didScheduleLocalNotification(int i, int i2, String str);

    /* JADX DEBUG: Multi-variable search result rejected for r21v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x00cc  */
    /* JADX WARNING: Removed duplicated region for block: B:19:? A[RETURN, SYNTHETIC] */
    public static void scheduleLocal(String payload, int time, int procId, int callbackId, GameJSActivity activity) {
        Exception e;
        LocalNotificationDatabase lndb = null;
        String notificationId = null;
        Context context = activity.getApplicationContext();
        try {
            LocalNotificationDatabase lndb2 = new LocalNotificationDatabase(context);
            try {
                lndb2.open();
                notificationId = lndb2.insert(procId, payload, time);
                lndb2.close();
                if (notificationId != null) {
                    Intent intent = new Intent((Context) activity, (Class<?>) SystemEventReceiver.class);
                    intent.setAction(context.getPackageName() + "." + notificationId);
                    intent.putExtra(LOCAL_NOTIFICATION_TAG, "true").putExtra(ID, notificationId).putExtra(PAYLOAD, payload).putExtra(TIME, time).putExtra("type", 0);
                    JSONObject json = new JSONObject();
                    json.put(ID, notificationId).put(PAYLOAD, new JSONObject(payload)).put(TIME, time).put("type", 0);
                    ((AlarmManager) activity.getSystemService("alarm")).set(0, 1000 * ((long) time), PendingIntent.getBroadcast(activity, 0, intent, 0));
                    didScheduleLocalNotification(procId, callbackId, json.toString());
                    return;
                }
                Log.e(TAG, "Couldn't get a valid id from LocalNotificationDatabase, notification not set!");
            } catch (Exception e2) {
                e = e2;
                lndb = lndb2;
                Log.e(TAG, "Not setting alarm notification due to exception: ");
                e.printStackTrace();
                if (notificationId == null) {
                }
            }
        } catch (Exception e3) {
            e = e3;
            Log.e(TAG, "Not setting alarm notification due to exception: ");
            e.printStackTrace();
            if (notificationId == null) {
                if (lndb == null) {
                    lndb = new LocalNotificationDatabase(context);
                    lndb.open();
                }
                lndb.deleteNotification(notificationId);
                lndb.close();
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for r11v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    public static void cancelAllScheduledLocal(int procId, GameJSActivity activity) {
        Context context = activity.getApplicationContext();
        LocalNotificationDatabase lndb = new LocalNotificationDatabase(context);
        lndb.open();
        Intent intent = new Intent((Context) activity, (Class<?>) SystemEventReceiver.class);
        Cursor c = lndb.getAllNotifications(procId);
        if (c != null) {
            AlarmManager alarmManager = (AlarmManager) activity.getSystemService("alarm");
            do {
                intent.setAction(context.getPackageName() + "." + c.getString(0));
                alarmManager.cancel(PendingIntent.getBroadcast(activity, 0, intent, 0));
            } while (c.moveToNext());
            c.close();
            lndb.deleteAllNotifications(procId);
        }
        lndb.close();
    }

    /* JADX DEBUG: Multi-variable search result rejected for r10v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    public static void cancelScheduledLocal(String notificationId, GameJSActivity activity) {
        if (notificationId != null && !notificationId.equals(ASConstants.kEmptyString)) {
            Context context = activity.getApplicationContext();
            Intent intent = new Intent((Context) activity, (Class<?>) SystemEventReceiver.class);
            intent.setAction(context.getPackageName() + "." + notificationId);
            ((AlarmManager) activity.getSystemService("alarm")).cancel(PendingIntent.getBroadcast(activity, 0, intent, 0));
            LocalNotificationDatabase lndb = new LocalNotificationDatabase(context);
            lndb.open();
            try {
                lndb.deleteNotification(notificationId);
            } catch (Exception e) {
                Log.e(TAG, "Error when deleting notification with id: " + notificationId);
                e.printStackTrace();
            }
            lndb.close();
        }
    }

    public static void handleFiredLocal(Intent intent, Context context) {
        String notificationId = intent.getExtras().getString(ID);
        LocalNotificationDatabase lndb = new LocalNotificationDatabase(context);
        lndb.open();
        lndb.deleteNotification(notificationId);
        lndb.close();
        intent.putExtra("type", 0);
        GameJSActivity activity = GameJSActivity.getActivity();
        if (activity == null || activity.isPaused()) {
            showLocal(intent, context);
        } else {
            notificationOccurred(intent, false);
        }
    }

    public static void showLocal(Intent intent, Context context) {
        Log.d(TAG, "Processing remote notification: " + intent.toString());
        try {
            JSONObject jsonPayload = new JSONObject(intent.getStringExtra(PAYLOAD));
            String message = jsonPayload.getString("message");
            String tag = jsonPayload.optString("collapseKey", null);
            String style = jsonPayload.optString("style", null);
            String iconUrl = jsonPayload.optString("iconUrl", null);
            boolean sound = true;
            if (jsonPayload.has("sound")) {
                String soundStr = jsonPayload.getString("sound");
                sound = (soundStr == null || soundStr.length() == 0) ? false : true;
            }
            String contentTitle = context.getString(R.string.notification_title);
            int key = intent.getExtras().getString(ID).startsWith("-2") ? 20 : 10;
            Bundle extras = intent.getExtras();
            Class myMainClass = PackageApplication.class;
            if (context.getPackageManager().resolveActivity(new Intent(context, myMainClass), 0) == null) {
                myMainClass = GameJSActivity.class;
            }
            Intent notificationIntent = new Intent(context, myMainClass);
            notificationIntent.addFlags(276824064);
            notificationIntent.putExtras(extras);
            notify(context, style, tag, key, contentTitle, message, notificationIntent, 0, R.drawable.icon, iconUrl, sound);
        } catch (JSONException e) {
            Log.e(TAG, "Not showing notification due to exception: " + e);
        }
    }

    public static void showRemote(Context context, Intent intent) {
        String alert;
        String tag;
        boolean isMobagePush;
        int remote;
        Log.d(TAG, "Processing remote notification: " + intent.toString());
        String style = null;
        String iconUrl = null;
        boolean sound = true;
        try {
            Bundle extras = intent.getExtras();
            if (extras.containsKey(ID)) {
                Object remoteObj = extras.get("remote");
                if (remoteObj instanceof String) {
                    try {
                        remote = Integer.parseInt((String) remoteObj);
                    } catch (NumberFormatException e) {
                        remote = 1;
                    }
                } else {
                    remote = extras.getInt("remote", 1);
                }
                isMobagePush = (remote & 1) > 0;
                alert = extras.getString("message");
                style = extras.getString("style");
                iconUrl = extras.getString("iconUrl");
                tag = extras.getString("collapseKey");
                if (extras.containsKey("sound")) {
                    String soundStr = extras.getString("sound");
                    sound = (soundStr == null || soundStr.length() == 0) ? false : true;
                }
            } else {
                Log.d(TAG, "extras has aps");
                String payload = extras.getString(PAYLOAD);
                JSONObject aps = new JSONObject(payload).getJSONObject("aps");
                alert = aps.getString("alert");
                tag = aps.optString(ASConstants.kEmptyString, null);
                isMobagePush = payload.contains("mobage-ww-") && payload.contains("://") && payload.contains("ServiceUI/");
                if (aps.has("sound")) {
                    String soundStr2 = aps.getString("sound");
                    sound = (soundStr2 == null || soundStr2.length() == 0) ? false : true;
                }
            }
            int icon = isMobagePush ? R.drawable.mobicon : R.drawable.icon;
            CharSequence contentTitle = context.getString(isMobagePush ? R.string.mobage : R.string.notification_title);
            Class myMainClass = PackageApplication.class;
            if (context.getPackageManager().resolveActivity(new Intent(context, myMainClass), 0) == null) {
                myMainClass = GameJSActivity.class;
            }
            Intent notificationIntent = new Intent(context, myMainClass);
            notificationIntent.putExtras(extras);
            notificationIntent.putExtra("type", 1);
            notificationIntent.addFlags(8388608);
            notificationIntent.setAction("android.intent.action.MAIN");
            notify(context, style, tag, isMobagePush ? 2 : 1, contentTitle, alert, notificationIntent, 1342177280, icon, iconUrl, sound);
        } catch (JSONException e2) {
            Log.e(TAG, "Not showing notification due to exception: " + e2);
        }
    }

    private static void notify(Context context, String style, String tag, int key, CharSequence contentTitle, CharSequence message, Intent notificationIntent, int contentIntentFlags, int icon, String iconUrl, boolean sound) {
        int notificationLayout;
        String currentDateTimeString;
        Date when = new Date();
        if (STYLE_LARGEICON.equals(style)) {
            notificationLayout = R.layout.notification_largeicon;
            currentDateTimeString = DateFormat.getInstance().format(when);
        } else {
            notificationLayout = R.layout.notification_normal;
            currentDateTimeString = new SimpleDateFormat("h:mm a").format(new Date(System.currentTimeMillis()));
        }
        RemoteViews contentView = new RemoteViews(context.getPackageName(), notificationLayout);
        if (iconUrl == null || iconUrl.length() == 0) {
            contentView.setImageViewResource(R.id.notification_image, icon);
        } else {
            Bitmap bitmap = fetchImage(iconUrl);
            if (bitmap != null) {
                contentView.setImageViewBitmap(R.id.notification_image, bitmap);
            } else {
                Log.e(TAG, "Invalid icon URL: " + iconUrl);
                contentView.setImageViewResource(R.id.notification_image, icon);
            }
        }
        contentView.setTextViewText(R.id.notification_title, contentTitle);
        contentView.setTextViewText(R.id.notification_text, message);
        contentView.setTextViewText(R.id.notification_time, currentDateTimeString);
        PendingIntent contentIntent = PendingIntent.getActivity(context, notificationIntent.hashCode(), notificationIntent, 0);
        Notification notification = new Notification(icon, message, when.getTime());
        if (Build.VERSION.SDK_INT >= 9) {
            notification.contentView = contentView;
            notification.contentIntent = contentIntent;
        } else {
            notification.setLatestEventInfo(context.getApplicationContext(), contentTitle, message, contentIntent);
        }
        notification.flags |= 16;
        if (sound) {
            notification.defaults |= 1;
        }
        ((NotificationManager) context.getSystemService("notification")).notify(tag, key, notification);
    }

    private static Bitmap fetchImage(String imageUrlStr) {
        Exception e;
        MalformedURLException m;
        Bitmap bmImg = null;
        try {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(imageUrlStr).openConnection();
                conn.setDoInput(true);
                conn.connect();
                bmImg = BitmapFactory.decodeStream(conn.getInputStream());
            } catch (MalformedURLException e2) {
                m = e2;
                try {
                    Log.e(TAG, "Image URL is malformed: " + imageUrlStr);
                    m.printStackTrace();
                } catch (Exception e3) {
                    e = e3;
                }
                return bmImg;
            } catch (Exception e4) {
                e = e4;
                Log.e(TAG, "Image not found at URL: " + imageUrlStr);
                e.printStackTrace();
                return bmImg;
            }
        } catch (MalformedURLException e5) {
            m = e5;
            Log.e(TAG, "Image URL is malformed: " + imageUrlStr);
            m.printStackTrace();
            return bmImg;
        }
        return bmImg;
    }

    public static void getAllScheduledLocal(int procId, int callbackId, GameJSActivity activity) {
        try {
            JSONArray notifications = new JSONArray();
            LocalNotificationDatabase lndb = new LocalNotificationDatabase(activity.getApplicationContext());
            lndb.open();
            Cursor c = lndb.getAllNotifications(procId);
            if (c != null) {
                do {
                    JSONObject notification = new JSONObject();
                    notification.put(ID, c.getString(0));
                    notification.put(PAYLOAD, c.getString(1));
                    notification.put(TIME, c.getInt(2));
                    notification.put("type", 0);
                    notifications.put(notification);
                } while (c.moveToNext());
                c.close();
            }
            lndb.close();
            didGetAllLocalNotifications(procId, callbackId, notifications.toString());
        } catch (Exception e) {
            Log.e(TAG, "Can't create response for getAllScheduled. Error: " + e.getMessage());
        }
    }

    public static void notificationOccurred(Intent intent, boolean clicked) {
        int remote;
        try {
            Bundle extras = intent.getExtras();
            extras.remove("from");
            extras.remove("collapseKey");
            JSONObject json = new JSONObject();
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                if (value instanceof String) {
                    String valueStr = value.toString();
                    if (!valueStr.equals(ASConstants.kEmptyString)) {
                        if (!valueStr.startsWith(ASConstants.kBraceOpen) && !valueStr.startsWith("[")) {
                            valueStr = JSONObject.quote(valueStr);
                        }
                        value = new JSONTokener(valueStr).nextValue();
                    }
                }
                json.put(key, value);
            }
            boolean isPriv = false;
            if (extras.getInt("type") == 0) {
                isPriv = !new StringBuilder().append(ASConstants.kEmptyString).append(extras.getString(ID)).toString().startsWith("-2");
            } else if (extras.getInt("type") == 1) {
                if (extras.containsKey(ID)) {
                    Object remoteObj = extras.get("remote");
                    if (remoteObj instanceof String) {
                        try {
                            remote = Integer.parseInt((String) remoteObj);
                        } catch (NumberFormatException e) {
                            remote = 1;
                        }
                    } else {
                        remote = extras.getInt("remote", 1);
                    }
                    isPriv = (remote & 1) > 0;
                } else {
                    String payload = extras.getString(PAYLOAD);
                    isPriv = payload.contains("mobage-ww-") && payload.contains("://") && payload.contains("ServiceUI/");
                }
            }
            if (clicked) {
                json.put("clicked", true);
            }
            if (!didReceiveNotification(isPriv ? -1 : -2, clicked, json.toString())) {
                Log.d(TAG, "Notification not handled: " + json.toString());
            }
        } catch (Exception e2) {
            Log.e(TAG, "Can't create response for onNotificationReceived. Error: ");
            e2.printStackTrace();
        }
    }
}
