package com.ngmoco.gamejs;

import java.util.Observable;

/* compiled from: NgSensor */
class GyroObservable extends Observable {
    GyroObservable() {
    }

    public void setGyro() {
        setChanged();
    }
}
