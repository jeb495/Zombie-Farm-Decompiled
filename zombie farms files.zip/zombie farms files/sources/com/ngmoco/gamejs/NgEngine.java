package com.ngmoco.gamejs;

import com.flurry.android.Constants;
import com.ngmoco.gamejs.gl.GameJSView;
import java.io.IOException;
import java.io.InputStream;
import java.util.Stack;

public class NgEngine {
    public static final String TAG = NgEngine.class.getCanonicalName();
    private static volatile NgEngine sInstance = null;
    private static final long serialVersionUID = 743347467977326218L;
    private GameJSView mGLView;
    private Stack<Runnable> mPreQueue = new Stack<>();

    public static NgEngine getInstance() {
        if (sInstance == null) {
            sInstance = new NgEngine();
        }
        return sInstance;
    }

    private NgEngine() {
    }

    public void queueEvent(Runnable event) {
        if (this.mGLView == null || !this.mGLView.queueEvent(event)) {
            Log.e(TAG, "Could not Queue event to GLView, saving.");
            this.mPreQueue.add(event);
            return;
        }
        while (!this.mPreQueue.isEmpty()) {
            this.mGLView.queueEvent(this.mPreQueue.get(0));
            this.mPreQueue.remove(0);
        }
    }

    public void registerGLView(GameJSView v) {
        this.mGLView = v;
    }

    public void onPauseTick() {
        this.mGLView.onPauseTick();
    }

    public void onResumeTick() {
        this.mGLView.onResumeTick();
    }

    public void setGameRenderingPause(boolean val) {
        this.mGLView.setGameRenderingPause(val);
    }

    public static InputStream openProtectedStream(final InputStream is) throws IOException {
        if (!is.markSupported()) {
            Log.e(TAG, "the stream does not support marking");
            return is;
        }
        byte[] leadingBytes = new byte[NgJNI.getProtectionHeaderMaxLength()];
        is.mark(leadingBytes.length);
        int numLeadingBytes = is.read(leadingBytes);
        int[] headerLen = new int[1];
        final int algo = NgJNI.getProtectionMethod(leadingBytes, numLeadingBytes, headerLen);
        if (algo == 0) {
            is.reset();
            return is;
        }
        if (numLeadingBytes != headerLen[0]) {
            is.reset();
            is.read(leadingBytes, 0, headerLen[0]);
        }
        return new InputStream() {
            /* class com.ngmoco.gamejs.NgEngine.AnonymousClass1 */
            private int algo_ = algo;
            private InputStream is_ = is;

            @Override // java.io.InputStream
            public int read() throws IOException {
                byte[] b = new byte[1];
                if (read(b, 0, 1) == 1) {
                    return b[0] & Constants.UNKNOWN;
                }
                return -1;
            }

            @Override // java.io.InputStream
            public int read(byte[] b) throws IOException {
                return read(b, 0, b.length);
            }

            @Override // java.io.InputStream
            public int read(byte[] b, int off, int len) throws IOException {
                int ret = this.is_.read(b, off, len);
                if (ret > 0) {
                    NgJNI.decryptInPlace(this.algo_, b, off, ret);
                }
                return ret;
            }

            @Override // java.io.InputStream
            public long skip(long n) throws IOException {
                return this.is_.skip(n);
            }

            @Override // java.io.InputStream
            public int available() throws IOException {
                return this.is_.available();
            }

            @Override // java.io.Closeable, java.lang.AutoCloseable, java.io.InputStream
            public void close() throws IOException {
                this.is_.close();
            }

            public void mark(int readlimit) {
                this.is_.mark(readlimit);
            }

            @Override // java.io.InputStream
            public void reset() throws IOException {
                this.is_.reset();
            }

            public boolean markSupported() {
                return this.is_.markSupported();
            }
        };
    }
}
