package com.ngmoco.gamejs.service;

import android.app.IntentService;
import android.content.Intent;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;

public class NgUserUpdateService extends IntentService {
    private static final String TAG = NgUserUpdateService.class.getSimpleName();

    public NgUserUpdateService() {
        super(TAG);
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent arg0) {
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.service.NgUserUpdateService.AnonymousClass1 */

            public void run() {
                NgJNI.nextUserUpdate();
            }
        });
    }
}
