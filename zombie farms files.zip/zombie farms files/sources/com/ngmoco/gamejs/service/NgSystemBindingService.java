package com.ngmoco.gamejs.service;

import android.app.IntentService;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.provider.ContactsContract;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import java.util.Hashtable;
import java.util.LinkedList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class NgSystemBindingService extends IntentService {
    private static final String CMD_CLOSE_CONTACTS = "closecontacts";
    private static final String CMD_CONTACTS = "contacts";
    private static final String CMD_DEVICE_TOKEN = "devicetoken";
    private static final String CMD_DEVICE_TOKEN_CB = "devicetokenCB";
    private static final String CMD_MORE_CONTACTS = "morecontacts";
    private static final int CONTACTS_BATCH_SIZE = 20;
    public static final String EXTRA_CALLBACK_ID = "callbackId";
    public static final String EXTRA_CONTINUE_ID = "continueId";
    public static final String EXTRA_DEVICE_TOKEN = "devicetoken";
    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_REGISTRATION_ERROR = "regerror";
    private static final String TAG = NgSystemBindingService.class.getSimpleName();
    private static Hashtable<Integer, AddrBookState> gAddrBookStates = new Hashtable<>();
    private static int gContinueIdGenerator = 1000;
    private static Object gContinueIdGeneratorLock = new Object();
    private static LinkedList<Integer> gDeviceTokenCBs = new LinkedList<>();
    private static Object gPrefsLock = new Object();

    /* access modifiers changed from: private */
    public static class AddrBookState {
        public int mCount = 0;
        public Cursor mCursor;

        public AddrBookState(Cursor cursor) {
            this.mCursor = cursor;
        }
    }

    public NgSystemBindingService() {
        super(TAG);
    }

    /* access modifiers changed from: protected */
    public void onHandleIntent(Intent intent) {
        String name = intent.getExtras().getString(EXTRA_NAME);
        int callbackId = intent.getExtras().getInt(EXTRA_CALLBACK_ID);
        try {
            if (CMD_CONTACTS.equals(name) || CMD_MORE_CONTACTS.equals(name) || CMD_CLOSE_CONTACTS.equals(name)) {
                handleContacts(intent, name, callbackId);
            } else if ("devicetoken".equals(name)) {
                handleC2DMRegist(callbackId);
            } else if (CMD_DEVICE_TOKEN_CB.equals(name)) {
                handleC2DMToken(intent);
            } else {
                handleUnknown(callbackId);
            }
        } catch (JSONException e) {
            Log.e(TAG, "JSONException preparing contacts: " + e);
            postCallbackEvent("{ name: 'callback', success: false, error: 'JSON exception', callbackId: " + callbackId + ASConstants.kBraceClose);
        }
    }

    private void handleUnknown(int callbackId) throws JSONException {
        JSONObject json = new JSONObject();
        json.put("success", false);
        json.put(EXTRA_NAME, "callback");
        json.put(EXTRA_CALLBACK_ID, callbackId);
        postCallbackEvent(json.toString());
    }

    private void handleC2DMToken(Intent intent) throws JSONException {
        String deviceTokenValue = intent.getExtras().getString("devicetoken");
        JSONObject json = new JSONObject();
        json.put(EXTRA_NAME, "callback");
        json.put("callbackname", "devicetoken");
        if (deviceTokenValue != null) {
            Log.d(TAG, "Handling device token CB: " + deviceTokenValue);
            json.put("success", true);
            json.put("devicetoken", deviceTokenValue);
        } else {
            Log.d(TAG, "Got error during c2dm reg");
            json.put("success", false);
            json.put(JSWebViewAdapter.Events.ERROR, intent.getExtras().getString(EXTRA_REGISTRATION_ERROR));
        }
        synchronized (gDeviceTokenCBs) {
            while (true) {
                Integer cbId = gDeviceTokenCBs.poll();
                if (cbId != null) {
                    json.put(EXTRA_CALLBACK_ID, cbId);
                    postCallbackEvent(json.toString());
                }
            }
        }
    }

    private void handleC2DMRegist(int callbackId) {
        Log.d(TAG, "Invoking Android c2dm registration");
        Intent registrationIntent = new Intent("com.google.android.c2dm.intent.REGISTER");
        registrationIntent.putExtra("app", PendingIntent.getBroadcast(this, 0, new Intent(), 0));
        registrationIntent.putExtra("sender", getString(R.string.c2dm_sender_id));
        startService(registrationIntent);
        synchronized (gDeviceTokenCBs) {
            gDeviceTokenCBs.offer(Integer.valueOf(callbackId));
        }
    }

    private void handleContacts(Intent intent, final String name, final int callbackId) {
        final int contId = intent.getExtras().containsKey(EXTRA_CONTINUE_ID) ? intent.getExtras().getInt(EXTRA_CONTINUE_ID) : -1;
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.service.NgSystemBindingService.AnonymousClass1 */

            public void run() {
                try {
                    JSONObject jsonobj = NgSystemBindingService.getContacts(this, name, contId);
                    jsonobj.put("callbackname", NgSystemBindingService.CMD_CONTACTS);
                    jsonobj.put(NgSystemBindingService.EXTRA_NAME, "callback");
                    jsonobj.put(NgSystemBindingService.EXTRA_CALLBACK_ID, callbackId);
                    NgSystemBindingService.this.postCallbackEvent(jsonobj.toString());
                } catch (JSONException e) {
                    Log.e(NgSystemBindingService.TAG, "JSONException preparing contacts: " + e);
                    NgSystemBindingService.this.postCallbackEvent("{ name: 'callback', success: false, error: 'JSON exception', callbackId: " + callbackId + ASConstants.kBraceClose);
                }
            }
        });
    }

    /* access modifiers changed from: private */
    public static JSONObject getContacts(Context ctx, String name, int contId) throws JSONException {
        AddrBookState aState;
        JSONArray contacts = new JSONArray();
        JSONObject retval = new JSONObject();
        retval.put("list", contacts);
        retval.put("success", true);
        boolean closeContacts = CMD_CLOSE_CONTACTS.equals(name);
        if (CMD_CONTACTS.equals(name)) {
            synchronized (gContinueIdGeneratorLock) {
                contId = gContinueIdGenerator;
                gContinueIdGenerator++;
            }
            aState = new AddrBookState(ctx.getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null));
            gAddrBookStates.put(Integer.valueOf(contId), aState);
        } else {
            aState = gAddrBookStates.get(Integer.valueOf(contId));
            if (aState == null || aState.mCursor == null) {
                retval.put("success", false);
                retval.put(JSWebViewAdapter.Events.ERROR, "ERROR: Contacts - closed or non-existing ResultSet");
                return retval;
            }
        }
        retval.put(EXTRA_CONTINUE_ID, contId);
        synchronized (aState) {
            if (CMD_CONTACTS.equals(name) || CMD_MORE_CONTACTS.equals(name)) {
                int currCount = 0;
                while (currCount < 20 && !closeContacts) {
                    JSONObject oneContact = getNextContact(ctx, aState.mCursor);
                    if (oneContact != null) {
                        contacts.put(oneContact);
                        aState.mCount++;
                        currCount++;
                    } else {
                        closeContacts = true;
                    }
                }
            }
            if (closeContacts) {
                if (!CMD_CLOSE_CONTACTS.equals(name)) {
                    retval.put("total", aState.mCount);
                }
                aState.mCursor.close();
                aState.mCursor = null;
                retval.put("rsclosed", true);
            }
        }
        if (closeContacts) {
            gAddrBookStates.remove(Integer.valueOf(contId));
        }
        return retval;
    }

    private static JSONObject getNextContact(Context ctx, Cursor cursor) throws JSONException {
        if (!cursor.moveToNext()) {
            return null;
        }
        String contactId = cursor.getString(cursor.getColumnIndex("_id"));
        JSONArray jsonEmails = new JSONArray();
        Cursor emails = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Email.CONTENT_URI, null, "contact_id = " + contactId, null, null);
        while (emails.moveToNext()) {
            jsonEmails.put(emails.getString(emails.getColumnIndex("data1")).toLowerCase());
        }
        emails.close();
        JSONObject oneContact = new JSONObject();
        oneContact.put("lowercaseEmails", jsonEmails);
        oneContact.put("displayName", cursor.getString(cursor.getColumnIndex("display_name")));
        JSONArray jsonPhones = new JSONArray();
        Cursor phones = ctx.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id = " + contactId, null, null);
        while (phones.moveToNext()) {
            jsonPhones.put(phones.getString(phones.getColumnIndex("data1")));
        }
        phones.close();
        if (jsonPhones.length() <= 0) {
            return oneContact;
        }
        oneContact.put("phoneNumbers", jsonPhones);
        return oneContact;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void postCallbackEvent(final String retval) {
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.service.NgSystemBindingService.AnonymousClass2 */

            public void run() {
                NgJNI.handleSystemBindingEvent(retval);
            }
        });
    }
}
