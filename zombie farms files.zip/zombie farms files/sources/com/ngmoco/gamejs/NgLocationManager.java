package com.ngmoco.gamejs;

import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import com.ngmoco.gamejs.activity.GameJSActivity;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class NgLocationManager {
    static final int ALTITUDE = 4;
    static final double ALTITUDE_THRESHOLD = 0.001d;
    static final int HEADING = 8;
    static final int HIGH = 2;
    static final int LATITUDE = 1;
    static final double LATITUDE_THRESHOLD = 9.0E-5d;
    static final int LONGITUDE = 2;
    static final double LONGITUDE_THRESHOLD = 9.0E-5d;
    static final int LOW = 0;
    static final int MEDIUM = 1;
    static final String TAG = "NgLocationManager";
    private Observer _accelListener;
    private Criteria _criteria;
    private float _distanceFilter;
    private int _elements;
    private Location _lastLocation;
    private LocationListener _locationListener;
    private Observer _magneticListener;
    private boolean _updating = false;

    public native void didUpdateHeading(double d, double d2, double d3, double d4);

    public native void didUpdateLocation(double d, double d2, double d3, double d4, double d5);

    public void setCriteria(int accuracy, int elements) {
        this._elements = elements;
        this._criteria = new Criteria();
        switch (accuracy) {
            case 0:
                this._criteria.setAccuracy(2);
                this._criteria.setPowerRequirement(1);
                break;
            case 1:
                this._criteria.setAccuracy(1);
                this._criteria.setPowerRequirement(2);
                break;
            default:
                this._criteria.setAccuracy(1);
                this._criteria.setPowerRequirement(3);
                break;
        }
        this._distanceFilter = 0.0f;
        if (this._updating) {
            stopUpdating();
            startUpdating();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private boolean toNotifyLocationUpdate(Location location) {
        if (this._lastLocation == null) {
            return true;
        }
        return ((this._elements & 1) != 0 && (Math.abs(this._lastLocation.getLatitude() - location.getLatitude()) > 9.0E-5d ? 1 : (Math.abs(this._lastLocation.getLatitude() - location.getLatitude()) == 9.0E-5d ? 0 : -1)) >= 0) || ((this._elements & 2) != 0 && (Math.abs(this._lastLocation.getLongitude() - location.getLongitude()) > 9.0E-5d ? 1 : (Math.abs(this._lastLocation.getLongitude() - location.getLongitude()) == 9.0E-5d ? 0 : -1)) >= 0) || ((this._elements & 4) != 0 && (Math.abs(this._lastLocation.getAltitude() - location.getAltitude()) > ALTITUDE_THRESHOLD ? 1 : (Math.abs(this._lastLocation.getAltitude() - location.getAltitude()) == ALTITUDE_THRESHOLD ? 0 : -1)) >= 0);
    }

    private void createListener() {
        this._locationListener = new LocationListener() {
            /* class com.ngmoco.gamejs.NgLocationManager.AnonymousClass1 */

            public void onLocationChanged(Location location) {
                if (NgLocationManager.this.toNotifyLocationUpdate(location)) {
                    NgLocationManager.this.didUpdateLocation((double) (location.getTime() / 1000), location.getLatitude(), location.getLongitude(), location.getAltitude(), (double) location.getAccuracy());
                }
                NgLocationManager.this._lastLocation = location;
            }

            public void onProviderDisabled(String provider) {
            }

            public void onProviderEnabled(String provider) {
            }

            public void onStatusChanged(String provider, int status, Bundle extras) {
            }
        };
        this._accelListener = new Observer() {
            /* class com.ngmoco.gamejs.NgLocationManager.AnonymousClass2 */

            public void update(Observable o, Object arg) {
            }
        };
        this._magneticListener = new Observer() {
            /* class com.ngmoco.gamejs.NgLocationManager.AnonymousClass3 */

            public void update(Observable o, Object arg) {
                Float azimuth = (Float) arg;
                if (azimuth != null) {
                    NgLocationManager.this.updateHeading((double) azimuth.floatValue());
                }
            }
        };
    }

    NgLocationManager() {
        createListener();
        setCriteria(2, 15);
    }

    private boolean toIgnoreLocation() {
        return (this._elements & 1) == 0 && (this._elements & 2) == 0 && (this._elements & 4) == 0;
    }

    private void startUpdatingLocation() {
        if (!toIgnoreLocation()) {
            LocationManager locationManager = (LocationManager) GameJSActivity.getActivity().getSystemService("location");
            List<String> providers = locationManager.getProviders(true);
            if (!providers.isEmpty()) {
                for (String providerName : providers) {
                    locationManager.requestLocationUpdates(providerName, 0, this._distanceFilter, this._locationListener, Looper.getMainLooper());
                    Location loc = locationManager.getLastKnownLocation(providerName);
                    if (this._lastLocation == null) {
                        this._lastLocation = loc;
                    }
                }
                if (!(this._lastLocation == null || toIgnoreLocation())) {
                    didUpdateLocation((double) (this._lastLocation.getTime() / 1000), this._lastLocation.getLatitude(), this._lastLocation.getLongitude(), this._lastLocation.getAltitude(), (double) this._lastLocation.getAccuracy());
                }
            }
        }
    }

    private void startUpdatingMagnetic() {
        if ((this._elements & 8) != 0) {
            NgSensor sensor = GameJSActivity.getActivity().getSensor();
            sensor.addAccelObserver(this._accelListener);
            sensor.addMagneticObserver(this._magneticListener);
        }
    }

    public void startUpdating() {
        startUpdatingLocation();
        startUpdatingMagnetic();
        this._updating = true;
    }

    private void stopUpdatingLocation() {
        if (!toIgnoreLocation() && this._lastLocation != null) {
            ((LocationManager) GameJSActivity.getActivity().getSystemService("location")).removeUpdates(this._locationListener);
        }
    }

    private void stopUpdatingMagnetic() {
        if ((this._elements & 8) != 0) {
            NgSensor sensor = GameJSActivity.getActivity().getSensor();
            sensor.removeAccelObserver(this._accelListener);
            sensor.removeMagneticObserver(this._magneticListener);
        }
    }

    public void stopUpdating() {
        if (this._updating) {
            stopUpdatingLocation();
            stopUpdatingMagnetic();
            this._updating = false;
        }
    }

    public void updateHeading(final double azimuth) {
        if ((this._elements & 8) != 0) {
            NgEngine.getInstance().queueEvent(new Runnable() {
                /* class com.ngmoco.gamejs.NgLocationManager.AnonymousClass4 */

                public void run() {
                    NgLocationManager.this.didUpdateHeading((1.0d * ((double) System.currentTimeMillis())) / 1000.0d, azimuth, -1.0d, 0.0d);
                }
            });
        }
    }
}
