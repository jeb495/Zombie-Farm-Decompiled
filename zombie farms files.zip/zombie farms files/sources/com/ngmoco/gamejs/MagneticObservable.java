package com.ngmoco.gamejs;

import java.util.Observable;

/* compiled from: NgSensor */
class MagneticObservable extends Observable {
    MagneticObservable() {
    }

    public void setAzimuth() {
        setChanged();
    }
}
