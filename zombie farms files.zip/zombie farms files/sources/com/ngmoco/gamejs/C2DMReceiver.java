package com.ngmoco.gamejs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;

public class C2DMReceiver extends BroadcastReceiver {
    private static final String TAG = C2DMReceiver.class.getSimpleName();

    public static final class Flags {
        public static final int REMOTE_PAYLOAD = 2;
        public static final int SERVICE = 1;
    }

    private void handleRegistration(Context context, Intent intent) {
        String registration = intent.getStringExtra("registration_id");
        String error = intent.getStringExtra(JSWebViewAdapter.Events.ERROR);
        if (error != null) {
            Log.e(TAG, "Registration Error: " + error);
            Intent intent2 = new Intent(context, NgSystemBindingService.class);
            intent2.putExtra(NgSystemBindingService.EXTRA_NAME, "devicetokenCB");
            intent2.putExtra(NgSystemBindingService.EXTRA_REGISTRATION_ERROR, error);
            context.startService(intent2);
        } else if (intent.getStringExtra("unregistered") != null) {
            Log.d(TAG, "Unregistration is complete.");
        } else if (registration != null) {
            Log.d(TAG, "Received registration ID: " + registration);
            Intent intent22 = new Intent(context, NgSystemBindingService.class);
            intent22.putExtra(NgSystemBindingService.EXTRA_NAME, "devicetokenCB");
            intent22.putExtra(NgSystemBindingService.EXTRA_DEVICE_TOKEN, registration);
            context.startService(intent22);
        }
    }

    public final void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.google.android.c2dm.intent.REGISTRATION")) {
            handleRegistration(context, intent);
        } else if (intent.getAction().equals("com.google.android.c2dm.intent.RECEIVE")) {
            intent.putExtra("type", 1);
            GameJSActivity activity = GameJSActivity.getActivity();
            if (activity == null || activity.isPaused()) {
                NotificationEmitter.showRemote(context, intent);
            } else {
                NotificationEmitter.notificationOccurred(intent, false);
            }
        }
        if (isOrderedBroadcast()) {
            setResult(-1, null, null);
        }
    }
}
