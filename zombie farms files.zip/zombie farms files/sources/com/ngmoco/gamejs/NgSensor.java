package com.ngmoco.gamejs;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.util.List;
import java.util.Observer;

public class NgSensor implements SensorEventListener {
    protected static final int ACCEL_X = 0;
    protected static final int ACCEL_Y = 1;
    protected static final int ACCEL_Z = 2;
    private static final String TAG = "JSActivity";
    protected static Sensor sAccelerometer;
    protected static Sensor sGyroscope;
    protected static boolean sHaveA11r = false;
    protected static Sensor sMagnetic;
    private static SensorManager sSensors;
    private AccelObservable mAccelObservers;
    private final Activity mActivity;
    private float[] mGeoMags = new float[3];
    private float[] mGravs = new float[3];
    private GyroObservable mGyroObservers;
    private MagneticObservable mMagneticObservers;
    private float[] mOrientation = new float[3];
    private float[] mRemapedRotationM = new float[9];
    private float[] mRotationM = new float[9];

    public NgSensor(Activity activity) {
        this.mActivity = activity;
        sSensors = (SensorManager) activity.getSystemService("sensor");
        this.mAccelObservers = new AccelObservable();
        this.mGyroObservers = new GyroObservable();
        this.mMagneticObservers = new MagneticObservable();
    }

    public void pause() {
        if (sHaveA11r && this.mAccelObservers.countObservers() > 0) {
            sSensors.unregisterListener(this, sAccelerometer);
        }
        if (sGyroscope != null && this.mGyroObservers.countObservers() > 0) {
            sSensors.unregisterListener(this, sGyroscope);
        }
        if (sMagnetic != null && this.mMagneticObservers.countObservers() > 0) {
            sSensors.unregisterListener(this, sMagnetic);
        }
    }

    public void resume() {
        List<Sensor> l = sSensors.getSensorList(1);
        sHaveA11r = l.size() > 0;
        if (sHaveA11r) {
            sAccelerometer = l.get(0);
            if (this.mAccelObservers.countObservers() > 0) {
                sSensors.registerListener(this, sAccelerometer, 1);
            }
        }
        sGyroscope = sSensors.getDefaultSensor(4);
        if (sGyroscope == null || this.mGyroObservers.countObservers() <= 0) {
            Log.d(TAG, "gyroscope not found on this device.");
        } else {
            sSensors.registerListener(this, sGyroscope, 1);
        }
        sMagnetic = sSensors.getDefaultSensor(2);
        if (sMagnetic == null || this.mMagneticObservers.countObservers() <= 0) {
            Log.d(TAG, "geomagnetic sensor not found on this device.");
        } else {
            sSensors.registerListener(this, sMagnetic, 1);
        }
    }

    public void addAccelObserver(Observer observer) {
        this.mAccelObservers.addObserver(observer);
        if (this.mAccelObservers.countObservers() == 1) {
            startAccelerometer();
        }
    }

    public void removeAccelObserver(Observer observer) {
        this.mAccelObservers.deleteObserver(observer);
        if (this.mAccelObservers.countObservers() == 0) {
            stopAccelerometer();
        }
    }

    public void addGyroObserver(Observer observer) {
        this.mGyroObservers.addObserver(observer);
        if (this.mGyroObservers.countObservers() == 1) {
            startGyroscope();
        }
    }

    public void removeGyroObserver(Observer observer) {
        this.mGyroObservers.deleteObserver(observer);
        if (this.mGyroObservers.countObservers() == 0) {
            stopGyroscope();
        }
    }

    public void addMagneticObserver(Observer observer) {
        this.mMagneticObservers.addObserver(observer);
        if (this.mMagneticObservers.countObservers() == 1) {
            startMagnetic();
        }
    }

    public void removeMagneticObserver(Observer observer) {
        this.mMagneticObservers.deleteObserver(observer);
        if (this.mMagneticObservers.countObservers() == 0) {
            stopMagnetic();
        }
    }

    private void startAccelerometer() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass1 */

            public void run() {
                if (NgSensor.sAccelerometer != null) {
                    NgSensor.sSensors.registerListener(this, NgSensor.sAccelerometer, 1);
                }
            }
        });
    }

    private void stopAccelerometer() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass2 */

            public void run() {
                if (NgSensor.sAccelerometer != null) {
                    NgSensor.sSensors.unregisterListener(this, NgSensor.sAccelerometer);
                }
            }
        });
    }

    private void startGyroscope() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass3 */

            public void run() {
                if (NgSensor.sGyroscope != null) {
                    NgSensor.sSensors.registerListener(this, NgSensor.sGyroscope, 1);
                }
            }
        });
    }

    private void stopGyroscope() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass4 */

            public void run() {
                if (NgSensor.sGyroscope != null) {
                    NgSensor.sSensors.unregisterListener(this, NgSensor.sGyroscope);
                }
            }
        });
    }

    private void startMagnetic() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass5 */

            public void run() {
                if (NgSensor.sMagnetic != null) {
                    NgSensor.sSensors.registerListener(this, NgSensor.sMagnetic, 1);
                }
            }
        });
    }

    private void stopMagnetic() {
        this.mActivity.runOnUiThread(new Runnable() {
            /* class com.ngmoco.gamejs.NgSensor.AnonymousClass6 */

            public void run() {
                if (NgSensor.sMagnetic != null) {
                    NgSensor.sSensors.unregisterListener(this, NgSensor.sMagnetic);
                }
            }
        });
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    public void onSensorChanged(SensorEvent event) {
        int sensorType = event.sensor.getType();
        if (sensorType == 1) {
            for (int i = 0; i < 3; i++) {
                this.mGravs[i] = event.values[i];
            }
            this.mAccelObservers.setAccel();
            this.mAccelObservers.notifyObservers(this.mGravs);
        } else if (sensorType == 4) {
            float[] gyro = {event.values[0], event.values[1], event.values[2]};
            this.mGyroObservers.setGyro();
            this.mGyroObservers.notifyObservers(gyro);
        } else if (sensorType == 2) {
            for (int i2 = 0; i2 < 3; i2++) {
                this.mGeoMags[i2] = event.values[i2];
            }
            if (SensorManager.getRotationMatrix(this.mRotationM, null, this.mGravs, this.mGeoMags)) {
                SensorManager.remapCoordinateSystem(this.mRotationM, 1, 3, this.mRemapedRotationM);
                SensorManager.getOrientation(this.mRemapedRotationM, this.mOrientation);
                float azimuth = (((float) Math.toDegrees((double) this.mOrientation[0])) + 360.0f) % 360.0f;
                this.mMagneticObservers.setAzimuth();
                this.mMagneticObservers.notifyObservers(new Float(azimuth));
            }
        } else {
            Log.d(TAG, "unknown sensor");
        }
    }

    public static boolean hasCompass() {
        return !sSensors.getSensorList(2).isEmpty();
    }

    public static boolean hasGyro() {
        return !sSensors.getSensorList(4).isEmpty();
    }

    public static boolean hasAccel() {
        return !sSensors.getSensorList(1).isEmpty();
    }
}
