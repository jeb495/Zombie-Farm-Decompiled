package com.ngmoco.gamejs;

import com.android.adsymp.core.ASConstants;

public class IPCEmitter {
    private final String TAG = "IPCEmitter";

    public static class Service {
        public static final int SystemDownloadProvider = 1;
    }

    public static String getServiceClassName(int serviceEnum) {
        switch (serviceEnum) {
            case 1:
                return "com.android.providers.downloads.DownloadService";
            default:
                return ASConstants.kEmptyString;
        }
    }
}
