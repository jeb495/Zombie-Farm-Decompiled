package com.ngmoco.gamejs;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.SoundPool;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

public abstract class NgMediaSource {
    private static final String TAG = "NgMediaSource";
    private static File sTempDir = null;

    /* access modifiers changed from: package-private */
    public abstract void close() throws IOException;

    /* access modifiers changed from: package-private */
    public abstract int load(SoundPool soundPool, int i) throws IOException;

    /* access modifiers changed from: package-private */
    public abstract void setSource(MediaPlayer mediaPlayer) throws IOException;

    public static void init(Context context) {
        if (sTempDir == null) {
            sTempDir = context.getFileStreamPath(".media");
            if (sTempDir.exists()) {
                String[] files = sTempDir.list();
                if (!(files == null || files.length == 0)) {
                    for (String str : files) {
                        File file = new File(sTempDir, str);
                        if (!file.delete()) {
                            Log.w(TAG, "failed to remove file: " + file.toString());
                        }
                    }
                }
            } else if (!sTempDir.mkdirs()) {
                Log.e(TAG, "failed to create temporary directory");
            }
        }
    }

    static NgMediaSource createFromPath(final String path) {
        return new NgMediaSource() {
            /* class com.ngmoco.gamejs.NgMediaSource.AnonymousClass1 */

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public void setSource(MediaPlayer mediaPlayer) throws IOException {
                mediaPlayer.setDataSource(path);
            }

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public int load(SoundPool pool, int priority) {
                return pool.load(path, 1);
            }

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public void close() {
            }
        };
    }

    static NgMediaSource createFromBytes(byte[] data) throws IOException {
        final File file = File.createTempFile("ngmusic-", ".bin", sTempDir);
        file.deleteOnExit();
        final RandomAccessFile fileIO = new RandomAccessFile(file, "rws");
        fileIO.write(data);
        fileIO.getFD().sync();
        final int length = data.length;
        return new NgMediaSource() {
            /* class com.ngmoco.gamejs.NgMediaSource.AnonymousClass2 */

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public void setSource(MediaPlayer mediaPlayer) throws IOException {
                fileIO.seek(0);
                mediaPlayer.setDataSource(fileIO.getFD());
            }

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public int load(SoundPool pool, int priority) throws IOException {
                return pool.load(fileIO.getFD(), 0, (long) length, priority);
            }

            /* access modifiers changed from: package-private */
            @Override // com.ngmoco.gamejs.NgMediaSource
            public void close() throws IOException {
                fileIO.close();
                if (!file.delete()) {
                    throw new IOException("failed to unlink temporary file");
                }
            }
        };
    }
}
