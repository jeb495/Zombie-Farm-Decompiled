package com.ngmoco.gamejs;

import android.content.Intent;
import android.media.AudioManager;
import com.ngmoco.gamejs.activity.GameJSActivity;
import java.util.HashMap;

public class NgMusic {
    private static final int PAUSE = 2;
    private static final int PLAY = 1;
    private static final int STOP = 0;
    public static final String TAG = "NgMusic";
    private static final String mMediaService = "com.android.music.musicservicecommand";
    private static volatile NgMusic sInstance = null;
    private static Boolean suspend = Boolean.FALSE;
    private static final Object suspendLock = new Object();
    private HashMap<Integer, NgMusicPlayer> players = new HashMap<>();

    private static native void changeState(int i, int i2);

    static NgMusic getInstance() {
        if (sInstance == null) {
            sInstance = new NgMusic();
        }
        return sInstance;
    }

    private NgMusic() {
    }

    private NgMusicPlayer player(int id) throws Exception {
        NgMusicPlayer player = this.players.get(new Integer(id));
        if (player != null) {
            return player;
        }
        throw new Exception(String.format("NgMusic: no player found for id:%d", Integer.valueOf(id)));
    }

    public static void reset(int id) {
        try {
            getInstance().player(id).reset();
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void play(int id) {
        try {
            getInstance().player(id).play();
            changeState(id, 1);
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void stop(int id) {
        try {
            getInstance().player(id).stop();
            changeState(id, 0);
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void pause(int id) {
        Log.d(TAG, "pause 1");
        try {
            Log.d(TAG, "pause 2");
            getInstance().player(id).pause();
            changeState(id, 2);
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void setLoop(int id, boolean toLoop) {
        try {
            getInstance().player(id).setLoop(toLoop);
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void setPath(int id, String path) {
        try {
            getInstance().player(id).setSource(NgMediaSource.createFromPath(path));
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static void setBytes(int id, byte[] data) {
        try {
            getInstance().player(id).setSource(NgMediaSource.createFromBytes(data));
        } catch (Exception e) {
            Log.d(TAG, "failed to set music: " + e.getMessage());
        }
    }

    public static void setVolume(int id, float volume) {
        try {
            getInstance().player(id).setVolume(volume);
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
        }
    }

    public static int createPlayer() {
        NgMusicPlayer player = new NgMusicPlayer();
        int hashCode = player.hashCode();
        Log.d(TAG, String.format("player hash:%d", Integer.valueOf(hashCode)));
        getInstance().players.put(new Integer(hashCode), player);
        return hashCode;
    }

    public static void removePlayer(int hashCode) {
        getInstance().players.remove(new Integer(hashCode));
    }

    public static void suspendMusic() {
        synchronized (suspendLock) {
            for (NgMusicPlayer player : getInstance().players.values()) {
                player.suspend();
            }
            suspend = Boolean.TRUE;
        }
    }

    public static void pauseUserMusic() {
        if (((AudioManager) GameJSActivity.getActivity().getApplicationContext().getSystemService("audio")).isMusicActive()) {
            Intent i = new Intent(mMediaService);
            i.putExtra("command", "pause");
            GameJSActivity.getActivity().sendBroadcast(i);
        }
    }

    public static void resumeMusic() {
        synchronized (suspendLock) {
            for (NgMusicPlayer player : getInstance().players.values()) {
                player.resume();
            }
            suspend = Boolean.FALSE;
        }
    }

    public static int getCurrentPosition(int id) {
        try {
            return getInstance().player(id).getCurrentPosition();
        } catch (Exception ex) {
            Log.d(TAG, ex.getMessage());
            return 0;
        }
    }
}
