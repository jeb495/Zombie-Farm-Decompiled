package com.ngmoco.gamejs.gl;

import android.content.Context;
import android.content.pm.ConfigurationInfo;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.activity.JSActivity;
import com.ngmoco.gamejs.ui.widgets.UIWidget;
import java.io.Writer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import javax.microedition.khronos.opengles.GL;
import javax.microedition.khronos.opengles.GL10;

public class NGGLSurfaceView extends SurfaceView implements SurfaceHolder.Callback, UIWidget {
    public static final int DEBUG_CHECK_GL_ERROR = 1;
    public static final int DEBUG_LOG_GL_CALLS = 2;
    private static final boolean DRAW_TWICE_AFTER_SIZE_CHANGED = true;
    private static final boolean LOG_EGL = false;
    private static volatile boolean LOG_GL_THREADING = false;
    private static final boolean LOG_PAUSE_RESUME = false;
    private static final boolean LOG_RENDERER = false;
    private static final boolean LOG_RENDERER_DRAW_FRAME = false;
    private static final boolean LOG_SURFACE = false;
    private static final boolean LOG_THREADS = false;
    public static final int RENDERMODE_CONTINUOUSLY = 1;
    public static final int RENDERMODE_WHEN_DIRTY = 0;
    public static GLThread mGLThread = null;
    private static volatile boolean mIsPaused = false;
    private static int mLifecycleCount = 2;
    private static ReentrantLock mLifecycleLock = new ReentrantLock();
    private static ReentrantLock mSurfaceLock = new ReentrantLock();
    private static final Condition sGLCondition = mSurfaceLock.newCondition();
    private static final GLThreadManager sGLThreadManager = new GLThreadManager();
    private static final Condition sLifecycleCondition = mLifecycleLock.newCondition();
    private static int sLifecycleGLCount = 0;
    private JSActivity mActivity;
    private int mDebugFlags;
    private EGLConfigChooser mEGLConfigChooser;
    private int mEGLContextClientVersion;
    private EGLContextFactory mEGLContextFactory;
    private EGLWindowSurfaceFactory mEGLWindowSurfaceFactory;
    private long mFrameRate = 17;
    private GLWrapper mGLWrapper;
    private boolean mSizeChanged = true;
    private boolean mThreadPaused = false;
    private long mTimeOut = 3000;
    private long mWaitRate = 2;
    private int mX;
    private int mY;

    public interface EGLConfigChooser {
        EGLConfig chooseConfig(EGL10 egl10, EGLDisplay eGLDisplay);
    }

    public interface EGLContextFactory {
        EGLContext createContext(EGL10 egl10, EGLDisplay eGLDisplay, EGLConfig eGLConfig);

        void destroyContext(EGL10 egl10, EGLDisplay eGLDisplay, EGLContext eGLContext);
    }

    public interface EGLWindowSurfaceFactory {
        EGLSurface createWindowSurface(EGL10 egl10, EGLDisplay eGLDisplay, EGLConfig eGLConfig, Object obj);

        void destroySurface(EGL10 egl10, EGLDisplay eGLDisplay, EGLSurface eGLSurface);
    }

    public interface GLWrapper {
        GL wrap(GL gl);
    }

    public interface Renderer {
        boolean onDrawFrame(GL10 gl10);

        void onSurfaceChanged(GL10 gl10, int i, int i2);

        void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig);
    }

    static /* synthetic */ int access$2512(int x0) {
        int i = mLifecycleCount + x0;
        mLifecycleCount = i;
        return i;
    }

    static /* synthetic */ int access$2520(int x0) {
        int i = mLifecycleCount - x0;
        mLifecycleCount = i;
        return i;
    }

    static /* synthetic */ int access$3412(int x0) {
        int i = sLifecycleGLCount + x0;
        sLifecycleGLCount = i;
        return i;
    }

    static /* synthetic */ int access$3420(int x0) {
        int i = sLifecycleGLCount - x0;
        sLifecycleGLCount = i;
        return i;
    }

    public void setPaused(boolean val) {
        mIsPaused = val;
    }

    public NGGLSurfaceView(Context context) {
        super(context);
        init();
    }

    public NGGLSurfaceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        SurfaceHolder holder = getHolder();
        holder.addCallback(this);
        holder.setFormat(4);
    }

    public void setGLWrapper(GLWrapper glWrapper) {
        this.mGLWrapper = glWrapper;
    }

    public void setDebugFlags(int debugFlags) {
        this.mDebugFlags = debugFlags;
    }

    public int getDebugFlags() {
        return this.mDebugFlags;
    }

    public void setGLThreadingLog(boolean value) {
        Log.d("NGGLSurfaceView", "Setting gl threading to :" + value);
    }

    public void quitApplication() {
        Log.d("NGGLSurfaceView/Engine", "Call to quit application called ... Initiating shutdown");
        mGLThread.quitApplication();
    }

    public synchronized void setRenderer(Renderer renderer) {
        if (this.mEGLConfigChooser == null) {
            this.mEGLConfigChooser = new SimpleEGLConfigChooser(true);
        }
        if (this.mEGLContextFactory == null) {
            this.mEGLContextFactory = new DefaultContextFactory();
        }
        if (this.mEGLWindowSurfaceFactory == null) {
            this.mEGLWindowSurfaceFactory = new DefaultWindowSurfaceFactory();
        }
        if (mGLThread == null) {
            mGLThread = new GLThread(renderer, true);
            mGLThread.start();
        } else {
            mGLThread.startGL(renderer, true);
        }
    }

    public synchronized void startThread() {
        if (mGLThread == null) {
            mGLThread = new GLThread(null, false);
            mGLThread.start();
        } else {
            mGLThread.stopGL();
        }
    }

    public void stopGL() {
        if (mGLThread != null) {
            mGLThread.stopGL();
        }
    }

    public void setEGLContextFactory(EGLContextFactory factory) {
        this.mEGLContextFactory = factory;
    }

    public void setEGLWindowSurfaceFactory(EGLWindowSurfaceFactory factory) {
        this.mEGLWindowSurfaceFactory = factory;
    }

    public void setEGLConfigChooser(EGLConfigChooser configChooser) {
        this.mEGLConfigChooser = configChooser;
    }

    public void setEGLConfigChooser(boolean needDepth) {
        setEGLConfigChooser(new SimpleEGLConfigChooser(needDepth));
    }

    public void setEGLConfigChooser(int redSize, int greenSize, int blueSize, int alphaSize, int depthSize, int stencilSize) {
        setEGLConfigChooser(new ComponentSizeChooser(redSize, greenSize, blueSize, alphaSize, depthSize, stencilSize));
    }

    public void setEGLContextClientVersion(int version) {
        this.mEGLContextClientVersion = version;
    }

    public void setRenderMode(int renderMode) {
        if (mGLThread != null) {
            mGLThread.setRenderMode(renderMode);
        }
    }

    public int getRenderMode() {
        if (mGLThread != null) {
        }
        return 0;
    }

    public void requestRender() {
        if (mGLThread != null) {
            mGLThread.requestRender();
        }
    }

    public void surfaceCreated(SurfaceHolder holder) {
        Log.d("NGGLSurfaceView", "++++++++++++++++++++++++++++++++++++++++Surface is created");
        if (mGLThread != null) {
            mGLThread.surfaceCreated();
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.d("NGGLSurfaceView", "++++++++++++++++++++++++++++++++++++++++Surface is destroyed");
        if (mGLThread != null) {
            mGLThread.surfaceDestroyed();
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        if (mGLThread != null) {
            mGLThread.onWindowResize(w, h);
        }
    }

    public void onPause() {
        if (mGLThread != null) {
            mGLThread.onPause();
        }
    }

    public void onResume() {
        if (mGLThread != null) {
            mGLThread.onResume();
        }
    }

    public void onStart() {
        if (mGLThread != null) {
            mGLThread.onStart();
        }
    }

    public void onPauseTick() {
        if (mGLThread != null) {
            mGLThread.onPauseTick();
        }
    }

    public void onResumeTick() {
        if (mGLThread != null) {
            mGLThread.onResumeTick();
        }
    }

    public void setGameRenderingPause(boolean val) {
        if (mGLThread != null) {
            mGLThread.setGameRenderingPause(val);
        }
    }

    public boolean queueEvent(Runnable r) {
        if (mGLThread == null) {
            return false;
        }
        mGLThread.queueEvent(r);
        return true;
    }

    public void setActivity(JSActivity activity) {
        this.mActivity = activity;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mGLThread != null) {
            mGLThread.requestExitAndWait();
        }
    }

    private class DefaultContextFactory implements EGLContextFactory {
        private int EGL_CONTEXT_CLIENT_VERSION;

        private DefaultContextFactory() {
            this.EGL_CONTEXT_CLIENT_VERSION = 12440;
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLContextFactory
        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] attrib_list = {this.EGL_CONTEXT_CLIENT_VERSION, NGGLSurfaceView.this.mEGLContextClientVersion, 12344};
            EGLContext eGLContext = EGL10.EGL_NO_CONTEXT;
            if (NGGLSurfaceView.this.mEGLContextClientVersion == 0) {
                attrib_list = null;
            }
            return egl.eglCreateContext(display, config, eGLContext, attrib_list);
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLContextFactory
        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            if (!egl.eglDestroyContext(display, context)) {
                Log.e("DefaultContextFactory", "display:" + display + " context: " + context);
                throw new RuntimeException("eglDestroyContext failed: " + egl.eglGetError());
            }
        }
    }

    private static class DefaultWindowSurfaceFactory implements EGLWindowSurfaceFactory {
        private DefaultWindowSurfaceFactory() {
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLWindowSurfaceFactory
        public EGLSurface createWindowSurface(EGL10 egl, EGLDisplay display, EGLConfig config, Object nativeWindow) {
            return egl.eglCreateWindowSurface(display, config, nativeWindow, null);
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLWindowSurfaceFactory
        public void destroySurface(EGL10 egl, EGLDisplay display, EGLSurface surface) {
            egl.eglDestroySurface(display, surface);
        }
    }

    private abstract class BaseConfigChooser implements EGLConfigChooser {
        protected int[] mConfigSpec;

        /* access modifiers changed from: package-private */
        public abstract EGLConfig chooseConfig(EGL10 egl10, EGLDisplay eGLDisplay, EGLConfig[] eGLConfigArr);

        public BaseConfigChooser(int[] configSpec) {
            this.mConfigSpec = filterConfigSpec(configSpec);
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLConfigChooser
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[] num_config = new int[1];
            if (!egl.eglChooseConfig(display, this.mConfigSpec, null, 0, num_config)) {
                throw new IllegalArgumentException("eglChooseConfig failed");
            }
            int numConfigs = num_config[0];
            if (numConfigs <= 0) {
                throw new IllegalArgumentException("No configs match configSpec");
            }
            EGLConfig[] configs = new EGLConfig[numConfigs];
            if (!egl.eglChooseConfig(display, this.mConfigSpec, configs, numConfigs, num_config)) {
                throw new IllegalArgumentException("eglChooseConfig#2 failed");
            }
            EGLConfig config = chooseConfig(egl, display, configs);
            if (config != null) {
                return config;
            }
            throw new IllegalArgumentException("No config chosen");
        }

        private int[] filterConfigSpec(int[] configSpec) {
            if (NGGLSurfaceView.this.mEGLContextClientVersion != 2) {
                return configSpec;
            }
            int len = configSpec.length;
            int[] newConfigSpec = new int[(len + 2)];
            System.arraycopy(configSpec, 0, newConfigSpec, 0, len - 1);
            newConfigSpec[len - 1] = 12352;
            newConfigSpec[len] = 4;
            newConfigSpec[len + 1] = 12344;
            return newConfigSpec;
        }
    }

    private class ComponentSizeChooser extends BaseConfigChooser {
        protected int mAlphaSize;
        protected int mBlueSize;
        protected int mDepthSize;
        protected int mGreenSize;
        protected int mRedSize;
        protected int mStencilSize;
        private int[] mValue = new int[1];

        public ComponentSizeChooser(int redSize, int greenSize, int blueSize, int alphaSize, int depthSize, int stencilSize) {
            super(new int[]{12324, redSize, 12323, greenSize, 12322, blueSize, 12321, alphaSize, 12325, depthSize, 12326, stencilSize, 12344});
            this.mRedSize = redSize;
            this.mGreenSize = greenSize;
            this.mBlueSize = blueSize;
            this.mAlphaSize = alphaSize;
            this.mDepthSize = depthSize;
            this.mStencilSize = stencilSize;
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.BaseConfigChooser
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for (EGLConfig config : configs) {
                int d = findConfigAttrib(egl, display, config, 12325, 0);
                int s = findConfigAttrib(egl, display, config, 12326, 0);
                if (d >= this.mDepthSize && s >= this.mStencilSize) {
                    int r = findConfigAttrib(egl, display, config, 12324, 0);
                    int g = findConfigAttrib(egl, display, config, 12323, 0);
                    int b = findConfigAttrib(egl, display, config, 12322, 0);
                    int a = findConfigAttrib(egl, display, config, 12321, 0);
                    if (r == this.mRedSize && g == this.mGreenSize && b == this.mBlueSize && a == this.mAlphaSize) {
                        return config;
                    }
                }
            }
            return null;
        }

        private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
            if (egl.eglGetConfigAttrib(display, config, attribute, this.mValue)) {
                return this.mValue[0];
            }
            return defaultValue;
        }
    }

    private class SimpleEGLConfigChooser extends ComponentSizeChooser {
        /* JADX WARNING: Illegal instructions before constructor call */
        public SimpleEGLConfigChooser(boolean withDepthBuffer) {
            super(5, 6, 5, 0, r6, 0);
            int i;
            if (withDepthBuffer) {
                i = 16;
            } else {
                i = 0;
            }
        }
    }

    /* access modifiers changed from: private */
    public class EglHelper {
        EGL10 mEgl;
        EGLConfig mEglConfig;
        EGLContext mEglContext;
        EGLDisplay mEglDisplay;
        EGLSurface mEglSurface;

        public EglHelper() {
        }

        public void start() {
            this.mEgl = (EGL10) EGLContext.getEGL();
            this.mEglDisplay = this.mEgl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            if (this.mEglDisplay == EGL10.EGL_NO_DISPLAY) {
                throw new RuntimeException("eglGetDisplay failed");
            }
            if (!this.mEgl.eglInitialize(this.mEglDisplay, new int[2])) {
                throw new RuntimeException("eglInitialize failed");
            }
            this.mEglConfig = NGGLSurfaceView.this.mEGLConfigChooser.chooseConfig(this.mEgl, this.mEglDisplay);
            this.mEglContext = NGGLSurfaceView.this.mEGLContextFactory.createContext(this.mEgl, this.mEglDisplay, this.mEglConfig);
            if (this.mEglContext == null || this.mEglContext == EGL10.EGL_NO_CONTEXT) {
                this.mEglContext = null;
                throwEglException("createContext");
            }
            this.mEglSurface = null;
            NgJNI.eglContextStart();
        }

        public GL createSurface(SurfaceHolder holder) {
            if (this.mEgl == null) {
                throw new RuntimeException("egl not initialized");
            } else if (this.mEglDisplay == null) {
                throw new RuntimeException("eglDisplay not initialized");
            } else if (this.mEglConfig == null) {
                throw new RuntimeException("mEglConfig not initialized");
            } else {
                if (!(this.mEglSurface == null || this.mEglSurface == EGL10.EGL_NO_SURFACE)) {
                    this.mEgl.eglMakeCurrent(this.mEglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    NGGLSurfaceView.this.mEGLWindowSurfaceFactory.destroySurface(this.mEgl, this.mEglDisplay, this.mEglSurface);
                }
                this.mEglSurface = NGGLSurfaceView.this.mEGLWindowSurfaceFactory.createWindowSurface(this.mEgl, this.mEglDisplay, this.mEglConfig, holder);
                if (this.mEglSurface == null || this.mEglSurface == EGL10.EGL_NO_SURFACE) {
                    int error = this.mEgl.eglGetError();
                    if (error == 12299) {
                        Log.e("EglHelper", "createWindowSurface returned EGL_BAD_NATIVE_WINDOW.");
                        return null;
                    }
                    throwEglException("createWindowSurface", error);
                }
                if (!this.mEgl.eglMakeCurrent(this.mEglDisplay, this.mEglSurface, this.mEglSurface, this.mEglContext)) {
                    throwEglException("eglMakeCurrent");
                }
                GL gl = this.mEglContext.getGL();
                if (NGGLSurfaceView.this.mGLWrapper != null) {
                    return NGGLSurfaceView.this.mGLWrapper.wrap(gl);
                }
                return gl;
            }
        }

        public boolean swap() {
            if (!this.mEgl.eglSwapBuffers(this.mEglDisplay, this.mEglSurface)) {
                switch (this.mEgl.eglGetError()) {
                    case 12299:
                        Log.e("EglHelper", "eglSwapBuffers returned EGL_BAD_NATIVE_WINDOW. tid=" + Thread.currentThread().getId());
                        break;
                    case 12300:
                    case 12301:
                    default:
                        Log.d("eglSwapBuffers", "Cannot Swap buffer");
                        break;
                    case 12302:
                        return false;
                }
            }
            return true;
        }

        public void destroySurface() {
            if (this.mEglSurface != null && this.mEglSurface != EGL10.EGL_NO_SURFACE) {
                this.mEgl.eglMakeCurrent(this.mEglDisplay, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                NGGLSurfaceView.this.mEGLWindowSurfaceFactory.destroySurface(this.mEgl, this.mEglDisplay, this.mEglSurface);
                this.mEglSurface = null;
            }
        }

        public void finish() {
            NgJNI.eglContextFinish();
            if (this.mEglContext != null) {
                NGGLSurfaceView.this.mEGLContextFactory.destroyContext(this.mEgl, this.mEglDisplay, this.mEglContext);
                this.mEglContext = null;
            }
            if (this.mEglDisplay != null) {
                this.mEgl.eglTerminate(this.mEglDisplay);
                this.mEglDisplay = null;
            }
        }

        private void throwEglException(String function) {
            throwEglException(function, this.mEgl.eglGetError());
        }

        private void throwEglException(String function, int error) {
            throw new RuntimeException(function + " failed: " + error);
        }
    }

    /* access modifiers changed from: package-private */
    public class GLThread extends Thread {
        private static final String TAG = "GLThread";
        volatile GLParametersIntoThread gl_params_in = new GLParametersIntoThread();
        volatile GLParametersOutThread gl_params_out = new GLParametersOutThread();
        private EglHelper mEglHelper;
        private ConcurrentLinkedQueue<Runnable> mEventQueue = new ConcurrentLinkedQueue<>();
        private ConcurrentLinkedQueue<GLParametersIntoThread> mGLCommandQueue = new ConcurrentLinkedQueue<>();
        private Boolean mHasSurface = false;
        private volatile long mLastFrame = 0;
        private volatile boolean mQuit;
        private Renderer mRenderer;
        private long mTimeOut = 4000;

        GLThread(Renderer renderer, boolean startGL) {
            this.gl_params_in.mWidth = 0;
            this.gl_params_in.mHeight = 0;
            this.gl_params_in.mRequestRender = false;
            this.gl_params_in.mRenderMode = 1;
            this.mRenderer = renderer;
            this.gl_params_out.mStartGL = startGL;
            this.gl_params_in.mRequestStartGL = startGL;
            this.gl_params_in.mRequestPausedTick = false;
            this.gl_params_in.mRequestPaused = false;
            this.gl_params_in.mRequestRenderingSoftPause = false;
            this.gl_params_out.mRenderingSoftPause = false;
            requestRender();
        }

        public synchronized void start() {
            super.start();
            NgEngine.getInstance().queueEvent(new Runnable() {
                /* class com.ngmoco.gamejs.gl.NGGLSurfaceView.GLThread.AnonymousClass1 */

                public void run() {
                }
            });
        }

        public void setGameRenderingPause(boolean val) {
            new GLParametersIntoThread();
            this.gl_params_in.mRequestRenderingSoftPause = val;
            this.mGLCommandQueue.add(this.gl_params_in);
        }

        public void quitApplication() {
            this.mQuit = true;
        }

        public void startGL(Renderer renderer, boolean startGL) {
            if (NGGLSurfaceView.LOG_GL_THREADING) {
                Log.d(TAG, "startGL tid=" + getId());
            }
            this.mRenderer = renderer;
            new GLParametersIntoThread();
            this.gl_params_in.mRequestStartGL = true;
            this.mGLCommandQueue.add(this.gl_params_in);
        }

        public void stopGL() {
            if (NGGLSurfaceView.LOG_GL_THREADING) {
                Log.d(TAG, "stopGL tid=" + getId());
                Log.d(TAG, "************************************Stopping GL");
            }
            this.mRenderer = null;
            new GLParametersIntoThread();
            this.gl_params_in.mRequestStartGL = false;
            this.mGLCommandQueue.add(this.gl_params_in);
        }

        public void run() {
            setName("GLThread " + getId());
            try {
                Log.d(TAG, "Starting gl Thread");
                guardedRun();
            } catch (InterruptedException e) {
            } finally {
                NGGLSurfaceView.sGLThreadManager.threadExiting(this);
            }
        }

        private void stopEglSurfaceLocked() {
            if (this.gl_params_out.mHaveEglSurface) {
                this.gl_params_out.mHaveEglSurface = false;
                this.mEglHelper.destroySurface();
            }
        }

        private void stopEglContextLocked() {
            if (this.gl_params_out.mHaveEglContext) {
                this.mEglHelper.finish();
                this.gl_params_out.mHaveEglContext = false;
                NGGLSurfaceView.sGLThreadManager.releaseEglContextLocked(this);
            }
        }

        /* JADX INFO: finally extract failed */
        private void guardedRun() throws InterruptedException {
            long startFrameTime;
            this.mEglHelper = new EglHelper();
            this.gl_params_out.mHaveEglContext = false;
            this.gl_params_out.mHaveEglSurface = false;
            GL10 gl = null;
            boolean createEglContext = false;
            boolean createEglSurface = false;
            boolean lostEglContext = false;
            boolean sizeChanged = false;
            boolean wantRenderNotification = false;
            boolean doRenderNotification = false;
            try {
                this.mQuit = false;
                int w = 0;
                int h = 0;
                GLParametersIntoThread gl_cached_params_in = this.gl_params_in;
                while (true) {
                    GLParametersOutThread gl_cached_params_out = this.gl_params_out;
                    GLParametersIntoThread gl_current_params_in = this.mGLCommandQueue.poll();
                    if (gl_current_params_in != null) {
                        gl_cached_params_in = gl_current_params_in;
                        Log.d(TAG, "********************************Found input parameters in GL Queue");
                    }
                    while (true) {
                        boolean keepRunning = NgJNI.jsKeepEngineRunning();
                        startFrameTime = System.currentTimeMillis();
                        this.mLastFrame = startFrameTime;
                        if (this.mQuit) {
                            Log.d("NGGLSurfaceView/Engine", "Engine thread shutdown...");
                            if (this.gl_params_out.mStartGL) {
                                Log.d("NGGLSurfaceView/Engine", "GL JAVA system resources clean up...");
                                stopEglSurfaceLocked();
                                stopEglContextLocked();
                            }
                            Log.d("NGGLSurfaceView/Engine", "Calling Activity terminate");
                            final JSActivity activity = NGGLSurfaceView.this.mActivity;
                            NGGLSurfaceView.this.mActivity.runOnUiThread(new Runnable() {
                                /* class com.ngmoco.gamejs.gl.NGGLSurfaceView.GLThread.AnonymousClass2 */

                                public void run() {
                                    activity.onBackPressedSuperClass();
                                }
                            });
                            return;
                        }
                        if (NGGLSurfaceView.LOG_GL_THREADING) {
                            Log.d(TAG, "mStartGL is im beginning now " + gl_cached_params_out.mStartGL + " tid=" + getId());
                        }
                        if (gl_cached_params_out.mStartGL != gl_cached_params_in.mRequestStartGL) {
                            gl_cached_params_out.mStartGL = gl_cached_params_in.mRequestStartGL;
                            if (NGGLSurfaceView.LOG_GL_THREADING) {
                                Log.d(TAG, "mStartGL is now " + gl_cached_params_out.mStartGL + " tid=" + getId());
                            }
                        }
                        if (gl_cached_params_out.mRenderingSoftPause != gl_cached_params_in.mRequestRenderingSoftPause) {
                            gl_cached_params_out.mRenderingSoftPause = gl_cached_params_in.mRequestRenderingSoftPause;
                            if (NGGLSurfaceView.LOG_GL_THREADING) {
                                Log.d(TAG, "mRenderingSoftPause is now " + gl_cached_params_out.mRenderingSoftPause + " tid=" + getId());
                            }
                        }
                        if (gl_cached_params_in.mShouldExit) {
                            stopEglSurfaceLocked();
                            stopEglContextLocked();
                            gl_cached_params_in.mShouldExit = false;
                            gl_cached_params_out.mStartGL = false;
                        }
                        if (!gl_cached_params_out.mStartGL) {
                            boolean toIssuePauseEvent = false;
                            if (gl_cached_params_out.mPausedTick != gl_cached_params_in.mRequestPausedTick) {
                                gl_cached_params_out.mPausedTick = gl_cached_params_in.mRequestPausedTick;
                                if (gl_cached_params_out.mPausedTick) {
                                    toIssuePauseEvent = true;
                                }
                            }
                            if (!gl_cached_params_out.mPausedTick) {
                                NgJNI.doClockTick();
                                break;
                            }
                            boolean keepTicking = false;
                            NGGLSurfaceView.mLifecycleLock.lock();
                            try {
                                if (NGGLSurfaceView.mLifecycleCount != 1) {
                                    keepTicking = !gl_cached_params_out.mPausedTick;
                                }
                                if (toIssuePauseEvent) {
                                    NGGLSurfaceView.mLifecycleLock.lock();
                                    try {
                                        NgJNI.pauseProcedure();
                                    } finally {
                                        NGGLSurfaceView.mLifecycleLock.unlock();
                                    }
                                }
                                if (keepTicking || keepRunning) {
                                    NgJNI.doClockTick();
                                } else {
                                    NGGLSurfaceView.mLifecycleLock.lock();
                                    try {
                                        if (NGGLSurfaceView.mIsPaused) {
                                            NGGLSurfaceView.sLifecycleCondition.await();
                                        }
                                    } finally {
                                        NGGLSurfaceView.mLifecycleLock.unlock();
                                    }
                                }
                            } finally {
                                NGGLSurfaceView.mLifecycleLock.unlock();
                            }
                        } else {
                            if (gl_cached_params_out.mPaused != gl_cached_params_in.mRequestPaused) {
                                gl_cached_params_out.mPaused = gl_cached_params_in.mRequestPaused;
                            }
                            if (lostEglContext) {
                                stopEglSurfaceLocked();
                                stopEglContextLocked();
                                lostEglContext = false;
                            }
                            if (gl_cached_params_out.mHaveEglSurface && gl_cached_params_out.mPaused) {
                                NgJNI.pauseGL();
                                stopEglSurfaceLocked();
                                if (NGGLSurfaceView.sGLThreadManager.shouldReleaseEGLContextWhenPausing()) {
                                    stopEglContextLocked();
                                }
                                if (NGGLSurfaceView.sGLThreadManager.shouldTerminateEGLWhenPausing()) {
                                    this.mEglHelper.finish();
                                }
                                Log.d(TAG, "++++++++++++++++++++++++++++++++++++++++++++++Calling pause procedure");
                                NgJNI.pauseProcedure();
                            }
                            if (NGGLSurfaceView.mSurfaceLock.tryLock()) {
                                try {
                                    gl_cached_params_out.mHasSurface = this.mHasSurface.booleanValue();
                                    if (!gl_cached_params_out.mHasSurface && !gl_cached_params_out.mWaitingForSurface) {
                                        if (gl_cached_params_out.mHaveEglSurface) {
                                            stopEglSurfaceLocked();
                                        }
                                        gl_cached_params_out.mWaitingForSurface = true;
                                    }
                                    if (gl_cached_params_out.mHasSurface && gl_cached_params_out.mWaitingForSurface) {
                                        gl_cached_params_out.mWaitingForSurface = false;
                                    }
                                    if (doRenderNotification) {
                                        wantRenderNotification = false;
                                        doRenderNotification = false;
                                        gl_cached_params_out.mRenderComplete = true;
                                    }
                                    if (!gl_cached_params_out.mPaused && gl_cached_params_out.mHasSurface && gl_cached_params_in.mWidth > 0 && gl_cached_params_in.mHeight > 0 && (gl_cached_params_in.mRequestRender || gl_cached_params_in.mRenderMode == 1)) {
                                        if (!gl_cached_params_out.mHaveEglContext && NGGLSurfaceView.sGLThreadManager.tryAcquireEglContextLocked(this)) {
                                            try {
                                                this.mEglHelper.start();
                                                gl_cached_params_out.mHaveEglContext = true;
                                                createEglContext = true;
                                            } catch (RuntimeException t) {
                                                NGGLSurfaceView.sGLThreadManager.releaseEglContextLocked(this);
                                                throw t;
                                            }
                                        }
                                        if (gl_cached_params_out.mHaveEglContext && !gl_cached_params_out.mHaveEglSurface) {
                                            gl_cached_params_out.mHaveEglSurface = true;
                                            createEglSurface = true;
                                            sizeChanged = true;
                                        }
                                        if (gl_cached_params_out.mHaveEglSurface) {
                                            if (NGGLSurfaceView.this.mSizeChanged) {
                                                sizeChanged = true;
                                                w = gl_cached_params_in.mWidth;
                                                h = gl_cached_params_in.mHeight;
                                                wantRenderNotification = true;
                                                NGGLSurfaceView.this.mSizeChanged = false;
                                            } else {
                                                gl_cached_params_in.mRequestRender = false;
                                            }
                                            NGGLSurfaceView.mSurfaceLock.unlock();
                                        }
                                    }
                                    NGGLSurfaceView.mSurfaceLock.unlock();
                                    if (gl_cached_params_out.mPaused) {
                                        if (!keepRunning) {
                                            NGGLSurfaceView.mLifecycleLock.lock();
                                            try {
                                                if (NGGLSurfaceView.sLifecycleGLCount == 1) {
                                                    Log.d("NGGLSurfaceView", "NGGL: paused and parked!");
                                                    NGGLSurfaceView.sLifecycleCondition.await();
                                                }
                                            } finally {
                                                NGGLSurfaceView.mLifecycleLock.unlock();
                                            }
                                        } else {
                                            NgJNI.doClockTick();
                                            long frameTime = System.currentTimeMillis() - startFrameTime;
                                            NGGLSurfaceView.mSurfaceLock.lock();
                                            try {
                                                if (frameTime < NGGLSurfaceView.this.mFrameRate) {
                                                    Log.v("NGGLSurfaceView", "NGGL: paused and keptAlive!");
                                                    NGGLSurfaceView.sGLCondition.await(NGGLSurfaceView.this.mFrameRate - frameTime, TimeUnit.MILLISECONDS);
                                                }
                                            } finally {
                                                NGGLSurfaceView.mSurfaceLock.unlock();
                                            }
                                        }
                                    }
                                } catch (Throwable th) {
                                    NGGLSurfaceView.mSurfaceLock.unlock();
                                    throw th;
                                }
                            } else {
                                continue;
                            }
                        }
                    }
                    Runnable event = this.mEventQueue.poll();
                    if (event != null) {
                        event.run();
                    } else {
                        if (NGGLSurfaceView.mSurfaceLock.tryLock()) {
                            try {
                                if (this.mHasSurface.booleanValue() && gl_cached_params_out.mStartGL) {
                                    if (createEglSurface) {
                                        gl = (GL10) this.mEglHelper.createSurface(NGGLSurfaceView.this.getHolder());
                                        if (gl == null) {
                                            NGGLSurfaceView.mSurfaceLock.unlock();
                                            return;
                                        }
                                        NGGLSurfaceView.sGLThreadManager.checkGLDriver(gl);
                                        createEglSurface = false;
                                    }
                                    if (createEglContext) {
                                        this.mRenderer.onSurfaceCreated(gl, this.mEglHelper.mEglConfig);
                                        createEglContext = false;
                                    }
                                    if (sizeChanged) {
                                        this.mRenderer.onSurfaceChanged(gl, w, h);
                                        sizeChanged = false;
                                    }
                                    if (this.mRenderer.onDrawFrame(gl) && !gl_cached_params_out.mRenderingSoftPause) {
                                        if (!this.mEglHelper.swap()) {
                                            lostEglContext = true;
                                        }
                                        if (wantRenderNotification) {
                                            doRenderNotification = true;
                                        }
                                    }
                                }
                            } finally {
                                NGGLSurfaceView.mSurfaceLock.unlock();
                            }
                        }
                        this.gl_params_out = gl_cached_params_out;
                        long frameTime2 = System.currentTimeMillis() - startFrameTime;
                        NGGLSurfaceView.mSurfaceLock.lock();
                        try {
                            if (frameTime2 < NGGLSurfaceView.this.mFrameRate) {
                                NGGLSurfaceView.sGLCondition.await(NGGLSurfaceView.this.mFrameRate - frameTime2, TimeUnit.MILLISECONDS);
                            }
                        } finally {
                            NGGLSurfaceView.mSurfaceLock.unlock();
                        }
                    }
                }
            } finally {
                Log.d("NGGLSurfaceView/Engine", "Engine thread shutdown...");
                if (this.gl_params_out.mStartGL) {
                    Log.d("NGGLSurfaceView/Engine", "GL JAVA system resources clean up...");
                    stopEglSurfaceLocked();
                    stopEglContextLocked();
                }
                Log.d("NGGLSurfaceView/Engine", "Calling Activity terminate");
                final JSActivity activity2 = NGGLSurfaceView.this.mActivity;
                NGGLSurfaceView.this.mActivity.runOnUiThread(new Runnable() {
                    /* class com.ngmoco.gamejs.gl.NGGLSurfaceView.GLThread.AnonymousClass2 */

                    public void run() {
                        activity2.onBackPressedSuperClass();
                    }
                });
            }
        }

        public void setRenderMode(int renderMode) {
            if (renderMode < 0 || renderMode > 1) {
                throw new IllegalArgumentException("renderMode");
            }
            new GLParametersIntoThread();
            this.gl_params_in.mRenderMode = renderMode;
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRenderMode = renderMode;
            this.mGLCommandQueue.add(in_param);
        }

        public int getRenderMode() {
            return this.gl_params_in.mRenderMode;
        }

        public void requestRender() {
            new GLParametersIntoThread();
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRequestRender = true;
            this.mGLCommandQueue.add(in_param);
        }

        public void surfaceCreated() {
            try {
                if (NGGLSurfaceView.mSurfaceLock.tryLock(this.mTimeOut, TimeUnit.MILLISECONDS)) {
                    try {
                        this.mHasSurface = true;
                    } finally {
                        NGGLSurfaceView.mSurfaceLock.unlock();
                    }
                } else {
                    Log.d(TAG, "Engine tick is taking too long to respond... GL Will not start");
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void surfaceDestroyed() {
            try {
                if (NGGLSurfaceView.mSurfaceLock.tryLock(this.mTimeOut, TimeUnit.MILLISECONDS)) {
                    try {
                        this.mHasSurface = false;
                    } finally {
                        NGGLSurfaceView.mSurfaceLock.unlock();
                    }
                } else {
                    this.mHasSurface = false;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        public void onPause() {
            new GLParametersIntoThread();
            this.gl_params_in.mRequestPaused = true;
            this.mGLCommandQueue.add(this.gl_params_in);
            NGGLSurfaceView.mLifecycleLock.lock();
            try {
                NGGLSurfaceView.access$3412(1);
            } finally {
                NGGLSurfaceView.mLifecycleLock.unlock();
            }
        }

        public void onResume() {
            new GLParametersIntoThread();
            this.gl_params_in.mRequestPaused = false;
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRequestRender = true;
            this.mGLCommandQueue.add(in_param);
            NGGLSurfaceView.mLifecycleLock.lock();
            try {
                NGGLSurfaceView.access$3420(1);
                NGGLSurfaceView.sLifecycleCondition.signalAll();
            } finally {
                NGGLSurfaceView.mLifecycleLock.unlock();
            }
        }

        public void onStart() {
            new GLParametersIntoThread();
            this.gl_params_in.mRequestPaused = false;
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRequestRender = true;
            this.mGLCommandQueue.add(in_param);
            NGGLSurfaceView.mLifecycleLock.lock();
            try {
                int unused = NGGLSurfaceView.sLifecycleGLCount = 0;
                NGGLSurfaceView.sLifecycleCondition.signalAll();
            } finally {
                NGGLSurfaceView.mLifecycleLock.unlock();
            }
        }

        public void onPauseTick() {
            if (this.mRenderer == null) {
                new GLParametersIntoThread();
                this.gl_params_in.mRequestPausedTick = true;
                this.mGLCommandQueue.add(this.gl_params_in);
                NGGLSurfaceView.mLifecycleLock.lock();
                try {
                    NGGLSurfaceView.this.setPaused(true);
                    NGGLSurfaceView.access$2512(1);
                } finally {
                    NGGLSurfaceView.mLifecycleLock.unlock();
                }
            }
        }

        public void onResumeTick() {
            if (this.mRenderer == null) {
                new GLParametersIntoThread();
                this.gl_params_in.mRequestPausedTick = false;
                this.mGLCommandQueue.add(this.gl_params_in);
                NGGLSurfaceView.mLifecycleLock.lock();
                try {
                    NGGLSurfaceView.access$2520(1);
                    NGGLSurfaceView.this.setPaused(false);
                    NGGLSurfaceView.sLifecycleCondition.signalAll();
                } finally {
                    NGGLSurfaceView.mLifecycleLock.unlock();
                }
            }
        }

        public void onWindowResize(int w, int h) {
            new GLParametersIntoThread();
            this.gl_params_in.mWidth = w;
            this.gl_params_in.mHeight = h;
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRequestRender = true;
            this.mGLCommandQueue.add(in_param);
            NGGLSurfaceView.this.mSizeChanged = true;
            this.gl_params_out.mRenderComplete = false;
        }

        public void requestExitAndWait() {
            new GLParametersIntoThread();
            GLParametersIntoThread in_param = this.gl_params_in;
            in_param.mRequestStartGL = false;
            in_param.mShouldExit = true;
            this.mGLCommandQueue.add(in_param);
        }

        public void queueEvent(Runnable r) {
            if (r == null) {
                throw new IllegalArgumentException("r must not be null");
            }
            this.mEventQueue.add(r);
        }

        public long getLastFrame() {
            return this.mLastFrame;
        }

        /* access modifiers changed from: private */
        public class GLParametersIntoThread {
            private int mHeight;
            private int mRenderMode;
            private boolean mRequestPaused;
            private boolean mRequestPausedTick;
            private boolean mRequestRender;
            private boolean mRequestRenderingSoftPause;
            private boolean mRequestStartGL;
            private boolean mShouldExit;
            private int mWidth;

            private GLParametersIntoThread() {
            }
        }

        /* access modifiers changed from: private */
        public class GLParametersOutThread {
            private boolean mExited;
            private boolean mHasSurface;
            private boolean mHaveEglContext;
            private boolean mHaveEglSurface;
            private boolean mPaused;
            private boolean mPausedTick;
            private boolean mRenderComplete;
            private boolean mRenderingSoftPause;
            private boolean mStartGL;
            private boolean mWaitingForSurface;

            private GLParametersOutThread() {
            }
        }
    }

    static class LogWriter extends Writer {
        private StringBuilder mBuilder = new StringBuilder();

        LogWriter() {
        }

        @Override // java.io.Closeable, java.io.Writer, java.lang.AutoCloseable
        public void close() {
            flushBuilder();
        }

        @Override // java.io.Writer, java.io.Flushable
        public void flush() {
            flushBuilder();
        }

        @Override // java.io.Writer
        public void write(char[] buf, int offset, int count) {
            for (int i = 0; i < count; i++) {
                char c = buf[offset + i];
                if (c == '\n') {
                    flushBuilder();
                } else {
                    this.mBuilder.append(c);
                }
            }
        }

        private void flushBuilder() {
            if (this.mBuilder.length() > 0) {
                Log.d("NGGLSurfaceView", this.mBuilder.toString());
                this.mBuilder.delete(0, this.mBuilder.length());
            }
        }
    }

    /* access modifiers changed from: private */
    public static class GLThreadManager {
        private static String TAG = "GLThreadManager";
        private static final int kGLES_20 = 131072;
        private static final String kMSM7K_RENDERER_PREFIX = "Q3Dimension MSM7500 ";
        private GLThread mEglOwner;
        private boolean mGLESDriverCheckComplete;
        private int mGLESVersion;
        private boolean mGLESVersionCheckComplete;
        private boolean mMultipleGLESContextsAllowed;

        private GLThreadManager() {
        }

        public synchronized void threadExiting(GLThread thread) {
            thread.gl_params_out.mExited = true;
            if (this.mEglOwner == thread) {
                this.mEglOwner = null;
            }
            notifyAll();
        }

        public synchronized boolean tryAcquireEglContextLocked(GLThread thread) {
            boolean z = true;
            synchronized (this) {
                if (this.mEglOwner == thread || this.mEglOwner == null) {
                    this.mEglOwner = thread;
                } else {
                    checkGLESVersion();
                    if (!this.mMultipleGLESContextsAllowed) {
                        z = false;
                    }
                }
            }
            return z;
        }

        public void releaseEglContextLocked(GLThread thread) {
            if (this.mEglOwner == thread) {
                this.mEglOwner = null;
            }
        }

        public synchronized boolean shouldReleaseEGLContextWhenPausing() {
            return true;
        }

        public synchronized boolean shouldTerminateEGLWhenPausing() {
            checkGLESVersion();
            return !this.mMultipleGLESContextsAllowed;
        }

        public synchronized void checkGLDriver(GL10 gl) {
            boolean z = true;
            synchronized (this) {
                if (!this.mGLESDriverCheckComplete) {
                    checkGLESVersion();
                    if (this.mGLESVersion < kGLES_20) {
                        if (gl.glGetString(7937).startsWith(kMSM7K_RENDERER_PREFIX)) {
                            z = false;
                        }
                        this.mMultipleGLESContextsAllowed = z;
                        notifyAll();
                    }
                    this.mGLESDriverCheckComplete = true;
                }
            }
        }

        private void checkGLESVersion() {
            if (!this.mGLESVersionCheckComplete) {
                this.mGLESVersion = new ConfigurationInfo().reqGlEsVersion;
                if (this.mGLESVersion >= kGLES_20) {
                    this.mMultipleGLESContextsAllowed = true;
                }
                this.mGLESVersionCheckComplete = true;
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return 1.0f;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        return super.onSetAlpha(alpha);
    }
}
