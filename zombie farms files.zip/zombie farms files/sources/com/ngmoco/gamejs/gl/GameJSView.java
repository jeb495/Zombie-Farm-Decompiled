package com.ngmoco.gamejs.gl;

import android.view.SurfaceHolder;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.SplashScreen;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.gl.InputListener;
import com.ngmoco.gamejs.gl.NGGLSurfaceView;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.JSGLAdapter;
import com.ngmoco.gamejs.ui.ScreenShotter;
import com.ngmoco.gamejs.ui.widgets.UILayout;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.opengles.GL10;
import org.json.JSONArray;
import org.json.JSONObject;

public class GameJSView extends InputListener.ForGLView {
    private static final String GL_EXT_FILE_PATH = "gl_extensions.txt";
    private static final String TAG = "GameJSView";
    private static final boolean USE_GL2 = false;
    public static volatile String sExtensions = null;
    GameJSActivity mActivity;
    private boolean mGLRunning = false;
    private boolean mPaused = false;
    Renderer mRenderer;
    private boolean mRestarting = false;
    ScreenShotter mScreenShotter;
    private boolean mSplashShowing = false;

    /* JADX DEBUG: Multi-variable search result rejected for r2v0, resolved type: com.ngmoco.gamejs.activity.GameJSActivity */
    /* JADX WARN: Multi-variable type inference failed */
    public GameJSView(GameJSActivity activity) {
        super(activity);
        this.mActivity = activity;
        super.setActivity(activity);
        readExtensionCacheFile();
    }

    private void readExtensionCacheFile() {
        try {
            InputStreamReader inFile = new InputStreamReader(this.mActivity.openFileInput(GL_EXT_FILE_PATH));
            StringBuffer buffer = new StringBuffer();
            BufferedReader r = new BufferedReader(inFile, 1024);
            while (true) {
                String temp = r.readLine();
                if (temp == null) {
                    break;
                }
                buffer.append(temp);
            }
            if (buffer.length() > 0) {
                sExtensions = buffer.toString();
                NgJNI.setGLExtensions(sExtensions);
            }
        } catch (FileNotFoundException e) {
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void startThread() {
        super.startThread();
    }

    public void init() {
        init(false, 0, 0);
    }

    private void init(boolean translucent, int depth, int stencil) {
        setEGLConfigChooser(false);
        Log.d(TAG, "Initializing 5");
        Log.d(TAG, "Initializing 6");
        this.mRenderer = new Renderer();
        this.mRenderer.setActivity(this.mActivity);
        this.mRenderer.setView(this);
        Log.d(TAG, "Initializing 7");
        Log.d(TAG, "Initializing 8");
        setRenderer(this.mRenderer);
        Log.d(TAG, "Initializing 9");
        Log.d(TAG, "Initializing 10");
        setOnTouchListener(this);
        setOnKeyListener(this);
        setFocusable(true);
        requestFocus();
        Log.d(TAG, "Initializing 11");
        this.mGLRunning = true;
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void onPause() {
        super.onPause();
        queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.gl.GameJSView.AnonymousClass1 */

            public void run() {
                Log.d(GameJSView.TAG, "onPause mPaused = true");
                GameJSView.this.mPaused = true;
            }
        });
        Commands.getInstance(-1).retainCompositor();
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void onResume() {
        Log.d(TAG, "onResume");
        if (!NgJNI.mGLRunning) {
            mightRestart();
        } else if (this.mRestarting && !NgJNI.isGamePaused()) {
            showResumingDialog();
        }
        super.onResume();
        Commands.getInstance(-1).releaseCompositor();
        this.mActivity.getWindow().addFlags(0);
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void onStart() {
        Log.d(TAG, "onStart");
        super.onStart();
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void onPauseTick() {
        super.onPauseTick();
        Log.d(TAG, "onPauseTick");
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void onResumeTick() {
        Log.d(TAG, "onResumeTick");
        super.onResumeTick();
    }

    public void onPauseRendering() {
        this.mGLRunning = false;
        Log.d(TAG, "Pause just Rendering");
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.gl.GameJSView.AnonymousClass2 */

            public void run() {
                NgJNI.pauseGLRendering();
            }
        });
    }

    public boolean isGLRunning() {
        return this.mGLRunning;
    }

    public void showResumingDialog() {
        this.mSplashShowing = true;
        this.mRestarting = false;
        SplashScreen.setProgressText(ASConstants.kEmptyString);
        SplashScreen.showForGLResume();
        SplashScreen.setProgressText(this.mActivity.getString(R.string.resume_text) + this.mActivity.getString(R.string.resume_text_lastchar));
    }

    public void mightRestart() {
        this.mRestarting = true;
    }

    public void onJSResume() {
        if (this.mRestarting && !NgJNI.isGamePaused()) {
            showResumingDialog();
        }
    }

    public void onResumeRendering() {
        Log.d(TAG, "Resume just Rendering");
        this.mGLRunning = true;
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.gl.GameJSView.AnonymousClass3 */

            public void run() {
                NgJNI.resumeGLRendering();
            }
        });
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void stopGL() {
        this.mGLRunning = false;
        this.mRestarting = false;
        super.stopGL();
    }

    /* access modifiers changed from: private */
    public static void checkEglError(String prompt, EGL10 egl) {
        while (true) {
            int error = egl.eglGetError();
            if (error != 12288) {
                Log.e(TAG, String.format("%s: EGL error: 0x%x", prompt, Integer.valueOf(error)));
            } else {
                return;
            }
        }
    }

    private static class ContextFactory implements NGGLSurfaceView.EGLContextFactory {
        private static int EGL_CONTEXT_CLIENT_VERSION = 12440;

        private ContextFactory() {
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLContextFactory
        public EGLContext createContext(EGL10 egl, EGLDisplay display, EGLConfig eglConfig) {
            Log.w(GameJSView.TAG, "creating OpenGL ES 2.0 context");
            GameJSView.checkEglError("Before eglCreateContext", egl);
            EGLContext context = egl.eglCreateContext(display, eglConfig, EGL10.EGL_NO_CONTEXT, new int[]{EGL_CONTEXT_CLIENT_VERSION, 2, 12344});
            GameJSView.checkEglError("After eglCreateContext", egl);
            return context;
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLContextFactory
        public void destroyContext(EGL10 egl, EGLDisplay display, EGLContext context) {
            egl.eglDestroyContext(display, context);
        }
    }

    private static class ConfigChooser implements NGGLSurfaceView.EGLConfigChooser {
        private static int EGL_OPENGL_ES2_BIT = 4;
        private static int[] s_configAttribs2 = {12324, 4, 12323, 4, 12322, 4, 12352, EGL_OPENGL_ES2_BIT, 12344};
        protected int mAlphaSize;
        protected int mBlueSize;
        protected int mDepthSize;
        protected int mGreenSize;
        protected int mRedSize;
        protected int mStencilSize;
        private int[] mValue = new int[1];

        public ConfigChooser(int r, int g, int b, int a, int depth, int stencil) {
            this.mRedSize = r;
            this.mGreenSize = g;
            this.mBlueSize = b;
            this.mAlphaSize = a;
            this.mDepthSize = depth;
            this.mStencilSize = stencil;
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.EGLConfigChooser
        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display) {
            int[] num_config = new int[1];
            egl.eglChooseConfig(display, s_configAttribs2, null, 0, num_config);
            int numConfigs = num_config[0];
            if (numConfigs <= 0) {
                throw new IllegalArgumentException("No configs match configSpec");
            }
            EGLConfig[] configs = new EGLConfig[numConfigs];
            egl.eglChooseConfig(display, s_configAttribs2, configs, numConfigs, num_config);
            printConfigs(egl, display, configs);
            return chooseConfig(egl, display, configs);
        }

        public EGLConfig chooseConfig(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            for (EGLConfig config : configs) {
                int d = findConfigAttrib(egl, display, config, 12325, 0);
                int s = findConfigAttrib(egl, display, config, 12326, 0);
                if (d >= this.mDepthSize && s >= this.mStencilSize) {
                    int r = findConfigAttrib(egl, display, config, 12324, 0);
                    int g = findConfigAttrib(egl, display, config, 12323, 0);
                    int b = findConfigAttrib(egl, display, config, 12322, 0);
                    int a = findConfigAttrib(egl, display, config, 12321, 0);
                    if (r == this.mRedSize && g == this.mGreenSize && b == this.mBlueSize && a == this.mAlphaSize) {
                        return config;
                    }
                }
            }
            return null;
        }

        private int findConfigAttrib(EGL10 egl, EGLDisplay display, EGLConfig config, int attribute, int defaultValue) {
            if (egl.eglGetConfigAttrib(display, config, attribute, this.mValue)) {
                return this.mValue[0];
            }
            return defaultValue;
        }

        private void printConfigs(EGL10 egl, EGLDisplay display, EGLConfig[] configs) {
            int numConfigs = configs.length;
            Log.d(GameJSView.TAG, String.format("%d configurations", Integer.valueOf(numConfigs)));
            for (int i = 0; i < numConfigs; i++) {
                Log.d(GameJSView.TAG, String.format("Configuration %d:\n", Integer.valueOf(i)));
                printConfig(egl, display, configs[i]);
            }
        }

        private void printConfig(EGL10 egl, EGLDisplay display, EGLConfig config) {
            int[] attributes = {12320, 12321, 12322, 12323, 12324, 12325, 12326, 12327, 12328, 12329, 12330, 12331, 12332, 12333, 12334, 12335, 12336, 12337, 12338, 12339, 12340, 12343, 12342, 12341, 12345, 12346, 12347, 12348, 12349, 12350, 12351, 12352, 12354};
            String[] names = {"EGL_BUFFER_SIZE", "EGL_ALPHA_SIZE", "EGL_BLUE_SIZE", "EGL_GREEN_SIZE", "EGL_RED_SIZE", "EGL_DEPTH_SIZE", "EGL_STENCIL_SIZE", "EGL_CONFIG_CAVEAT", "EGL_CONFIG_ID", "EGL_LEVEL", "EGL_MAX_PBUFFER_HEIGHT", "EGL_MAX_PBUFFER_PIXELS", "EGL_MAX_PBUFFER_WIDTH", "EGL_NATIVE_RENDERABLE", "EGL_NATIVE_VISUAL_ID", "EGL_NATIVE_VISUAL_TYPE", "EGL_PRESERVED_RESOURCES", "EGL_SAMPLES", "EGL_SAMPLE_BUFFERS", "EGL_SURFACE_TYPE", "EGL_TRANSPARENT_TYPE", "EGL_TRANSPARENT_RED_VALUE", "EGL_TRANSPARENT_GREEN_VALUE", "EGL_TRANSPARENT_BLUE_VALUE", "EGL_BIND_TO_TEXTURE_RGB", "EGL_BIND_TO_TEXTURE_RGBA", "EGL_MIN_SWAP_INTERVAL", "EGL_MAX_SWAP_INTERVAL", "EGL_LUMINANCE_SIZE", "EGL_ALPHA_MASK_SIZE", "EGL_COLOR_BUFFER_TYPE", "EGL_RENDERABLE_TYPE", "EGL_CONFORMANT"};
            int[] value = new int[1];
            for (int i = 0; i < attributes.length; i++) {
                int attribute = attributes[i];
                String name = names[i];
                if (egl.eglGetConfigAttrib(display, config, attribute, value)) {
                    Log.w(GameJSView.TAG, String.format("  %s: %d\n", name, Integer.valueOf(value[0])));
                } else {
                    do {
                    } while (egl.eglGetError() != 12288);
                }
            }
        }
    }

    @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView
    public void surfaceDestroyed(SurfaceHolder holder) {
        super.surfaceDestroyed(holder);
        mightRestart();
    }

    static void printThread() {
        Log.i(TAG, "THREAD: thread id: " + Thread.currentThread().getName());
    }

    public void setScreenShotter(ScreenShotter screenShotter) {
        this.mScreenShotter = screenShotter;
    }

    public class Renderer implements NGGLSurfaceView.Renderer {
        int count = 0;
        GameJSActivity mActivity;
        int mHeight;
        private volatile boolean mPerformIntensiveLayout = true;
        private boolean mUpdating = false;
        GameJSView mView;
        int mWidth;
        boolean sNew = true;

        public Renderer() {
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.Renderer
        public boolean onDrawFrame(GL10 gl) {
            if (this.sNew) {
                if (!this.mPerformIntensiveLayout) {
                    return true;
                }
                String[] extensions = gl.glGetString(7939).split(" ");
                JSONArray joe = new JSONArray();
                for (String s : extensions) {
                    joe.put(s);
                }
                String foundExtensions = joe.toString();
                if (!foundExtensions.equals(GameJSView.sExtensions)) {
                    GameJSView.sExtensions = foundExtensions;
                    NgJNI.setGLExtensions(GameJSView.sExtensions);
                    try {
                        GameJSActivity gameJSActivity = this.mActivity;
                        GameJSActivity gameJSActivity2 = this.mActivity;
                        OutputStreamWriter outFile = new OutputStreamWriter(gameJSActivity.openFileOutput(GameJSView.GL_EXT_FILE_PATH, 0));
                        outFile.write(GameJSView.sExtensions);
                        outFile.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                this.sNew = false;
                this.mPerformIntensiveLayout = false;
                Log.d(GameJSView.TAG, "width is :" + this.mWidth);
                Log.d(GameJSView.TAG, "height is :" + this.mHeight);
                NgJNI.doInitGL(this.mWidth, this.mHeight);
                GameJSView.this.onStart();
                JSGLAdapter adp = JSGLAdapter.getInstance();
                if (adp != null) {
                    try {
                        JSONObject props = new JSONObject();
                        props.put("OGLExtensions", joe);
                        JSONObject event = new JSONObject();
                        event.put("objId", adp.objId());
                        event.put(NgSystemBindingService.EXTRA_NAME, AbstractJSAdapter.Events.UPDATE);
                        event.put("properties", props);
                        adp.context().sendEvent(event.toString());
                    } catch (Exception ex) {
                        Log.e(GameJSView.TAG, ex.getMessage() != null ? ex.getMessage() : "no message");
                    }
                }
                if (adp != null) {
                    adp.triggerCustomEventResponse(AbstractJSAdapter.Events.LOAD, new Object[0]);
                }
                Commands.frameWillStart();
                boolean bRet = NgJNI.glTick();
                Commands.frameFinished();
                this.mActivity.runOnUiThread(new Runnable() {
                    /* class com.ngmoco.gamejs.gl.GameJSView.Renderer.AnonymousClass1 */

                    public void run() {
                        SplashScreen.procDidStart(-2);
                        GameJSView.this.mSplashShowing = false;
                        UILayout rootLayout = Renderer.this.mActivity.getRootLayout();
                        rootLayout.invalidate();
                        rootLayout.requestLayout();
                        Log.d(GameJSView.TAG, "Requested Layout change after removing splash");
                    }
                });
                return bRet;
            } else if (this.mUpdating) {
                return true;
            } else {
                Commands.frameWillStart();
                boolean bRet2 = NgJNI.glTick();
                Commands.frameFinished();
                if (GameJSView.this.mScreenShotter != null) {
                    GameJSView.this.mScreenShotter.takeGLScreenShot(gl);
                    GameJSView.this.mScreenShotter = null;
                }
                if (!GameJSView.this.mSplashShowing) {
                    return bRet2;
                }
                SplashScreen.procDidStart(-2);
                GameJSView.this.mSplashShowing = false;
                return bRet2;
            }
        }

        public void setActivity(GameJSActivity activity) {
            this.mActivity = activity;
        }

        public void setView(GameJSView view) {
            this.mView = view;
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.Renderer
        public void onSurfaceChanged(GL10 gl, final int width, final int height) {
            Log.d(GameJSView.TAG, "Surface Changed");
            this.mWidth = width;
            this.mHeight = height;
            if (this.sNew) {
                this.mActivity.runOnUiThread(new Runnable() {
                    /* class com.ngmoco.gamejs.gl.GameJSView.Renderer.AnonymousClass2 */

                    public void run() {
                        Log.d(GameJSView.TAG, "this seems to be a new instance");
                        UILayout rootLayout = Renderer.this.mActivity.getRootLayout();
                        Renderer.this.mPerformIntensiveLayout = true;
                        rootLayout.invalidate();
                        rootLayout.requestLayout();
                    }
                });
                return;
            }
            if (GameJSView.this.mRestarting && !NgJNI.isGamePaused()) {
                GameJSView.this.showResumingDialog();
            }
            if (Thread.currentThread() != GameJSView.mGLThread) {
                this.mUpdating = true;
                NgEngine.getInstance().queueEvent(new Runnable() {
                    /* class com.ngmoco.gamejs.gl.GameJSView.Renderer.AnonymousClass3 */

                    public void run() {
                        if (GameJSView.this.mPaused || GameJSView.this.mRestarting) {
                            Log.d(GameJSView.TAG, "resume gl where you left");
                            NgJNI.resumeGL();
                            GameJSView.this.mPaused = false;
                        }
                        NgJNI.updateGL(width, height);
                        Renderer.this.mUpdating = false;
                    }
                });
                return;
            }
            if (GameJSView.this.mPaused || GameJSView.this.mRestarting) {
                Log.d(GameJSView.TAG, "resume gl where you left");
                NgJNI.resumeGL();
                GameJSView.this.mPaused = false;
            }
            NgJNI.updateGL(width, height);
        }

        @Override // com.ngmoco.gamejs.gl.NGGLSurfaceView.Renderer
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            Log.d(GameJSView.TAG, "onSurfaceCreated");
        }
    }
}
