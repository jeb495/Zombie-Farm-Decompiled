package com.ngmoco.gamejs.gl;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgEngine;
import com.ngmoco.gamejs.NgJNI;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class InputListener {
    static final int DOWN = 0;
    static final int MOVE = 2;
    static final int PRIMARY_ACTION_DIFF = 5;
    static final String TAG = "InputListener";
    static final int UP = 1;

    public static class ForView implements View.OnTouchListener, View.OnKeyListener {
        public boolean onTouch(View v, MotionEvent event) {
            return InputListener.onTouch(v, event);
        }

        public boolean onKey(View v, int keyCode, KeyEvent event) {
            return InputListener.onKey(v, keyCode, event);
        }
    }

    public static abstract class ForGLView extends NGGLSurfaceView implements View.OnTouchListener, View.OnKeyListener {
        public ForGLView(Context context) {
            super(context);
        }

        public ForGLView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public ForGLView(Context context, boolean translucent, int depth, int stencil, String game, String server) {
            super(context);
        }

        public boolean onTouch(View v, MotionEvent event) {
            return InputListener.onTouch(v, event);
        }

        public boolean onKey(View v, int keyCode, KeyEvent event) {
            return InputListener.onKey(v, keyCode, event);
        }
    }

    /* access modifiers changed from: private */
    public static boolean onKey(View v, final int keyCode, final KeyEvent event) {
        Log.v(TAG, "Key pressed " + keyCode);
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.gl.InputListener.AnonymousClass1 */

            public void run() {
                NgJNI.keyEvent(event.getAction() == 0 ? 1 : 0, event.getMetaState(), keyCode);
            }
        });
        return true;
    }

    /* access modifiers changed from: private */
    public static boolean onTouch(View v, MotionEvent event) {
        int touchAction = event.getAction() & SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
        if (touchAction == 2) {
            int count = event.getPointerCount();
            for (int i = 0; i < count; i++) {
                queueTouch(2, event.getPointerId(i) + 1, (int) event.getX(i), (int) event.getY(i));
            }
        } else {
            int touchIndex = event.getAction() >> 8;
            int touchId = event.getPointerId(touchIndex);
            if (touchAction == 1 || touchAction == 6 || touchAction == 3) {
                queueTouch(1, touchId + 1, (int) event.getX(touchIndex), (int) event.getY(touchIndex));
            } else if (touchAction == 0 || touchAction == 5) {
                queueTouch(0, touchId + 1, (int) event.getX(touchIndex), (int) event.getY(touchIndex));
            }
        }
        return true;
    }

    private static void queueTouch(final int action, final int id, final int xPos, final int yPos) {
        NgEngine.getInstance().queueEvent(new Runnable() {
            /* class com.ngmoco.gamejs.gl.InputListener.AnonymousClass2 */

            public void run() {
                NgJNI.touch(action, id, xPos, yPos);
            }
        });
    }
}
