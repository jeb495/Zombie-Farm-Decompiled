package com.ngmoco.gamejs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import com.android.adsymp.core.ASConstants;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.ad.AdfonicReporter;
import com.ngmoco.gamejs.ad.AdmobReporter;
import com.ngmoco.gamejs.ad.AdsymptoticReporter;
import com.ngmoco.gamejs.ad.Advertiser;
import com.ngmoco.gamejs.ad.BestCoolFunGamesReporter;
import com.ngmoco.gamejs.ad.ChartBoostReporter;
import com.ngmoco.gamejs.ad.FiksuReporter;
import com.ngmoco.gamejs.ad.FlurryReporter;
import com.ngmoco.gamejs.ad.G6PayReporter;
import com.ngmoco.gamejs.ad.GameViewReporter;
import com.ngmoco.gamejs.ad.GoogleAnalyticsReporter;
import com.ngmoco.gamejs.ad.GreyStripeReporter;
import com.ngmoco.gamejs.ad.InMobiReporter;
import com.ngmoco.gamejs.ad.InstallReporter;
import com.ngmoco.gamejs.ad.JumpTapReporter;
import com.ngmoco.gamejs.ad.LaunchReporter;
import com.ngmoco.gamejs.ad.LeadboltReporter;
import com.ngmoco.gamejs.ad.LifeStreetReporter;
import com.ngmoco.gamejs.ad.MdotmReporter;
import com.ngmoco.gamejs.ad.MillennialReporter;
import com.ngmoco.gamejs.ad.MobclixReporter;
import com.ngmoco.gamejs.ad.MojivaReporter;
import com.ngmoco.gamejs.ad.SessionReporter;
import com.ngmoco.gamejs.ad.SponsorPayReporter;
import com.ngmoco.gamejs.ad.TapItReporter;
import com.ngmoco.gamejs.ad.TapjoyReporter;
import com.ngmoco.gamejs.ad.W3iReporter;
import com.ngmoco.gamejs.ad.gametheory.AppendaReporter;
import com.ngmoco.gamejs.ad.gametheory.OfferLabsReporter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class TrackingReceiver extends BroadcastReceiver {
    private static final String FILENAME = "installreferrer";
    private static final String INSTALL_TRACKED = "INSTALL_TRACKED";
    private static final String PREFS_PACKAGE = "com.mobage";
    private static final int SPONSORPAY_CHECK_MANIFEST = -1;
    private static final String TAG = "TrackingReceiver";
    private static final HashMap<Class<?>, Integer> sAdvertiserKeys = new HashMap<>();
    static boolean sTracked = false;

    static {
        sAdvertiserKeys.put(AdfonicReporter.class, Integer.valueOf((int) R.string._ad_use_Adfonic));
        sAdvertiserKeys.put(AdmobReporter.class, Integer.valueOf((int) R.string._ad_use_Admob));
        sAdvertiserKeys.put(AdsymptoticReporter.class, Integer.valueOf((int) R.string._ad_use_Adsymptotic));
        sAdvertiserKeys.put(BestCoolFunGamesReporter.class, Integer.valueOf((int) R.string._ad_use_BestCoolFunGames));
        sAdvertiserKeys.put(ChartBoostReporter.class, Integer.valueOf((int) R.string._ad_ChartBoostAppId));
        sAdvertiserKeys.put(FiksuReporter.class, Integer.valueOf((int) R.string._ad_use_Fiksu));
        sAdvertiserKeys.put(FlurryReporter.class, Integer.valueOf((int) R.string._ad_FlurryAppId));
        sAdvertiserKeys.put(G6PayReporter.class, Integer.valueOf((int) R.string._G6PayAppId));
        sAdvertiserKeys.put(GameViewReporter.class, Integer.valueOf((int) R.string._GameViewAppId));
        sAdvertiserKeys.put(GoogleAnalyticsReporter.class, Integer.valueOf((int) R.string._ad_use_GoogleAnalytics));
        sAdvertiserKeys.put(GreyStripeReporter.class, Integer.valueOf((int) R.string._GreystripeAppId));
        sAdvertiserKeys.put(InMobiReporter.class, Integer.valueOf((int) R.string._ad_use_InMobi));
        sAdvertiserKeys.put(JumpTapReporter.class, Integer.valueOf((int) R.string._ad_use_JumpTap));
        sAdvertiserKeys.put(LeadboltReporter.class, Integer.valueOf((int) R.string._ad_LeadBoltIntAppId));
        sAdvertiserKeys.put(LifeStreetReporter.class, Integer.valueOf((int) R.string._ad_use_LifeStreet));
        sAdvertiserKeys.put(MdotmReporter.class, Integer.valueOf((int) R.string._ad_use_MdotM));
        sAdvertiserKeys.put(MillennialReporter.class, Integer.valueOf((int) R.string._MillenialAppId));
        sAdvertiserKeys.put(MobclixReporter.class, Integer.valueOf((int) R.string._ad_use_Mobclix));
        sAdvertiserKeys.put(MojivaReporter.class, Integer.valueOf((int) R.string._ad_use_Mojiva));
        sAdvertiserKeys.put(SponsorPayReporter.class, -1);
        sAdvertiserKeys.put(TapItReporter.class, Integer.valueOf((int) R.string._ad_use_TapIt));
        sAdvertiserKeys.put(TapjoyReporter.class, Integer.valueOf((int) R.string._TapjoyAppId));
        sAdvertiserKeys.put(W3iReporter.class, Integer.valueOf((int) R.string._ad_W3iAppId));
        sAdvertiserKeys.put(AppendaReporter.class, Integer.valueOf((int) R.string._ad_GameTheory_AppendaAppId));
        sAdvertiserKeys.put(OfferLabsReporter.class, Integer.valueOf((int) R.string._ad_GameTheory_OfferLabsAppId));
    }

    private static ArrayList<Advertiser> getAdvertisers(Context ctx, Class<?> interfaceClass) {
        ArrayList<Advertiser> advertisers = new ArrayList<>();
        for (Class<?> advertiserClass : sAdvertiserKeys.keySet()) {
            if (interfaceClass.isAssignableFrom(advertiserClass)) {
                try {
                    int key = sAdvertiserKeys.get(advertiserClass).intValue();
                    if (key != -1) {
                        String shouldUse = ctx.getString(key);
                        if (shouldUse != null) {
                            if (shouldUse.equals(ASConstants.kEmptyString)) {
                            }
                        }
                    } else if (!SponsorPayReporter.isEnabled(ctx)) {
                    }
                    Advertiser newAdvertiser = (Advertiser) advertiserClass.newInstance();
                    newAdvertiser.configure(ctx);
                    advertisers.add(newAdvertiser);
                } catch (Throwable t) {
                    Log.e(TAG, "Error creating instance of " + advertiserClass.getSimpleName() + " : " + t.getMessage());
                }
            }
        }
        return advertisers;
    }

    public void onReceive(Context context, Intent intent) {
        onInstall(context, intent);
        String installReferrer = intent.getStringExtra("referrer");
        if (installReferrer != null) {
            setInstallReferrer(context, URLDecoder.decode(installReferrer));
        } else {
            Log.w(TAG, "referrer not found");
        }
        if (!context.getPackageName().startsWith("jp.mbga.portal")) {
            Iterator i$ = getAdvertisers(context, InstallReporter.class).iterator();
            while (i$.hasNext()) {
                Advertiser advertiser = i$.next();
                if (advertiser instanceof InstallReporter) {
                    Log.d(TAG, "sending onTrackingOnInstall: " + advertiser.getClass().getSimpleName());
                    ((InstallReporter) advertiser).sendTrackingOnInstall(context, intent);
                }
            }
        }
    }

    private void onInstall(Context c, Intent i) {
        try {
            String referrer = i.getStringExtra("referrer");
            FileWriter fw = new FileWriter(new File(c.getFilesDir().getAbsolutePath() + "/referrer"));
            fw.write(referrer);
            fw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void setInstallReferrer(Context context, String installReferrer) {
        try {
            FileInputStream fis = context.openFileInput(FILENAME);
            Log.d(TAG, "install referrer already set. Will not override");
            fis.close();
        } catch (Exception e) {
            try {
                FileOutputStream fos = context.openFileOutput(FILENAME, 0);
                fos.write(installReferrer.getBytes());
                Log.d(TAG, "set " + installReferrer + " to " + context.getFilesDir().getPath());
                fos.close();
            } catch (Exception e2) {
                Log.e(TAG, "Failed to write install referrer.");
            }
        }
    }

    public static String getInstallReferrer(Context context) {
        try {
            FileInputStream fis = context.openFileInput(FILENAME);
            byte[] buffer = new byte[1024];
            int numRead = fis.read(buffer, 0, 1023);
            fis.close();
            String installReferrer = new String(buffer, 0, numRead);
            Log.d(TAG, "get " + installReferrer + " from " + context.getFilesDir().getPath());
            return installReferrer;
        } catch (Exception e) {
            Log.d(TAG, "referrer not found");
            return null;
        }
    }

    public void sendTrackingOnLaunch(final Context context, Intent intent) {
        if (!sTracked && isFirstLaunch(context)) {
            final ArrayList<Advertiser> launchReporters = getAdvertisers(context, LaunchReporter.class);
            new AsyncTask<Object, Object, Object>() {
                /* class com.ngmoco.gamejs.TrackingReceiver.AnonymousClass1 */

                /* access modifiers changed from: protected */
                @Override // android.os.AsyncTask
                public Object doInBackground(Object... params) {
                    if (TrackingReceiver.this.isFirstLaunch(context)) {
                        Iterator i$ = launchReporters.iterator();
                        while (i$.hasNext()) {
                            Advertiser advertiser = (Advertiser) i$.next();
                            if (advertiser instanceof LaunchReporter) {
                                Log.d(TrackingReceiver.TAG, "sending TrackingOnLaunch: " + advertiser.getClass().getSimpleName());
                                try {
                                    ((LaunchReporter) advertiser).sendTrackingOnLaunch(context);
                                } catch (Throwable e) {
                                    Log.e(TrackingReceiver.TAG, ASConstants.kEmptyString + advertiser.getClass().getSimpleName() + " threw an exception: " + e.toString());
                                }
                            }
                        }
                        TrackingReceiver.this.setHasLaunched(context);
                    }
                    return null;
                }
            }.execute(new Object[0]);
        }
    }

    public boolean isFirstLaunch(Context context) {
        if (context.getApplicationContext().getSharedPreferences(PREFS_PACKAGE, 0).getString(INSTALL_TRACKED, null) == null) {
            return true;
        }
        return false;
    }

    public void setHasLaunched(Context context) {
        SharedPreferences.Editor editPrefs = context.getApplicationContext().getSharedPreferences(PREFS_PACKAGE, 0).edit();
        editPrefs.putString(INSTALL_TRACKED, Boolean.TRUE.toString());
        editPrefs.commit();
    }

    public void wipeFirstLaunchInformation(Context context) {
        SharedPreferences.Editor editPrefs = context.getApplicationContext().getSharedPreferences(PREFS_PACKAGE, 0).edit();
        editPrefs.remove(INSTALL_TRACKED);
        editPrefs.commit();
    }

    public void startSession(Context context, Intent intent) {
        Iterator i$ = getAdvertisers(context, SessionReporter.class).iterator();
        while (i$.hasNext()) {
            Advertiser advertiser = i$.next();
            if (advertiser instanceof SessionReporter) {
                Log.d(TAG, "starting session: " + advertiser.getClass().getSimpleName());
                try {
                    ((SessionReporter) advertiser).start(context);
                } catch (Throwable e) {
                    Log.e(TAG, ASConstants.kEmptyString + advertiser.getClass().getSimpleName() + " threw an exception: " + e.toString());
                }
            }
        }
    }

    public void stopSession(Context context) {
        Iterator i$ = getAdvertisers(context, SessionReporter.class).iterator();
        while (i$.hasNext()) {
            Advertiser advertiser = i$.next();
            if (advertiser instanceof SessionReporter) {
                Log.d(TAG, "stopping session: " + advertiser.getClass().getSimpleName());
                try {
                    ((SessionReporter) advertiser).stop(context);
                } catch (Throwable e) {
                    Log.e(TAG, ASConstants.kEmptyString + advertiser.getClass().getSimpleName() + " threw an exception: " + e.toString());
                }
            }
        }
    }
}
