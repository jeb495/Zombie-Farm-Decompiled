package com.ngmoco.gamejs.ui;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UICheckoutView;
import com.ngmoco.util.Base64;

public class JSCheckoutViewAdapter extends AbstractJSViewAdapter {

    /* access modifiers changed from: private */
    public class InsideWebViewClient extends WebViewClient {
        private final String INNERTAG;

        private InsideWebViewClient() {
            this.INNERTAG = InsideWebViewClient.class.getSimpleName();
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            if (JSCheckoutViewAdapter.this.mCustomEventResponses.containsKey(AbstractJSAdapter.Events.LOAD)) {
                JSCheckoutViewAdapter.this.triggerCustomEventResponse(AbstractJSAdapter.Events.LOAD, "urlEncoded", Base64.encodeToString(url.getBytes(), 0));
            }
            view.loadUrl(url);
            return true;
        }
    }

    private JSCheckoutViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSCheckoutViewAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UICheckoutView(this.mJSContext.getActivity());
        UICheckoutView webView = (UICheckoutView) this.mView;
        webView.setWebViewClient(new InsideWebViewClient());
        webView.requestFocus(Commands.CommandIDs.playVideo);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        if (this.mView == null) {
            throw new NullPointerException("View is not initialized for an update");
        }
        UICheckoutView checkoutView = (UICheckoutView) this.mView;
        switch (commandId) {
            case Commands.CommandIDs.setPostData /*{ENCODED_INT: 73}*/:
                checkoutView.setPostData((String) args[0]);
                return this;
            case Commands.CommandIDs.loadPostURL /*{ENCODED_INT: 74}*/:
                checkoutView.loadPostUrl((String) args[0]);
                return this;
            case 75:
                checkoutView.loadUrl((String) args[0]);
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }
}
