package com.ngmoco.gamejs.ui;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.OrientationRestrictable;
import com.ngmoco.gamejs.ui.widgets.StatefulWidget;
import com.ngmoco.gamejs.ui.widgets.Styleable;
import com.ngmoco.gamejs.ui.widgets.Touchable;
import com.ngmoco.gamejs.ui.widgets.UIDrawable;
import com.ngmoco.gamejs.ui.widgets.UIWidget;
import com.ngmoco.gamejs.ui.widgets.UIWidgetCommon;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class AbstractJSViewAdapter extends AbstractJSAdapter implements JSViewAdapter {
    protected static final String ERR_MSG_NOT_VIEW_GROUP = "View is not a view group";
    protected static final String ERR_MSG_UNINITIALIZED_WIDGET = "View is not initialized for an update";
    private static final String TAG = "AbstractJSViewAdapter";
    TouchHandler mTouchHandler;
    protected View mView;

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public JSViewAdapter createView() throws Exception {
        if (this.mView == null) {
            throw new NullPointerException(ERR_MSG_UNINITIALIZED_WIDGET);
        }
        if (!(this instanceof JSGLAdapter)) {
            sendEventResponse(AbstractJSAdapter.Events.LOAD, new Object[0]);
        }
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public View getView() {
        return this.mView;
    }

    /* access modifiers changed from: protected */
    public TouchHandler getTouchHandler() {
        if (this.mTouchHandler == null) {
            this.mTouchHandler = new TouchHandler(this);
            this.mView.setOnTouchListener(this.mTouchHandler);
        }
        return this.mTouchHandler;
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public JSViewAdapter removeFromSuperview() throws Exception {
        if (this.mView.getAnimation() != null) {
            Utils.removeAnimation(this.mView);
        }
        if (this.mJSContext.getAnimationBlock() != null) {
            this.mJSContext.getAnimationBlock().addDisappearAnimation(this.mView);
        } else {
            ViewParent pV = this.mView.getParent();
            if (pV == this.mJSContext.getActivity().getRootLayout()) {
                JSWindowLayerAdapter.removeChild(this.mView);
            } else if (pV != null && (pV instanceof ViewGroup)) {
                ((ViewGroup) pV).removeView(this.mView);
            }
        }
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter enableEventResponse(String eventType, boolean enable) throws Exception {
        super.enableEventResponse(eventType, enable);
        if (eventType.equalsIgnoreCase(AbstractJSAdapter.Events.CLICK)) {
            getTouchHandler().listenForTouch(enable);
        } else if (eventType.equalsIgnoreCase(AbstractJSAdapter.Events.CLICK_CANCEL)) {
            getTouchHandler().listenForTouchCancel(enable);
        } else if (eventType.equalsIgnoreCase(AbstractJSAdapter.Events.CLICK_DOWN)) {
            getTouchHandler().listenForTouchDown(enable);
        } else if (eventType.equalsIgnoreCase(AbstractJSAdapter.Events.LONGPRESS)) {
            this.mView.setOnLongClickListener(enable ? getTouchHandler() : null);
        } else if (eventType.equalsIgnoreCase(AbstractJSAdapter.Events.SWIPE)) {
            getTouchHandler().listenForSwipe(true);
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void setTouchable(boolean canTouch) {
        if (this.mTouchHandler != null && !canTouch) {
            this.mTouchHandler.purge(this.mView);
        }
        if (this.mView instanceof Touchable) {
            ((Touchable) this.mView).setTouchable(canTouch);
        } else {
            getTouchHandler().listenForTouch(canTouch);
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        boolean z;
        int i = 0;
        if (this.mView == null) {
            throw new NullPointerException(ERR_MSG_UNINITIALIZED_WIDGET);
        }
        AnimationBlock a = this.mJSContext.getAnimationBlock();
        switch (commandId) {
            case 5:
                setTouchable(((Boolean) args[0]).booleanValue());
                return this;
            case 9:
                View view = this.mView;
                if (!((Boolean) args[0]).booleanValue()) {
                    i = 8;
                }
                view.setVisibility(i);
                return this;
            case 10:
                this.mView.setEnabled(((Boolean) args[0]).booleanValue());
                return this;
            case 11:
                View view2 = this.mView;
                if ((((Integer) args[0]).intValue() & Commands.State.Disabled) == 0) {
                    z = true;
                } else {
                    z = false;
                }
                view2.setEnabled(z);
                if (!(this.mView instanceof StatefulWidget)) {
                    return this;
                }
                ((StatefulWidget) this.mView).setState(((Integer) args[0]).intValue());
                return this;
            case 13:
                removeFromSuperview();
                return this;
            case 16:
                if (a != null && this.mView.getVisibility() == 0) {
                    a.addFrameAnimation(this.mView, Utils.floatArray(args));
                    return this;
                } else if (this.mView instanceof UIWidget) {
                    UIWidgetCommon.setFrame((UIWidget) this.mView, Utils.floatArray(args));
                    return this;
                } else {
                    UIWidgetCommon.setLayout(this.mView, Utils.floatArray(args));
                    return this;
                }
            case Commands.CommandIDs.setBackgroundColor /*{ENCODED_INT: 21}*/:
                Drawable bkgrnd = this.mView.getBackground();
                JSONObject temp = gradientJSONForColor((String) args[0]);
                if (bkgrnd == null || !(bkgrnd instanceof UIDrawable)) {
                    return this;
                }
                ((UIDrawable) bkgrnd).setGradientDefinition(temp, subCommand);
                return this;
            case Commands.CommandIDs.setGradient /*{ENCODED_INT: 51}*/:
                Drawable d = this.mView.getBackground();
                if (d == null || !(d instanceof UIDrawable)) {
                    Log.w(getClass().getSimpleName(), "Trying to set gradient def for " + this.mView.getClass().getSimpleName() + " with drawable of type " + (d == null ? "null" : d.getClass().getSimpleName()));
                    return this;
                }
                ((UIDrawable) d).setGradientDefinition((String) args[0], subCommand);
                return this;
            case Commands.CommandIDs.setAlpha /*{ENCODED_INT: 97}*/:
                if (!(this.mView instanceof UIWidget)) {
                    return this;
                }
                float fAlpha = ((Float) args[0]).floatValue();
                if (a != null) {
                    a.addAlphaAnimation(this.mView, UIWidgetCommon.getAlpha((UIWidget) this.mView), fAlpha);
                }
                UIWidgetCommon.setAlpha((UIWidget) this.mView, fAlpha);
                return this;
            case Commands.CommandIDs.clearAnimations /*{ENCODED_INT: 126}*/:
                Utils.removeAnimation(this.mView);
                return this;
            case Commands.CommandIDs.setStyle /*{ENCODED_INT: 127}*/:
                if (!(this.mView instanceof Styleable)) {
                    return this;
                }
                ((Styleable) this.mView).setStyle(((JSStyleAdapter) this.mJSContext.getAdapter((Integer) args[0])).getStyle());
                return this;
            case Commands.CommandIDs.setVisibleInOrientations /*{ENCODED_INT: 128}*/:
                if (!(this.mView instanceof OrientationRestrictable)) {
                    return this;
                }
                ((OrientationRestrictable) this.mView).setVisibleInOrientations(((Integer) args[0]).intValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    /* access modifiers changed from: protected */
    public JSONObject gradientJSONForColor(String value) {
        JSONException e;
        JSONObject temp = null;
        try {
            JSONObject temp2 = new JSONObject();
            try {
                temp2.accumulate("gradient", value + " 0.0");
                temp2.accumulate("gradient", value + " 1.0");
                return temp2;
            } catch (JSONException e2) {
                e = e2;
                temp = temp2;
                e.printStackTrace();
                return temp;
            }
        } catch (JSONException e3) {
            e = e3;
            e.printStackTrace();
            return temp;
        }
    }

    protected AbstractJSViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public void cleanup() {
        try {
            removeFromSuperview();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
