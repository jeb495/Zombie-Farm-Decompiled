package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIProgressDialog;

public class JSProgressDialogAdapter extends AbstractJSAdapter {
    private UIProgressDialog mDialog;
    private boolean mShowing;

    private JSProgressDialogAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSProgressDialogAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [com.ngmoco.gamejs.activity.JSActivity, android.app.Activity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    private JSProgressDialogAdapter createView() {
        this.mDialog = new UIProgressDialog(this.mJSContext.getActivity());
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case Commands.CommandIDs.setText:
                this.mDialog.setMessage((String) args[0]);
                return this;
            case Commands.CommandIDs.setTitle:
                this.mDialog.setTitle((String) args[0]);
                return this;
            case Commands.CommandIDs.show:
                if (this.mShowing) {
                    return this;
                }
                this.mDialog.showDialog();
                this.mShowing = true;
                return this;
            case Commands.CommandIDs.hide:
                if (!this.mShowing) {
                    return this;
                }
                this.mDialog.dismissDialog();
                this.mShowing = false;
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public void cleanup() {
        this.mDialog.dismissDialog();
    }
}
