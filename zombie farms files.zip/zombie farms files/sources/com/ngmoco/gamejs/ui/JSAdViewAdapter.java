package com.ngmoco.gamejs.ui;

import android.graphics.Canvas;
import android.view.ViewGroup;
import com.mobclix.android.sdk.MobclixAdView;
import com.mobclix.android.sdk.MobclixAdViewListener;
import com.mobclix.android.sdk.MobclixMMABannerXLAdView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.widgets.UILayout;

public class JSAdViewAdapter extends AbstractJSViewAdapter implements MobclixAdViewListener {
    private static final String LOAD_FAILURE = "failedload";
    private static final String TAG = "JSAdViewAdapter";
    private MobclixAdView mAdView = null;
    private boolean mAutoplay = false;
    private boolean mAutoplaySet = false;
    private boolean mCustomRefreshRate = false;
    private boolean mPaused = false;
    private long mRefreshRate;

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSAdViewAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARN: Type inference failed for: r1v3, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 2 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mAdView = new MobclixMMABannerXLAdView(this.mJSContext.getActivity());
        this.mAdView.addMobclixAdViewListener(this);
        this.mAdView.setPadding(0, 0, 0, 0);
        enableEventResponse(LOAD_FAILURE, true);
        enableEventResponse(AbstractJSAdapter.Events.LOAD, true);
        enableEventResponse(AbstractJSAdapter.Events.CLICK, true);
        this.mView = new UILayout.Root(this.mJSContext.getActivity(), null) {
            /* class com.ngmoco.gamejs.ui.JSAdViewAdapter.AnonymousClass1 */

            @Override // com.ngmoco.gamejs.ui.widgets.UILayout.Root, com.ngmoco.gamejs.ui.widgets.UILayout
            public void draw(Canvas canvas) {
                if (isLayoutRequested()) {
                    measure(getWidth(), getHeight());
                    layout(this.mX, this.mY, this.mX + getWidth(), this.mY + getHeight());
                }
                super.draw(canvas);
            }
        };
        this.mView.setBackgroundColor(0);
        ((ViewGroup) this.mView).addView(this.mAdView);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public void cleanup() {
        this.mAdView.removeMobclixAdViewListener(this);
        this.mAdView.removeAllViews();
        ((ViewGroup) this.mView).removeAllViews();
        super.cleanup();
    }

    private JSAdViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        if (commandId != 93) {
            if (commandId != 94) {
                if (commandId != 95) {
                    if (commandId != 96) {
                        switch (commandId) {
                            case 16:
                                int w = ((Float) args[2]).intValue();
                                int h = ((Float) args[3]).intValue();
                                super.handleCommand(commandId, subCommand, args);
                                this.mAdView.setLayoutParams(new ViewGroup.LayoutParams(w, h));
                                break;
                            default:
                                super.handleCommand(commandId, subCommand, args);
                                break;
                        }
                    } else {
                        Log.d(TAG, "set Ad Allow autoplay");
                        if (args[0] != null) {
                            this.mAutoplaySet = true;
                            this.mAutoplay = ((Boolean) args[0]).booleanValue();
                            Log.d(TAG, "AutoPlay set to :" + this.mAutoplay);
                            this.mAdView.setAllowAutoplay(this.mAutoplay);
                        }
                    }
                } else {
                    Log.d(TAG, "set Ad Refresh Rate");
                    if (args[0] != null) {
                        this.mCustomRefreshRate = true;
                        this.mRefreshRate = ((Integer) args[0]).longValue();
                        Log.d(TAG, "set Ad Refresh Rate is " + this.mRefreshRate);
                        this.mAdView.setRefreshTime(this.mRefreshRate);
                    }
                }
            } else {
                Log.d(TAG, "resume ads");
                this.mPaused = false;
                this.mAdView.resume();
            }
        } else {
            Log.d(TAG, "paused ads");
            this.mPaused = true;
            this.mAdView.pause();
        }
        return this;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onSuccessfulLoad(MobclixAdView adView) {
        triggerCustomEventResponse(AbstractJSAdapter.Events.LOAD, "network_id", "Mobclix");
        if (this.mCustomRefreshRate) {
            adView.setRefreshTime(this.mRefreshRate);
        }
        if (this.mPaused) {
            adView.pause();
        } else {
            adView.resume();
        }
        if (this.mAutoplaySet) {
            adView.setAllowAutoplay(this.mAutoplay);
        }
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onFailedLoad(MobclixAdView adView, int errorCode) {
        triggerCustomEventResponse(LOAD_FAILURE, "custom_url", Integer.valueOf(errorCode));
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public boolean onOpenAllocationLoad(MobclixAdView adView, int openAllocationCode) {
        return false;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public String keywords() {
        return null;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public String query() {
        return null;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onAdClick(MobclixAdView adView) {
        onCustomAdTouchThrough(adView, null);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter enableEventResponse(String eventType, boolean enable) throws Exception {
        if (!AbstractJSAdapter.Events.CLICK.equals(eventType)) {
            super.enableEventResponse(eventType, enable);
        }
        return this;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onCustomAdTouchThrough(MobclixAdView adView, String string) {
        sendEventResponse(AbstractJSAdapter.Events.CLICK, "custom_url", string);
    }
}
