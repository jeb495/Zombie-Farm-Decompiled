package com.ngmoco.gamejs.ui;

public interface Operation {
    void cancel();
}
