package com.ngmoco.gamejs.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class RelativeLayoutForSplash extends RelativeLayout {
    public RelativeLayoutForSplash(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public RelativeLayoutForSplash(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RelativeLayoutForSplash(Context context) {
        super(context);
    }

    /* access modifiers changed from: protected */
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec - (widthMeasureSpec % 4), heightMeasureSpec - (heightMeasureSpec % 4));
    }
}
