package com.ngmoco.gamejs.ui;

import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIEditText;
import com.ngmoco.gamejs.ui.widgets.UIShadow;

public class JSEditTextAdapter extends AbstractJSViewAdapter implements TextWatcher {
    private static final String TAG = "JSEditTextAdapter";
    protected static JSEditTextAdapter sCurrentlyFocusedAdapter = null;
    private boolean mJSFocused = false;

    protected JSEditTextAdapter(Commands jsContext, Integer objId) throws Exception {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSEditTextAdapter(jsContext, objId).createView();
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        return createView(true, 19);
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* access modifiers changed from: protected */
    /* JADX WARNING: Unknown variable types count: 1 */
    public JSViewAdapter createView(boolean singleLine, int gravity) throws Exception {
        UIEditText textView = new UIEditText(this.mJSContext.getActivity()) {
            /* class com.ngmoco.gamejs.ui.JSEditTextAdapter.AnonymousClass1 */

            /* access modifiers changed from: protected */
            public void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
                JSEditTextAdapter.this.widgetFocusChanged(focused);
                if (focused) {
                    JSEditTextAdapter.this.mJSContext.retainCompositor();
                    showKeyboard();
                } else {
                    JSEditTextAdapter.this.mJSContext.releaseCompositor();
                }
                super.onFocusChanged(focused, direction, previouslyFocusedRect);
            }

            public void onEditorAction(int actionCode) {
                switch (actionCode) {
                    case 5:
                    default:
                        super.onEditorAction(actionCode);
                        return;
                    case 2:
                    case 3:
                    case 4:
                        JSEditTextAdapter.this.triggerCustomEventResponse("action", new Object[0]);
                        break;
                    case 6:
                        break;
                }
                JSEditTextAdapter.this.triggerCustomEventResponse(AbstractJSAdapter.Events.BLUR, new Object[0]);
                hideKeyboard();
            }
        };
        textView.setSingleLine(singleLine);
        textView.setGravity(gravity);
        textView.setTypeface(Typeface.DEFAULT, 0);
        textView.setEnterKeyType(1);
        textView.addTextChangedListener(this);
        enableEventResponse(AbstractJSAdapter.Events.CHANGE, true);
        this.mView = textView;
        getTouchHandler().setShouldConsume(false);
        return super.createView();
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIEditText field = (UIEditText) this.mView;
        switch (commandId) {
            case 13:
                field.hideKeyboard();
                return super.handleCommand(commandId, subCommand, args);
            case Commands.CommandIDs.setText /*{ENCODED_INT: 31}*/:
                field.setText((String) args[0]);
                return this;
            case 32:
                field.setTextColorForState(Utils.colorFromString((String) args[0]), subCommand);
                return this;
            case Commands.CommandIDs.setTextFont /*{ENCODED_INT: 33}*/:
                field.setTypeface(this.mJSContext.getFontManager().getFont((String) args[0]));
                return this;
            case Commands.CommandIDs.setTextShadow /*{ENCODED_INT: 34}*/:
                field.setShadowForState(new UIShadow((String) args[0]), subCommand);
                return this;
            case Commands.CommandIDs.setTextSize /*{ENCODED_INT: 35}*/:
                field.setTextSize(((Float) args[0]).floatValue());
                return this;
            case Commands.CommandIDs.setPlaceholderText /*{ENCODED_INT: 59}*/:
                field.setHint((String) args[0]);
                return this;
            case Commands.CommandIDs.setPlaceholderTextColor /*{ENCODED_INT: 60}*/:
                field.setHintTextColor(Utils.colorFromString((String) args[0]));
                return this;
            case Commands.CommandIDs.setPlaceholderTextShadow /*{ENCODED_INT: 61}*/:
                field.setPlaceholderShadow(new UIShadow((String) args[0]));
                return this;
            case Commands.CommandIDs.setEnterKeyType /*{ENCODED_INT: 62}*/:
                field.setEnterKeyType(((Integer) args[0]).intValue());
                return this;
            case Commands.CommandIDs.setInputType /*{ENCODED_INT: 63}*/:
                field.setCoreInputType(((Integer) args[0]).intValue());
                if (((Integer) args[0]).intValue() == 8) {
                    field.setImeOptions(6);
                    return this;
                }
                field.setImeOptions(268435462);
                return this;
            case Commands.CommandIDs.setFocus /*{ENCODED_INT: 124}*/:
                if (((Boolean) args[0]).booleanValue()) {
                    field.requestFocus();
                    field.showKeyboard();
                    return this;
                }
                field.hideKeyboard();
                if (!field.isFocused()) {
                    return this;
                }
                widgetFocusChanged(false);
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    public void widgetFocusChanged(boolean focused) {
        if (this.mJSFocused != focused) {
            sendEventResponse(focused ? AbstractJSAdapter.Events.FOCUS : AbstractJSAdapter.Events.BLUR, new Object[0]);
            this.mJSFocused = focused;
            if (!focused) {
                this = null;
            }
            sCurrentlyFocusedAdapter = this;
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public void cleanup() {
        ((UIEditText) this.mView).hideKeyboard();
        super.cleanup();
    }

    static void hideKeyboard() {
        if (sCurrentlyFocusedAdapter != null) {
            ((UIEditText) sCurrentlyFocusedAdapter.mView).hideKeyboard();
            sCurrentlyFocusedAdapter.widgetFocusChanged(false);
        }
    }

    public void afterTextChanged(Editable s) {
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (!this.mJSFocused && this.mView != null && this.mView.isFocused()) {
            widgetFocusChanged(true);
        }
        sendEventResponse(AbstractJSAdapter.Events.CHANGE, "text", s);
    }
}
