package com.ngmoco.gamejs.ui;

import android.view.ViewGroup;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UISpinner;

public class JSSpinnerAdapter extends AbstractJSViewAdapter {
    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSSpinnerAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UISpinner(this.mJSContext.getActivity(), false);
        return super.createView();
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case Commands.CommandIDs.setDarkStyle:
                UISpinner newSpinner = new UISpinner(this.mJSContext.getActivity(), ((Boolean) args[0]).booleanValue());
                newSpinner.setOrigin(this.mView.getLeft(), this.mView.getTop());
                newSpinner.setSize(this.mView.getWidth(), this.mView.getHeight());
                ViewGroup parent = (ViewGroup) this.mView.getParent();
                if (parent != null) {
                    int index = parent.indexOfChild(this.mView);
                    parent.removeViewAt(index);
                    parent.addView(newSpinner, index);
                }
                this.mView = newSpinner;
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    public JSSpinnerAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }
}
