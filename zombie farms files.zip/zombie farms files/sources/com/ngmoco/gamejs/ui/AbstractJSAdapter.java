package com.ngmoco.gamejs.ui;

import android.view.View;
import com.android.adsymp.core.ASConstants;
import com.millennialmedia.android.MMAdView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import com.ngmoco.gamejs.ui.widgets.UICheckBox;
import com.ngmoco.gamejs.ui.widgets.UIImageDrawable;
import com.ngmoco.gamejs.ui.widgets.UIImageLoadListener;
import com.ngmoco.gamejs.ui.widgets.UIShadow;
import com.ngmoco.gamejs.ui.widgets.UITextDrawable;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class AbstractJSAdapter implements JSAdapter, UIImageLoadListener {
    private static final String TAG = "AbstractJSAdapter";
    protected HashMap<String, UIEventResponse> mCustomEventResponses = new HashMap<>();
    protected Commands mJSContext;
    protected Integer mObjId;

    public static class Events {
        public static final String ACTION = "action";
        public static final String APPEAR = "appear";
        public static final String BLUR = "blur";
        public static final String CHANGE = "change";
        public static final String CHOICE = "choice";
        public static final String CLICK = "click";
        public static final String CLICK_CANCEL = "clickCancel";
        public static final String CLICK_DOWN = "clickDown";
        public static final String DESELECT = "deselect";
        public static final String DISAPPEAR = "disappear";
        public static final String EVENT = "event";
        public static final String FOCUS = "focus";
        protected static final String KEY_CALLBACK_ID = "callbackId";
        protected static final String KEY_EVENT_TYPE = "eventType";
        protected static final String KEY_NAME = "name";
        protected static final String KEY_OBJECT_ID = "objId";
        protected static final String KEY_PROPERTIES = "properties";
        public static final String LOAD = "load";
        public static final String LONGPRESS = "longPress";
        public static final String REGION_CHANGE = "regionchange";
        public static final String SCROLL = "scroll";
        public static final String SCROLL_ENDED = "scrollEnded";
        public static final String SELECT = "select";
        public static final String SWIPE = "swipe";
        public static final String TEXT_MEASURED = "textMeasured";
        public static final String TITLE_MEASURED = "titleMeasured";
        public static final String UNLOAD = "unload";
        public static final String UPDATE = "update";
    }

    /* access modifiers changed from: protected */
    public class UIEventResponse implements CustomEventListener, View.OnClickListener {
        private JSONObject responseDictionary = new JSONObject();

        private void send() {
            AbstractJSAdapter.this.mJSContext.sendEvent(this.responseDictionary.toString());
        }

        @Override // com.ngmoco.gamejs.ui.CustomEventListener
        public void onEvent() {
            send();
        }

        public void onEvent(Object... keyValuePairs) {
            String key = null;
            try {
                for (Object val : keyValuePairs) {
                    if (key == null) {
                        key = (String) val;
                    } else {
                        this.responseDictionary.put(key, val);
                        key = null;
                    }
                }
                send();
                for (int i = 0; i < keyValuePairs.length; i += 2) {
                    this.responseDictionary.remove((String) keyValuePairs[i]);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void onClick(View v) {
            if (v instanceof UICheckBox) {
                onEvent("checked", Boolean.valueOf(((UICheckBox) v).isChecked()));
                return;
            }
            onEvent();
        }

        public UIEventResponse(Commands jsContext, String eventType, Integer objId) throws JSONException {
            AbstractJSAdapter.this.mJSContext = jsContext;
            this.responseDictionary.put(NgSystemBindingService.EXTRA_NAME, Events.EVENT);
            this.responseDictionary.put("eventType", eventType);
            this.responseDictionary.put("objId", objId);
        }
    }

    /* access modifiers changed from: protected */
    public void applyTextDrawableProperties(UITextDrawable drawable, int commandId, int state, Object[] args) {
        switch (commandId) {
            case 11:
                drawable.setControlState(((Integer) args[0]).intValue());
                return;
            case Commands.CommandIDs.setText /*{ENCODED_INT: 31}*/:
            case Commands.CommandIDs.setTitle /*{ENCODED_INT: 41}*/:
                drawable.setTextForState(state, (String) args[0]);
                return;
            case 32:
            case Commands.CommandIDs.setTitleColor /*{ENCODED_INT: 42}*/:
                drawable.setColorForState(state, Utils.colorFromString((String) args[0]));
                return;
            case Commands.CommandIDs.setTextFont /*{ENCODED_INT: 33}*/:
            case Commands.CommandIDs.setTitleFont /*{ENCODED_INT: 43}*/:
                drawable.setFontForState(state, this.mJSContext.getFontManager().getFont((String) args[0]));
                return;
            case Commands.CommandIDs.setTextShadow /*{ENCODED_INT: 34}*/:
            case Commands.CommandIDs.setTitleShadow /*{ENCODED_INT: 44}*/:
                String s = (String) args[0];
                drawable.setShadowForState(state, (s == null || s.length() <= 0) ? null : new UIShadow(s));
                return;
            case Commands.CommandIDs.setTextSize /*{ENCODED_INT: 35}*/:
            case Commands.CommandIDs.setTitleSize /*{ENCODED_INT: 45}*/:
                drawable.setFontSize(((Float) args[0]).floatValue());
                return;
            case Commands.CommandIDs.setTextGravity /*{ENCODED_INT: 36}*/:
            case Commands.CommandIDs.setTitleGravity /*{ENCODED_INT: 46}*/:
                drawable.setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return;
            case Commands.CommandIDs.setTextInsets /*{ENCODED_INT: 37}*/:
            case Commands.CommandIDs.setTitleInsets /*{ENCODED_INT: 47}*/:
                drawable.setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return;
            case Commands.CommandIDs.setTextOverflow /*{ENCODED_INT: 38}*/:
            case Commands.CommandIDs.setTextMaxLines /*{ENCODED_INT: 39}*/:
            case Commands.CommandIDs.setTextMinSize /*{ENCODED_INT: 40}*/:
            case Commands.CommandIDs.setTitleOverflow /*{ENCODED_INT: 48}*/:
            case Commands.CommandIDs.setTitleMaxLines /*{ENCODED_INT: 49}*/:
            case 50:
                return;
            case Commands.CommandIDs.setLineHeight /*{ENCODED_INT: 131}*/:
                drawable.setLineHeight(((Float) args[0]).floatValue());
                return;
            default:
                Log.w(TAG, "Unknown Command Modifier for Text property");
                return;
        }
    }

    /* access modifiers changed from: protected */
    public void applyImageDrawableProperties(UIImageDrawable drawable, int commandId, int state, Object[] args) {
        switch (commandId) {
            case Commands.CommandIDs.setImage /*{ENCODED_INT: 22}*/:
            case Commands.CommandIDs.setRightImage /*{ENCODED_INT: 83}*/:
                drawable.setImageURLForState(state, (String) args[0], this);
                return;
            case Commands.CommandIDs.setImageBorder /*{ENCODED_INT: 23}*/:
            case Commands.CommandIDs.setRightImageBorder /*{ENCODED_INT: 84}*/:
                try {
                    drawable.setGradientDefinition((String) args[0], state);
                    return;
                } catch (Exception e) {
                    Log.d("ImageDrawable", "Error in Gradient for Border: " + e.getMessage());
                    return;
                }
            case Commands.CommandIDs.setImageFitMode /*{ENCODED_INT: 24}*/:
            case Commands.CommandIDs.setRightImageFitMode /*{ENCODED_INT: 85}*/:
                drawable.setFit(((Integer) args[0]).intValue());
                return;
            case Commands.CommandIDs.setImageGravity /*{ENCODED_INT: 25}*/:
            case Commands.CommandIDs.setRightImageGravity /*{ENCODED_INT: 86}*/:
                drawable.setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return;
            case Commands.CommandIDs.setImageOrigin /*{ENCODED_INT: 26}*/:
            case Commands.CommandIDs.setImageAnchor /*{ENCODED_INT: 27}*/:
            case Commands.CommandIDs.setImageSize /*{ENCODED_INT: 28}*/:
            case Commands.CommandIDs.setRightImageOrigin /*{ENCODED_INT: 87}*/:
            case Commands.CommandIDs.setRightImageAnchor /*{ENCODED_INT: 88}*/:
            case Commands.CommandIDs.setRightImageSize /*{ENCODED_INT: 89}*/:
                return;
            case Commands.CommandIDs.setImageInsets /*{ENCODED_INT: 29}*/:
            case Commands.CommandIDs.setRightImageInsets /*{ENCODED_INT: 90}*/:
                drawable.setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return;
            case Commands.CommandIDs.setImageTransform /*{ENCODED_INT: 30}*/:
            case Commands.CommandIDs.setRightImageTransform /*{ENCODED_INT: 91}*/:
                drawable.setTransform(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue(), ((Float) args[4]).floatValue(), ((Float) args[5]).floatValue());
                return;
            default:
                Log.w(TAG, "Unknown Command Modifier for Image property");
                return;
        }
    }

    public Commands getContext() {
        return this.mJSContext;
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public void setJSContext(Commands mContext) {
        this.mJSContext = mContext;
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 6:
                enableEventResponse((String) args[0], true);
                break;
            case 7:
                enableEventResponse((String) args[0], false);
                break;
            default:
                Log.w(getClass().getSimpleName(), "Unrecognized Command: " + Integer.toString(commandId));
                break;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public UIEventResponse getCustomEventResponse(String eventType) {
        return this.mCustomEventResponses.get(eventType);
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter triggerCustomEventResponse(String eventType, Object... keyValPairs) {
        UIEventResponse rsp = this.mCustomEventResponses.get(eventType);
        if (rsp != null) {
            if (keyValPairs == null) {
                rsp.onEvent();
            } else {
                rsp.onEvent(keyValPairs);
            }
        }
        return this;
    }

    public void sendEventResponse(String eventType, Object... keyValPairs) {
        if (keyValPairs == null || keyValPairs.length == 0) {
            this.mJSContext.sendEvent("{\"eventType\":\"" + eventType + "\",\"name\":\"event\",\"objId\":" + this.mObjId + ASConstants.kBraceClose);
            return;
        }
        try {
            UIEventResponse rsp = this.mCustomEventResponses.get(eventType);
            if (rsp == null) {
                rsp = new UIEventResponse(this.mJSContext, eventType, this.mObjId);
            }
            rsp.onEvent(keyValPairs);
        } catch (Exception e) {
            Log.e(getClass().getSimpleName(), "Could not send " + eventType + " event for " + getClass().getName());
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter enableEventResponse(String eventType, boolean enable) throws Exception {
        if (enable) {
            this.mCustomEventResponses.put(eventType, new UIEventResponse(this.mJSContext, eventType, this.mObjId));
        } else {
            this.mCustomEventResponses.remove(eventType);
        }
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public boolean isEventResponseEnabled(String eventType) {
        return this.mCustomEventResponses.containsKey(eventType);
    }

    protected AbstractJSAdapter(Commands jsContext, Integer objId) {
        this.mJSContext = jsContext;
        this.mObjId = objId;
        if (this.mObjId.intValue() > 0 && !(this instanceof AbstractJSViewAdapter)) {
            sendEventResponse(Events.LOAD, new Object[0]);
        }
    }

    public Integer objId() {
        return this.mObjId;
    }

    public Commands context() {
        return this.mJSContext;
    }

    @Override // com.ngmoco.gamejs.ui.JSAdapter
    public void cleanup() {
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIImageLoadListener
    public void onImageLoaded(String imageUrl, int width, int height) {
        triggerCustomEventResponse("imageLoaded", "url", imageUrl, MMAdView.KEY_WIDTH, Integer.valueOf(width), MMAdView.KEY_HEIGHT, Integer.valueOf(height));
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIImageLoadListener
    public void onImageLoadFailed(String imageUrl, int errorCode, String errorMessage) {
        triggerCustomEventResponse("imageLoadFailed", "url", imageUrl, JSWebViewAdapter.Events.ERROR, Integer.valueOf(errorCode), "message", errorMessage);
    }
}
