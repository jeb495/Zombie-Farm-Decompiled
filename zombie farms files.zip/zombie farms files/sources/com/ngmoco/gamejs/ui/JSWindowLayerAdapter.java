package com.ngmoco.gamejs.ui;

import android.view.View;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UILayout;
import java.util.ArrayList;
import java.util.Iterator;

public class JSWindowLayerAdapter extends AbstractJSAdapter implements JSViewGroupAdapter {
    private static final String TAG = "JSWindowLayerAdapter";
    private static boolean sAddRemove = false;
    private static JSWindowLayerAdapter sRoot = null;
    private static UILayout sRootLayout = null;
    int layerLevel = 0;
    protected ArrayList<View> mChildren = new ArrayList<>();
    boolean mInSet = false;
    private JSWindowLayerAdapter mNext = null;
    int startIndex = 0;

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSWindowLayerAdapter(jsContext, objId);
    }

    protected JSWindowLayerAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
        if (sRootLayout == null && jsContext != null) {
            sRootLayout = jsContext.getActivity().getRootLayout();
        }
    }

    public static class SplashWrapper extends JSWindowLayerAdapter {
        public SplashWrapper(View wrapView) {
            super(null, 0);
            if (JSWindowLayerAdapter.sRootLayout == null) {
                UILayout unused = JSWindowLayerAdapter.sRootLayout = GameJSActivity.getActivity().getRootLayout();
            }
            this.layerLevel = -1;
            addLayer(this);
            this.mChildren.add(wrapView);
            updateRootIndex();
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public View getView() {
        return sRootLayout;
    }

    /* access modifiers changed from: package-private */
    public void addSubview(View v, int atIndex) {
        if (atIndex < 0) {
            this.mChildren.add(v);
        } else {
            this.mChildren.add(atIndex, v);
        }
        if (this.mInSet) {
            if (atIndex >= 0) {
                atIndex += this.startIndex;
            }
            if (this.mNext != null) {
                if (atIndex < 0) {
                    atIndex = (this.startIndex + this.mChildren.size()) - 1;
                }
                if (atIndex > this.mNext.startIndex) {
                    atIndex = this.mNext.startIndex;
                }
            }
            sAddRemove = true;
            if (atIndex < 0) {
                sRootLayout.addView(v);
            } else {
                sRootLayout.addView(v, atIndex);
            }
            sAddRemove = false;
            updateIndexes(this);
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSViewGroupAdapter
    public JSViewGroupAdapter addSubview(JSViewAdapter subAdapter, int atIndex) throws Exception {
        Log.d(TAG, "Adding adapter " + subAdapter + " at index " + atIndex);
        addSubview(subAdapter.getView(), atIndex);
        return this;
    }

    private static void updateIndexes(JSWindowLayerAdapter a) {
        if (a != null) {
            int count = a.startIndex;
            while (a != null) {
                a.startIndex = count;
                count += a.mChildren.size();
                a = a.mNext;
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0030  */
    /* JADX WARNING: Removed duplicated region for block: B:7:0x0018  */
    public static void updateRootIndex() {
        if (!sAddRemove && sRoot != null) {
            int rootChildCount = sRootLayout.getChildCount();
            JSWindowLayerAdapter layer = sRoot;
            while (layer.mChildren.isEmpty() && (layer = layer.mNext) != null) {
                while (layer.mChildren.isEmpty()) {
                    while (layer.mChildren.isEmpty()) {
                    }
                }
            }
            int startIndex2 = 0;
            if (layer != null) {
                View firstChild = layer.mChildren.get(0);
                while (firstChild != sRootLayout.getChildAt(startIndex2) && (startIndex2 = startIndex2 + 1) < rootChildCount) {
                    while (firstChild != sRootLayout.getChildAt(startIndex2)) {
                        while (firstChild != sRootLayout.getChildAt(startIndex2)) {
                        }
                    }
                }
            } else {
                startIndex2 = rootChildCount;
            }
            if (startIndex2 != sRoot.startIndex) {
                sRoot.startIndex = startIndex2;
                updateIndexes(sRoot);
            }
        }
    }

    public static void addLayer(JSWindowLayerAdapter toAdd) {
        if (!toAdd.mInSet) {
            JSWindowLayerAdapter prev = null;
            if (sRoot == null) {
                toAdd.mNext = null;
                sRoot = toAdd;
            } else if (toAdd.layerLevel <= sRoot.layerLevel) {
                toAdd.mNext = sRoot;
                sRoot = toAdd;
            } else {
                JSWindowLayerAdapter a = sRoot;
                while (true) {
                    if (a == null) {
                        break;
                    } else if (a.mNext == null || toAdd.layerLevel <= a.mNext.layerLevel) {
                        toAdd.mNext = a.mNext;
                        a.mNext = toAdd;
                        prev = a;
                    } else {
                        a = a.mNext;
                    }
                }
                toAdd.mNext = a.mNext;
                a.mNext = toAdd;
                prev = a;
            }
            toAdd.mInSet = true;
            if (prev == null) {
                updateRootIndex();
            } else {
                toAdd.startIndex = prev.startIndex + prev.mChildren.size();
            }
            int i = toAdd.startIndex;
            sAddRemove = true;
            Iterator i$ = toAdd.mChildren.iterator();
            while (i$.hasNext()) {
                sRootLayout.addView(i$.next(), i);
                i++;
            }
            sAddRemove = false;
            updateIndexes(toAdd);
        }
    }

    public static void removeChild(View child) {
        JSWindowLayerAdapter a = sRoot;
        sAddRemove = true;
        while (true) {
            if (a == null) {
                break;
            } else if (a.mChildren.contains(child)) {
                a.mChildren.remove(child);
                sRootLayout.removeView(child);
                updateIndexes(a);
                break;
            } else {
                a = a.mNext;
            }
        }
        sAddRemove = false;
        if (child.getParent() == sRootLayout) {
            sRootLayout.removeView(child);
        }
    }

    public void setLevel(int level) {
        removeFromList();
        this.layerLevel = (level * 2) + 2 + this.mJSContext.getProcId();
        addLayer(this);
    }

    public void removeFromList() {
        if (this.mInSet) {
            JSWindowLayerAdapter prev = null;
            for (JSWindowLayerAdapter a = sRoot; a != null; a = a.mNext) {
                if (a == this) {
                    if (prev == null) {
                        sRoot = this.mNext;
                    } else {
                        prev.mNext = this.mNext;
                    }
                    this.mNext = null;
                    updateIndexes(prev);
                    this.mInSet = false;
                    sAddRemove = true;
                    Iterator i$ = this.mChildren.iterator();
                    while (i$.hasNext()) {
                        sRootLayout.removeView(i$.next());
                    }
                    sAddRemove = false;
                    return;
                }
                prev = a;
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public void cleanup() {
        removeFromList();
        this.mChildren.clear();
        super.cleanup();
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public JSViewAdapter createView() throws Exception {
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter
    public JSViewAdapter removeFromSuperview() throws Exception {
        removeFromList();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 12:
                addSubview((JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]), ((Integer) args[1]).intValue());
                return this;
            case Commands.CommandIDs.setIntValue:
                setLevel(((Integer) args[0]).intValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }
}
