package com.ngmoco.gamejs.ui;

import android.view.View;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIWidget;

public class JSListViewSection extends AbstractJSAdapter {
    protected int[] mBounds = {0, 0, 0, 0};
    protected boolean mHasTitle;
    protected JSViewAdapter mTitleAdapter;

    public static JSAdapter newInstance(Commands jsContext, Integer objectId) {
        return new JSListViewSection(jsContext, objectId);
    }

    protected JSListViewSection(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public void scrollPositionChanged(int newY, int height) {
        if (this.mTitleAdapter != null) {
            View v = this.mTitleAdapter.getView();
            int t = v.getTop();
            int h = v.getHeight();
            int newTitlePos = this.mBounds[1];
            if (newTitlePos < newY) {
                newTitlePos = newY;
            }
            int relMaxLabelY = (this.mBounds[1] + this.mBounds[3]) - h;
            if (newTitlePos > relMaxLabelY) {
                newTitlePos = relMaxLabelY;
            }
            if (t != newTitlePos) {
                v.offsetTopAndBottom(newTitlePos - t);
            }
        }
    }

    private void repositionHeader() {
        if (this.mTitleAdapter != null) {
            View v = this.mTitleAdapter.getView();
            if (this.mBounds[2] > 0) {
                ((UIWidget) v).setSize(this.mBounds[2], v.getHeight());
            }
            ((UIWidget) v).setOrigin(this.mBounds[0], this.mBounds[1]);
            v.bringToFront();
        }
    }

    public void bringTitleForward() {
        if (this.mTitleAdapter != null) {
            this.mTitleAdapter.getView().bringToFront();
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 16:
                this.mBounds = new int[]{((Float) args[0]).intValue(), ((Float) args[1]).intValue(), ((Float) args[2]).intValue(), ((Float) args[3]).intValue()};
                scrollPositionChanged(this.mBounds[1], this.mBounds[3]);
                repositionHeader();
                return this;
            case Commands.CommandIDs.setTitleView:
                this.mTitleAdapter = (JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                repositionHeader();
                scrollPositionChanged(this.mBounds[1], this.mBounds[3]);
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }
}
