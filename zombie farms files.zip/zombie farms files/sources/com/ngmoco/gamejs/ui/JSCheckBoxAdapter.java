package com.ngmoco.gamejs.ui;

import android.view.View;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UICheckBox;

public final class JSCheckBoxAdapter extends AbstractJSViewAdapter implements View.OnClickListener {
    private JSCheckBoxAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSCheckBoxAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSCheckBoxAdapter createView() throws Exception {
        this.mView = new UICheckBox(this.mJSContext.getActivity(), this.mJSContext.getImageCache());
        ((UICheckBox) this.mView).setOnClickListener(this);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UICheckBox checkbox = (UICheckBox) this.mView;
        if (Commands.isImageCommand(commandId)) {
            applyImageDrawableProperties(checkbox.getImageDrawable(), commandId, subCommand, args);
            return this;
        } else if (Commands.isTextCommand(commandId)) {
            applyTextDrawableProperties(checkbox.getTextDrawable(), commandId, subCommand, args);
            return this;
        } else {
            switch (commandId) {
                case 6:
                    super.handleCommand(commandId, subCommand, args);
                    return this;
                case Commands.CommandIDs.setGradient /*{ENCODED_INT: 51}*/:
                    checkbox.getBoxDrawable().setGradientDefinition((String) args[0], subCommand);
                    return this;
                case 64:
                    checkbox.setChecked(((Boolean) args[0]).booleanValue());
                    return this;
                default:
                    return super.handleCommand(commandId, subCommand, args);
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter enableEventResponse(String eventType, boolean enable) throws Exception {
        return eventType.equalsIgnoreCase(AbstractJSAdapter.Events.CLICK) ? this : super.enableEventResponse(eventType, enable);
    }

    public void onClick(View v) {
        sendEventResponse(AbstractJSAdapter.Events.CLICK, "checked", Boolean.valueOf(((UICheckBox) this.mView).getChecked()));
    }
}
