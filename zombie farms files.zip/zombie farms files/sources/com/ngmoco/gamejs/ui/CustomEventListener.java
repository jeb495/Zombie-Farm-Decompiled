package com.ngmoco.gamejs.ui;

public interface CustomEventListener {
    void onEvent();
}
