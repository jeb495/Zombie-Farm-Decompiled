package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.widgets.UIImageView;

public final class JSImageViewAdapter extends AbstractJSViewAdapter {
    private JSImageViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSImageViewAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIImageView(this.mJSContext.getActivity(), this.mJSContext.getImageCache());
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIImageView imageView = (UIImageView) this.mView;
        if (!Commands.isImageCommand(commandId)) {
            return super.handleCommand(commandId, subCommand, args);
        }
        applyImageDrawableProperties(imageView.getImageDrawable(), commandId, subCommand, args);
        return this;
    }
}
