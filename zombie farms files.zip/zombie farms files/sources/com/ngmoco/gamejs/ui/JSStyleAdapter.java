package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.Style;
import com.ngmoco.gamejs.ui.widgets.UIContentDrawable;
import com.ngmoco.gamejs.ui.widgets.UIShadow;

public class JSStyleAdapter extends AbstractJSAdapter {
    private Style mStyle = new Style();

    public Style getStyle() {
        return this.mStyle;
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSStyleAdapter(jsContext, objId);
    }

    public JSStyleAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int state, Object[] args) throws Exception {
        switch (commandId) {
            case Commands.CommandIDs.setImage:
                this.mStyle.ensureImageStyle().setImageURLForState(this.mJSContext.getImageCache(), state, (String) args[0], this);
                return this;
            case Commands.CommandIDs.setImageBorder:
                this.mStyle.ensureImageStyle().mGradients.put(Integer.valueOf(state), (Object) new UIContentDrawable.UIGradientDefinition((String) args[0]));
                return this;
            case Commands.CommandIDs.setImageFitMode:
                this.mStyle.ensureImageStyle().mFit = ((Integer) args[0]).intValue();
                return this;
            case Commands.CommandIDs.setImageGravity:
                this.mStyle.ensureImageStyle().setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.setImageInsets:
                this.mStyle.ensureImageStyle().setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return this;
            case Commands.CommandIDs.setImageTransform:
                this.mStyle.ensureImageStyle().setTransform(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue(), ((Float) args[4]).floatValue(), ((Float) args[5]).floatValue());
                return this;
            case Commands.CommandIDs.setText:
                this.mStyle.ensureTextStyle().mTexts.put(Integer.valueOf(state), (String) args[0]);
                return this;
            case 32:
                this.mStyle.ensureTextStyle().mColors.put(Integer.valueOf(state), Integer.valueOf(Utils.colorFromString((String) args[0])));
                return this;
            case Commands.CommandIDs.setTextFont:
                this.mStyle.ensureTextStyle().mTypefaces.put(Integer.valueOf(state), this.mJSContext.getFontManager().getFont((String) args[0]));
                return this;
            case Commands.CommandIDs.setTextShadow:
                String s = (String) args[0];
                this.mStyle.ensureTextStyle().mShadows.put(Integer.valueOf(state), (s == null || s.length() <= 0) ? null : new UIShadow(s));
                return this;
            case Commands.CommandIDs.setTextSize:
                this.mStyle.ensureTextStyle().mFontSize = ((Float) args[0]).floatValue();
                return this;
            case Commands.CommandIDs.setTextGravity:
                this.mStyle.ensureTextStyle().setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.setTextInsets:
                this.mStyle.ensureTextStyle().setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return this;
            case Commands.CommandIDs.setTitle:
                this.mStyle.ensureTitleStyle().mTexts.put(Integer.valueOf(state), (String) args[0]);
                return this;
            case Commands.CommandIDs.setTitleColor:
                this.mStyle.ensureTitleStyle().mColors.put(Integer.valueOf(state), Integer.valueOf(Utils.colorFromString((String) args[0])));
                return this;
            case Commands.CommandIDs.setTitleFont:
                this.mStyle.ensureTitleStyle().mTypefaces.put(Integer.valueOf(state), this.mJSContext.getFontManager().getFont((String) args[0]));
                return this;
            case Commands.CommandIDs.setTitleShadow:
                String s2 = (String) args[0];
                this.mStyle.ensureTitleStyle().mShadows.put(Integer.valueOf(state), (s2 == null || s2.length() <= 0) ? null : new UIShadow(s2));
                return this;
            case Commands.CommandIDs.setTitleSize:
                this.mStyle.ensureTitleStyle().mFontSize = ((Float) args[0]).floatValue();
                return this;
            case Commands.CommandIDs.setTitleGravity:
                this.mStyle.ensureTitleStyle().setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.setTitleInsets:
                this.mStyle.ensureTitleStyle().setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return this;
            case Commands.CommandIDs.setGradient:
                this.mStyle.ensureGradientStyle().mGradients.put(Integer.valueOf(state), new UIContentDrawable.UIGradientDefinition((String) args[0]));
                return this;
            case Commands.CommandIDs.setRightImage:
                this.mStyle.ensureRightImageStyle().setImageURLForState(this.mJSContext.getImageCache(), state, (String) args[0], this);
                return this;
            case Commands.CommandIDs.setRightImageBorder:
                this.mStyle.ensureRightImageStyle().mGradients.put(Integer.valueOf(state), (Object) new UIContentDrawable.UIGradientDefinition((String) args[0]));
                return this;
            case Commands.CommandIDs.setRightImageFitMode:
                this.mStyle.ensureRightImageStyle().mFit = ((Integer) args[0]).intValue();
                return this;
            case Commands.CommandIDs.setRightImageGravity:
                this.mStyle.ensureRightImageStyle().setGravity(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.setRightImageInsets:
                this.mStyle.ensureRightImageStyle().setInsets(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue());
                return this;
            case Commands.CommandIDs.setRightImageTransform:
                this.mStyle.ensureRightImageStyle().setTransform(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue(), ((Float) args[4]).floatValue(), ((Float) args[5]).floatValue());
                return this;
            default:
                return super.handleCommand(commandId, state, args);
        }
    }
}
