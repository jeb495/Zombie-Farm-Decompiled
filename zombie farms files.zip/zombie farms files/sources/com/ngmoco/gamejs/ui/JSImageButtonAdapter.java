package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.widgets.UIImageButton;

public class JSImageButtonAdapter extends AbstractJSViewAdapter {
    private static final String TAG = JSImageButtonAdapter.class.getSimpleName();

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSImageButtonAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIImageButton(this.mJSContext.getActivity(), this.mJSContext.getImageCache());
        getTouchHandler().listenForTouch(true);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIImageButton button = (UIImageButton) this.mView;
        if (Commands.isTextCommand(commandId)) {
            applyTextDrawableProperties(button.getTextDrawable(), commandId, subCommand, args);
            return this;
        } else if (Commands.isImageCommand(commandId)) {
            applyImageDrawableProperties(button.getImageDrawable(), commandId, subCommand, args);
            return this;
        } else {
            switch (commandId) {
                case 6:
                    super.handleCommand(commandId, subCommand, args);
                    return this;
                default:
                    return super.handleCommand(commandId, subCommand, args);
            }
        }
    }

    private JSImageButtonAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }
}
