package com.ngmoco.gamejs.ui;

public class JSEditTextAreaAdapter extends JSEditTextAdapter {
    private static final String TAG = "JSEditTextAreaAdapter";

    private JSEditTextAreaAdapter(Commands jsContext, Integer objId) throws Exception {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSEditTextAreaAdapter(jsContext, objId).createView();
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.JSEditTextAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        return super.createView(false, 51);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.JSEditTextAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        return super.handleCommand(commandId, subCommand, args);
    }
}
