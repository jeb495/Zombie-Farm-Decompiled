package com.ngmoco.gamejs.ui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.view.View;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.gl.GameJSView;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import javax.microedition.khronos.opengles.GL10;
import org.json.JSONException;
import org.json.JSONObject;

public class ScreenShotter implements Operation {
    private static List<ScreenShotter> sScreenShotQueue = new ArrayList();
    String mCallback;
    boolean mCanceled = false;
    Bitmap mCompositeBitmap;
    int mDesiredHeight;
    int mDesiredWidth;
    String mFilename;
    Bitmap mGLBitmap;
    private Handler mHandler = null;
    Commands mJSContext;
    JSONObject mOptions;
    Bitmap mUIBitmap;
    boolean mWaitForGL;
    boolean mWaitForUI;
    private volatile boolean wroteFile = false;

    public ScreenShotter(int w, int h, String filename, String options, String callbackId, Commands jsContext) {
        this.mJSContext = jsContext;
        this.mCallback = callbackId;
        this.mDesiredWidth = w;
        this.mDesiredHeight = h;
        try {
            this.mOptions = new JSONObject(options);
        } catch (Throwable t) {
            t.printStackTrace();
        }
        this.mFilename = filename;
        switch (this.mOptions.optInt("screenshotType", 0)) {
            case 1:
                this.mWaitForGL = true;
                break;
            case 2:
                this.mWaitForUI = true;
                break;
            default:
                this.mWaitForGL = true;
                this.mWaitForUI = true;
                break;
        }
        sScreenShotQueue.add(this);
        if (sScreenShotQueue.get(0) == this) {
            takeScreenShot();
        }
        this.mJSContext.addOperation(this);
    }

    /* access modifiers changed from: protected */
    public void takeScreenShot() {
        if (!this.mCanceled) {
            final View rootView = this.mJSContext.baseJsWindowLayerAdapter.getView();
            int w = rootView.getWidth();
            int h = rootView.getHeight();
            try {
                if (this.mWaitForGL) {
                    this.mGLBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    GameJSView glView = this.mJSContext.getActivity().getGLView();
                    if (!glView.isGLRunning()) {
                        this.mWaitForGL = false;
                        tryComposition();
                    } else {
                        glView.setScreenShotter(this);
                    }
                }
                if (this.mWaitForUI) {
                    this.mUIBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    this.mJSContext.getActivity().runOnUiThread(new Runnable() {
                        /* class com.ngmoco.gamejs.ui.ScreenShotter.AnonymousClass1 */

                        public void run() {
                            Canvas canvas = new Canvas(ScreenShotter.this.mUIBitmap);
                            canvas.drawColor(0);
                            rootView.draw(canvas);
                            ScreenShotter.this.mWaitForUI = false;
                            ScreenShotter.this.tryComposition();
                        }
                    });
                }
            } catch (OutOfMemoryError e) {
                try {
                    JSONObject j = new JSONObject();
                    j.put(NgSystemBindingService.EXTRA_NAME, "callback");
                    j.put("callback_id", this.mCallback);
                    j.put(JSWebViewAdapter.Events.ERROR, "Out of memory attempting to allocate buffer for a screenshot.");
                    j.put(ASConstants.kASResponseKeyStatusCode, -3);
                    this.mJSContext.sendEvent(j.toString());
                } catch (JSONException e2) {
                    e2.printStackTrace();
                } finally {
                    advanceQueue();
                }
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void advanceQueue() {
        this.mJSContext.removeOperation(this);
        disposeHandler();
        sScreenShotQueue.remove(this);
        if (!sScreenShotQueue.isEmpty()) {
            sScreenShotQueue.get(0).takeScreenShot();
        }
    }

    @Override // com.ngmoco.gamejs.ui.Operation
    public void cancel() {
        this.mCanceled = true;
    }

    private synchronized Handler getHandler() {
        if (this.mHandler == null || this.mHandler.getLooper() == null || this.mHandler.getLooper().getThread() == null || !this.mHandler.getLooper().getThread().isAlive()) {
            HandlerThread thread = new HandlerThread(getClass().getSimpleName());
            thread.start();
            this.mHandler = new Handler(thread.getLooper());
        }
        return this.mHandler;
    }

    private synchronized void disposeHandler() {
        if (this.mHandler != null) {
            Looper l = this.mHandler.getLooper();
            if (l != null) {
                l.quit();
            }
            this.mHandler = null;
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void tryComposition() {
        if (!this.wroteFile) {
            getHandler().post(new Runnable() {
                /* class com.ngmoco.gamejs.ui.ScreenShotter.AnonymousClass2 */

                public void run() {
                    if (!ScreenShotter.this.mCanceled && !ScreenShotter.this.wroteFile && !ScreenShotter.this.mWaitForGL && !ScreenShotter.this.mWaitForUI) {
                        if (ScreenShotter.this.mGLBitmap != null && ScreenShotter.this.mUIBitmap != null) {
                            ScreenShotter.this.mCompositeBitmap = ScreenShotter.this.mGLBitmap;
                            new Canvas(ScreenShotter.this.mCompositeBitmap).drawBitmap(ScreenShotter.this.mUIBitmap, 0.0f, 0.0f, new Paint(7));
                        } else if (ScreenShotter.this.mGLBitmap != null) {
                            ScreenShotter.this.mCompositeBitmap = ScreenShotter.this.mGLBitmap;
                        } else if (ScreenShotter.this.mUIBitmap != null) {
                            ScreenShotter.this.mCompositeBitmap = ScreenShotter.this.mUIBitmap;
                        }
                        try {
                            ScreenShotter.this.mDesiredWidth = ScreenShotter.this.mDesiredWidth <= 0 ? ScreenShotter.this.mCompositeBitmap.getWidth() : ScreenShotter.this.mDesiredWidth;
                            ScreenShotter.this.mDesiredHeight = ScreenShotter.this.mDesiredHeight <= 0 ? ScreenShotter.this.mCompositeBitmap.getHeight() : ScreenShotter.this.mDesiredHeight;
                            ImageCompositor ic = new ImageCompositor(ScreenShotter.this.mDesiredWidth, ScreenShotter.this.mDesiredHeight, ScreenShotter.this.mFilename, ScreenShotter.this.mCallback, ScreenShotter.this.mJSContext);
                            ic.addImage(ScreenShotter.this.mOptions, ScreenShotter.this.mCompositeBitmap);
                            ic.finish();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } finally {
                            ScreenShotter.this.advanceQueue();
                        }
                    }
                }
            });
        }
    }

    public void takeGLScreenShot(GL10 gl) {
        int width = this.mGLBitmap.getWidth();
        int height = this.mGLBitmap.getHeight();
        int screenshotSize = width * height;
        int[] b = new int[screenshotSize];
        int[] bt = new int[screenshotSize];
        IntBuffer ib = IntBuffer.wrap(b);
        ib.position(0);
        gl.glReadPixels(0, 0, width, height, 6408, 5121, ib);
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int pix = b[(i * width) + j];
                bt[(((height - i) - 1) * width) + j] = (-16711936 & pix) | ((pix << 16) & Commands.State.Custom) | ((pix >> 16) & SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
            }
        }
        this.mGLBitmap.setPixels(bt, 0, width, 0, 0, width, height);
        this.mWaitForGL = false;
        tryComposition();
    }
}
