package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIAnnotation;
import com.ngmoco.gamejs.ui.widgets.UIAnnotationCalloutView;
import com.ngmoco.gamejs.ui.widgets.UIAnnotationListener;

public class JSMapAnnotationAdapter extends AbstractJSViewAdapter implements UIAnnotationListener {
    protected UIAnnotation mAnnotation;

    private JSMapAnnotationAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSMapAnnotationAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mAnnotation = new UIAnnotation(this.mJSContext.getActivity(), null, "Title", "subtitle", this);
        this.mView = this.mAnnotation.getCalloutView();
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIAnnotationListener
    public void onSelect() {
        if (this.mCustomEventResponses.containsKey(AbstractJSAdapter.Events.SELECT)) {
            try {
                triggerCustomEventResponse(AbstractJSAdapter.Events.SELECT, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIAnnotationListener
    public void onDeselect() {
        if (this.mCustomEventResponses.containsKey(AbstractJSAdapter.Events.DESELECT)) {
            try {
                triggerCustomEventResponse(AbstractJSAdapter.Events.DESELECT, new Object[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public UIAnnotation getAnnotation() {
        return this.mAnnotation;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIAnnotationCalloutView calloutView = this.mAnnotation.getCalloutView();
        switch (commandId) {
            case Commands.CommandIDs.setView:
                this.mAnnotation.setView(((JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0])).getView());
                return this;
            case Commands.CommandIDs.setCoordinate:
                this.mAnnotation.setCoordinate((double) ((Float) args[0]).floatValue(), (double) ((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.setCalloutTitle:
                if (calloutView == null) {
                    return this;
                }
                calloutView.setTitle((String) args[0]);
                return this;
            case Commands.CommandIDs.setCalloutSubtitle:
                if (calloutView == null) {
                    return this;
                }
                calloutView.setSubtitle((String) args[0]);
                return this;
            case Commands.CommandIDs.setCalloutEnabled:
                this.mAnnotation.setCalloutEnabled(((Boolean) args[0]).booleanValue());
                return this;
            case Commands.CommandIDs.setCalloutLeftView:
                JSViewAdapter view = (JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                if (calloutView == null) {
                    return this;
                }
                calloutView.setLeftAccessoryView(view.getView());
                return this;
            case Commands.CommandIDs.setCalloutRightView:
                JSViewAdapter view2 = (JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                if (calloutView == null) {
                    return this;
                }
                calloutView.setRightAccessoryView(view2.getView());
                return this;
            case Commands.CommandIDs.setCenterOffset:
                this.mAnnotation.setCenterOffset(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }
}
