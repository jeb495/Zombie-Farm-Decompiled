package com.ngmoco.gamejs.ui;

public interface JSViewGroupAdapter extends JSViewAdapter {
    JSViewGroupAdapter addSubview(JSViewAdapter jSViewAdapter, int i) throws Exception;
}
