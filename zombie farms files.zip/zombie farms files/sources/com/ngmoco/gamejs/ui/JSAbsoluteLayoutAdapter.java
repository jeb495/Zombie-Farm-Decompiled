package com.ngmoco.gamejs.ui;

import android.view.View;
import android.view.ViewGroup;
import com.ngmoco.gamejs.ui.widgets.UIViewGroup;
import java.io.InvalidObjectException;

public class JSAbsoluteLayoutAdapter extends AbstractJSViewAdapter implements JSViewGroupAdapter {
    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSAbsoluteLayoutAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        if (this.mView == null) {
            this.mView = new UIViewGroup(this.mJSContext.getActivity(), this.mJSContext.getImageCache());
        }
        super.createView();
        return this;
    }

    protected JSAbsoluteLayoutAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.JSViewGroupAdapter
    public JSViewGroupAdapter addSubview(JSViewAdapter newSub, int atIndex) throws Exception {
        if (this.mView == null) {
            throw new NullPointerException("View is not initialized for an update");
        } else if (!(this.mView instanceof ViewGroup)) {
            throw new InvalidObjectException("View is not a view group");
        } else {
            View widget = newSub.getView();
            if (atIndex < 0) {
                ((ViewGroup) this.mView).addView(widget);
            } else {
                ((ViewGroup) this.mView).addView(widget, atIndex);
            }
            if (this.mJSContext.getAnimationBlock() != null) {
                this.mJSContext.getAnimationBlock().addAppearAnimation(widget);
            }
            return this;
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIViewGroup myView = (UIViewGroup) this.mView;
        if (Commands.isImageCommand(commandId)) {
            applyImageDrawableProperties(myView.mImageDrawable, commandId, subCommand, args);
            return this;
        }
        switch (commandId) {
            case 12:
                addSubview((JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]), ((Integer) args[1]).intValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }
}
