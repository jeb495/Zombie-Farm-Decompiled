package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.widgets.UICellView;

public class JSCellViewAdapter extends JSAbsoluteLayoutAdapter {
    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSCellViewAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter, com.ngmoco.gamejs.ui.JSAbsoluteLayoutAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UICellView(this.mJSContext.getActivity(), this.mJSContext.getImageCache());
        return super.createView();
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter, com.ngmoco.gamejs.ui.JSAbsoluteLayoutAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UICellView cell = (UICellView) this.mView;
        if (Commands.isTitleCommand(commandId)) {
            applyTextDrawableProperties(cell.getTitleDrawable(), commandId, subCommand, args);
            return this;
        } else if (Commands.isTextCommand(commandId)) {
            applyTextDrawableProperties(cell.getTextDrawable(), commandId, subCommand, args);
            return this;
        } else if (Commands.isImageCommand(commandId)) {
            applyImageDrawableProperties(cell.getImageDrawable(), commandId, subCommand, args);
            return this;
        } else if (Commands.isRightImageCommand(commandId)) {
            applyImageDrawableProperties(cell.getRightImageDrawable(), commandId, subCommand, args);
            return this;
        } else {
            switch (commandId) {
                case 6:
                    super.handleCommand(commandId, subCommand, args);
                    return this;
                default:
                    return super.handleCommand(commandId, subCommand, args);
            }
        }
    }

    public JSCellViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }
}
