package com.ngmoco.gamejs.ui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.activity.JSActivity;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import java.io.FileInputStream;
import org.json.JSONException;
import org.json.JSONObject;

public class ImagePicker {
    protected static final int CAMERA_MODE = 1;
    protected static final int GALLERY_MODE = 0;
    private static final int IMAGE_MAX_SIZE = 640;
    public static final int NO_ERROR = 0;
    public static final int USER_NOTPICK = 1;
    public static final int USER_PICKED_INVALID = 2;
    private static volatile ImagePicker sInstance;
    JSActivity mActivity;
    Commands mJSContext;
    protected int mMode = -1;
    protected ImageRequest mRequest = null;
    protected long reqId = 0;
    protected long responseId = 0;

    /* access modifiers changed from: private */
    public class ImageRequest {
        String _inFilename;
        String callbackId;
        int height;
        String options;
        String outFilename;
        int width;

        public ImageRequest(int w, int h, String filename, String opt, String cbid) {
            this.outFilename = filename;
            this.options = opt;
            this.callbackId = cbid;
            this.width = w;
            this.height = h;
        }

        public void setResponse(String infilename) {
            this._inFilename = infilename;
        }

        public void reset(int w, int h, String filename, String opt, String cbid) {
            this.outFilename = filename;
            this.options = opt;
            this.callbackId = cbid;
            this.width = w;
            this.height = h;
        }
    }

    public static ImagePicker getInstance() {
        if (sInstance == null) {
            sInstance = new ImagePicker();
        }
        return sInstance;
    }

    public void setActivity(JSActivity _activity) {
        this.mActivity = _activity;
    }

    public void pickPhotoRequest(int w, int h, String filename, String options, String callbackId, Commands jsContext) {
        this.mJSContext = jsContext;
        if (this.reqId == this.responseId) {
            if (this.mRequest == null) {
                this.mRequest = new ImageRequest(w, h, filename, options, callbackId);
            } else {
                this.mRequest.reset(w, h, filename, options, callbackId);
            }
            this.mMode = 0;
            try {
                this.mActivity.launchGallery();
            } catch (Throwable t) {
                returnError(1);
                t.printStackTrace();
            }
            this.reqId++;
        }
    }

    public void pickPhotoCamera(int w, int h, String filename, String options, String callbackId, Commands jsContext) {
        this.mJSContext = jsContext;
        if (this.reqId == this.responseId) {
            if (this.mRequest == null) {
                this.mRequest = new ImageRequest(w, h, filename, options, callbackId);
            } else {
                this.mRequest.reset(w, h, filename, options, callbackId);
            }
            try {
                this.mActivity.launchCamera();
            } catch (Throwable t) {
                returnError(1);
                t.printStackTrace();
            }
            this.mMode = 1;
            this.reqId++;
        }
    }

    public void onCancel() {
    }

    private void returnError(int error) {
        if (this.mRequest != null) {
            try {
                JSONObject j = new JSONObject();
                j.put(NgSystemBindingService.EXTRA_NAME, "callback");
                j.put("callback_id", this.mRequest.callbackId);
                String err = ASConstants.kEmptyString;
                switch (error) {
                    case 1:
                        err = "User did not pick an image";
                        break;
                    case 2:
                        err = "User picked an invalid file";
                        break;
                }
                j.put(JSWebViewAdapter.Events.ERROR, err);
                this.mJSContext.sendEvent(j.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public void onImagePicked(String possibleURL, int error) {
        if (error == 0) {
            try {
                JSONObject info = new JSONObject(this.mRequest.options);
                info.put("image", possibleURL);
                ImageCompositor ic = new ImageCompositor(this.mRequest.width, this.mRequest.height, this.mRequest.outFilename, this.mRequest.callbackId, this.mJSContext);
                ic.addImage(info);
                ic.finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            returnError(error);
        }
        this.responseId++;
    }

    public void onImagePicked(Bitmap bm, int error) {
        Throwable t;
        if (error == 0) {
            try {
                JSONObject info = new JSONObject(this.mRequest.options);
                try {
                    if (this.mRequest.width == 0 || this.mRequest.height == 0) {
                        this.mRequest.width = bm.getWidth();
                        this.mRequest.height = bm.getHeight();
                    }
                    ImageCompositor ic = new ImageCompositor(this.mRequest.width, this.mRequest.height, this.mRequest.outFilename, this.mRequest.callbackId, this.mJSContext);
                    ic.addImage(info, bm);
                    ic.finish();
                } catch (Throwable th) {
                    t = th;
                    t.printStackTrace();
                    this.responseId++;
                }
            } catch (Throwable th2) {
                t = th2;
                t.printStackTrace();
                this.responseId++;
            }
        } else {
            returnError(error);
        }
        this.responseId++;
    }

    public static Bitmap decodeFile(String f) {
        if (f == null) {
            return null;
        }
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            FileInputStream fis = new FileInputStream(f);
            BitmapFactory.decodeStream(fis, null, o);
            fis.close();
            int scale = 1;
            if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
                scale = (int) Math.pow(2.0d, (double) ((int) Math.round(Math.log(640.0d / ((double) Math.max(o.outHeight, o.outWidth))) / Math.log(0.5d))));
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            FileInputStream fis2 = new FileInputStream(f);
            Bitmap b = BitmapFactory.decodeStream(fis2, null, o2);
            fis2.close();
            return b;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
