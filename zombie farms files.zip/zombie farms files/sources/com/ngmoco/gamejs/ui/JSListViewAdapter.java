package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.ScrollingView;
import org.json.JSONArray;

public class JSListViewAdapter extends JSScrollViewAdapter {
    protected JSListViewSection[] sections;

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.ui.JSScrollViewAdapter
    public boolean canTransform() {
        return false;
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSListViewAdapter(jsContext, objId).createView();
    }

    private void updatePosition(int y) {
        if (this.sections != null) {
            int height = this.mView.getHeight();
            for (JSListViewSection section : this.sections) {
                section.scrollPositionChanged(y, height);
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSScrollViewAdapter, com.ngmoco.gamejs.ui.JSViewGroupAdapter
    public JSViewGroupAdapter addSubview(JSViewAdapter newSub, int atIndex) throws Exception {
        super.addSubview(newSub, atIndex);
        if (this.sections != null) {
            for (JSListViewSection section : this.sections) {
                section.bringTitleForward();
            }
        }
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIScrollListener, com.ngmoco.gamejs.ui.JSScrollViewAdapter
    public void onScrollChanged(int x, int y, int oldX, int oldY) {
        updatePosition(y);
        super.onScrollChanged(x, y, oldX, oldY);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter, com.ngmoco.gamejs.ui.JSScrollViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case Commands.CommandIDs.setSections:
                JSONArray sectionIDs = new JSONArray((String) args[0]);
                this.sections = new JSListViewSection[sectionIDs.length()];
                for (int i = 0; i < sectionIDs.length(); i++) {
                    this.sections[i] = (JSListViewSection) this.mJSContext.getAdapter(Integer.valueOf(sectionIDs.optInt(i)));
                }
                updatePosition(((ScrollingView) this.mView).getScrollY());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    protected JSListViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }
}
