package com.ngmoco.gamejs.ui;

import android.view.View;

public interface JSViewAdapter extends JSAdapter {
    JSViewAdapter createView() throws Exception;

    View getView();

    JSViewAdapter removeFromSuperview() throws Exception;
}
