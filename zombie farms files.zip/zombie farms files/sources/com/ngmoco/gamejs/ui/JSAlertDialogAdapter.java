package com.ngmoco.gamejs.ui;

import android.content.DialogInterface;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIAlertDialogBuilder;
import org.json.JSONArray;
import org.json.JSONObject;

public final class JSAlertDialogAdapter extends AbstractJSAdapter {
    JSONObject jsonForChoiceEvent;
    private UIAlertDialogBuilder mBuilder;

    /* JADX WARN: Type inference failed for: r1v0, types: [com.ngmoco.gamejs.activity.JSActivity, android.app.Activity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    private JSAlertDialogAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
        this.mBuilder = new UIAlertDialogBuilder(jsContext.getActivity());
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSAlertDialogAdapter(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case Commands.CommandIDs.setText /*{ENCODED_INT: 31}*/:
                this.mBuilder.setMessage(Utils.localized((String) args[0]));
                return this;
            case Commands.CommandIDs.setTitle /*{ENCODED_INT: 41}*/:
                this.mBuilder.setTitle(Utils.localized((String) args[0]));
                return this;
            case Commands.CommandIDs.setChoices /*{ENCODED_INT: 70}*/:
                JSONArray choicesJSON = new JSONArray((String) args[0]);
                String[] choices = new String[choicesJSON.length()];
                for (int i = 0; i < choices.length; i++) {
                    choices[i] = Utils.localized(choicesJSON.getString(i));
                }
                enableEventResponse(AbstractJSAdapter.Events.CHOICE, choices.length > 0);
                this.mBuilder.setChoices(choices, new DialogInterface.OnClickListener() {
                    /* class com.ngmoco.gamejs.ui.JSAlertDialogAdapter.AnonymousClass1 */

                    public void onClick(DialogInterface dialog, int which) {
                        int which2;
                        Log.d("Alert Dialog", "Got Choice " + which);
                        switch (which) {
                            case Commands.ResourceError.Out_Of_Memory /*{ENCODED_INT: -3}*/:
                                which2 = 2;
                                break;
                            case -2:
                                which2 = 1;
                                break;
                            case -1:
                                which2 = 0;
                                break;
                            default:
                                which2 = -1;
                                break;
                        }
                        try {
                            JSAlertDialogAdapter.this.triggerCustomEventResponse(AbstractJSAdapter.Events.CHOICE, AbstractJSAdapter.Events.CHOICE, Integer.valueOf(which2));
                        } catch (Exception e) {
                            Log.d("Alert Dialog", "Could not report button press " + which2 + " " + e.toString());
                        }
                    }
                });
                return this;
            case Commands.CommandIDs.show /*{ENCODED_INT: 71}*/:
                if (GameJSActivity.mSuiciding) {
                    return this;
                }
                this.mBuilder.showDialog();
                return this;
            case Commands.CommandIDs.hide /*{ENCODED_INT: 72}*/:
                this.mBuilder.dismissDialog();
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter
    public void cleanup() {
        this.mBuilder.dismissDialog();
    }
}
