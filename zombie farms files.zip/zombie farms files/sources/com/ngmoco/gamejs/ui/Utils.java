package com.ngmoco.gamejs.ui;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.widget.AbsoluteLayout;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIScrollAnimation;
import com.tapit.adview.ormma.OrmmaController;
import java.util.HashMap;
import org.json.JSONArray;

public class Utils {
    private static final String TAG = "com.ngmoco.gamejs.ui.Utils";
    private static DisplayMetrics mDisplayMetrics;
    private static HashMap<String, Integer> mLocaleKeys = new HashMap<>();
    private static Activity sActivity = null;

    static {
        mLocaleKeys.put("sd card is full", Integer.valueOf((int) R.string.sd_card_full_dialog_message));
        mLocaleKeys.put("file location has changed (302)", 0);
        mLocaleKeys.put("bad request to server (400)", 0);
        mLocaleKeys.put("authorization failed (401)", 0);
        mLocaleKeys.put("server permissions error (403)", 0);
        mLocaleKeys.put("resource not found (404)", 0);
        mLocaleKeys.put("request timed out (408)", 0);
        mLocaleKeys.put("internal server error (500)", 0);
        mLocaleKeys.put("cannot process request (501)", 0);
        mLocaleKeys.put("bad gateway (502)", 0);
        mLocaleKeys.put("service overloaded / down for maintenance (503)", 0);
        mLocaleKeys.put("timeout at intervening gateway (504)", 0);
        mLocaleKeys.put("network error", Integer.valueOf((int) R.string.network_failure_msg));
        mLocaleKeys.put("application requires working data connection", Integer.valueOf((int) R.string.working_connection_msg));
        mLocaleKeys.put("cannot download game without network connection.", Integer.valueOf((int) R.string.can_not_download_msg));
        mLocaleKeys.put("ok", 0);
        mLocaleKeys.put(OrmmaController.EXIT, Integer.valueOf((int) R.string.err_dialog_dismiss_button));
    }

    public static void init(Activity activity) {
        mDisplayMetrics = new DisplayMetrics();
        sActivity = activity;
        activity.getWindowManager().getDefaultDisplay().getMetrics(mDisplayMetrics);
    }

    public static int colorFromString(String colorStr) {
        if (colorStr.length() == 2) {
            colorStr = "FF" + colorStr;
        }
        if (colorStr.length() == 4) {
            String substr = colorStr.substring(2);
            colorStr = colorStr + substr + substr;
        }
        return Color.parseColor("#" + colorStr);
    }

    public static RectF rectFFromFrame(JSONArray frame) {
        float x = (float) frame.optDouble(0);
        float y = (float) frame.optDouble(1);
        return new RectF(x, y, x + ((float) frame.optDouble(2)), y + ((float) frame.optDouble(3)));
    }

    public static Float[] floatArray(Object[] src) {
        Float[] dst = new Float[src.length];
        System.arraycopy(src, 0, dst, 0, src.length);
        return dst;
    }

    public static Rect rectFromFrame(JSONArray frame) {
        int x = frame.optInt(0);
        int y = frame.optInt(1);
        return new Rect(x, y, x + frame.optInt(2), y + frame.optInt(3));
    }

    public static AbsoluteLayout.LayoutParams layoutFromFrame(JSONArray frame) {
        return new AbsoluteLayout.LayoutParams(frame.optInt(2), frame.optInt(3), frame.optInt(0), frame.optInt(1));
    }

    public static float pixelsForFontSize(float fontSize) {
        return mDisplayMetrics.density * fontSize;
    }

    public static void applyGravity(Rect containerBounds, Rect contentBounds, float gravX, float gravY) {
        int w = contentBounds.width();
        int h = contentBounds.height();
        float cX = (((float) containerBounds.width()) * gravX) - (((float) w) * gravX);
        float cY = (((float) containerBounds.height()) * gravY) - (((float) h) * gravY);
        contentBounds.left = containerBounds.left + ((int) cX);
        contentBounds.top = containerBounds.top + ((int) cY);
        contentBounds.right = contentBounds.left + w;
        contentBounds.bottom = contentBounds.top + h;
    }

    public static void applyGravity(Rect containerBounds, RectF contentBounds, float gravX, float gravY) {
        float w = contentBounds.width();
        float h = contentBounds.height();
        float cX = (((float) containerBounds.width()) * gravX) - (w * gravX);
        float cY = (((float) containerBounds.height()) * gravY) - (h * gravY);
        contentBounds.left = (float) (containerBounds.left + ((int) cX));
        contentBounds.top = (float) (containerBounds.top + ((int) cY));
        contentBounds.right = contentBounds.left + w;
        contentBounds.bottom = contentBounds.top + h;
    }

    public static void applyGravity(RectF containerBounds, RectF contentBounds, float gravX, float gravY) {
        float w = contentBounds.width();
        float h = contentBounds.height();
        float cX = (containerBounds.width() * gravX) - (w * gravX);
        float cY = (containerBounds.height() * gravY) - (h * gravY);
        contentBounds.left = containerBounds.left + ((float) ((int) cX));
        contentBounds.top = containerBounds.top + ((float) ((int) cY));
        contentBounds.right = contentBounds.left + w;
        contentBounds.bottom = contentBounds.top + h;
    }

    public static int fontStyleFromAndroidStyle(int androidStyle) {
        switch (androidStyle) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                return 0;
        }
    }

    public static int androidStyleFromFontStyle(int fontStyle) {
        switch (fontStyle) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 3;
            default:
                return 0;
        }
    }

    public static int controlStateFromStateSet(int[] stateSet) {
        int controlState = 0;
        boolean enabled = false;
        for (int state : stateSet) {
            switch (state) {
                case 16842908:
                    controlState |= 1;
                    break;
                case 16842910:
                    enabled = true;
                    break;
                case 16842912:
                    controlState |= 8;
                    break;
                case 16842913:
                    controlState |= 2;
                    break;
                case 16842919:
                    controlState |= 4;
                    break;
            }
        }
        if (!enabled) {
            return controlState | Commands.State.Disabled;
        }
        return controlState;
    }

    public static String localized(String key) {
        Integer resourceId = mLocaleKeys.get(key.toLowerCase().trim());
        return (resourceId == null || resourceId.intValue() == 0) ? key : sActivity.getString(resourceId.intValue());
    }

    public static void removeAnimation(View v) {
        Animation a = v.getAnimation();
        if (a != null) {
            Log.d(TAG, "Removing animation for " + v);
            cancelAnimation(a);
            v.clearAnimation();
        }
    }

    public static void removeScrollAnimations(View v) {
        Animation a = v.getAnimation();
        if (a instanceof UIScrollAnimation) {
            cancelAnimation(a);
            v.clearAnimation();
        }
        if (a instanceof AnimationSet) {
            for (Animation a2 : ((AnimationSet) a).getAnimations()) {
                if (a2 instanceof UIScrollAnimation) {
                    cancelAnimation(a);
                }
            }
        }
    }

    private static void cancelAnimation(Animation a) {
        if (Build.VERSION.SDK_INT >= 8) {
            a.cancel();
            return;
        }
        a.setDuration(0);
        a.restrictDuration(0);
    }
}
