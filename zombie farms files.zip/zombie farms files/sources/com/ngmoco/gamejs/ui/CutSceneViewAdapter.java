package com.ngmoco.gamejs.ui;

import android.media.MediaPlayer;
import android.view.View;
import android.widget.VideoView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import org.json.JSONObject;

public class CutSceneViewAdapter extends AbstractJSViewAdapter implements MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener, MediaPlayer.OnErrorListener, View.OnClickListener {
    private String mCallbackId = null;

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new CutSceneViewAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new VideoView(this.mJSContext.getActivity());
        ((VideoView) this.mView).setOnErrorListener(this);
        ((VideoView) this.mView).setOnPreparedListener(this);
        ((VideoView) this.mView).setOnCompletionListener(this);
        return super.createView();
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 13:
                ((VideoView) this.mView).stopPlayback();
                return super.handleCommand(commandId, subCommand, args);
            case Commands.CommandIDs.playVideo /*{ENCODED_INT: 130}*/:
                ((VideoView) this.mView).setVideoPath(this.mJSContext.getManifestRoot().concat("/" + ((String) args[0])));
                this.mCallbackId = (String) args[1];
                ((VideoView) this.mView).start();
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    protected CutSceneViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    private void sendCallback(MediaPlayer mp, String error, int errorCode) {
        try {
            JSONObject j = new JSONObject();
            j.put(NgSystemBindingService.EXTRA_NAME, "callback");
            j.put("callback_id", this.mCallbackId);
            if (error != null) {
                j.put(JSWebViewAdapter.Events.ERROR, error);
            }
            if (errorCode != 0) {
                j.put("errorCode", errorCode);
            }
            j.put("didFinish", mp.getCurrentPosition() >= mp.getDuration());
            j.put("playbackPosition", mp.getCurrentPosition());
            this.mJSContext.sendEvent(j.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onError(MediaPlayer mp, int what, int extra) {
        String errStr = "An error occurred";
        if (what == 100) {
            errStr = "The media server has died";
        }
        sendCallback(mp, errStr, extra);
        return false;
    }

    public void onPrepared(MediaPlayer arg0) {
        Log.d("CutSceneView", "Video was prepared");
    }

    public void onCompletion(MediaPlayer mp) {
        Log.d("CutSceneView", "Video Finished");
        sendCallback(mp, null, 0);
    }

    public void onClick(View v) {
        triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK, new Object[0]);
    }
}
