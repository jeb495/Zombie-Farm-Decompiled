package com.ngmoco.gamejs.ui;

import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import com.millennialmedia.android.MMAdView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.SimpleImageCache;
import com.ngmoco.gamejs.SplashScreen;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.activity.JSActivity;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.widgets.TextLayout;
import java.io.File;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONArray;
import org.json.JSONObject;

public class Commands implements Handler.Callback {
    private static final String TAG = "UIActionHandler";
    private static boolean sDebugProfiling = CommandsWithProfiling.sTraceFile.exists();
    static View sForcedCompositor = null;
    static int sForcedCompositorCount = 0;
    private static volatile Handler sHandler;
    private static ConcurrentHashMap<Integer, Commands> sInstances = new ConcurrentHashMap<>();
    private static ConcurrentLinkedQueue<UICommand> sQueue = new ConcurrentLinkedQueue<>();
    private static volatile int sReusableCount = 0;
    private static ConcurrentLinkedQueue<UICommand> sReuseQueue = new ConcurrentLinkedQueue<>();
    JSWindowLayerAdapter baseJsWindowLayerAdapter = null;
    private JSActivity mActivity;
    private AnimationBlock mAnimationBlock = null;
    private FontManager mFontManager;
    private HashMap<Integer, JSAdapter> mIdsToAdapters = new HashMap<>();
    private SimpleImageCache mImageCache;
    private String mManifestRoot;
    private ConcurrentLinkedQueue<String> mOutboundMessages = new ConcurrentLinkedQueue<>();
    private boolean mProcHasGL = false;
    private int mProcId = 0;
    private HashSet<Operation> mRunningOperations = new HashSet<>();
    private volatile boolean mStartupComplete = false;

    public static class Autodetect {
        public static final int None = 0;
        public static final int Phone = 1;
    }

    public static class ButtonLayout {
        public static final int CenterImageOver = 5;
        public static final int CenterTextOver = 0;
        public static final int StackImageBottom = 4;
        public static final int StackImageLeft = 1;
        public static final int StackImageRight = 3;
        public static final int StackImageTop = 2;
    }

    public static class CommandIDs {
        public static final int REMOVED_doChoosePhoto = -105;
        public static final int addAnnotation = 109;
        public static final int addSubview = 12;
        public static final int clearAnimations = 126;
        public static final int create = -2;
        public static final int destroy = 3;
        public static final int disableEvent = 7;
        public static final int doChooseCamera = -106;
        public static final int doChoosePhoto = -121;
        public static final int doCompositeImages = -104;
        public static final int enableEvent = 6;
        public static final int eventOccurred = -8;
        public static final int executeAnimation = -15;
        public static final int goBack = 80;
        public static final int goForward = 81;
        public static final int hide = 72;
        public static final int hideKeyboard = -132;
        public static final int initializeNative = -1;
        public static final int invoke = 79;
        public static final int loadGetURL = 75;
        public static final int loadPostURL = 74;
        public static final int loadURL = 76;
        public static final int measureText = -123;
        public static final int pauseAds = 93;
        public static final int playVideo = 130;
        public static final int postURL = 98;
        public static final int reload = 78;
        public static final int removeAnnotation = 110;
        public static final int removeFromSuperview = 13;
        public static final int resumeAds = 94;
        public static final int selectAnnotation = 111;
        public static final int setActive = 4;
        public static final int setAdAllowAutoplay = 96;
        public static final int setAdRefreshRate = 95;
        public static final int setAlpha = 97;
        public static final int setAnchor = 18;
        public static final int setAutodetection = 129;
        public static final int setBackgroundColor = 21;
        public static final int setBarGradient = 58;
        public static final int setBasicAuthCredentials = 82;
        public static final int setBoolValue = 55;
        public static final int setButtonLayout = 56;
        public static final int setCalloutEnabled = 117;
        public static final int setCalloutLeftView = 118;
        public static final int setCalloutRightView = 119;
        public static final int setCalloutSubtitle = 116;
        public static final int setCalloutTitle = 115;
        public static final int setCenterOffset = 120;
        public static final int setChecked = 64;
        public static final int setChoices = 70;
        public static final int setContentInsets = 57;
        public static final int setCoordinate = 114;
        public static final int setDarkStyle = 103;
        public static final int setEnabled = 10;
        public static final int setEnterKeyType = 62;
        public static final int setFloatValue = 53;
        public static final int setFocus = 124;
        public static final int setFrame = 16;
        public static final int setGradient = 51;
        public static final int setImage = 22;
        public static final int setImageAnchor = 27;
        public static final int setImageBorder = 23;
        public static final int setImageFitMode = 24;
        public static final int setImageGravity = 25;
        public static final int setImageInsets = 29;
        public static final int setImageOrigin = 26;
        public static final int setImageSize = 28;
        public static final int setImageTransform = 30;
        public static final int setInputType = 63;
        public static final int setIntValue = 54;
        public static final int setIsVisible = 9;
        public static final int setLineHeight = 131;
        public static final int setOrigin = 17;
        public static final int setPlaceholderText = 59;
        public static final int setPlaceholderTextColor = 60;
        public static final int setPlaceholderTextShadow = 61;
        public static final int setPostData = 73;
        public static final int setProgress = 101;
        public static final int setProgressGradient = 99;
        public static final int setRegion = 112;
        public static final int setRightImage = 83;
        public static final int setRightImageAnchor = 88;
        public static final int setRightImageBorder = 84;
        public static final int setRightImageFitMode = 85;
        public static final int setRightImageGravity = 86;
        public static final int setRightImageInsets = 90;
        public static final int setRightImageOrigin = 87;
        public static final int setRightImageSize = 89;
        public static final int setRightImageTransform = 91;
        public static final int setScrollIndicatorsVisible = 122;
        public static final int setScrollPosition = 65;
        public static final int setScrollable = 107;
        public static final int setScrollableSize = 66;
        public static final int setSecondaryGradient = 100;
        public static final int setSections = 67;
        public static final int setSize = 19;
        public static final int setSourceDocument = 69;
        public static final int setState = 11;
        public static final int setStatusBarHidden = -92;
        public static final int setStringValue = 52;
        public static final int setStyle = 127;
        public static final int setText = 31;
        public static final int setTextColor = 32;
        public static final int setTextFont = 33;
        public static final int setTextGravity = 36;
        public static final int setTextInsets = 37;
        public static final int setTextMaxLines = 39;
        public static final int setTextMinSize = 40;
        public static final int setTextOverflow = 38;
        public static final int setTextShadow = 34;
        public static final int setTextSize = 35;
        public static final int setTitle = 41;
        public static final int setTitleColor = 42;
        public static final int setTitleFont = 43;
        public static final int setTitleGravity = 46;
        public static final int setTitleInsets = 47;
        public static final int setTitleMaxLines = 49;
        public static final int setTitleMinSize = 50;
        public static final int setTitleOverflow = 48;
        public static final int setTitleShadow = 44;
        public static final int setTitleSize = 45;
        public static final int setTitleView = 68;
        public static final int setTouchable = 5;
        public static final int setTransform = 20;
        public static final int setView = 113;
        public static final int setViewportEnabled = 125;
        public static final int setVisibleInOrientations = 128;
        public static final int setZoomable = 108;
        public static final int show = 71;
        public static final int startAnimation = -14;
        public static final int stopLoading = 77;
        public static final int takeScreenshot = -133;
        public static final int useForUpdateProgress = 102;
    }

    public static class EnterKeyType {
        public static final int Done = 1;
        public static final int Go = 4;
        public static final int Next = 2;
        public static final int Return = 0;
        public static final int Search = 5;
        public static final int Send = 6;
        public static final int Submit = 3;
    }

    public static class FitMode {
        public static final int AspectHeight = 6;
        public static final int AspectWidth = 5;
        public static final int Fill = 2;
        public static final int Inside = 1;
        public static final int InsideNoUpscaling = 7;
        public static final int None = 0;
        public static final int Stretch = 3;
    }

    public static class FontStyle {
        public static final int Bold = 1;
        public static final int BoldItalic = 3;
        public static final int Italic = 2;
        public static final int Normal = 0;
    }

    public static class InputType {
        public static final int ANDROID_LANDSCAPE_FULLSCREEN = 8;
        public static final int Date = 7;
        public static final int Email = 5;
        public static final int None = 0;
        public static final int Numeric = 4;
        public static final int Password = 2;
        public static final int TextWithCorrection = 1;
        public static final int URL = 6;
    }

    public static class OrientationFlag {
        public static final int Landscape = 1;
        public static final int Portrait = 2;
    }

    public static class Proc {
        public static final int Game = -2;
        public static final int Persist = -1;
    }

    public static class ResourceError {
        public static final int Connectivity_Error = -4;
        public static final int Decode_Failed = -5;
        public static final int File_Not_Found = -2;
        public static final int None = 0;
        public static final int Other = -1;
        public static final int Out_Of_Memory = -3;
    }

    public static class Scaling {
        public static final int Percent = 3;
        public static final int Pixels = 0;
        public static final int Points = 1;
        public static final int Unit = 2;
        public static final int iPhone = 4;
    }

    public static class ScreenshotType {
        public static final int GLOnly = 1;
        public static final int Normal = 0;
        public static final int UIOnly = 2;
    }

    public static class State {
        public static final int Checked = 8;
        public static final int Custom = 16711680;
        public static final int Disabled = 1073741824;
        public static final int Focused = 1;
        public static final int Normal = 0;
        public static final int Pressed = 4;
        public static final int Selected = 2;
    }

    public static class SwipeDirection {
        public static final int Down = 4;
        public static final int Left = 1;
        public static final int Right = 2;
        public static final int Up = 3;
    }

    /* access modifiers changed from: private */
    public static class UICommand {
        Object[] args;
        Commands commandObject;
        int mCommandId;
        int mObjectId;
        int mSubcommand;

        private UICommand() {
        }
    }

    public AnimationBlock getAnimationBlock() {
        return this.mAnimationBlock;
    }

    public static class CommandsWithProfiling extends Commands {
        private static final String TAG = "CommandsWithProfiling";
        static HashMap<Integer, String> sNameMapping;
        private static final File sTraceFile = new File("/sdcard/ngcore_ui_profile.txt");

        private static class CommandsProfileEntry {
            protected int mCallCount = 0;
            protected String mCommandName;
            protected long mTotalTime = 0;
        }

        static {
            sNameMapping = null;
            Log.d(TAG, "UI PROFILING " + (sTraceFile.exists() ? "ENABLED" : "DISABLED"));
            if (sTraceFile.exists()) {
                sNameMapping = new HashMap<>();
                Field[] ids = CommandIDs.class.getFields();
                for (int i = 0; i < ids.length; i++) {
                    try {
                        sNameMapping.put(Integer.valueOf(ids[i].getInt(null)), ids[i].getName());
                    } catch (Exception e) {
                    }
                }
            }
        }

        protected CommandsWithProfiling(int procId, JSActivity activity) {
            super(procId, activity);
        }

        @Override // com.ngmoco.gamejs.ui.Commands
        public boolean handleMessage(Message message) {
            HashMap<Integer, CommandsProfileEntry> frameProf = new HashMap<>();
            long outerStartTime = System.currentTimeMillis();
            while (true) {
                UICommand cmd = (UICommand) Commands.sQueue.poll();
                if (cmd == null) {
                    break;
                }
                int cmdId = cmd.mCommandId;
                CommandsProfileEntry e = frameProf.get(Integer.valueOf(cmdId));
                if (e == null) {
                    e = new CommandsProfileEntry();
                    e.mCommandName = sNameMapping.get(Integer.valueOf(cmdId));
                    if (e.mCommandName == null) {
                        e.mCommandName = "< unknown command " + cmdId + ">";
                    }
                    frameProf.put(Integer.valueOf(cmdId), e);
                }
                long sTime = System.currentTimeMillis();
                cmd.commandObject.handleUICommand(cmd);
                e.mTotalTime += System.currentTimeMillis() - sTime;
                e.mCallCount++;
            }
            if (frameProf.isEmpty()) {
                return true;
            }
            long totalTime = 0;
            for (CommandsProfileEntry e2 : frameProf.values()) {
                Log.i(TAG, String.format("%s called %d times (AVG %.3f ms, TOTAL %d ms)", e2.mCommandName, Integer.valueOf(e2.mCallCount), Double.valueOf(((double) e2.mTotalTime) / ((double) e2.mCallCount)), Long.valueOf(e2.mTotalTime)));
                totalTime += e2.mTotalTime;
            }
            Log.i(TAG, " -- UI Processing Complete for frame -- INNER " + totalTime + "ms, OUTER " + (System.currentTimeMillis() - outerStartTime) + "ms -- ");
            return true;
        }
    }

    public static boolean isProfilingEnabled() {
        return sDebugProfiling;
    }

    public static Commands getInstance(int procId) {
        Commands instance = sInstances.get(Integer.valueOf(procId));
        if (instance == null) {
            if (sDebugProfiling) {
                instance = new CommandsWithProfiling(procId, GameJSActivity.getActivity());
            } else {
                instance = new Commands(procId, GameJSActivity.getActivity());
            }
            sInstances.put(Integer.valueOf(procId), instance);
        }
        return instance;
    }

    public void addOperation(Operation operation) {
        this.mRunningOperations.add(operation);
    }

    public void removeOperation(Operation operation) {
        this.mRunningOperations.remove(operation);
    }

    public void setGame(boolean isPriveleged, String repo, String gameDir) {
        this.mManifestRoot = repo + "/" + gameDir;
        if (!isPriveleged) {
            repo = null;
        }
        this.mImageCache = new SimpleImageCache(repo, this.mManifestRoot);
        this.mFontManager = new FontManager(this.mManifestRoot);
    }

    public String getManifestRoot() {
        return this.mManifestRoot;
    }

    public static void postMessage(int procId, int objectId, int commandId, int subCommand, Object[] args) {
        UICommand cmd = sReuseQueue.poll();
        if (cmd != null) {
            sReusableCount--;
        } else {
            cmd = new UICommand();
        }
        cmd.commandObject = getInstance(procId);
        cmd.mObjectId = objectId;
        cmd.mCommandId = commandId;
        cmd.mSubcommand = subCommand;
        cmd.args = args;
        if (commandId == -123) {
            Commands instance = getInstance(procId);
            Paint textPaint = new Paint((int) CommandIDs.setVisibleInOrientations);
            float fontSize = 0.0f;
            if (args[4] != null) {
                fontSize = ((Float) args[4]).floatValue();
            }
            String font = (String) args[3];
            if (fontSize > 0.0f) {
                textPaint.setTextSize(Utils.pixelsForFontSize(fontSize));
            }
            if (font != null && font.length() > 0) {
                textPaint.setTypeface(instance.getFontManager().getFont(font));
            }
            TextLayout layout = new TextLayout((String) args[0], textPaint);
            layout.setMeasurementListener(new TextLayout.OnTextMeasuredListener(instance) {
                /* class com.ngmoco.gamejs.ui.Commands.AnonymousClass1 */
                final /* synthetic */ Commands val$instance;

                {
                    this.val$instance = r1;
                }

                @Override // com.ngmoco.gamejs.ui.widgets.TextLayout.OnTextMeasuredListener
                public void textWasMeasured(Object context, int measuredWidth, int measuredHeight, int totalWidth, int[] lineWidths) {
                    try {
                        JSONObject j = new JSONObject();
                        j.put(NgSystemBindingService.EXTRA_NAME, "callback");
                        j.put("callback_id", context);
                        JSONArray lines = new JSONArray();
                        for (int i : lineWidths) {
                            lines.put(i);
                        }
                        j.put(MMAdView.KEY_WIDTH, measuredWidth);
                        j.put(MMAdView.KEY_HEIGHT, measuredHeight);
                        j.put("totalWidth", totalWidth);
                        j.put("lineWidths", lines);
                        this.val$instance.sendEvent(j.toString());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }, (String) args[5]);
            layout.measure(new Rect(0, 0, ((Integer) args[1]).intValue(), ((Integer) args[2]).intValue()));
            return;
        }
        sQueue.add(cmd);
    }

    public static void frameFinished() {
        if (!sQueue.isEmpty()) {
            sHandler.obtainMessage().sendToTarget();
        }
    }

    public JSAdapter getAdapter(Integer objId) {
        return this.mIdsToAdapters.get(objId);
    }

    public int getProcId() {
        return this.mProcId;
    }

    public JSAdapter createAdapter(int objId, String objType) throws Exception {
        JSAdapter adapter = this.mIdsToAdapters.get(Integer.valueOf(objId));
        if (adapter == null) {
            adapter = JSViewAdapterFactory.getAdapter(this, Integer.valueOf(objId), objType);
            this.mIdsToAdapters.put(Integer.valueOf(objId), adapter);
            if (adapter instanceof JSGLAdapter) {
                this.mProcHasGL = true;
            } else if (!this.mStartupComplete) {
                this.mStartupComplete = true;
                if (!this.mProcHasGL) {
                    SplashScreen.procDidStart(this.mProcId);
                }
            }
        }
        return adapter;
    }

    public JSActivity getActivity() {
        return this.mActivity;
    }

    public FontManager getFontManager() {
        return this.mFontManager;
    }

    public SimpleImageCache getImageCache() {
        return this.mImageCache;
    }

    private void onDestroyProc() {
        for (JSAdapter a : this.mIdsToAdapters.values()) {
            if (a instanceof JSWebViewAdapter) {
                ((JSWebViewAdapter) a).onDestroy();
            }
            a.cleanup();
        }
        Iterator i$ = this.mRunningOperations.iterator();
        while (i$.hasNext()) {
            i$.next().cancel();
        }
    }

    public static void onDestroy() {
        for (Commands c : sInstances.values()) {
            c.onDestroyProc();
        }
    }

    private void onPauseProc() {
        for (JSAdapter a : this.mIdsToAdapters.values()) {
            if (a instanceof JSWebViewAdapter) {
                ((JSWebViewAdapter) a).onPause();
            }
        }
    }

    public static void onPause() {
        for (Commands c : sInstances.values()) {
            c.onPauseProc();
        }
    }

    public void sendEvent(String jsonString) {
        this.mOutboundMessages.add(jsonString);
    }

    private void sendOutboundMessages() {
        while (true) {
            String jsonString = this.mOutboundMessages.poll();
            if (jsonString != null) {
                NgJNI.handleUIEvent(this.mProcId, jsonString);
            } else {
                return;
            }
        }
    }

    public static void frameWillStart() {
        for (Commands c : sInstances.values()) {
            if (!c.mOutboundMessages.isEmpty()) {
                c.sendOutboundMessages();
            }
        }
    }

    public static boolean isTitleCommand(int commandId) {
        switch (commandId) {
            case CommandIDs.setTitle /*{ENCODED_INT: 41}*/:
            case CommandIDs.setTitleColor /*{ENCODED_INT: 42}*/:
            case CommandIDs.setTitleFont /*{ENCODED_INT: 43}*/:
            case CommandIDs.setTitleShadow /*{ENCODED_INT: 44}*/:
            case CommandIDs.setTitleSize /*{ENCODED_INT: 45}*/:
            case CommandIDs.setTitleGravity /*{ENCODED_INT: 46}*/:
            case CommandIDs.setTitleInsets /*{ENCODED_INT: 47}*/:
            case CommandIDs.setTitleOverflow /*{ENCODED_INT: 48}*/:
            case CommandIDs.setTitleMaxLines /*{ENCODED_INT: 49}*/:
            case 50:
                return true;
            default:
                return false;
        }
    }

    public static boolean isTextCommand(int commandId) {
        switch (commandId) {
            case CommandIDs.setText /*{ENCODED_INT: 31}*/:
            case 32:
            case CommandIDs.setTextFont /*{ENCODED_INT: 33}*/:
            case CommandIDs.setTextShadow /*{ENCODED_INT: 34}*/:
            case CommandIDs.setTextSize /*{ENCODED_INT: 35}*/:
            case CommandIDs.setTextGravity /*{ENCODED_INT: 36}*/:
            case CommandIDs.setTextInsets /*{ENCODED_INT: 37}*/:
            case CommandIDs.setTextOverflow /*{ENCODED_INT: 38}*/:
            case CommandIDs.setTextMaxLines /*{ENCODED_INT: 39}*/:
            case CommandIDs.setTextMinSize /*{ENCODED_INT: 40}*/:
            case CommandIDs.setLineHeight /*{ENCODED_INT: 131}*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean isImageCommand(int commandId) {
        switch (commandId) {
            case CommandIDs.setImage /*{ENCODED_INT: 22}*/:
            case CommandIDs.setImageBorder /*{ENCODED_INT: 23}*/:
            case CommandIDs.setImageFitMode /*{ENCODED_INT: 24}*/:
            case CommandIDs.setImageGravity /*{ENCODED_INT: 25}*/:
            case CommandIDs.setImageOrigin /*{ENCODED_INT: 26}*/:
            case CommandIDs.setImageAnchor /*{ENCODED_INT: 27}*/:
            case CommandIDs.setImageSize /*{ENCODED_INT: 28}*/:
            case CommandIDs.setImageInsets /*{ENCODED_INT: 29}*/:
            case CommandIDs.setImageTransform /*{ENCODED_INT: 30}*/:
                return true;
            default:
                return false;
        }
    }

    public static boolean isRightImageCommand(int commandId) {
        switch (commandId) {
            case CommandIDs.setRightImage /*{ENCODED_INT: 83}*/:
            case CommandIDs.setRightImageBorder /*{ENCODED_INT: 84}*/:
            case CommandIDs.setRightImageFitMode /*{ENCODED_INT: 85}*/:
            case CommandIDs.setRightImageGravity /*{ENCODED_INT: 86}*/:
            case CommandIDs.setRightImageOrigin /*{ENCODED_INT: 87}*/:
            case CommandIDs.setRightImageAnchor /*{ENCODED_INT: 88}*/:
            case CommandIDs.setRightImageSize /*{ENCODED_INT: 89}*/:
            case CommandIDs.setRightImageInsets /*{ENCODED_INT: 90}*/:
            case CommandIDs.setRightImageTransform /*{ENCODED_INT: 91}*/:
                return true;
            default:
                return false;
        }
    }

    public void addChildToRoot(View child, int index) {
        this.baseJsWindowLayerAdapter.addSubview(child, index);
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    public void retainCompositor() {
        int i = sForcedCompositorCount;
        sForcedCompositorCount = i + 1;
        if (i == 0) {
            if (sForcedCompositor == null) {
                sForcedCompositor = new View(this.mActivity);
                sForcedCompositor.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
                this.mActivity.getWindow().addContentView(sForcedCompositor, sForcedCompositor.getLayoutParams());
            }
            sForcedCompositor.setVisibility(0);
            sForcedCompositor.setWillNotDraw(false);
        }
    }

    public void releaseCompositor() {
        int i = sForcedCompositorCount - 1;
        sForcedCompositorCount = i;
        if (i == 0) {
            sForcedCompositor.setVisibility(8);
            sForcedCompositor.setWillNotDraw(true);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void handleUICommand(UICommand cmd) {
        try {
            Object[] args = cmd.args;
            if (cmd.mCommandId == 3) {
                JSAdapter adapter = getAdapter(Integer.valueOf(cmd.mObjectId));
                if (adapter != null) {
                    adapter.cleanup();
                }
                this.mIdsToAdapters.remove(Integer.valueOf(cmd.mObjectId));
            } else if (cmd.mObjectId > 0) {
                getAdapter(Integer.valueOf(cmd.mObjectId)).handleCommand(cmd.mCommandId, cmd.mSubcommand, args);
            } else {
                switch (cmd.mCommandId) {
                    case CommandIDs.takeScreenshot /*{ENCODED_INT: -133}*/:
                        new ScreenShotter(((Integer) args[0]).intValue(), ((Integer) args[1]).intValue(), (String) args[2], (String) args[3], (String) args[4], this);
                        break;
                    case CommandIDs.hideKeyboard /*{ENCODED_INT: -132}*/:
                        JSEditTextAdapter.hideKeyboard();
                        break;
                    case CommandIDs.doChoosePhoto /*{ENCODED_INT: -121}*/:
                    case CommandIDs.REMOVED_doChoosePhoto /*{ENCODED_INT: -105}*/:
                        ImagePicker.getInstance().pickPhotoRequest(((Integer) args[0]).intValue(), ((Integer) args[1]).intValue(), (String) args[2], (String) args[3], (String) args[4], this);
                        break;
                    case CommandIDs.doChooseCamera /*{ENCODED_INT: -106}*/:
                        ImagePicker.getInstance().pickPhotoCamera(((Integer) args[0]).intValue(), ((Integer) args[1]).intValue(), (String) args[2], (String) args[3], (String) args[4], this);
                        break;
                    case CommandIDs.doCompositeImages /*{ENCODED_INT: -104}*/:
                        try {
                            ImageCompositor ic = new ImageCompositor(((Integer) args[0]).intValue(), ((Integer) args[1]).intValue(), (String) args[2], (String) args[4], this);
                            JSONArray images = new JSONArray((String) args[3]);
                            for (int infoI = 0; infoI < images.length(); infoI++) {
                                ic.addImage(images.getJSONObject(infoI));
                            }
                            ic.finish();
                            break;
                        } catch (Error e) {
                            e.printStackTrace();
                            break;
                        }
                    case CommandIDs.setStatusBarHidden /*{ENCODED_INT: -92}*/:
                        this.mActivity.getWindow().setFlags(((Boolean) args[0]).booleanValue() ? 1024 : 2048, 3072);
                        break;
                    case CommandIDs.executeAnimation /*{ENCODED_INT: -15}*/:
                        if (this.mAnimationBlock != null) {
                            JSONObject options = null;
                            try {
                                options = new JSONObject((String) args[0]);
                            } catch (Exception e2) {
                                options = new JSONObject();
                            } finally {
                                this.mAnimationBlock.execute(options);
                            }
                        }
                        this.mAnimationBlock = null;
                        break;
                    case CommandIDs.startAnimation /*{ENCODED_INT: -14}*/:
                        this.mAnimationBlock = new AnimationBlock(this, ((Integer) args[0]).intValue(), (String) args[1]);
                        break;
                    case -2:
                        createAdapter(((Integer) args[0]).intValue(), (String) args[1]);
                        break;
                    case -1:
                        this.mActivity.getWindow().setFlags(1024, 3072);
                        if (this.baseJsWindowLayerAdapter != null) {
                            this.baseJsWindowLayerAdapter.removeFromList();
                        }
                        this.baseJsWindowLayerAdapter = new JSWindowLayerAdapter(this, 0);
                        this.baseJsWindowLayerAdapter.setLevel(0);
                        for (JSAdapter a : this.mIdsToAdapters.values()) {
                            a.cleanup();
                        }
                        this.mIdsToAdapters.clear();
                        Iterator i$ = this.mRunningOperations.iterator();
                        while (i$.hasNext()) {
                            i$.next().cancel();
                        }
                        this.mRunningOperations.clear();
                        this.mActivity.reset();
                        this.mProcHasGL = false;
                        break;
                    case 12:
                        View newChild = ((JSViewAdapter) getAdapter((Integer) args[0])).getView();
                        addChildToRoot(newChild, ((Integer) args[1]).intValue());
                        if (this.mAnimationBlock != null) {
                            this.mAnimationBlock.addAppearAnimation(newChild);
                            break;
                        }
                        break;
                    default:
                        throw new Exception("Cannot dispatch a static method to an instance");
                }
            }
            if (sReusableCount < 50) {
                sReusableCount++;
                sReuseQueue.add(cmd);
            }
        } catch (Exception e3) {
            e3.printStackTrace();
            if (sReusableCount < 50) {
                sReusableCount++;
                sReuseQueue.add(cmd);
            }
        } catch (Throwable th) {
            if (sReusableCount < 50) {
                sReusableCount++;
                sReuseQueue.add(cmd);
            }
            throw th;
        }
    }

    public boolean handleMessage(Message message) {
        while (true) {
            UICommand cmd = sQueue.poll();
            if (cmd == null) {
                return true;
            }
            cmd.commandObject.handleUICommand(cmd);
        }
    }

    protected Commands(int procId, JSActivity activity) {
        if (sHandler == null) {
            sHandler = new Handler(Looper.getMainLooper(), this);
        }
        this.mActivity = activity;
        this.mProcId = procId;
    }
}
