package com.ngmoco.gamejs.ui;

import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.widgets.Touchable;

public class TouchHandler implements View.OnTouchListener, View.OnLongClickListener {
    AbstractJSViewAdapter mAdapter;
    private int mLastSwipeDirection = -1;
    private boolean mListenForSwipe;
    private boolean mListenForTouch;
    private boolean mListenForTouchCancel;
    private boolean mListenForTouchDown;
    private boolean mShouldConsume;
    protected float mStartX;
    protected float mStartY;
    private int mTouchSlop;
    protected boolean mTracking = false;

    private void sendSwipe(int direction) {
        if (direction != this.mLastSwipeDirection) {
            this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.SWIPE, "direction", Integer.valueOf(direction));
            this.mLastSwipeDirection = direction;
        }
    }

    public boolean onTouch(View view, MotionEvent event) {
        float f;
        if (this.mListenForTouch || this.mListenForSwipe || this.mListenForTouchDown || this.mListenForTouchCancel) {
            switch (event.getAction()) {
                case 0:
                    this.mLastSwipeDirection = -1;
                    this.mStartX = event.getX();
                    this.mStartY = event.getY();
                    if (this.mListenForTouchDown) {
                        this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK_DOWN, "touchX", Float.valueOf(event.getX()), "touchY", Float.valueOf(event.getY()));
                    }
                    if (view instanceof Touchable) {
                        ((Touchable) view).track(true);
                    }
                    this.mTracking = true;
                    break;
                case 1:
                    if (this.mTracking && (this.mListenForTouch || this.mListenForTouchCancel)) {
                        int x = (int) event.getX();
                        int y = (int) event.getY();
                        boolean outOfBounds = x < (-this.mTouchSlop) || y < (-this.mTouchSlop) || x > view.getWidth() + this.mTouchSlop || y > view.getHeight() + this.mTouchSlop;
                        if (view instanceof Touchable) {
                            ((Touchable) view).track(false);
                        }
                        if (outOfBounds) {
                            this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK_CANCEL, "touchX", Integer.valueOf(x), "touchY", Integer.valueOf(y));
                        } else {
                            this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK, "touchX", Integer.valueOf(x), "touchY", Integer.valueOf(y));
                        }
                    }
                    this.mTracking = false;
                    break;
                case 2:
                    if (this.mTracking && this.mListenForSwipe) {
                        float dX = event.getX() - this.mStartX;
                        float dY = event.getY() - this.mStartY;
                        if (dX < 0.0f) {
                            f = -dX;
                        } else {
                            f = dX;
                        }
                        float cardinality = f - (dY < 0.0f ? -dY : dY);
                        if (cardinality * cardinality > 400.0f) {
                            if (cardinality > 0.0f) {
                                if (dX < -20.0f) {
                                    sendSwipe(1);
                                } else if (dX > 20.0f) {
                                    sendSwipe(2);
                                }
                            } else if (dY < -20.0f) {
                                sendSwipe(3);
                            } else if (dY > 20.0f) {
                                sendSwipe(4);
                            }
                        }
                    }
                    if (this.mTracking && (view instanceof Touchable)) {
                        int x2 = (int) event.getX();
                        int y2 = (int) event.getY();
                        ((Touchable) view).track(!(x2 < (-this.mTouchSlop) || y2 < (-this.mTouchSlop) || x2 > view.getWidth() + this.mTouchSlop || y2 > view.getHeight() + this.mTouchSlop));
                        break;
                    }
                    break;
                case 3:
                case 4:
                    if (this.mTracking && this.mListenForTouchCancel) {
                        this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK_CANCEL, new Object[0]);
                    }
                    if (view instanceof Touchable) {
                        ((Touchable) view).track(false);
                    }
                    this.mTracking = false;
                    break;
            }
        }
        if (!this.mShouldConsume || view.getVisibility() != 0) {
            return false;
        }
        return true;
    }

    public void listenForTouch(boolean enabled) {
        this.mListenForTouch = enabled;
    }

    public void listenForSwipe(boolean enabled) {
        this.mListenForSwipe = enabled;
    }

    public void listenForTouchDown(boolean enabled) {
        this.mListenForTouchDown = enabled;
    }

    public void listenForTouchCancel(boolean enabled) {
        this.mListenForTouchCancel = enabled;
    }

    public void purge(View view) {
        if (this.mTracking) {
            if (this.mListenForTouchCancel) {
                this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.CLICK_CANCEL, new Object[0]);
            }
            if (view instanceof Touchable) {
                ((Touchable) view).track(false);
            }
        }
        this.mTracking = false;
    }

    /* JADX WARN: Type inference failed for: r0v4, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    public TouchHandler(AbstractJSViewAdapter a) {
        this.mAdapter = a;
        this.mTouchSlop = ViewConfiguration.get(this.mAdapter.getContext().getActivity()).getScaledTouchSlop();
        this.mShouldConsume = true;
    }

    public boolean onLongClick(View view) {
        this.mAdapter.triggerCustomEventResponse(AbstractJSAdapter.Events.LONGPRESS, new Object[0]);
        this.mTracking = false;
        if (view instanceof Touchable) {
            ((Touchable) view).track(false);
        }
        if (view.getVisibility() == 0) {
            return true;
        }
        return false;
    }

    public void setShouldConsume(boolean shouldConsume) {
        this.mShouldConsume = shouldConsume;
    }
}
