package com.ngmoco.gamejs.ui;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.WebSettings;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIWebView;
import com.ngmoco.gamejs.ui.widgets.UIWebViewClient;
import org.json.JSONObject;

public class JSWebViewAdapter extends AbstractJSViewAdapter {
    protected UIWebView mWebView;
    protected UIWebViewClient mWebViewClient;

    public static class Events {
        public static final String AUTHCHALLENGE = "authchallenge";
        public static final String ERROR = "error";
        public static final String EXTERNALLINK = "externalLink";
        public static final String PAGEEVENT = "pageevent";
        public static final String PAGELOAD = "pageload";
        public static final String SHOULDLOAD = "shouldload";
        public static final String STARTLOAD = "startload";
    }

    private JSWebViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSWebViewAdapter(jsContext, objId).createView();
    }

    private String composeURL(String base, String path) {
        if (base.endsWith("/")) {
            base = base.substring(0, base.length() - 2);
        }
        if (path.startsWith("/")) {
            return base + path;
        }
        return base + "/" + path;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        UIWebView uIWebView = new UIWebView(this.mJSContext.getActivity());
        this.mWebView = uIWebView;
        this.mView = uIWebView;
        this.mWebView.setJSContext(this.mJSContext);
        this.mWebView.requestFocus(Commands.CommandIDs.playVideo);
        this.mWebViewClient = new UIWebViewClient(this);
        this.mWebView.setWebViewClient(this.mWebViewClient);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        if (this.mWebView == null) {
            throw new NullPointerException("View is not initialized for an update");
        }
        switch (commandId) {
            case Commands.CommandIDs.setBackgroundColor:
                this.mWebView.setBackgroundColor(Color.parseColor("#" + ((String) args[0])));
                return this;
            case Commands.CommandIDs.setSourceDocument:
                this.mWebViewClient.setLoadableURL((String) args[0]);
                this.mWebView.loadDocument((String) args[0]);
                return this;
            case Commands.CommandIDs.loadURL:
                String url = (String) args[0];
                Uri target = Uri.parse(url);
                String scheme = target.getScheme();
                if (scheme == null) {
                    url = composeURL("file://" + GameJSActivity.getSandboxRoot(), url);
                } else if (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https") && !scheme.equalsIgnoreCase("file") && !scheme.equalsIgnoreCase("ftp")) {
                    getContext().getActivity().startActivity(new Intent("android.intent.action.VIEW", target));
                    return this;
                }
                this.mWebViewClient.setLoadableURL(url);
                this.mWebView.loadUrl(url);
                this.mWebView.requestFocus();
                return this;
            case Commands.CommandIDs.stopLoading:
                this.mWebViewClient.setEnterStopLoading(true);
                this.mWebView.stopLoading();
                return this;
            case Commands.CommandIDs.reload:
                this.mWebView.reload();
                return this;
            case Commands.CommandIDs.invoke:
                this.mWebView.loadUrl("javascript:" + ((String) args[0]));
                return this;
            case Commands.CommandIDs.goBack:
                this.mWebView.goBack();
                return this;
            case Commands.CommandIDs.goForward:
                this.mWebView.goForward();
                return this;
            case Commands.CommandIDs.setBasicAuthCredentials:
                JSONObject authArgs = new JSONObject((String) args[0]);
                this.mWebView.setHttpAuthUsernamePassword(authArgs.getString("host"), authArgs.getString("realm"), authArgs.getString("username"), authArgs.getString("password"));
                return this;
            case Commands.CommandIDs.postURL:
                this.mWebViewClient.setLoadableURL((String) args[0]);
                this.mWebView.postUrl((String) args[0], ((String) args[1]).getBytes());
                return this;
            case Commands.CommandIDs.setScrollable:
                this.mWebView.setScrollable(((Boolean) args[0]).booleanValue());
                return this;
            case Commands.CommandIDs.setViewportEnabled:
                Boolean enabled = (Boolean) args[0];
                WebSettings settings = this.mWebView.getSettings();
                settings.setUseWideViewPort(enabled.booleanValue());
                settings.setLoadWithOverviewMode(enabled.booleanValue());
                return this;
            case Commands.CommandIDs.setAutodetection:
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    public void onPause() {
    }

    public void onDestroy() {
        try {
            this.mWebView.stopLoading();
            this.mWebView.setWebChromeClient(null);
            this.mWebView.setWebViewClient(null);
            this.mWebView.destroy();
            this.mWebView = null;
        } catch (Exception e) {
            Log.e("JSWebViewAdapter", "failed in setting progress: " + e.getMessage());
        }
    }
}
