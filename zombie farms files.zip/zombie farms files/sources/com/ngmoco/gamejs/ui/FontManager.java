package com.ngmoco.gamejs.ui;

import android.graphics.Typeface;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgJNI;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

public class FontManager {
    private static Pattern fNamePattern = Pattern.compile("(.+)\\.(otf|ttf)", 66);
    private static HashMap<String, File> sSystemFonts = new HashMap<>();
    private HashMap<String, File> mAvailableFonts = new HashMap<>(sSystemFonts);
    private String mRoot;

    static {
        try {
            scanSandbox(new File("/system/fonts/"), sSystemFonts);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void scanSandbox(File path, HashMap<String, File> map) throws IOException {
        Matcher m;
        if (path != null) {
            if (path.isFile() && (m = fNamePattern.matcher(path.getName())) != null && m.matches()) {
                map.put(m.group(1), path.getCanonicalFile());
            }
            File[] children = path.listFiles();
            if (children != null) {
                for (File childItem : children) {
                    scanSandbox(childItem, map);
                }
            }
        }
    }

    public static Set<String> availableSystemFonts() {
        return sSystemFonts.keySet();
    }

    public Set<String> availableFonts() {
        return this.mAvailableFonts.keySet();
    }

    public Typeface getFont(String familyName) {
        File f = this.mAvailableFonts.get(familyName);
        if (f == null) {
            f = new File(this.mRoot + "/" + familyName);
        }
        if (f != null) {
            try {
                if (f.exists()) {
                    return Typeface.createFromFile(f);
                }
            } catch (Exception e) {
                Log.e("FontManager", "Got exception loading font with family \"" + familyName + "\": " + e.getMessage());
                return null;
            }
        }
        return Typeface.create(familyName, 0);
    }

    public void scanManifest(String root) {
        long startTime = System.currentTimeMillis();
        try {
            Iterator<String> keys = new JSONObject(NgJNI.readStringFromFile(root + "/webgame.ngmanifest")).keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (key.endsWith(".ttf") || key.endsWith(".otf")) {
                    File f = new File(root + "/" + key);
                    String name = f.getName();
                    String name2 = name.substring(0, name.length() - 4);
                    Log.d("FontManager", "Found font " + name2 + " at " + f.getPath());
                    this.mAvailableFonts.put(name2, f);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d("FontManager", "Scanned manifest in " + (System.currentTimeMillis() - startTime) + " ms");
    }

    public FontManager(String root) {
        this.mRoot = root;
        scanManifest(root);
    }
}
