package com.ngmoco.gamejs.ui;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import com.ngmoco.gamejs.ui.widgets.UILayout;
import com.ngmoco.gamejs.ui.widgets.UIMatrixAnimation;
import com.ngmoco.gamejs.ui.widgets.UIWidget;
import com.ngmoco.gamejs.ui.widgets.UIWidgetCommon;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

public class AnimationBlock implements Animation.AnimationListener {
    ConcurrentHashMap<View, Animation> mAnimations = new ConcurrentHashMap<>();
    String mCallback;
    int mDuration;
    long mExecuteTime;
    Commands mHost;
    HashSet<View> mToRemove = new HashSet<>();

    public void addAnimation(View v, Animation a) {
        Animation existing = this.mAnimations.get(v);
        if (existing == null) {
            this.mAnimations.put(v, a);
        } else if (existing instanceof AnimationSet) {
            ((AnimationSet) existing).addAnimation(a);
        } else {
            AnimationSet theSet = new AnimationSet(true);
            theSet.addAnimation(existing);
            theSet.addAnimation(a);
            this.mAnimations.put(v, theSet);
        }
    }

    private void clampRect(RectF toClamp, int parentW, int parentH) {
        float offsetX = toClamp.left;
        float offsetY = toClamp.top;
        if (offsetX >= ((float) parentW)) {
            offsetX = (float) (parentW - 1);
        } else if (toClamp.right < 1.0f) {
            offsetX = 1.0f - toClamp.width();
        }
        if (offsetY >= ((float) parentH)) {
            offsetY = (float) (parentH - 1);
        } else if (toClamp.bottom < 1.0f) {
            offsetY = 1.0f - toClamp.height();
        }
        if (offsetX != toClamp.left || offsetY != toClamp.right) {
            toClamp.offsetTo(offsetX, offsetY);
        }
    }

    public void addFrameAnimation(View v, Float[] newFrame) {
        ViewGroup vp = (ViewGroup) v.getParent();
        if (vp != null) {
            try {
                vp.getWidth();
                vp.getHeight();
                RectF startRect = new RectF((float) v.getLeft(), (float) v.getTop(), (float) v.getRight(), (float) v.getBottom());
                RectF endRect = new RectF(newFrame[0].floatValue(), newFrame[1].floatValue(), newFrame[0].floatValue() + newFrame[2].floatValue(), newFrame[1].floatValue() + newFrame[3].floatValue());
                Matrix startMatrix = new Matrix();
                startMatrix.postScale(((float) v.getWidth()) / newFrame[2].floatValue(), ((float) v.getHeight()) / newFrame[3].floatValue());
                startMatrix.postTranslate(((float) v.getLeft()) - newFrame[0].floatValue(), ((float) v.getTop()) - newFrame[1].floatValue());
                UIMatrixAnimation a = new UIMatrixAnimation(1.0f, 1.0f, startMatrix, new Matrix());
                a.setFillAfter(true);
                addAnimation(v, a);
                endRect.union(startRect);
                vp.invalidate((int) endRect.left, (int) endRect.top, (int) endRect.right, (int) endRect.bottom);
            } catch (Exception e) {
                Log.d("Animation", "Ignoring frame animation that caused " + e.getClass().getName());
            }
        }
        UIWidgetCommon.setFrame((UIWidget) v, newFrame);
    }

    public void addAlphaAnimation(View v, float fromAlpha, float toAlpha) {
        AlphaAnimation a = new AlphaAnimation(fromAlpha, toAlpha);
        a.setFillBefore(true);
        a.setFillAfter(true);
        v.invalidate();
        addAnimation(v, a);
    }

    public void addAppearAnimation(View v) {
        addAlphaAnimation(v, 0.0f, 1.0f);
    }

    public void addDisappearAnimation(View v) {
        this.mToRemove.add(v);
        addAlphaAnimation(v, 1.0f, 0.01f);
    }

    public void execute(JSONObject options) {
        Interpolator i;
        ((UILayout.Root) GameJSActivity.getActivity().getRootLayout()).addFPSCounter(Integer.valueOf(hashCode()));
        this.mExecuteTime = System.currentTimeMillis();
        if (this.mAnimations.isEmpty()) {
            onAnimationEnd(null);
            return;
        }
        if (options.optString("animationCurve", "EaseInOut").equalsIgnoreCase("linear")) {
            i = new LinearInterpolator();
        } else {
            i = new AccelerateDecelerateInterpolator();
        }
        for (Map.Entry<View, Animation> e : this.mAnimations.entrySet()) {
            Animation a = e.getValue();
            a.setDuration((long) this.mDuration);
            a.setInterpolator(i);
            a.setZAdjustment(1);
            a.setAnimationListener(this);
            e.getKey().startAnimation(a);
        }
    }

    public synchronized void onAnimationEnd(Animation animation) {
        for (View v : this.mAnimations.keySet()) {
            if (v.getAnimation() == animation) {
                v.setAnimation(null);
                v.invalidate();
            }
        }
        if (this.mHost != null) {
            UILayout.Root rootLayout = (UILayout.Root) GameJSActivity.getActivity().getRootLayout();
            ArrayList<Integer> frames = rootLayout.getFPSCounter(Integer.valueOf(hashCode()));
            double elapsed = (double) (System.currentTimeMillis() - this.mExecuteTime);
            double drawTime = 0.0d;
            Iterator i$ = frames.iterator();
            while (i$.hasNext()) {
                drawTime += (double) i$.next().intValue();
            }
            Log.d("AnimationBlock", String.format("Animated %d frames in %.0fms. FPS: %.3f LOAD: %.3f%%", Integer.valueOf(frames.size()), Double.valueOf(elapsed), Double.valueOf((1000.0d * ((double) frames.size())) / elapsed), Double.valueOf((100.0d * drawTime) / elapsed)));
            rootLayout.removeFPSCounter(Integer.valueOf(hashCode()));
            final Commands host = this.mHost;
            this.mHost.getActivity().getHandler().post(new Runnable() {
                /* class com.ngmoco.gamejs.ui.AnimationBlock.AnonymousClass1 */

                public void run() {
                    try {
                        ViewGroup rootLayout = host.getActivity().getRootLayout();
                        Iterator i$ = AnimationBlock.this.mToRemove.iterator();
                        while (i$.hasNext()) {
                            View v = i$.next();
                            ViewParent pV = v.getParent();
                            if (pV == rootLayout) {
                                JSWindowLayerAdapter.removeChild(v);
                            } else if (pV != null && (pV instanceof ViewGroup)) {
                                ((ViewGroup) pV).removeView(v);
                            }
                        }
                        AnimationBlock.this.mToRemove.clear();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            if (this.mHost != null) {
                try {
                    JSONObject j = new JSONObject();
                    j.put(NgSystemBindingService.EXTRA_NAME, "callback");
                    j.put("callback_id", this.mCallback);
                    j.put("canceled", animation == null ? true : !animation.hasEnded() || animation.getDuration() == 0);
                    Log.d("AnimationBlock", j.toString());
                    this.mHost.sendEvent(j.toString());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                this.mHost = null;
            }
        }
    }

    public void onAnimationRepeat(Animation animation) {
    }

    public void onAnimationStart(Animation animation) {
    }

    public AnimationBlock(Commands host, int durationMs, String callbackId) {
        this.mHost = host;
        this.mDuration = durationMs;
        this.mCallback = callbackId;
    }
}
