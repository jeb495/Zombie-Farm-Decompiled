package com.ngmoco.gamejs.ui.widgets;

public interface StatefulWidget extends UIWidget {
    int getState();

    void setState(int i);

    void stateChanged();
}
