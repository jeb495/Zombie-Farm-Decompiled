package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.widget.AbsoluteLayout;
import android.widget.TextView;

public class UIAnnotationCalloutView extends AbsoluteLayout {
    private View _leftAccessoryView;
    private View _rightAccessoryView;
    private TextView _subtitleView;
    private TextView _titleView = new TextView(getContext());

    public UIAnnotationCalloutView(Context context) {
        super(context);
        setWillNotDraw(false);
        setBackgroundResource(17301654);
        new View(getContext()).layout(0, 0, 10, 10);
        this._titleView.setTypeface(null, 1);
        this._titleView.setTextColor(-1);
        this._titleView.setTextSize(15.0f);
        addView(this._titleView);
        this._subtitleView = new TextView(getContext());
        this._subtitleView.setTextColor(-1);
        this._subtitleView.setTextSize(12.0f);
        addView(this._subtitleView);
        layout();
    }

    /* access modifiers changed from: protected */
    public void layout() {
        int x = 0;
        int textboxwidth = Math.min(250, (int) Math.max(this._titleView.getPaint().measureText(this._titleView.getText().toString()), this._subtitleView.getPaint().measureText(this._subtitleView.getText().toString())));
        if (this._leftAccessoryView != null) {
            this._leftAccessoryView.setLayoutParams(new AbsoluteLayout.LayoutParams(this._leftAccessoryView.getWidth(), this._leftAccessoryView.getHeight(), 0, 10));
            this._leftAccessoryView.layout(0, 10, this._leftAccessoryView.getWidth() + 0, this._leftAccessoryView.getHeight() + 10);
            x = 0 + this._leftAccessoryView.getWidth() + 15;
        }
        this._titleView.setWidth(textboxwidth);
        this._titleView.setLayoutParams(new AbsoluteLayout.LayoutParams(textboxwidth, (int) (this._titleView.getTextSize() * 1.4f), x, 0));
        this._titleView.layout(x, 0, this._titleView.getWidth() + x, this._titleView.getHeight() + 0);
        int y1 = 0 + ((int) (this._titleView.getTextSize() * 1.2f));
        this._subtitleView.setWidth(textboxwidth);
        this._subtitleView.setLayoutParams(new AbsoluteLayout.LayoutParams(textboxwidth, (int) (this._subtitleView.getTextSize() * 1.3f), x, y1));
        this._subtitleView.layout(x, y1, this._subtitleView.getWidth() + x, this._subtitleView.getHeight() + y1);
        int x2 = x + textboxwidth + 15;
        if (this._rightAccessoryView != null) {
            this._rightAccessoryView.setLayoutParams(new AbsoluteLayout.LayoutParams(this._rightAccessoryView.getWidth(), this._rightAccessoryView.getHeight(), x2, 10));
            this._rightAccessoryView.layout(x2, 10, this._rightAccessoryView.getWidth() + x2, this._rightAccessoryView.getHeight() + 10);
        }
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    public void setSubtitle(String _calloutSubtitle) {
        this._subtitleView.setText(_calloutSubtitle);
        layout();
    }

    public String getSubtitle() {
        return this._subtitleView.getText().toString();
    }

    public void setLeftAccessoryView(View _leftCalloutAccessoryView) {
        this._leftAccessoryView = _leftCalloutAccessoryView;
        addView(this._leftAccessoryView);
        layout();
    }

    public View getLeftAccessoryView() {
        return this._leftAccessoryView;
    }

    public void setRightAccessoryView(View _rightCalloutAccessoryView) {
        this._rightAccessoryView = _rightCalloutAccessoryView;
        addView(this._rightAccessoryView);
        layout();
    }

    public View getRightAccessoryView() {
        return this._rightAccessoryView;
    }

    public void setTitle(String _calloutTitle) {
        this._titleView.setText(_calloutTitle);
        layout();
    }

    public String getTitle() {
        return this._titleView.getText().toString();
    }
}
