package com.ngmoco.gamejs.ui.widgets;

public interface OrientationRestrictable {
    void orientationChanged(boolean z);

    void setVisibleInOrientations(int i);
}
