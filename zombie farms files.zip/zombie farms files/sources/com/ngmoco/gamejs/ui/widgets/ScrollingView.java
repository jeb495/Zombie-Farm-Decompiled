package com.ngmoco.gamejs.ui.widgets;

import android.view.View;

public interface ScrollingView extends UIWidget {
    void addContainedView(View view);

    void addContainedView(View view, int i);

    int getContentHeight();

    int getContentWidth();

    int getScrollX();

    int getScrollY();

    void setContentSize(int i, int i2);

    void setOnScrollListener(UIScrollListener uIScrollListener);
}
