package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.ui.Utils;
import com.ngmoco.gamejs.ui.widgets.Style;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.util.HashMap;

public class UIEditText extends EditText implements StatefulWidget, Styleable {
    private static HashMap<Integer, Integer> sEnterKeyMaps = new HashMap<>();
    private static HashMap<Integer, Integer> sEnterKeyTexts = new HashMap<>();
    private static HashMap<Integer, Integer> sModeMaps = new HashMap<>();
    protected int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    protected UIShadow mPlaceholderShadow;
    protected StateMap<UIShadow> mShadows = new StateMap<>();
    protected int mState = 0;
    protected StateMap<Integer> mTextColors = new StateMap<>();
    protected boolean mTextFontSet;
    protected boolean mTextSizeSet;
    protected Style.TextStyle mTextStyle;
    protected int mTransientState = 0;
    protected float mWidgetAlpha = 1.0f;
    private int mX;
    private int mY;

    static {
        sModeMaps.put(0, 524465);
        sModeMaps.put(1, 1);
        sModeMaps.put(4, 8194);
        sModeMaps.put(2, 524417);
        sModeMaps.put(5, 33);
        sModeMaps.put(6, 17);
        sModeMaps.put(7, 20);
        sModeMaps.put(8, 1);
        sEnterKeyMaps.put(0, 0);
        sEnterKeyMaps.put(1, 6);
        sEnterKeyMaps.put(2, 5);
        sEnterKeyMaps.put(4, 2);
        sEnterKeyMaps.put(6, 4);
        sEnterKeyMaps.put(3, 4);
        sEnterKeyMaps.put(5, 3);
        sEnterKeyTexts.put(0, Integer.valueOf((int) R.string.edit_text_return));
        sEnterKeyTexts.put(1, Integer.valueOf((int) R.string.edit_text_done));
        sEnterKeyTexts.put(2, Integer.valueOf((int) R.string.edit_text_next));
        sEnterKeyTexts.put(4, Integer.valueOf((int) R.string.edit_text_go));
        sEnterKeyTexts.put(6, Integer.valueOf((int) R.string.edit_text_send));
        sEnterKeyTexts.put(3, Integer.valueOf((int) R.string.edit_text_submit));
        sEnterKeyTexts.put(5, Integer.valueOf((int) R.string.edit_text_search));
    }

    public void setCoreInputType(int newModeEnum) {
        setInputType(sModeMaps.get(Integer.valueOf(newModeEnum)).intValue());
    }

    public void setEnterKeyType(int newTypeEnum) {
        setImeActionLabel(getContext().getString(sEnterKeyTexts.get(Integer.valueOf(newTypeEnum)).intValue()), newTypeEnum);
        setImeOptions(sEnterKeyMaps.get(Integer.valueOf(newTypeEnum)).intValue());
    }

    public int textColorForState(int stateFlags) {
        Integer i = this.mTextColors.getValueForState(Integer.valueOf(stateFlags), this.mTextStyle != null ? this.mTextStyle.mColors : null);
        if (i != null) {
            return i.intValue();
        }
        return -16777216;
    }

    public void setTextColorForState(int color, int stateFlags) {
        this.mTextColors.put(Integer.valueOf(stateFlags), Integer.valueOf(color));
        stateChanged();
    }

    public UIShadow textShadowForState(int stateFlags) {
        return this.mShadows.getValueForState(Integer.valueOf(stateFlags));
    }

    public void setShadowForState(UIShadow shadow, int stateFlags) {
        this.mShadows.put(Integer.valueOf(stateFlags), shadow);
        stateChanged();
    }

    public void setPlaceholderShadow(UIShadow shadow) {
        this.mPlaceholderShadow = shadow;
        stateChanged();
    }

    public UIEditText(Context context) {
        super(context);
        setBackgroundDrawable(new UIDrawable(this));
        setInputType(1);
    }

    public boolean isOpaque() {
        return false;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public int getState() {
        return this.mState | this.mTransientState;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void setState(int newState) {
        int i = this.mState;
        this.mState = newState;
        if (i != newState) {
            stateChanged();
        }
    }

    public void hideKeyboard() {
        InputMethodManager mgr = (InputMethodManager) getContext().getSystemService("input_method");
        if (!mgr.isActive() || mgr.isActive(this)) {
            mgr.hideSoftInputFromWindow(getWindowToken(), 0);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        clearFocus();
    }

    public void setEnabled(boolean enabled) {
        if (enabled != isEnabled()) {
            super.setEnabled(enabled);
            if (!enabled) {
                hideKeyboard();
            }
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        this.mTransientState = Utils.controlStateFromStateSet(getDrawableState());
        stateChanged();
    }

    public void setTextSize(float textSize) {
        if (textSize != 0.0f || this.mTextStyle == null) {
            super.setTextSize(textSize);
            this.mTextSizeSet = true;
            return;
        }
        super.setTextSize(this.mTextStyle.mFontSize);
        this.mTextSizeSet = false;
    }

    public void setTypeface(Typeface tf) {
        if (tf != null || this.mTextStyle == null || this.mTextStyle.mTypefaces.getValueForState(0) == null) {
            super.setTypeface(tf);
            this.mTextFontSet = true;
            return;
        }
        super.setTypeface(this.mTextStyle.mTypefaces.getValueForState(0));
        this.mTextFontSet = false;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        int applyState = this.mState | this.mTransientState;
        ((UIDrawable) getBackground()).setControlState(applyState);
        UIShadow textShadow = this.mShadows.getValueForState(Integer.valueOf(applyState), this.mTextStyle != null ? this.mTextStyle.mShadows : null);
        if (textShadow != null) {
            textShadow.applyToPaint(getPaint());
        } else if (this.mPlaceholderShadow == null || getText().length() != 0) {
            getPaint().setShadowLayer(0.0f, 0.0f, 0.0f, 0);
        } else {
            this.mPlaceholderShadow.applyToPaint(getPaint());
        }
        setTextColor(textColorForState(applyState));
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        this.mX = x;
        this.mY = y;
        layout(x, y, getWidth() + x, getHeight() + y);
        invalidate();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha != 255) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }

    public void showKeyboard() {
        InputMethodManager mgr = (InputMethodManager) getContext().getSystemService("input_method");
        if (isFocused() && getVisibility() == 0) {
            if (!mgr.isActive() || mgr.isActive(this)) {
                mgr.showSoftInput(this, 1);
            }
        }
    }

    public void clearFocus() {
        super.clearFocus();
        hideKeyboard();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Styleable
    public void setStyle(Style style) {
        ((UIDrawable) getBackground()).setStyle(style.ensureGradientStyle());
        this.mTextStyle = style.ensureTextStyle();
        if (!this.mTextFontSet && this.mTextStyle.mTypefaces.getValueForState(0) != null) {
            super.setTypeface(this.mTextStyle.mTypefaces.getValueForState(0));
        }
        if (!this.mTextSizeSet && this.mTextStyle.mFontSize != 0.0f) {
            super.setTextSize(this.mTextStyle.mFontSize);
        }
        stateChanged();
    }
}
