package com.ngmoco.gamejs.ui.widgets;

public interface UIImageLoadListener {
    void onImageLoadFailed(String str, int i, String str2);

    void onImageLoaded(String str, int i, int i2);
}
