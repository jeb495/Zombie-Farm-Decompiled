package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.webkit.WebView;
import com.ngmoco.gamejs.Log;

public class UICheckoutView extends WebView {
    private static final String TAG = UICheckoutView.class.getSimpleName();
    private String mPostData = null;

    public void setPostData(String data) {
        this.mPostData = data;
    }

    public void loadPostUrl(String url) {
        if (this.mPostData != null) {
            postUrl(url, this.mPostData.getBytes());
        } else {
            Log.e(TAG, "Request to post with null data");
        }
    }

    public UICheckoutView(Context context) {
        super(context);
        setVerticalScrollbarOverlay(true);
        setHorizontalScrollbarOverlay(true);
        setVerticalScrollBarEnabled(true);
        setHorizontalScrollBarEnabled(false);
    }
}
