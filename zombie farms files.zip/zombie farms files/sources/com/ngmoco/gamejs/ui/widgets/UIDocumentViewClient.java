package com.ngmoco.gamejs.ui.widgets;

import android.webkit.WebViewClient;

public class UIDocumentViewClient extends WebViewClient {
}
