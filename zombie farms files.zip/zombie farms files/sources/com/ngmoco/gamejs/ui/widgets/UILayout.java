package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.ui.JSWindowLayerAdapter;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class UILayout extends ViewGroup implements UIWidget, Touchable, ViewGroup.OnHierarchyChangeListener, StatefulWidget, OrientationRestrictable {
    protected static boolean sLandscape = false;
    private int mAlpha;
    private HashSet<View> mLayoutChildren;
    protected int mState;
    private boolean mTouchable;
    protected int mUnderlyingVisibility;
    protected int mVisibleOrientations;
    protected float mWidgetAlpha;
    protected int mX;
    protected int mY;

    public static class Root extends UILayout {
        private boolean isWindowRoot = false;
        HashMap<Integer, ArrayList<Integer>> mFPSCounters = null;
        private OnSizeListener mOnSizeListener;

        public interface OnSizeListener {
            void onSizeChanged(int i, int i2, int i3, int i4);
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public Root(Context context, AttributeSet attrs) {
            super(context, attrs);
            boolean z = false;
            this.isWindowRoot = getId() == R.id.rootLayout ? true : z;
        }

        @Override // android.view.ViewGroup
        public void addView(View child, int index) {
            if (this.isWindowRoot) {
                JSWindowLayerAdapter.updateRootIndex();
            }
            UILayout.super.addView(child, index);
        }

        public void removeView(View view) {
            UILayout.super.removeView(view);
            if (this.isWindowRoot) {
                JSWindowLayerAdapter.updateRootIndex();
            }
        }

        public void addFPSCounter(Integer key) {
            if (this.mFPSCounters == null) {
                this.mFPSCounters = new HashMap<>();
            } else if (this.mFPSCounters.containsKey(key)) {
                return;
            }
            synchronized (this.mFPSCounters) {
                this.mFPSCounters.put(key, new ArrayList<>());
            }
        }

        public ArrayList<Integer> getFPSCounter(Integer key) {
            if (this.mFPSCounters == null) {
                return null;
            }
            return this.mFPSCounters.get(key);
        }

        public void removeFPSCounter(Integer key) {
            if (this.mFPSCounters != null) {
                synchronized (this.mFPSCounters) {
                    this.mFPSCounters.remove(key);
                    if (this.mFPSCounters.isEmpty()) {
                        this.mFPSCounters = null;
                    }
                }
            }
        }

        @Override // com.ngmoco.gamejs.ui.widgets.UILayout
        public void draw(Canvas canvas) {
            if (this.mFPSCounters != null) {
                long startTime = System.currentTimeMillis();
                UILayout.super.draw(canvas);
                Integer elapsed = Integer.valueOf((int) (System.currentTimeMillis() - startTime));
                if (this.mFPSCounters != null) {
                    synchronized (this.mFPSCounters) {
                        if (!this.mFPSCounters.isEmpty()) {
                            for (ArrayList<Integer> list : this.mFPSCounters.values()) {
                                list.add(elapsed);
                            }
                        }
                    }
                    return;
                }
                return;
            }
            UILayout.super.draw(canvas);
        }

        @Override // com.ngmoco.gamejs.ui.widgets.UILayout
        public boolean isOpaque() {
            return true;
        }

        public void setOnSizeListener(OnSizeListener listener) {
            this.mOnSizeListener = listener;
            if (getWidth() > 0 && getHeight() > 0) {
                this.mOnSizeListener.onSizeChanged(getWidth(), getHeight(), -1, -1);
            }
        }

        /* access modifiers changed from: protected */
        public void onSizeChanged(int w, int h, int oldw, int oldh) {
            if (this.mOnSizeListener != null) {
                this.mOnSizeListener.onSizeChanged(w, h, oldw, oldh);
            }
            UILayout.super.onSizeChanged(w, h, oldw, oldh);
            if (this.isWindowRoot) {
                boolean z = sLandscape;
                boolean z2 = w > h;
                sLandscape = z2;
                if (z != z2) {
                    orientationChanged(sLandscape);
                }
            }
        }

        public static boolean getIsLandscape() {
            return sLandscape;
        }
    }

    public static class LayoutParams extends ViewGroup.LayoutParams {
        public int left = 0;
        public int top = 0;

        public LayoutParams(int l, int t, int w, int h) {
            super(w, h);
            this.left = l;
            this.top = t;
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public int getState() {
        return this.mState;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void setState(int newState) {
        int i = this.mState;
        this.mState = newState;
        if (i != newState) {
            stateChanged();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        ((UIDrawable) getBackground()).setControlState(this.mState);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    public UILayout(Context context) {
        super(context);
        this.mVisibleOrientations = Integer.MAX_VALUE;
        this.mTouchable = true;
        this.mWidgetAlpha = 1.0f;
        this.mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
        this.mLayoutChildren = new HashSet<>();
        this.mUnderlyingVisibility = getVisibility();
        setOnHierarchyChangeListener(this);
        setBackgroundDrawable(new UIDrawable(this));
    }

    public UILayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mVisibleOrientations = Integer.MAX_VALUE;
        this.mTouchable = true;
        this.mWidgetAlpha = 1.0f;
        this.mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
        this.mLayoutChildren = new HashSet<>();
        setOnHierarchyChangeListener(this);
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (this.mTouchable) {
            super.dispatchTouchEvent(ev);
        }
        return this.mTouchable;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void setTouchable(boolean canTouch) {
        this.mTouchable = canTouch;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void track(boolean inBounds) {
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public boolean isOpaque() {
        return this.mAlpha == 255 && super.isOpaque();
    }

    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha < 254) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }

    public void addLayoutChild(View view) {
        if (this.mLayoutChildren.add(view) && (getParent() instanceof UILayout)) {
            ((UILayout) getParent()).addLayoutChild(this);
        }
    }

    public void removeLayoutChild(View view) {
        this.mLayoutChildren.remove(view);
        if (this.mLayoutChildren.isEmpty() && (getParent() instanceof UILayout)) {
            ((UILayout) getParent()).removeLayoutChild(this);
        }
    }

    public void onChildViewAdded(View parent, View child) {
        if (!(child instanceof UIWidget) || ((child instanceof UILayout) && !((UILayout) child).mLayoutChildren.isEmpty())) {
            addLayoutChild(child);
        }
    }

    public void onChildViewRemoved(View parent, View child) {
        if (!(child instanceof UIWidget) || (child instanceof UILayout)) {
            removeLayoutChild(child);
        }
    }

    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        if (!this.mLayoutChildren.isEmpty()) {
            Iterator i$ = this.mLayoutChildren.iterator();
            while (i$.hasNext()) {
                View v = i$.next();
                if (v instanceof UIWidget) {
                    v.layout(v.getLeft(), v.getTop(), v.getRight(), v.getBottom());
                } else if (v.getLayoutParams() instanceof LayoutParams) {
                    LayoutParams lp = (LayoutParams) v.getLayoutParams();
                    v.layout(lp.left, lp.top, lp.left + lp.width, lp.top + lp.height);
                } else {
                    v.layout(0, 0, right - left, bottom - top);
                }
            }
        }
    }

    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (!this.mLayoutChildren.isEmpty()) {
            Iterator i$ = this.mLayoutChildren.iterator();
            while (i$.hasNext()) {
                measureChild(i$.next(), widthMeasureSpec, heightMeasureSpec);
            }
        }
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams p) {
        return true;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.OrientationRestrictable
    public void setVisibleInOrientations(int orientations) {
        int i = this.mVisibleOrientations;
        this.mVisibleOrientations = orientations;
        if (i != orientations) {
            orientationChanged(sLandscape);
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.OrientationRestrictable
    public void orientationChanged(boolean landscape) {
        if (checkOrientation(landscape)) {
            super.setVisibility(this.mUnderlyingVisibility);
        } else {
            super.setVisibility(8);
        }
        for (int idx = 0; idx < getChildCount(); idx++) {
            View child = getChildAt(idx);
            if (child instanceof OrientationRestrictable) {
                ((OrientationRestrictable) child).orientationChanged(landscape);
            }
        }
    }

    public void setVisibility(int visibility) {
        this.mUnderlyingVisibility = visibility;
        super.setVisibility(checkOrientation(sLandscape) ? this.mUnderlyingVisibility : 8);
    }

    /* access modifiers changed from: protected */
    public boolean checkOrientation(boolean landscape) {
        int mask = landscape ? 1 : 2;
        if ((this.mVisibleOrientations & mask) == mask) {
            return true;
        }
        return false;
    }

    public void onAttachedToWindow() {
        orientationChanged(Root.getIsLandscape());
    }

    @Override // android.view.ViewGroup
    public void addView(View child, int index, ViewGroup.LayoutParams params) {
        super.addView(child, index, params);
        if (Build.VERSION.SDK_INT < 8) {
            onChildViewAdded(this, child);
        }
    }
}
