package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.PointF;
import android.view.View;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.ngmoco.gamejs.NGItemizedOverlay;

public class UIAnnotation extends OverlayItem {
    private boolean _calloutEnabled = true;
    private GeoPoint _coordinate;
    private boolean _hasFocus;
    private UIAnnotationListener listener;
    public UIMapView mParentMapView;

    public UIAnnotation(Context context, GeoPoint point, String title, String snippet, UIAnnotationListener listener2) {
        super(point, title, snippet);
        setMarker(new UIAnnotationDrawable(context));
        this.listener = listener2;
    }

    public void setCoordinate(double latitude, double longitude) {
        this._coordinate = new GeoPoint((int) (latitude * 1000000.0d), (int) (longitude * 1000000.0d));
        if (this.mParentMapView != null) {
            this.mParentMapView.invalidate();
        }
    }

    private void onSelect() {
        this.listener.onSelect();
    }

    private void onDeselect() {
        this.listener.onDeselect();
    }

    public void gotFocus() {
        if (!this._hasFocus) {
            this._hasFocus = true;
            if (isCalloutEnabled()) {
                if (getCalloutView() != null) {
                    getCalloutView().layout();
                }
                View view = getView();
                if (!(this.mParentMapView == null || view == null)) {
                    this.mParentMapView.addView(getCalloutView(), new MapView.LayoutParams(-2, -2, getCoordinate(), 0, (-getView().getHeight()) / 2, 81));
                }
            }
            onSelect();
        }
    }

    public void lostFocus() {
        if (this._hasFocus) {
            this._hasFocus = false;
            if (isCalloutEnabled() && this.mParentMapView != null) {
                this.mParentMapView.removeView(getCalloutView());
            }
            onDeselect();
        }
    }

    public GeoPoint getPoint() {
        return this._coordinate;
    }

    public GeoPoint getCoordinate() {
        return this._coordinate;
    }

    public double getLatitude() {
        return ((double) this.mPoint.getLatitudeE6()) / 1000000.0d;
    }

    public double getLongitude() {
        return ((double) this.mPoint.getLongitudeE6()) / 1000000.0d;
    }

    public void setCenterOffset(float x, float y) {
        if (this.mMarker instanceof UIAnnotationDrawable) {
            ((UIAnnotationDrawable) this.mMarker).setCenterOffset(new PointF(x, y));
        }
    }

    public void setCalloutEnabled(boolean _calloutEnabled2) {
        NGItemizedOverlay overlay;
        if (!_calloutEnabled2 && this._calloutEnabled && this.mParentMapView != null && (overlay = this.mParentMapView.getMainOverlay()) != null && this._hasFocus) {
            overlay.setFocus((UIAnnotation) null);
        }
        this._calloutEnabled = _calloutEnabled2;
    }

    public boolean isCalloutEnabled() {
        return this._calloutEnabled;
    }

    public void setView(View view) {
        if (this.mMarker instanceof UIAnnotationDrawable) {
            ((UIAnnotationDrawable) this.mMarker).setView(view);
        }
    }

    public View getView() {
        if (this.mMarker instanceof UIAnnotationDrawable) {
            return ((UIAnnotationDrawable) this.mMarker).getView();
        }
        return null;
    }

    public UIAnnotationCalloutView getCalloutView() {
        if (this.mMarker instanceof UIAnnotationDrawable) {
            return ((UIAnnotationDrawable) this.mMarker).getCalloutView();
        }
        return null;
    }
}
