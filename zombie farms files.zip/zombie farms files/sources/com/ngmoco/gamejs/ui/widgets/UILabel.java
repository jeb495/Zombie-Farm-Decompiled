package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

public class UILabel extends ViewWithState implements UIWidget {
    UITextDrawable mTextDrawable = new UITextDrawable(this);

    public UITextDrawable getTextDrawable() {
        return this.mTextDrawable;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.Styleable
    public void setStyle(Style style) {
        this.mTextDrawable.setStyle(style.ensureTextStyle());
        super.setStyle(style);
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable who) {
        return who == this.mTextDrawable || super.verifyDrawable(who);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.mTextDrawable.setBounds(0, 0, w, h);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        this.mTextDrawable.draw(canvas);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        this.mTextDrawable.setControlState(this.mState | this.mTransientState);
        super.stateChanged();
    }

    public UILabel(Context context) {
        super(context);
        this.mTouchable = false;
    }
}
