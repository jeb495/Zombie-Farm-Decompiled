package com.ngmoco.gamejs.ui.widgets;

public interface Touchable {
    void setTouchable(boolean z);

    void track(boolean z);
}
