package com.ngmoco.gamejs.ui.widgets;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.SimpleImageCache;
import com.ngmoco.gamejs.SimpleImageObserver;
import com.ngmoco.gamejs.ui.Utils;
import com.ngmoco.gamejs.ui.widgets.Style;
import java.util.HashMap;
import java.util.Map;

public class UIImageDrawable extends UIDrawable implements SimpleImageObserver {
    private HashMap<String, Bitmap> mBitmaps = new HashMap<>();
    private RectF mDrawBounds = new RectF();
    protected int mFit = -1;
    protected Bitmap mImage;
    protected SimpleImageCache mImageCache;
    protected UIImageLoadListener mImageLoadListener = null;
    private StateMap<String> mImageURLs = new StateMap<>();
    private HashMap<Integer, String> mPendingURLs = new HashMap<>();

    public int getFit() {
        if (this.mFit >= 0) {
            return this.mFit;
        }
        if (this.mStyle != null) {
            return ((Style.ImageStyle) this.mStyle).mFit;
        }
        return 1;
    }

    public void setFit(int newFit) {
        int i = this.mFit;
        this.mFit = newFit;
        if (i != newFit) {
            invalidateSelf();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIDrawable, com.ngmoco.gamejs.ui.widgets.UIContentDrawable
    public void stateChanged() {
        updateBitmap();
        super.stateChanged();
    }

    private void updateBitmap() {
        Bitmap bitmap = this.mImage;
        Bitmap bitmapForState = getBitmapForState(this.mState);
        this.mImage = bitmapForState;
        if (bitmap != bitmapForState) {
            invalidateSelf();
        }
    }

    public void setImageURLForState(int state, String newURL, UIImageLoadListener listener) {
        this.mImageLoadListener = listener;
        if (newURL != this.mPendingURLs.put(Integer.valueOf(state), newURL)) {
            if (this.mBitmaps.containsKey(newURL)) {
                this.mImageURLs.put(Integer.valueOf(state), newURL);
            } else if (newURL == null || newURL.equals(ASConstants.kEmptyString)) {
                String oldURL = this.mImageURLs.remove(Integer.valueOf(state));
                if (!this.mImageURLs.containsValue(oldURL)) {
                    this.mImageCache.removeObserver(this, oldURL);
                    this.mBitmaps.remove(oldURL);
                }
            } else {
                this.mImageCache.addObserver(this, newURL);
            }
        }
        updateBitmap();
    }

    public void setBitmapForState(int state, Bitmap newBitmap) {
        String newURL = Integer.toHexString(newBitmap.hashCode());
        String oldURL = this.mImageURLs.get(Integer.valueOf(state));
        boolean hadNewURL = this.mImageURLs.containsValue(newURL);
        this.mImageURLs.put(Integer.valueOf(state), newURL);
        if (oldURL != newURL) {
            if (oldURL != null && !this.mImageURLs.containsValue(oldURL)) {
                this.mImageCache.removeObserver(this, oldURL);
                this.mBitmaps.remove(oldURL);
            }
            if (newURL != null && !hadNewURL) {
                this.mBitmaps.put(newURL, newBitmap);
            }
        }
        updateBitmap();
    }

    public String getImageURLForState(int state) {
        return this.mImageURLs.getValueForState(Integer.valueOf(state), this.mStyle != null ? ((Style.ImageStyle) this.mStyle).mImageURLs : null);
    }

    public Bitmap getBitmapForState(int state) {
        String url = getImageURLForState(state);
        Bitmap bitmap = this.mBitmaps.get(url);
        if (bitmap != null || this.mStyle == null) {
            return bitmap;
        }
        return ((Style.ImageStyle) this.mStyle).mBitmaps.get(url);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIDrawable
    public void draw(Canvas cnv) {
        if (this.mImage == null) {
            super.draw(cnv);
        } else if ((this.mCachedPath != null && this.mCachedRect != null) || cachePath()) {
            this.mDrawBounds.set(this.mCachedRect);
            float[] insets = getInsets();
            if (insets != null) {
                this.mDrawBounds.top += insets[0];
                this.mDrawBounds.right -= insets[1];
                this.mDrawBounds.bottom -= insets[2];
                this.mDrawBounds.left += insets[3];
            }
            float w = (float) this.mImage.getWidth();
            float h = (float) this.mImage.getHeight();
            float scaleW = 1.0f;
            float scaleH = 1.0f;
            switch (getFit()) {
                case 0:
                    scaleH = 1.0f;
                    scaleW = 1.0f;
                    break;
                case 1:
                    float scaleW2 = this.mDrawBounds.width() / w;
                    scaleH = this.mDrawBounds.height() / h;
                    if (scaleW2 < scaleH) {
                        scaleH = scaleW2;
                    }
                    scaleW = scaleH;
                    break;
                case 2:
                    float scaleW3 = this.mDrawBounds.width() / w;
                    scaleH = this.mDrawBounds.height() / h;
                    if (scaleW3 > scaleH) {
                        scaleH = scaleW3;
                    }
                    scaleW = scaleH;
                    break;
                case 3:
                    scaleW = this.mDrawBounds.width() / w;
                    scaleH = this.mDrawBounds.height() / h;
                    break;
                case 5:
                    scaleH = this.mDrawBounds.width() / w;
                    scaleW = scaleH;
                    break;
                case 6:
                    scaleH = this.mDrawBounds.height() / h;
                    scaleW = scaleH;
                    break;
                case 7:
                    scaleH = Math.min(1.0f, Math.min(this.mDrawBounds.width() / w, this.mDrawBounds.height() / h));
                    scaleW = scaleH;
                    break;
            }
            cnv.save(3);
            if (this.mCachedPath != null) {
                if (!sCheckHWAccel || !cnv.isHardwareAccelerated()) {
                    cnv.clipPath(this.mCachedPath, Region.Op.INTERSECT);
                } else {
                    RectF r = new RectF(cnv.getClipBounds());
                    if (r.intersect(this.mCachedRect)) {
                        cnv.clipRect(r);
                    }
                }
            }
            RectF contentBounds = new RectF(0.0f, 0.0f, scaleW * w, scaleH * h);
            float[] gravity = getGravity();
            Utils.applyGravity(this.mDrawBounds, contentBounds, gravity[0], gravity[1]);
            if (getTransform() != null) {
                float cX = contentBounds.centerX();
                float cY = contentBounds.centerY();
                contentBounds.offset(-cX, -cY);
                cnv.translate(cX, cY);
                cnv.concat(getTransform());
            }
            cnv.scale(scaleW, scaleH, contentBounds.left, contentBounds.top);
            cnv.drawBitmap(this.mImage, contentBounds.left, contentBounds.top, this.mContentPaint);
            cnv.restore();
            if (this.mCachedPath != null) {
                super.draw(cnv);
            }
        }
    }

    @Override // com.ngmoco.gamejs.SimpleImageObserver
    public void setImage(String relativeUrl, Bitmap image) {
        for (Map.Entry<Integer, String> e : this.mPendingURLs.entrySet()) {
            if (e.getValue().equals(relativeUrl)) {
                String oldUrl = this.mImageURLs.remove(e.getKey());
                if (!this.mImageURLs.containsValue(oldUrl)) {
                    this.mImageCache.removeObserver(this, oldUrl);
                    this.mBitmaps.remove(oldUrl);
                }
                this.mImageURLs.put(e.getKey(), e.getValue());
            }
        }
        if (this.mImageURLs.containsValue(relativeUrl)) {
            this.mBitmaps.put(relativeUrl, image);
            updateBitmap();
        }
        if (this.mImageLoadListener != null) {
            this.mImageLoadListener.onImageLoaded(relativeUrl, image.getWidth(), image.getHeight());
        }
    }

    @Override // com.ngmoco.gamejs.SimpleImageObserver
    public void imageLoadFailed(String relativeUrl, int errorCode, String errorMessage) {
        if (this.mImageLoadListener != null) {
            this.mImageLoadListener.onImageLoadFailed(relativeUrl, errorCode, errorMessage);
        }
    }

    public UIImageDrawable(Drawable.Callback v, SimpleImageCache cache) {
        super(v);
        this.mImageCache = cache;
        this.mContentPaint.setAntiAlias(true);
        this.mContentPaint.setFilterBitmap(true);
    }
}
