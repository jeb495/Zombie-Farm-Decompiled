package com.ngmoco.gamejs.ui.widgets;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Typeface;
import com.ngmoco.gamejs.SimpleImageCache;
import com.ngmoco.gamejs.SimpleImageObserver;
import com.ngmoco.gamejs.ui.widgets.UIContentDrawable;
import com.ngmoco.gamejs.ui.widgets.UITextDrawable;
import java.util.HashMap;

public class Style {
    GradientStyle mGradientStyle;
    ImageStyle mImageStyle;
    ImageStyle mRightImageStyle;
    TextStyle mTextStyle;
    TextStyle mTitleStyle;

    public static class GradientStyle extends ContentStyle {
        public StateMap<UIContentDrawable.UIGradientDefinition> mGradients = new StateMap<>();
    }

    public static class TextStyle extends ContentStyle {
        static final float DEFAULT_SIZE = 16.0f;
        public StateMap<Integer> mColors = new StateMap<>();
        public float mFontSize = DEFAULT_SIZE;
        public StateMap<UIShadow> mShadows = new StateMap<>();
        public UITextDrawable.TextMap mTexts = new UITextDrawable.TextMap();
        public StateMap<Typeface> mTypefaces = new StateMap<>();
    }

    public static class ContentStyle {
        public float[] mGravity = {0.5f, 0.5f};
        protected UIImageLoadListener mImageLoadListener = null;
        public float[] mInsets = {0.0f, 0.0f, 0.0f, 0.0f};
        public Matrix mTransform;

        public void setGravity(float x, float y) {
            this.mGravity[0] = x;
            this.mGravity[1] = y;
        }

        public void setInsets(float t, float r, float b, float l) {
            this.mInsets[0] = t;
            this.mInsets[1] = r;
            this.mInsets[2] = b;
            this.mInsets[3] = l;
        }

        public void setTransform(float a, float b, float c, float d, float tx, float ty) {
            if (a == 1.0f && b == 0.0f && c == 0.0f && d == 1.0f && tx == 0.0f && ty == 0.0f) {
                this.mTransform = null;
                return;
            }
            if (this.mTransform == null) {
                this.mTransform = new Matrix();
            }
            this.mTransform.setValues(new float[]{a, c, tx, b, d, ty, 0.0f, 0.0f, 1.0f});
        }
    }

    public static class ImageStyle extends GradientStyle implements SimpleImageObserver {
        static final int DEFAULT_FIT = 1;
        public HashMap<String, Bitmap> mBitmaps = new HashMap<>();
        public int mFit = 1;
        public StateMap<String> mImageURLs = new StateMap<>();

        public void setImageURLForState(SimpleImageCache imageCache, int state, String newURL, UIImageLoadListener imageLoadListener) {
            this.mImageLoadListener = imageLoadListener;
            String oldURL = this.mImageURLs.put(Integer.valueOf(state), newURL);
            if (newURL != oldURL) {
                if (oldURL != null) {
                    imageCache.removeObserver(this, oldURL);
                }
                if (newURL != null) {
                    imageCache.addObserver(this, newURL);
                }
            }
        }

        @Override // com.ngmoco.gamejs.SimpleImageObserver
        public void setImage(String relativeUrl, Bitmap image) {
            if (image == null) {
                this.mBitmaps.remove(relativeUrl);
            } else {
                this.mBitmaps.put(relativeUrl, image);
            }
        }

        @Override // com.ngmoco.gamejs.SimpleImageObserver
        public void imageLoadFailed(String relativeUrl, int errorCode, String errorMessage) {
            if (this.mImageLoadListener != null) {
                this.mImageLoadListener.onImageLoadFailed(relativeUrl, errorCode, errorMessage);
            }
        }
    }

    public GradientStyle ensureGradientStyle() {
        if (this.mGradientStyle != null) {
            return this.mGradientStyle;
        }
        GradientStyle gradientStyle = new GradientStyle();
        this.mGradientStyle = gradientStyle;
        return gradientStyle;
    }

    public ImageStyle ensureImageStyle() {
        if (this.mImageStyle != null) {
            return this.mImageStyle;
        }
        ImageStyle imageStyle = new ImageStyle();
        this.mImageStyle = imageStyle;
        return imageStyle;
    }

    public ImageStyle ensureRightImageStyle() {
        if (this.mRightImageStyle != null) {
            return this.mRightImageStyle;
        }
        ImageStyle imageStyle = new ImageStyle();
        this.mRightImageStyle = imageStyle;
        return imageStyle;
    }

    public TextStyle ensureTextStyle() {
        if (this.mTextStyle != null) {
            return this.mTextStyle;
        }
        TextStyle textStyle = new TextStyle();
        this.mTextStyle = textStyle;
        return textStyle;
    }

    public TextStyle ensureTitleStyle() {
        if (this.mTitleStyle != null) {
            return this.mTitleStyle;
        }
        TextStyle textStyle = new TextStyle();
        this.mTitleStyle = textStyle;
        return textStyle;
    }
}
