package com.ngmoco.gamejs.ui.widgets;

import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.widgets.Style;
import com.ngmoco.gamejs.ui.widgets.UIContentDrawable;
import org.json.JSONObject;

public class UIDrawable extends UIContentDrawable {
    static boolean sCheckHWAccel = (Build.VERSION.SDK_INT >= 11);
    Path mCachedInnerPath = null;
    Path mCachedOuterPath = null;
    Path mCachedPath = null;
    RectF mCachedRect = null;
    UIContentDrawable.UIGradientDefinition mGradient = null;
    StateMap<UIContentDrawable.UIGradientDefinition> mGradients = new StateMap<>();
    View mHostView;

    private void invalidatePath() {
        this.mCachedPath = null;
        this.mCachedInnerPath = null;
        this.mCachedOuterPath = null;
        this.mCachedRect = null;
    }

    private void updateGradient() {
        UIContentDrawable.UIGradientDefinition uIGradientDefinition = this.mGradient;
        UIContentDrawable.UIGradientDefinition valueForState = this.mGradients.getValueForState(Integer.valueOf(this.mState), this.mStyle != null ? ((Style.GradientStyle) this.mStyle).mGradients : null);
        this.mGradient = valueForState;
        if (uIGradientDefinition != valueForState) {
            if (sCheckHWAccel && this.mGradient != null && !this.mGradient.canDrawHW()) {
                this.mHostView.setLayerType(1, null);
                this.mHostView.destroyDrawingCache();
            }
            this.mIsOpaque = this.mGradient == null ? false : this.mGradient.getIsOpaque();
            invalidatePath();
            invalidateSelf();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIContentDrawable
    public void stateChanged() {
        updateGradient();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIContentDrawable
    public void boundsWillChange(Rect newBounds) {
        invalidatePath();
    }

    public void setGradientDefinition(JSONObject def, int state) {
        if (def == null) {
            this.mGradients.remove(Integer.valueOf(state));
        } else {
            UIContentDrawable.UIGradientDefinition g = new UIContentDrawable.UIGradientDefinition();
            this.mGradients.put(Integer.valueOf(state), g);
            g.set(def);
        }
        if (((this.mState ^ -1) & state) == 0) {
            updateGradient();
        }
    }

    public void setGradientDefinition(String def, int state) throws Exception {
        setGradientDefinition(new JSONObject(def), state);
    }

    /* access modifiers changed from: protected */
    public boolean cachePath() {
        Rect myBounds = getBounds();
        if (myBounds == null || myBounds.isEmpty()) {
            Log.w("NGUIDrawable", "Bounds were not set! Aborting draw command!");
            return false;
        }
        if (this.mGradient == null) {
            this.mCachedRect = new RectF(myBounds);
        } else {
            this.mCachedRect = new RectF();
            this.mCachedPath = this.mGradient.getPathForBounds(myBounds, this.mCachedRect);
            this.mCachedInnerPath = this.mGradient.getInnerPath(this.mCachedRect);
            this.mCachedOuterPath = this.mGradient.getOuterPath(this.mCachedRect);
        }
        return true;
    }

    public void draw(Canvas cnv) {
        if (this.mGradient != null) {
            if ((this.mCachedPath != null && this.mCachedRect != null) || cachePath()) {
                if (!sCheckHWAccel || !cnv.isHardwareAccelerated()) {
                    this.mGradient.draw(cnv, this.mCachedPath, this.mCachedRect);
                } else {
                    this.mGradient.drawHW(cnv, this.mCachedPath, this.mCachedInnerPath, this.mCachedOuterPath, this.mCachedRect);
                }
            }
        }
    }

    public UIDrawable(Drawable.Callback host) {
        super(host);
        if (host instanceof View) {
            this.mHostView = (View) host;
        }
    }
}
