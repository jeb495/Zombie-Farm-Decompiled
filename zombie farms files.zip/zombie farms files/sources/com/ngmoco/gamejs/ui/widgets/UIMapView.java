package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.ngmoco.gamejs.NGItemizedOverlay;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.util.Timer;
import java.util.TimerTask;

public class UIMapView extends MapView implements UIWidget {
    private static final int initialAnimationCheckTime = 250;
    private static final int repeatAnimationCheckTime = 50;
    private UIMapViewListener _mapViewListener;
    private NGItemizedOverlay itemizedOverlay;
    protected int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    private Timer mAnimationCheckTimer = new Timer();
    private int mH;
    private boolean mIsAnimating = false;
    private int mLastLatSpan = -1;
    private boolean mLayoutOverlays = false;
    private boolean mRecentScroll = false;
    private int mW;
    protected float mWidgetAlpha = 1.0f;
    private int mX;
    private int mY;
    private boolean mZoomable = true;
    private boolean send = false;

    public void setMapViewListener(UIMapViewListener listener) {
        this._mapViewListener = listener;
    }

    public UIMapView(Context context, String apiKey) {
        super(context, apiKey);
        this.itemizedOverlay = new NGItemizedOverlay(null, context);
        getOverlays().add(this.itemizedOverlay);
        setClickable(true);
        setOnTouchListener(new View.OnTouchListener() {
            /* class com.ngmoco.gamejs.ui.widgets.UIMapView.AnonymousClass1 */

            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == 2) {
                    UIMapView.this.send = true;
                    if (event.getPointerCount() > 1) {
                        UIMapView.this.mLayoutOverlays = true;
                    }
                }
                if (event.getAction() == 1 && UIMapView.this.send) {
                    UIMapView.this.send = false;
                    ((UIMapView) v).onRegionChange();
                    ((UIMapView) v).showContextMenuForChild(v);
                }
                return !UIMapView.this.mZoomable && event.getPointerCount() > 1;
            }
        });
    }

    public void onRegionChange() {
        this._mapViewListener.onRegionChange((double) getMapCenter().getLatitudeE6(), (double) getMapCenter().getLongitudeE6(), (double) getLatitudeSpan(), (double) getLongitudeSpan());
    }

    public void setCenter(float latitude, float longitude) {
        getController().setCenter(new GeoPoint((int) (((double) latitude) * 1000000.0d), (int) (((double) longitude) * 1000000.0d)));
    }

    private class AnimationCheckTask extends TimerTask {
        private float latitude;
        private float longitude;

        public AnimationCheckTask(float desiredLatitude, float desiredLongitude) {
            this.latitude = desiredLatitude;
            this.longitude = desiredLongitude;
        }

        public void run() {
            if (UIMapView.this.mRecentScroll) {
                UIMapView.this.mAnimationCheckTimer.schedule(new AnimationCheckTask(this.latitude, this.longitude), 50);
                UIMapView.this.mRecentScroll = false;
                return;
            }
            UIMapView.this.setCenter(this.latitude, this.longitude);
        }
    }

    public void setRegion(float latitude, float longitude, float latitudeDelta, float longitudeDelta, boolean animated) {
        if (animated) {
            this.mIsAnimating = true;
            this.mAnimationCheckTimer.schedule(new AnimationCheckTask(latitude, longitude), 250);
            getController().animateTo(new GeoPoint((int) (((double) latitude) * 1000000.0d), (int) (((double) longitude) * 1000000.0d)), new Runnable() {
                /* class com.ngmoco.gamejs.ui.widgets.UIMapView.AnonymousClass2 */

                public void run() {
                    UIMapView.this.mAnimationCheckTimer.cancel();
                    UIMapView.this.mAnimationCheckTimer = new Timer();
                }
            });
            zoomToSpan((int) (((double) latitudeDelta) * 1000000.0d), (int) (((double) longitudeDelta) * 1000000.0d));
            this.mLastLatSpan = getLatitudeSpan();
            return;
        }
        setCenter(latitude, longitude);
        getController().zoomToSpan((int) (((double) latitudeDelta) * 1000000.0d), (int) (((double) longitudeDelta) * 1000000.0d));
    }

    private void zoomToSpan(int reqLatSpan, int reqLonSpan) {
        if (reqLatSpan > 0 && reqLonSpan > 0) {
            float diffNeeded = Math.max(((float) reqLatSpan) / ((float) getLatitudeSpan()), ((float) reqLonSpan) / ((float) getLongitudeSpan()));
            if (diffNeeded > 1.0f) {
                int limit = getNextSquareNumberAbove(diffNeeded);
                for (int i = 0; i < limit; i++) {
                    getController().zoomOut();
                }
            } else if (((double) diffNeeded) < 0.5d) {
                int limit2 = getNextSquareNumberAbove(1.0f / diffNeeded) - 1;
                for (int i2 = 0; i2 < limit2; i2++) {
                    getController().zoomIn();
                }
            }
            this.mLayoutOverlays = true;
        }
    }

    public static int getNextSquareNumberAbove(float factor) {
        int out = 0;
        int cur = 1;
        int i = 1;
        while (((float) cur) <= factor) {
            out = i;
            cur *= 2;
            i++;
        }
        return out;
    }

    public void setZoomable(boolean enabled) {
        this.mZoomable = enabled;
    }

    public void setRegion(float latitude, float longitude, float latitudeDelta, float longitudeDelta) {
        setCenter(latitude, longitude);
        getController().zoomToSpan((int) (((double) latitudeDelta) * 1000000.0d), (int) (((double) longitudeDelta) * 1000000.0d));
    }

    private void updateAnnotations() {
        invalidate();
        measure(this.mW, this.mH);
        layout(this.mX, this.mY, this.mX + this.mW, this.mY + this.mH);
    }

    public void addAnnotation(UIAnnotation mapAnnotation) {
        this.itemizedOverlay.addOverlays(mapAnnotation);
        mapAnnotation.mParentMapView = this;
        invalidate();
    }

    public void removeAnnotation(UIAnnotation mapAnnotation) {
        if (this.itemizedOverlay.getFocus() == mapAnnotation) {
            this.itemizedOverlay.setFocus((UIAnnotation) null);
        }
        this.itemizedOverlay.removeOverlays(mapAnnotation);
        mapAnnotation.mParentMapView = null;
        invalidate();
    }

    public void selectAnnotation(UIAnnotation selectedannotation) {
        if (this.itemizedOverlay.getFocus() != null) {
            this.itemizedOverlay.setFocus((UIAnnotation) null);
        }
        if (selectedannotation != null) {
            this.itemizedOverlay.setFocus(selectedannotation);
        }
        invalidate();
    }

    public void addView(View child, ViewGroup.LayoutParams params) {
        UIMapView.super.addView(child, params);
        updateAnnotations();
    }

    public void removeView(View view) {
        UIMapView.super.removeView(view);
        updateAnnotations();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        this.mW = w;
        this.mH = h;
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public NGItemizedOverlay getMainOverlay() {
        return this.itemizedOverlay;
    }

    public void draw(Canvas canvas) {
        if (this.mLayoutOverlays || this.mIsAnimating) {
            measure(this.mW, this.mH);
            layout(this.mX, this.mY, this.mX + this.mW, this.mY + this.mH);
            this.mLayoutOverlays = false;
            if (this.mIsAnimating) {
                int i = this.mLastLatSpan;
                int latitudeSpan = getLatitudeSpan();
                this.mLastLatSpan = latitudeSpan;
                if (i != latitudeSpan) {
                    this.mIsAnimating = false;
                }
            }
        }
        if (this.mAlpha != 0) {
            boolean needRestore = false;
            if (this.mAlpha != 255) {
                needRestore = true;
                canvas.saveLayerAlpha((float) canvas.getClipBounds().left, (float) canvas.getClipBounds().top, (float) canvas.getClipBounds().right, (float) canvas.getClipBounds().bottom, this.mAlpha, 4);
            }
            UIMapView.super.draw(canvas);
            if (needRestore) {
                canvas.restore();
            }
        }
    }

    public void computeScroll() {
        UIMapView.super.computeScroll();
        this.mRecentScroll = true;
    }
}
