package com.ngmoco.gamejs.ui.widgets;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.Utils;

public class TextLayout {
    static final String TAG = "TextLayout";
    private char[] mChars;
    private Rect mContentRect = new Rect();
    protected Paint.FontMetrics mFontMetrics = new Paint.FontMetrics();
    private int[] mLineChars;
    private float mLineHeight = 0.0f;
    private int[] mLineStarts;
    private float[] mLineWidths;
    private Object mMeasureContext;
    private Rect mMeasuredRect = new Rect();
    int mNumLines = 0;
    private Paint mPaint = new Paint((int) Commands.CommandIDs.setAutodetection);
    private boolean mReported = true;
    private String mString;
    private OnTextMeasuredListener mTextMeasuredListener;
    private float mTotalWidth;

    public interface OnTextMeasuredListener {
        void textWasMeasured(Object obj, int i, int i2, int i3, int[] iArr);
    }

    public void setMeasurementListener(OnTextMeasuredListener listener, Object context) {
        this.mTextMeasuredListener = listener;
        this.mMeasureContext = context;
        reportResults();
    }

    private void reportResults() {
        if (!(this.mTextMeasuredListener == null || this.mReported)) {
            int[] widths = new int[this.mNumLines];
            for (int i = 0; i < this.mNumLines; i++) {
                widths[i] = Math.round(this.mLineWidths[i]);
            }
            this.mTextMeasuredListener.textWasMeasured(this.mMeasureContext, this.mContentRect.width(), this.mContentRect.height(), Math.round(this.mTotalWidth), widths);
            this.mReported = true;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:71:0x0218, code lost:
        if (r38.mChars[r12] == '\n') goto L_0x021a;
     */
    public void measure(Rect mRect) {
        int dim;
        this.mNumLines = 0;
        this.mReported = false;
        System.currentTimeMillis();
        if (this.mString != null) {
            int widthSpec = mRect.width() > 0 ? mRect.width() : Integer.MAX_VALUE;
            int heightSpec = mRect.height();
            if (this.mChars == null) {
                this.mChars = this.mString.toCharArray();
            }
            int charCount = this.mChars.length;
            float[] charWidths = new float[charCount];
            if (charCount != this.mPaint.getTextWidths(this.mChars, 0, charCount, charWidths)) {
                Log.e(TAG, "Error getting character advances: " + this.mString);
            }
            int wl = charWidths.length;
            this.mTotalWidth = 0.0f;
            for (int wx = 0; wx < wl; wx++) {
                this.mTotalWidth += charWidths[wx];
            }
            float baseHeight = this.mFontMetrics.descent - this.mFontMetrics.ascent;
            float lineHeight = ((double) this.mLineHeight) > 0.0d ? this.mLineHeight : baseHeight + this.mFontMetrics.leading;
            int maxLines = ((int) ((((float) heightSpec) - baseHeight) / lineHeight)) + 1;
            if (maxLines < 1) {
                maxLines = 1;
            }
            if (heightSpec <= 0) {
                maxLines = Integer.MAX_VALUE;
            }
            if (widthSpec == Integer.MAX_VALUE) {
                maxLines = 1;
            }
            boolean dynamicLines = maxLines > 16;
            if (this.mLineStarts == null || maxLines > this.mLineStarts.length || this.mLineStarts.length > 50) {
                if (dynamicLines) {
                    dim = 16;
                } else {
                    dim = maxLines;
                }
                this.mLineStarts = new int[dim];
                this.mLineChars = new int[dim];
                this.mLineWidths = new float[dim];
            }
            int j = 0;
            float maxLineW = 0.0f;
            int i = 0;
            while (true) {
                if (i < maxLines && j < charCount) {
                    if (j < charCount) {
                        switch (this.mChars[j]) {
                            case '\t':
                            case ' ':
                                if (i > 0) {
                                    j++;
                                    break;
                                }
                                break;
                            case '\r':
                                j++;
                                if (j < charCount) {
                                    break;
                                }
                                break;
                            case '\n':
                                j++;
                                break;
                        }
                    }
                    int rangeEnd = -1;
                    int wrapCharAt = -1;
                    float accruedW = 0.0f;
                    while (true) {
                        if (j < charCount) {
                            char c = this.mChars[j];
                            if (c == '\n' || c == '\r') {
                                rangeEnd = j;
                            } else {
                                if (c <= ' ' && wrapCharAt != j - 1) {
                                    wrapCharAt = j;
                                }
                                float w = charWidths[j];
                                if (accruedW + w <= ((float) widthSpec)) {
                                    accruedW += w;
                                    j++;
                                } else if (wrapCharAt > j) {
                                    rangeEnd = wrapCharAt;
                                    for (int rm = wrapCharAt; rm < j; rm++) {
                                        accruedW -= charWidths[rm];
                                    }
                                } else {
                                    rangeEnd = j;
                                }
                            }
                        }
                    }
                    if (rangeEnd < 0) {
                        rangeEnd = charCount;
                    }
                    if (dynamicLines && i >= this.mLineStarts.length) {
                        int l = this.mLineStarts.length;
                        int l2 = l < 1024 ? l << 1 : l + 1024;
                        int[] tempLS = new int[l2];
                        int[] tempLC = new int[l2];
                        float[] tempLW = new float[l2];
                        for (int ri = 0; ri < l; ri++) {
                            tempLS[ri] = this.mLineStarts[ri];
                            tempLC[ri] = this.mLineChars[ri];
                            tempLW[ri] = this.mLineWidths[ri];
                        }
                        this.mLineStarts = tempLS;
                        this.mLineChars = tempLC;
                        this.mLineWidths = tempLW;
                    }
                    if (rangeEnd >= j) {
                        this.mLineStarts[i] = j;
                        this.mLineChars[i] = rangeEnd - j;
                        this.mLineWidths[i] = accruedW;
                        if (accruedW > maxLineW) {
                            maxLineW = accruedW;
                        }
                        this.mNumLines = i + 1;
                        j = rangeEnd;
                        i++;
                    } else {
                        this.mNumLines = i;
                        Log.e(TAG, "ERROR: Text Wrap failed with zero-width string in: " + this.mString);
                    }
                }
            }
            this.mContentRect.set(0, 0, (int) Math.ceil((double) maxLineW), (int) Math.ceil((double) ((((float) (this.mNumLines - 1)) * lineHeight) + baseHeight)));
            this.mMeasuredRect.set(mRect);
        } else {
            this.mMeasuredRect.setEmpty();
            this.mContentRect.setEmpty();
        }
        reportResults();
    }

    public void draw(Canvas cnv, float[] gravity, Paint usePaint) {
        if (this.mNumLines > 0) {
            Utils.applyGravity(this.mMeasuredRect, this.mContentRect, gravity[0], gravity[1]);
            float lineAdvance = ((double) this.mLineHeight) > 0.0d ? this.mLineHeight : (this.mFontMetrics.descent - this.mFontMetrics.ascent) + this.mFontMetrics.leading;
            for (int i = 0; i < this.mNumLines; i++) {
                cnv.drawText(this.mChars, this.mLineStarts[i], this.mLineChars[i], ((float) this.mContentRect.left) + (gravity[0] * (((float) this.mContentRect.width()) - this.mLineWidths[i])), (((float) i) * lineAdvance) + (((float) this.mContentRect.top) - this.mFontMetrics.ascent), usePaint);
            }
        }
    }

    public String getString() {
        return this.mString;
    }

    public void setString(String aString) {
        this.mString = aString;
        this.mMeasuredRect.setEmpty();
    }

    public void setLineHeight(float aLineHeight) {
        this.mLineHeight = aLineHeight;
        this.mMeasuredRect.setEmpty();
    }

    public boolean ifSetParams(Rect r, Typeface t, float textSize, float lineHeight) {
        boolean invalid = !this.mMeasuredRect.equals(r);
        if (this.mPaint.getTextSize() != textSize) {
            this.mPaint.setTextSize(textSize);
            invalid = true;
        }
        if (t != null && !t.equals(this.mPaint.getTypeface())) {
            this.mPaint.setTypeface(t);
            invalid = true;
        }
        if (this.mLineHeight != lineHeight) {
            invalid = true;
        }
        if (invalid) {
            this.mMeasuredRect.setEmpty();
            this.mPaint.getFontMetrics(this.mFontMetrics);
        }
        return invalid;
    }

    public TextLayout(String aString) {
        this.mString = aString;
        this.mPaint.setTypeface(Typeface.SANS_SERIF);
        this.mPaint.setTextSize(Utils.pixelsForFontSize(16.0f));
    }

    public TextLayout(String aString, Paint textPaint) {
        this.mString = aString;
        this.mPaint = textPaint;
        this.mPaint.getFontMetrics(this.mFontMetrics);
    }
}
