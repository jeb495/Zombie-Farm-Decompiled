package com.ngmoco.gamejs.ui.widgets;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.KeyEvent;
import com.ngmoco.gamejs.Log;

public class UIAlertDialogBuilder extends AlertDialog.Builder {
    private static final String TAG = "UIAlertDialogBuilder";
    private AlertDialog mDialog;

    public UIAlertDialogBuilder(Activity activity) {
        super(activity);
    }

    public void setChoices(String[] choices, DialogInterface.OnClickListener listener) {
        String str;
        String str2;
        String str3 = null;
        if (choices.length > 0) {
            str = choices[0];
        } else {
            str = null;
        }
        setPositiveButton(str, listener);
        if (choices.length > 1) {
            str2 = choices[1];
        } else {
            str2 = null;
        }
        setNegativeButton(str2, listener);
        if (choices.length > 2) {
            str3 = choices[2];
        }
        setNeutralButton(str3, listener);
    }

    private void build() {
        setOnKeyListener(new DialogInterface.OnKeyListener() {
            /* class com.ngmoco.gamejs.ui.widgets.UIAlertDialogBuilder.AnonymousClass1 */

            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == 84) {
                    return true;
                }
                return false;
            }
        });
        this.mDialog = create();
        this.mDialog.setCancelable(false);
    }

    public void showDialog() {
        if (this.mDialog == null) {
            build();
        }
        if (this.mDialog != null && !this.mDialog.isShowing()) {
            this.mDialog.show();
            Log.d(TAG, "dialog shown");
        }
    }

    public void dismissDialog() {
        if (this.mDialog != null && this.mDialog.isShowing()) {
            this.mDialog.dismiss();
            Log.d(TAG, "dialog hidden");
        }
    }
}
