package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import com.ngmoco.gamejs.SimpleImageCache;

public class UIImageView extends ViewWithState implements UIWidget {
    public UIImageDrawable mImageDrawable;

    public UIImageDrawable getImageDrawable() {
        return this.mImageDrawable;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.Styleable
    public void setStyle(Style style) {
        this.mImageDrawable.setStyle(style.ensureImageStyle());
        super.setStyle(style);
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable who) {
        return who == this.mImageDrawable || super.verifyDrawable(who);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.mImageDrawable.setBounds(0, 0, w, h);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        this.mImageDrawable.draw(canvas);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        this.mImageDrawable.setControlState(this.mState | this.mTransientState);
        super.stateChanged();
    }

    public UIImageView(Context context, SimpleImageCache imageCache) {
        super(context);
        this.mImageDrawable = new UIImageDrawable(this, imageCache);
        this.mTouchable = false;
    }
}
