package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import com.ngmoco.gamejs.ui.Utils;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class UIHorizontalScrollView extends HorizontalScrollView implements ScrollingView, Touchable {
    private Runnable checkFlingRunnable = new Runnable() {
        /* class com.ngmoco.gamejs.ui.widgets.UIHorizontalScrollView.AnonymousClass1 */

        public void run() {
            if (!UIHorizontalScrollView.this.mFlinging) {
                return;
            }
            if (System.currentTimeMillis() - UIHorizontalScrollView.this.mLastScrollChange > 250) {
                UIHorizontalScrollView.this.mFlinging = false;
                if (UIHorizontalScrollView.this.mOnScrollListener != null) {
                    UIHorizontalScrollView.this.mOnScrollListener.onScrollEnded();
                    return;
                }
                return;
            }
            UIHorizontalScrollView.this.postDelayed(this, 250);
        }
    };
    private int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    protected UIScrollContentLayout mContentView;
    private boolean mFlinging = false;
    private long mLastScrollChange = 0;
    protected UIScrollListener mOnScrollListener;
    private boolean mTouchable = true;
    protected float mWidgetAlpha = 1.0f;
    private int mX;
    private int mY;

    public boolean onTouchEvent(MotionEvent event) {
        if (!this.mTouchable) {
            return false;
        }
        if (this.mOnScrollListener == null || event.getAction() != 1) {
            return super.onTouchEvent(event);
        }
        boolean onTouchEvent = super.onTouchEvent(event);
        if (this.mFlinging) {
            return onTouchEvent;
        }
        this.mOnScrollListener.onScrollEnded();
        return onTouchEvent;
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getAnimation() != null) {
            Utils.removeAnimation(this);
        }
        if (ev.getAction() == 0) {
            this.mFlinging = false;
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void setTouchable(boolean canTouch) {
        this.mTouchable = canTouch;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void track(boolean inBounds) {
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public void setContentSize(int w, int h) {
        this.mContentView.setLayoutParams(new FrameLayout.LayoutParams(w, h));
        this.mContentView.setSize(w, h);
        setHorizontalScrollBarEnabled(w > getWidth());
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public int getContentHeight() {
        return this.mContentView.getHeight();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public int getContentWidth() {
        return this.mContentView.getWidth();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public void addContainedView(View v) {
        this.mContentView.addView(v);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public void addContainedView(View v, int index) {
        this.mContentView.addView(v, index);
    }

    /* access modifiers changed from: protected */
    public void onScrollChanged(int l, int t, int oldl, int oldt) {
        if (this.mOnScrollListener != null) {
            this.mOnScrollListener.onScrollChanged(l, t, oldl, oldt);
        }
        if (this.mFlinging) {
            this.mLastScrollChange = System.currentTimeMillis();
        }
        super.onScrollChanged(l, t, oldl, oldt);
    }

    public void fling(int velocityY) {
        super.fling(velocityY);
        this.mFlinging = true;
        this.mLastScrollChange = System.currentTimeMillis();
        postDelayed(this.checkFlingRunnable, 250);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ScrollingView
    public void setOnScrollListener(UIScrollListener listener) {
        this.mOnScrollListener = listener;
    }

    public UIHorizontalScrollView(Context context) {
        super(context);
        this.mContentView = new UIScrollContentLayout(context);
        setHorizontalScrollBarEnabled(true);
        setHorizontalFadingEdgeEnabled(false);
        addView(this.mContentView);
    }

    public UIHorizontalScrollView(Context context, UIScrollView h) {
        super(context);
        this.mContentView = h.mContentView;
        setHorizontalScrollBarEnabled(true);
        setHorizontalFadingEdgeEnabled(false);
        ((ViewGroup) this.mContentView.getParent()).removeView(this.mContentView);
        addView(this.mContentView);
        setOrigin(h.getLeft(), h.getTop());
        setSize(h.getWidth(), h.getHeight());
        setHorizontalScrollBarEnabled(h.isHorizontalScrollBarEnabled());
        setVerticalScrollBarEnabled(h.isVerticalScrollBarEnabled());
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public boolean isOpaque() {
        return this.mAlpha == 255 && super.isOpaque();
    }

    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha != 255) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }
}
