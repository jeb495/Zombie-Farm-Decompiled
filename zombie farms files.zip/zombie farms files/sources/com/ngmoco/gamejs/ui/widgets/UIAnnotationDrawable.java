package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PointF;
import android.graphics.drawable.Drawable;
import android.view.View;

public class UIAnnotationDrawable extends Drawable {
    private UIAnnotationCalloutView _calloutView;
    private View _view;
    private PointF centerOffset;

    public UIAnnotationDrawable(Context context) {
        setCenterOffset(new PointF(0.0f, 0.0f));
        this._calloutView = new UIAnnotationCalloutView(context);
    }

    public void draw(Canvas canvas) {
        if (this._view != null) {
            canvas.save();
            canvas.translate(((float) ((-this._view.getWidth()) / 2)) + this.centerOffset.x, ((float) ((-this._view.getHeight()) / 2)) + this.centerOffset.y);
            this._view.draw(canvas);
            canvas.restore();
        }
    }

    public int getOpacity() {
        return -3;
    }

    public void setAlpha(int arg0) {
    }

    public void setColorFilter(ColorFilter arg0) {
    }

    public void setView(View _view2) {
        this._view = _view2;
    }

    public View getView() {
        return this._view;
    }

    public void setCenterOffset(PointF mCenterOffset) {
        this.centerOffset = mCenterOffset;
    }

    public PointF getCenterOffset() {
        return this.centerOffset;
    }

    public void setCalloutView(UIAnnotationCalloutView _calloutView2) {
        this._calloutView = _calloutView2;
    }

    public UIAnnotationCalloutView getCalloutView() {
        return this._calloutView;
    }
}
