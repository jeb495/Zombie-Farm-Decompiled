package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;

public class UIListView extends UIScrollView {
    public UIListView(Context context) {
        super(context);
    }
}
