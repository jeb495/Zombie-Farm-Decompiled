package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import com.ngmoco.gamejs.SimpleImageCache;
import com.ngmoco.gamejs.ui.Utils;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class UICellView extends UIViewGroup implements StatefulWidget {
    private int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    private boolean mAutoLayout = true;
    private UIImageDrawable mImageDrawable;
    private Rect mImageRect = new Rect();
    protected float[] mInsets = {0.0f, 0.0f, 0.0f, 0.0f};
    private int mLeftSize = -1;
    private UIImageDrawable mRightImageDrawable;
    private Rect mRightImageRect = new Rect();
    private int mRightSize = 32;
    private int mState = 0;
    private UITextDrawable mTextDrawable = new UITextDrawable(this);
    private Rect mTextRect = new Rect();
    private UITextDrawable mTitleDrawable = new UITextDrawable(this);
    private Rect mTitleRect = new Rect();
    private int mTransientState = 0;

    public UIImageDrawable getImageDrawable() {
        return this.mImageDrawable;
    }

    public UITextDrawable getTitleDrawable() {
        return this.mTitleDrawable;
    }

    public UITextDrawable getTextDrawable() {
        return this.mTextDrawable;
    }

    public UIImageDrawable getRightImageDrawable() {
        return this.mRightImageDrawable;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIViewGroup, com.ngmoco.gamejs.ui.widgets.Styleable
    public void setStyle(Style style) {
        this.mTitleDrawable.setStyle(style.ensureTitleStyle());
        this.mTextDrawable.setStyle(style.ensureTextStyle());
        this.mImageDrawable.setStyle(style.ensureImageStyle());
        this.mRightImageDrawable.setStyle(style.ensureRightImageStyle());
        super.setStyle(style);
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable dr) {
        return dr == this.mImageDrawable || dr == this.mTitleDrawable || dr == this.mTextDrawable || dr == this.mRightImageDrawable || super.verifyDrawable(dr);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable, com.ngmoco.gamejs.ui.widgets.UILayout
    public void track(boolean inBounds) {
        if (inBounds != ((this.mTransientState & 4) != 0)) {
            if (inBounds) {
                this.mTransientState |= 4;
            } else {
                this.mTransientState &= -5;
            }
            stateChanged();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout, com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public int getState() {
        return this.mState;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout, com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void setState(int newState) {
        if (newState != this.mState) {
            this.mState = newState;
            stateChanged();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout
    public boolean isOpaque() {
        return false;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget, com.ngmoco.gamejs.ui.widgets.UILayout
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        return super.onSetAlpha(alpha);
    }

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.ui.widgets.UIViewGroup
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        int top = (int) this.mInsets[0];
        int right = (int) (((float) w) - this.mInsets[1]);
        int bottom = (int) (((float) h) - this.mInsets[2]);
        int left = (int) this.mInsets[3];
        if (this.mAutoLayout) {
            int iL = left + (this.mLeftSize < 0 ? bottom - top : this.mLeftSize);
            this.mImageRect = new Rect(left, top, iL, bottom);
            int iR = right - (this.mRightSize < 0 ? bottom - top : this.mRightSize);
            this.mRightImageRect = new Rect(iR, top, right, bottom);
            int tDiv = (top + bottom) / 2;
            this.mTitleRect = new Rect(iL, top, iR, tDiv);
            this.mTextRect = new Rect(iL, tDiv, iR, bottom);
        }
        this.mImageDrawable.setBounds(this.mImageRect);
        this.mTitleDrawable.setBounds(this.mTitleRect);
        this.mTextDrawable.setBounds(this.mTextRect);
        this.mRightImageDrawable.setBounds(this.mRightImageRect);
    }

    /* access modifiers changed from: protected */
    @Override // com.ngmoco.gamejs.ui.widgets.UIViewGroup
    public void onDraw(Canvas canvas) {
        getBackground().draw(canvas);
        if (this.mImageDrawable != null) {
            this.mImageDrawable.draw(canvas);
        }
        if (this.mTitleDrawable != null) {
            this.mTitleDrawable.draw(canvas);
        }
        if (this.mTextDrawable != null) {
            this.mTextDrawable.draw(canvas);
        }
        if (this.mRightImageDrawable != null) {
            this.mRightImageDrawable.draw(canvas);
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout
    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha != 255) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }

    public void setInsets(int top, int right, int bottom, int left) {
        this.mInsets[0] = (float) top;
        this.mInsets[1] = (float) right;
        this.mInsets[2] = (float) bottom;
        this.mInsets[3] = (float) left;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UILayout, com.ngmoco.gamejs.ui.widgets.StatefulWidget, com.ngmoco.gamejs.ui.widgets.UIViewGroup
    public void stateChanged() {
        int applyState = this.mState | this.mTransientState;
        this.mImageDrawable.setControlState(applyState);
        this.mTitleDrawable.setControlState(applyState);
        this.mTextDrawable.setControlState(applyState);
        this.mRightImageDrawable.setControlState(applyState);
        ((UIDrawable) getBackground()).setControlState(applyState);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        this.mTransientState = Utils.controlStateFromStateSet(getDrawableState());
        stateChanged();
    }

    public UICellView(Context context, SimpleImageCache imageCache) {
        super(context, imageCache);
        this.mImageDrawable = new UIImageDrawable(this, imageCache);
        this.mRightImageDrawable = new UIImageDrawable(this, imageCache);
        setSoundEffectsEnabled(false);
        setBackgroundDrawable(new UIDrawable(this));
        this.mTitleDrawable.setGravity(0.0f, 0.75f);
        this.mTextDrawable.setGravity(0.0f, 0.25f);
        setClickable(true);
    }
}
