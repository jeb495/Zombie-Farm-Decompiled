package com.ngmoco.gamejs.ui.widgets;

import java.util.Comparator;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class StateMap<V> extends TreeMap<Integer, V> {
    private static final long serialVersionUID = -2174704940364472397L;
    private boolean mHasEntries = false;

    public V getValueForState(Integer state) {
        Map.Entry<Integer, V> match = null;
        if (this.mHasEntries) {
            for (Map.Entry<Integer, V> e : entrySet()) {
                int k = e.getKey().intValue();
                if (((state.intValue() ^ -1) & k) == 0) {
                    match = e;
                }
                if (k >= state.intValue()) {
                    break;
                }
            }
        }
        if (match == null) {
            return null;
        }
        return match.getValue();
    }

    public V getValueForState(Integer state, StateMap<V> fallbackMap) {
        Map.Entry<Integer, V> match = null;
        if (this.mHasEntries) {
            for (Map.Entry<Integer, V> e : entrySet()) {
                int k = e.getKey().intValue();
                if (((state.intValue() ^ -1) & k) == 0) {
                    match = e;
                }
                if (k >= state.intValue()) {
                    break;
                }
            }
        }
        if (fallbackMap != null && fallbackMap.mHasEntries && (match == null || match.getKey().intValue() < state.intValue())) {
            for (Map.Entry<Integer, V> e2 : fallbackMap.entrySet()) {
                int k2 = e2.getKey().intValue();
                if (((state.intValue() ^ -1) & k2) == 0 && (match == null || k2 > match.getKey().intValue())) {
                    match = e2;
                }
                if (k2 >= state.intValue()) {
                    break;
                }
            }
        }
        if (match == null) {
            return null;
        }
        return match.getValue();
    }

    @Override // java.util.AbstractMap, java.util.TreeMap, java.util.Map
    public V remove(Object key) {
        V removeVal = (V) super.remove(key);
        this.mHasEntries = size() > 0;
        return removeVal;
    }

    public V put(Integer key, V value) {
        if (value == null) {
            return remove(key);
        }
        if (!this.mHasEntries) {
            this.mHasEntries = true;
        }
        return (V) super.put((Object) key, (Object) value);
    }

    public StateMap() {
    }

    public StateMap(Comparator<Integer> comparator) {
        super(comparator);
    }

    public StateMap(Map<Integer, ? extends V> map) {
        super(map);
    }

    public StateMap(SortedMap<Integer, ? extends V> map) {
        super((SortedMap) map);
    }
}
