package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.webkit.WebView;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;

public class UIDocumentView extends WebView implements UIWidget {
    private int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    protected float mWidgetAlpha = 1.0f;
    private int mX;
    private int mY;

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    public void loadDocument(String relPath) {
        loadUrl("file://" + GameJSActivity.getSandboxRoot() + "/" + relPath);
    }

    public UIDocumentView(Context context) {
        super(context);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha != 255) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }
}
