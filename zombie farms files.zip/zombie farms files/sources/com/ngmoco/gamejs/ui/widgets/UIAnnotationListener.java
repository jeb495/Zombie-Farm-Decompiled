package com.ngmoco.gamejs.ui.widgets;

public interface UIAnnotationListener {
    void onDeselect();

    void onSelect();
}
