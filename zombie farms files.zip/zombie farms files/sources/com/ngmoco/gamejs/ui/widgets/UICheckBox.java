package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.widget.CheckBox;
import com.ngmoco.gamejs.SimpleImageCache;
import com.ngmoco.gamejs.ui.Utils;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.io.IOException;

public class UICheckBox extends CheckBox implements StatefulWidget, Touchable {
    protected int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    private UIDrawable mBackDrawable = new UIDrawable(this);
    private UIImageDrawable mImageDrawable;
    protected int mState = 0;
    private UITextDrawable mTextDrawable = new UITextDrawable(this);
    private boolean mTouchable = true;
    protected int mTransientState = 0;
    protected float mWidgetAlpha = 1.0f;
    private int mX;
    private int mY;

    public UITextDrawable getTextDrawable() {
        return this.mTextDrawable;
    }

    public UIImageDrawable getImageDrawable() {
        return this.mImageDrawable;
    }

    public UIDrawable getBoxDrawable() {
        return this.mBackDrawable;
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (!this.mTouchable) {
            return false;
        }
        return super.onTouchEvent(event);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void setTouchable(boolean canTouch) {
        this.mTouchable = canTouch;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.Touchable
    public void track(boolean inBounds) {
        if (inBounds != ((this.mTransientState & 4) != 0)) {
            if (inBounds) {
                this.mTransientState |= 4;
            } else {
                this.mTransientState &= -5;
            }
            stateChanged();
        }
    }

    /* access modifiers changed from: protected */
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        int bottom2 = bottom - top;
        int split = 0 + (bottom2 - 0);
        this.mImageDrawable.setBounds(0, 0, split, bottom2);
        this.mTextDrawable.setBounds(split, 0, right - left, bottom2);
        this.mBackDrawable.setBounds(0, 0, split, bottom2);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        this.mTextDrawable.draw(canvas);
        if (this.mBackDrawable != null) {
            this.mBackDrawable.draw(canvas);
        }
        this.mImageDrawable.draw(canvas);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public int getState() {
        return this.mState;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void setState(int newState) {
        int i = this.mState;
        this.mState = newState;
        if (i != newState) {
            stateChanged();
        }
    }

    public boolean getChecked() {
        return (this.mState & 8) > 0;
    }

    public void setChecked(boolean checked) {
        super.setChecked(checked);
        if (checked) {
            int i = this.mState;
            int i2 = this.mState | 8;
            this.mState = i2;
            if (i != i2 && this.mImageDrawable != null) {
                stateChanged();
                return;
            }
            return;
        }
        int i3 = this.mState;
        int i4 = this.mState & -9;
        this.mState = i4;
        if (i3 != i4 && this.mImageDrawable != null) {
            stateChanged();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        int applyState = this.mState | this.mTransientState;
        this.mTextDrawable.setControlState(applyState);
        this.mImageDrawable.setControlState(applyState);
        this.mBackDrawable.setControlState(applyState);
    }

    /* access modifiers changed from: protected */
    public void drawableStateChanged() {
        int i = this.mTransientState;
        int controlStateFromStateSet = Utils.controlStateFromStateSet(getDrawableState());
        this.mTransientState = controlStateFromStateSet;
        if (i != controlStateFromStateSet) {
            stateChanged();
        }
        super.drawableStateChanged();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setSize(int w, int h) {
        setMeasuredDimension(w, h);
        layout(this.mX, this.mY, this.mX + w, this.mY + h);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setOrigin(int x, int y) {
        if (this.mX != x) {
            offsetLeftAndRight(x - this.mX);
        }
        if (this.mY != y) {
            offsetTopAndBottom(y - this.mY);
        }
        this.mX = x;
        this.mY = y;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public void setWidgetAlpha(float alpha) {
        this.mWidgetAlpha = alpha;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public float getWidgetAlpha() {
        return this.mWidgetAlpha;
    }

    public boolean isOpaque() {
        return false;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIWidget
    public boolean onSetAlpha(int alpha) {
        this.mAlpha = alpha;
        invalidate();
        return true;
    }

    public void draw(Canvas canvas) {
        if (this.mAlpha != 0) {
            int alphaRestore = 0;
            if (this.mAlpha != 255) {
                alphaRestore = canvas.saveLayerAlpha(new RectF(canvas.getClipBounds()), this.mAlpha, 4);
            }
            super.draw(canvas);
            if (alphaRestore > 0) {
                canvas.restoreToCount(alphaRestore);
            }
        }
    }

    public UICheckBox(Context context, SimpleImageCache imageCache) {
        super(context);
        this.mImageDrawable = new UIImageDrawable(this, imageCache);
        try {
            this.mImageDrawable.setBitmapForState(0, BitmapFactory.decodeStream(context.getAssets().open("ui_checkmark.png")));
        } catch (IOException e) {
            e.printStackTrace();
        }
        requestLayout();
    }
}
