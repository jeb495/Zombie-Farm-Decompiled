package com.ngmoco.gamejs.ui.widgets;

public interface Styleable {
    void setStyle(Style style);
}
