package com.ngmoco.gamejs.ui.widgets;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.Utils;
import com.ngmoco.gamejs.ui.widgets.Style;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import org.json.JSONArray;
import org.json.JSONObject;

public abstract class UIContentDrawable extends Drawable {
    private static final float[] sDefaultGravity = {0.5f, 0.5f};
    protected int mAlpha = SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE;
    protected Paint mContentPaint = new Paint();
    protected float[] mGravity;
    protected float[] mInsets;
    protected boolean mIsOpaque = false;
    protected int mState = 0;
    protected Style.ContentStyle mStyle;
    protected Matrix mTransform;

    public abstract void boundsWillChange(Rect rect);

    public abstract void stateChanged();

    public void setColorFilter(ColorFilter cf) {
    }

    public void setAlpha(int alpha) {
        int i = this.mAlpha;
        this.mAlpha = alpha;
        if (i != alpha) {
            invalidateSelf();
        }
    }

    public void setStyle(Style.ContentStyle style) {
        this.mStyle = style;
        stateChanged();
    }

    public int getOpacity() {
        return this.mIsOpaque ? -1 : -3;
    }

    public float[] getInsets() {
        if (this.mInsets != null) {
            return this.mInsets;
        }
        if (this.mStyle != null) {
            return this.mStyle.mInsets;
        }
        return null;
    }

    public void setInsets(float t, float r, float b, float l) {
        if (this.mInsets == null) {
            this.mInsets = new float[]{0.0f, 0.0f, 0.0f, 0.0f};
        }
        if (t != this.mInsets[0] || r != this.mInsets[1] || b != this.mInsets[2] || l != this.mInsets[3]) {
            this.mInsets[0] = t;
            this.mInsets[1] = r;
            this.mInsets[2] = b;
            this.mInsets[3] = l;
            boundsWillChange(getBounds());
            invalidateSelf();
        }
    }

    public float[] getGravity() {
        if (this.mGravity != null) {
            return this.mGravity;
        }
        return this.mStyle != null ? this.mStyle.mGravity : sDefaultGravity;
    }

    public void setGravity(float x, float y) {
        if (this.mGravity == null) {
            this.mGravity = new float[]{0.5f, 0.5f};
        }
        if (x != this.mGravity[0] || y != this.mGravity[1]) {
            this.mGravity[0] = x;
            this.mGravity[1] = y;
            invalidateSelf();
        }
    }

    public Matrix getTransform() {
        if (this.mTransform != null) {
            return this.mTransform;
        }
        if (this.mStyle != null) {
            return this.mStyle.mTransform;
        }
        return null;
    }

    public void setTransform(float a, float b, float c, float d, float tx, float ty) {
        if (a == 1.0f && b == 0.0f && c == 0.0f && d == 1.0f && tx == 0.0f && ty == 0.0f) {
            this.mTransform = null;
        } else {
            if (this.mTransform == null) {
                this.mTransform = new Matrix();
            }
            this.mTransform.setValues(new float[]{a, c, tx, b, d, ty, 0.0f, 0.0f, 1.0f});
        }
        invalidateSelf();
    }

    public int getControlState() {
        return this.mState;
    }

    public boolean setControlState(int newState) {
        int i = this.mState;
        this.mState = newState;
        if (i == newState) {
            return false;
        }
        stateChanged();
        return true;
    }

    public boolean setState(int[] stateSet) {
        super.setState(stateSet);
        return setControlState(Utils.controlStateFromStateSet(stateSet));
    }

    public void setBounds(Rect bounds) {
        if (!getBounds().equals(bounds)) {
            boundsWillChange(bounds);
            super.setBounds(bounds);
            invalidateSelf();
        }
    }

    public void setBounds(int left, int top, int right, int bottom) {
        Rect r = getBounds();
        if (left != r.left || top != r.top || right != r.right || bottom != r.bottom) {
            boundsWillChange(new Rect(left, top, right, bottom));
            super.setBounds(left, top, right, bottom);
            invalidateSelf();
        }
    }

    public UIContentDrawable(Drawable.Callback v) {
        setCallback(v);
    }

    public static class UIGradientDefinition {
        RectF lastBounds = new RectF();
        boolean mCanDrawHW;
        int[] mColors;
        float[] mCornerInnerRadii = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        float[] mCornerOuterRadii = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        float[] mCornerRadii = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
        int mFillMode = 0;
        Paint mFillPaint = new Paint(1);
        float mGradientAngle = 90.0f;
        int mInnerColor = 0;
        Paint mInnerHWPaint = new Paint(1);
        Paint mInnerPaint = new Paint(1);
        float mInnerShadowBlur = 0.0f;
        int mInnerShadowColor = 0;
        float mInnerShadowOffsetX = 0.0f;
        float mInnerShadowOffsetY = 0.0f;
        float mInnerWidth = 0.0f;
        float[] mInsets = {0.0f, 0.0f, 0.0f, 0.0f};
        private boolean mOpaqueFill = false;
        int mOuterColor = 0;
        Paint mOuterHWPaint = new Paint(1);
        Paint mOuterPaint = new Paint(1);
        float mOuterShadowBlur = 0.0f;
        int mOuterShadowColor = 0;
        float mOuterShadowOffsetX = 0.0f;
        float mOuterShadowOffsetY = 0.0f;
        float mOuterWidth = 0.0f;
        float[] mPositions;

        public boolean canDrawHW() {
            return this.mCanDrawHW;
        }

        public void reset() {
            this.mColors = null;
            this.mPositions = null;
            this.mGradientAngle = 90.0f;
            for (int i = 0; i < this.mCornerRadii.length; i++) {
                this.mCornerRadii[i] = 0.0f;
                this.mCornerInnerRadii[i] = 0.0f;
                this.mCornerOuterRadii[i] = 0.0f;
            }
            for (int i2 = 0; i2 < this.mInsets.length; i2++) {
                this.mInsets[i2] = 0.0f;
            }
            this.mInnerColor = 0;
            this.mInnerWidth = 0.0f;
            this.mOuterColor = 0;
            this.mOuterWidth = 0.0f;
            this.mInnerShadowColor = 0;
            this.mInnerShadowBlur = 0.0f;
            this.mOuterShadowColor = 0;
            this.mOuterShadowBlur = 0.0f;
        }

        public void setGradientAngle(double newAngle) {
            this.mGradientAngle = 90.0f * ((float) Math.round((newAngle / 90.0d) % 4.0d));
        }

        private String[] splitOnChar(String s, char c) {
            if (s == null || s.length() == 0) {
                return null;
            }
            int index = 0;
            int count = 0;
            do {
                count++;
                index = s.indexOf(c, index + 1);
            } while (index > 0);
            String[] rVal = new String[count];
            int count2 = count - 1;
            int i = 0;
            int index2 = 0;
            while (i < count2) {
                int index3 = s.indexOf(c, index2);
                rVal[i] = s.substring(index2, index3);
                i++;
                index2 = index3 + 1;
            }
            rVal[count2] = s.substring(index2);
            return rVal;
        }

        public void setColorsAndPositions(JSONArray stringVals) {
            int count;
            this.mOpaqueFill = false;
            if (stringVals == null || (count = stringVals.length()) <= 0) {
                this.mColors = new int[0];
                this.mPositions = null;
                return;
            }
            this.mOpaqueFill = true;
            if (count == 1) {
                count = 2;
            }
            this.mColors = new int[count];
            this.mPositions = new float[count];
            for (int index = 0; index < count; index++) {
                String aString = stringVals.optString(index % count);
                int splitOne = aString.indexOf(32, 0);
                this.mColors[index] = Utils.colorFromString(aString.substring(0, splitOne));
                this.mPositions[index] = Float.parseFloat(aString.substring(splitOne + 1));
                this.mOpaqueFill = ((this.mColors[index] >> 24) == 255) & this.mOpaqueFill;
            }
        }

        public void setInsets(String spec) {
            if (spec != null && spec.length() > 0) {
                if (spec.charAt(0) == '{') {
                    spec = spec.substring(1, spec.length() - 1);
                }
                String[] parts = splitOnChar(spec, ',');
                if (parts != null && parts.length > 0) {
                    int nParts = parts.length;
                    for (int i = 0; i < 4; i++) {
                        this.mInsets[i] = Float.parseFloat(parts[i % nParts]);
                    }
                    return;
                }
            }
            float[] fArr = this.mInsets;
            float[] fArr2 = this.mInsets;
            float[] fArr3 = this.mInsets;
            this.mInsets[3] = 0.0f;
            fArr3[2] = 0.0f;
            fArr2[1] = 0.0f;
            fArr[0] = 0.0f;
        }

        public void setCornerRadii(String spec) {
            String[] radii;
            if (spec == null || spec.length() <= 0 || (radii = splitOnChar(spec, ' ')) == null || radii.length <= 0) {
                this.mCornerRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                this.mCornerInnerRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                this.mCornerOuterRadii = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
                return;
            }
            for (int i = 0; i < 4; i++) {
                int idx = i * 2;
                float[] fArr = this.mCornerRadii;
                float parseFloat = Float.parseFloat(radii[i % radii.length]);
                this.mCornerRadii[idx + 1] = parseFloat;
                fArr[idx] = parseFloat;
            }
            adjustCornerRadii();
        }

        private void adjustCornerRadii() {
            float innerAdjust = this.mInnerWidth / 2.0f;
            float outerAdjust = (this.mOuterWidth / 2.0f) + 1.0f;
            for (int i = 0; i < 4; i++) {
                int idx = i * 2;
                float[] fArr = this.mCornerInnerRadii;
                float[] fArr2 = this.mCornerInnerRadii;
                int i2 = idx + 1;
                float max = this.mCornerRadii[idx] == 0.0f ? 0.0f : Math.max(0.001f, this.mCornerRadii[idx] - innerAdjust);
                fArr2[i2] = max;
                fArr[idx] = max;
                float[] fArr3 = this.mCornerOuterRadii;
                float[] fArr4 = this.mCornerOuterRadii;
                int i3 = idx + 1;
                float max2 = this.mCornerRadii[idx] == 0.0f ? 0.0f : Math.max(0.001f, this.mCornerRadii[idx] + outerAdjust);
                fArr4[i3] = max2;
                fArr3[idx] = max2;
            }
        }

        public void setInnerLine(String spec) {
            if (spec != null && spec.length() > 0) {
                int index = spec.indexOf(32);
                this.mInnerColor = Utils.colorFromString(spec.substring(0, index));
                this.mInnerWidth = Float.parseFloat(spec.substring(index + 1));
            }
            this.mInnerColor = 0;
            this.mInnerWidth = 0.0f;
            adjustCornerRadii();
        }

        public void setOuterLine(String spec) {
            if (spec == null || spec.length() <= 0) {
                this.mOuterColor = 0;
                this.mOuterWidth = 0.0f;
                adjustCornerRadii();
                return;
            }
            int index = spec.indexOf(32);
            this.mOuterColor = Utils.colorFromString(spec.substring(0, index));
            this.mOuterWidth = Float.parseFloat(spec.substring(index + 1));
        }

        public Path getPathForBounds(Rect bounds, RectF pathBoundsOut) {
            float pad = (float) Math.ceil((double) (this.mOuterWidth + this.mOuterShadowBlur));
            RectF r = new RectF(((float) bounds.left) + this.mInsets[3] + pad, ((float) bounds.top) + this.mInsets[0] + pad, (((float) bounds.right) - this.mInsets[1]) - pad, (((float) bounds.bottom) - this.mInsets[2]) - pad);
            Path myPath = new Path();
            if (pathBoundsOut != null) {
                pathBoundsOut.set((float) ((int) r.left), (float) ((int) r.top), (float) Math.round(r.right), (float) Math.round(r.bottom));
            }
            if (this.mCornerRadii[0] == 0.0f && this.mCornerRadii[2] == 0.0f && this.mCornerRadii[4] == 0.0f && this.mCornerRadii[6] == 0.0f) {
                myPath.addRect(r, Path.Direction.CW);
            } else {
                myPath.addRoundRect(r, this.mCornerRadii, Path.Direction.CW);
            }
            return myPath;
        }

        public Path getInnerPath(RectF pathBounds) {
            float adjust = this.mInnerWidth / 2.0f;
            RectF r = new RectF(pathBounds.left + adjust, pathBounds.top + adjust, pathBounds.right - adjust, pathBounds.bottom - adjust);
            Path myPath = new Path();
            if (this.mCornerInnerRadii[0] == 0.0f && this.mCornerInnerRadii[2] == 0.0f && this.mCornerInnerRadii[4] == 0.0f && this.mCornerInnerRadii[6] == 0.0f) {
                myPath.addRect(r, Path.Direction.CW);
            } else {
                myPath.addRoundRect(r, this.mCornerInnerRadii, Path.Direction.CW);
            }
            return myPath;
        }

        public Path getOuterPath(RectF pathBounds) {
            float adjust = this.mOuterWidth / 2.0f;
            RectF r = new RectF(pathBounds.left - adjust, pathBounds.top - adjust, pathBounds.right + adjust, pathBounds.bottom + adjust);
            Path myPath = new Path();
            if (this.mCornerOuterRadii[0] == 0.0f && this.mCornerOuterRadii[2] == 0.0f && this.mCornerOuterRadii[4] == 0.0f && this.mCornerOuterRadii[6] == 0.0f) {
                myPath.addRect(r, Path.Direction.CW);
            } else {
                myPath.addRoundRect(r, this.mCornerOuterRadii, Path.Direction.CW);
            }
            return myPath;
        }

        private void updatePaints() {
            int i = 2;
            this.mInnerPaint.setStyle(Paint.Style.STROKE);
            this.mInnerPaint.setStrokeWidth(((float) Math.ceil((double) this.mInnerWidth)) * 2.0f);
            this.mInnerPaint.setColor(this.mInnerColor);
            if (this.mInnerShadowColor != 0) {
                this.mInnerPaint.setShadowLayer(this.mInnerShadowBlur, this.mInnerShadowOffsetX, this.mInnerShadowOffsetY, this.mInnerShadowColor);
            } else {
                this.mInnerPaint.clearShadowLayer();
            }
            this.mOuterPaint.setStyle(Paint.Style.STROKE);
            this.mOuterPaint.setStrokeWidth(((float) Math.ceil((double) this.mOuterWidth)) * 2.0f);
            this.mOuterPaint.setColor(this.mOuterColor);
            if (this.mOuterShadowColor != 0) {
                this.mOuterPaint.setShadowLayer(this.mOuterShadowBlur, this.mOuterShadowOffsetX, this.mOuterShadowOffsetY, this.mOuterShadowColor);
            } else {
                this.mOuterPaint.clearShadowLayer();
            }
            this.mInnerHWPaint.setStyle(Paint.Style.STROKE);
            this.mInnerHWPaint.setStrokeWidth((float) Math.ceil((double) this.mInnerWidth));
            this.mInnerHWPaint.setColor(this.mInnerColor);
            this.mOuterHWPaint.setStyle(Paint.Style.STROKE);
            this.mOuterHWPaint.setStrokeWidth((float) Math.ceil((double) this.mOuterWidth));
            this.mOuterHWPaint.setColor(this.mOuterColor);
            this.lastBounds.setEmpty();
            this.mFillPaint.setShader(null);
            this.mFillPaint.setStyle(Paint.Style.FILL);
            if (this.mColors.length == 1 || (this.mColors.length == 2 && this.mColors[0] == this.mColors[1])) {
                this.mFillMode = 1;
                this.mFillPaint.setColor(this.mColors[0]);
                return;
            }
            if (this.mColors.length <= 1) {
                i = 0;
            }
            this.mFillMode = i;
        }

        public void drawHW(Canvas cnv, Path path, Path innerPath, Path outerPath, RectF pathBounds) {
            LinearGradient lg;
            if (this.mFillMode == 2 && !this.lastBounds.equals(pathBounds)) {
                this.lastBounds.set(pathBounds);
                switch ((int) this.mGradientAngle) {
                    case 0:
                    case 360:
                        lg = new LinearGradient(pathBounds.right, 0.0f, pathBounds.left, 0.0f, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    case 180:
                        lg = new LinearGradient(pathBounds.left, 0.0f, pathBounds.right, 0.0f, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    case 270:
                        lg = new LinearGradient(0.0f, pathBounds.bottom, 0.0f, pathBounds.top, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    default:
                        lg = new LinearGradient(0.0f, pathBounds.top, 0.0f, pathBounds.bottom, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                }
                this.mFillPaint.setShader(lg);
            }
            if (this.mFillMode > 0) {
                cnv.drawPath(path, this.mFillPaint);
            }
            if (this.mInnerWidth > 0.0f) {
                cnv.drawPath(innerPath, this.mInnerHWPaint);
            }
            if (this.mOuterWidth > 0.0f) {
                cnv.drawPath(outerPath, this.mOuterHWPaint);
            }
        }

        public void draw(Canvas cnv, Path path, RectF pathBounds) {
            LinearGradient lg;
            if (this.mFillMode == 2 && !this.lastBounds.equals(pathBounds)) {
                this.lastBounds.set(pathBounds);
                switch ((int) this.mGradientAngle) {
                    case 0:
                    case 360:
                        lg = new LinearGradient(pathBounds.right, 0.0f, pathBounds.left, 0.0f, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    case 180:
                        lg = new LinearGradient(pathBounds.left, 0.0f, pathBounds.right, 0.0f, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    case 270:
                        lg = new LinearGradient(0.0f, pathBounds.bottom, 0.0f, pathBounds.top, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                    default:
                        lg = new LinearGradient(0.0f, pathBounds.top, 0.0f, pathBounds.bottom, this.mColors, this.mPositions, Shader.TileMode.CLAMP);
                        break;
                }
                this.mFillPaint.setShader(lg);
            }
            if (this.mFillMode > 0) {
                cnv.drawPath(path, this.mFillPaint);
            }
            if (this.mInnerWidth > 0.0f || this.mInnerShadowColor != 0) {
                cnv.save(2);
                cnv.clipPath(path, Region.Op.INTERSECT);
                path.toggleInverseFillType();
                cnv.drawPath(path, this.mInnerPaint);
                path.toggleInverseFillType();
                cnv.restore();
            }
            if (this.mOuterWidth > 0.0f || this.mOuterShadowColor != 0) {
                cnv.save(2);
                cnv.clipPath(path, Region.Op.DIFFERENCE);
                cnv.drawPath(path, this.mOuterPaint);
                cnv.restore();
            }
        }

        public boolean getIsOpaque() {
            return this.mOpaqueFill && this.mOuterShadowBlur == 0.0f && this.mInsets[0] <= 0.0f && this.mInsets[1] <= 0.0f && this.mInsets[2] <= 0.0f && this.mInsets[3] <= 0.0f && this.mCornerRadii[0] == 0.0f && this.mCornerRadii[2] == 0.0f && this.mCornerRadii[4] == 0.0f && this.mCornerRadii[6] == 0.0f && (this.mOuterWidth == 0.0f || (this.mOuterColor >> 24) == 255);
        }

        public void set(JSONObject spec) {
            String s;
            String s2;
            boolean z = true;
            setColorsAndPositions(spec.optJSONArray("gradient"));
            if (spec.has("innerShadow")) {
                String s3 = spec.optString("innerShadow");
                int index = s3.indexOf(32, 0);
                this.mInnerShadowColor = Utils.colorFromString(s3.substring(0, index));
                int index2 = s3.indexOf(123, index);
                this.mInnerShadowBlur = Float.parseFloat(s3.substring(index + 1, index2));
                int i = index2 + 1;
                int index3 = s3.indexOf(44, index2);
                this.mInnerShadowOffsetX = Float.parseFloat(s3.substring(i, index3));
                this.mInnerShadowOffsetY = Float.parseFloat(s3.substring(index3 + 1, s3.indexOf(Commands.CommandIDs.setViewportEnabled, index3)));
            }
            if (spec.has("innerLine") && (s2 = spec.optString("innerLine")) != null && s2.length() > 0) {
                int index4 = s2.indexOf(32);
                this.mInnerColor = Utils.colorFromString(s2.substring(0, index4));
                this.mInnerWidth = Float.parseFloat(s2.substring(index4 + 1));
            }
            if (spec.has("outerShadow")) {
                String s4 = spec.optString("outerShadow");
                int index5 = s4.indexOf(32, 0);
                this.mOuterShadowColor = Utils.colorFromString(s4.substring(0, index5));
                int index6 = s4.indexOf(123, index5);
                this.mOuterShadowBlur = Float.parseFloat(s4.substring(index5 + 1, index6));
                int i2 = index6 + 1;
                int index7 = s4.indexOf(44, index6);
                this.mOuterShadowOffsetX = Float.parseFloat(s4.substring(i2, index7));
                this.mOuterShadowOffsetY = Float.parseFloat(s4.substring(index7 + 1, s4.indexOf(Commands.CommandIDs.setViewportEnabled, index7)));
            }
            if (spec.has("outerLine") && (s = spec.optString("outerLine")) != null && s.length() > 0) {
                int index8 = s.indexOf(32);
                this.mOuterColor = Utils.colorFromString(s.substring(0, index8));
                this.mOuterWidth = Float.parseFloat(s.substring(index8 + 1));
            }
            if (spec.has("insets")) {
                setInsets(spec.optString("insets"));
            }
            if (spec.has("corners")) {
                setCornerRadii(spec.optString("corners"));
            }
            if (spec.has("gradientAngle")) {
                setGradientAngle((double) ((float) spec.optDouble("gradientAngle")));
            }
            updatePaints();
            if (!(((this.mOuterShadowBlur == 0.0f && (this.mOuterShadowColor >> 24) == 0) || (this.mInsets[0] <= 0.0f && this.mInsets[1] <= 0.0f && this.mInsets[2] <= 0.0f && this.mInsets[3] <= 0.0f)) && this.mInnerShadowBlur == 0.0f && (this.mInnerShadowColor >> 24) == 0)) {
                z = false;
            }
            this.mCanDrawHW = z;
        }

        public UIGradientDefinition() {
        }

        public UIGradientDefinition(String json) {
            try {
                set(new JSONObject(json));
            } catch (Exception e) {
                Log.e("UIGradient", e.toString());
            }
        }
    }
}
