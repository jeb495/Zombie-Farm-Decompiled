package com.ngmoco.gamejs.ui.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import com.ngmoco.gamejs.SimpleImageCache;

public class UIImageButton extends ViewWithState {
    private UIImageDrawable mImageDrawable;
    private UITextDrawable mTextDrawable = new UITextDrawable(this);

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (!this.mTouchable) {
            return false;
        }
        if (super.dispatchTouchEvent(event) || this.mTouchable) {
            return true;
        }
        return false;
    }

    public UITextDrawable getTextDrawable() {
        return this.mTextDrawable;
    }

    public UIImageDrawable getImageDrawable() {
        return this.mImageDrawable;
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.Styleable
    public void setStyle(Style style) {
        this.mImageDrawable.setStyle(style.ensureImageStyle());
        this.mTextDrawable.setStyle(style.ensureTextStyle());
        super.setStyle(style);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState
    public boolean isOpaque() {
        return false;
    }

    /* access modifiers changed from: protected */
    public boolean verifyDrawable(Drawable dr) {
        return dr == this.mTextDrawable || dr == this.mImageDrawable || super.verifyDrawable(dr);
    }

    /* access modifiers changed from: protected */
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.mTextDrawable.setBounds(0, 0, w, h);
        this.mImageDrawable.setBounds(0, 0, w, h);
    }

    /* access modifiers changed from: protected */
    public void onDraw(Canvas canvas) {
        this.mImageDrawable.draw(canvas);
        this.mTextDrawable.draw(canvas);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.ViewWithState, com.ngmoco.gamejs.ui.widgets.StatefulWidget
    public void stateChanged() {
        int applyState = this.mState | this.mTransientState;
        this.mTextDrawable.setControlState(applyState);
        this.mImageDrawable.setControlState(applyState);
        ((UIDrawable) getBackground()).setControlState(applyState);
    }

    public UIImageButton(Context context, SimpleImageCache imageCache) {
        super(context);
        this.mImageDrawable = new UIImageDrawable(this, imageCache);
        setSoundEffectsEnabled(false);
        setBackgroundDrawable(new UIDrawable(this));
        requestLayout();
    }
}
