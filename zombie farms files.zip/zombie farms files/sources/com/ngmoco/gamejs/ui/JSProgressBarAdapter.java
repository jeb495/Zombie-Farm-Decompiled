package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.SplashScreen;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIProgressBar;

public class JSProgressBarAdapter extends AbstractJSViewAdapter {
    private JSProgressBarAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSProgressBarAdapter(jsContext, objId).createView();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIProgressBar(this.mJSContext.getActivity());
        super.createView();
        return this;
    }

    private void useForUpdateProgress(boolean shouldUse) {
        SplashScreen.setUpdateProgressBar((UIProgressBar) this.mView, shouldUse);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        UIProgressBar progressBar = (UIProgressBar) this.mView;
        switch (commandId) {
            case Commands.CommandIDs.setProgressGradient:
                progressBar.setProgressGradient((String) args[0], subCommand);
                return this;
            case Commands.CommandIDs.setSecondaryGradient:
                progressBar.setSecondaryGradient((String) args[0], subCommand);
                return this;
            case 101:
                progressBar.setValue(((Float) args[0]).floatValue());
                progressBar.setSecondaryValue(((Float) args[1]).floatValue());
                return this;
            case Commands.CommandIDs.useForUpdateProgress:
                useForUpdateProgress(((Boolean) args[0]).booleanValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public void cleanup() {
        useForUpdateProgress(false);
    }
}
