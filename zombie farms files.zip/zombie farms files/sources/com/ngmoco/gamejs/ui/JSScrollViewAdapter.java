package com.ngmoco.gamejs.ui;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.ScrollingView;
import com.ngmoco.gamejs.ui.widgets.UIHorizontalScrollView;
import com.ngmoco.gamejs.ui.widgets.UIScrollAnimation;
import com.ngmoco.gamejs.ui.widgets.UIScrollListener;
import com.ngmoco.gamejs.ui.widgets.UIScrollView;
import org.json.JSONArray;

public class JSScrollViewAdapter extends AbstractJSViewAdapter implements JSViewGroupAdapter, UIScrollListener {
    protected JSONArray mEventPosition = new JSONArray();
    protected boolean mIsHorizontal;

    /* access modifiers changed from: protected */
    public boolean canTransform() {
        return true;
    }

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSScrollViewAdapter(jsContext, objId).createView();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIScrollListener
    public void onScrollChanged(int x, int y, int oldX, int oldY) {
        try {
            this.mEventPosition.put(0, x);
            this.mEventPosition.put(1, y);
            sendEventResponse(AbstractJSAdapter.Events.SCROLL, "scrollPosition", this.mEventPosition);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIScrollListener
    public void onScrollEnded() {
        Log.d("SCROLL", AbstractJSAdapter.Events.SCROLL_ENDED);
        triggerCustomEventResponse(AbstractJSAdapter.Events.SCROLL_ENDED, new Object[0]);
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIScrollView(this.mJSContext.getActivity());
        ((UIScrollView) this.mView).setOnScrollListener(this);
        return super.createView();
    }

    /* JADX WARN: Type inference failed for: r12v6, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARN: Type inference failed for: r12v7, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 2 */
    private void resolveSize() {
        View newView;
        FrameLayout frameLayout = (FrameLayout) this.mView;
        ScrollingView scrollView = (ScrollingView) this.mView;
        int cW = scrollView.getContentWidth();
        int cH = scrollView.getContentHeight();
        if (cW > 0 || cH > 0) {
            int w = this.mView.getWidth();
            int h = this.mView.getHeight();
            boolean shouldTransform = this.mView instanceof HorizontalScrollView ? cH > h : cW > w;
            boolean beHorizontal = ((float) cW) / ((float) w) > ((float) cH) / ((float) h);
            if (shouldTransform && canTransform() && beHorizontal != (this.mView instanceof UIHorizontalScrollView)) {
                Log.d("ScrollView", "Horizontal? " + (beHorizontal ? "YES" : "NO"));
                if (beHorizontal) {
                    newView = new UIHorizontalScrollView(this.mJSContext.getActivity(), (UIScrollView) this.mView);
                } else {
                    newView = new UIScrollView(this.mJSContext.getActivity(), (UIHorizontalScrollView) this.mView);
                }
                ((ScrollingView) newView).setOnScrollListener(this);
                ViewGroup g = (ViewGroup) this.mView.getParent();
                if (g != null) {
                    int index = g.indexOfChild(this.mView);
                    g.removeView(this.mView);
                    g.addView(newView, index);
                }
                this.mView = newView;
            }
            if (this.mView instanceof UIScrollView) {
                this.mView.setVerticalScrollBarEnabled(cH > h);
            } else if (this.mView instanceof UIHorizontalScrollView) {
                this.mView.setHorizontalScrollBarEnabled(cW > w);
            }
        }
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 12:
                addSubview((JSViewAdapter) this.mJSContext.getAdapter((Integer) args[0]), ((Integer) args[1]).intValue());
                return this;
            case 16:
                super.handleCommand(commandId, subCommand, args);
                resolveSize();
                return this;
            case Commands.CommandIDs.setScrollPosition:
                this.mView.clearAnimation();
                if (this.mJSContext.getAnimationBlock() != null) {
                    this.mJSContext.getAnimationBlock().addAnimation(this.mView, new UIScrollAnimation(this.mView, ((ScrollingView) this.mView).getScrollX(), ((ScrollingView) this.mView).getScrollY(), ((Float) args[0]).intValue(), ((Float) args[1]).intValue()));
                    return this;
                }
                this.mView.scrollTo(((Float) args[0]).intValue(), ((Float) args[1]).intValue());
                return this;
            case Commands.CommandIDs.setScrollableSize:
                ((ScrollingView) this.mView).setContentSize(((Float) args[0]).intValue(), ((Float) args[1]).intValue());
                resolveSize();
                return this;
            case Commands.CommandIDs.setScrollIndicatorsVisible:
                this.mView.setHorizontalScrollBarEnabled(((Boolean) args[0]).booleanValue());
                this.mView.setVerticalScrollBarEnabled(((Boolean) args[0]).booleanValue());
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSViewGroupAdapter
    public JSViewGroupAdapter addSubview(JSViewAdapter newSub, int atIndex) throws Exception {
        ScrollingView scrollView = (ScrollingView) this.mView;
        View widget = newSub.getView();
        if (atIndex < 0) {
            scrollView.addContainedView(widget);
        } else {
            scrollView.addContainedView(widget, atIndex);
        }
        return this;
    }

    protected JSScrollViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }
}
