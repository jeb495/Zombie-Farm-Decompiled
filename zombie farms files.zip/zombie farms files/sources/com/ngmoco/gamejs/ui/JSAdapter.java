package com.ngmoco.gamejs.ui;

public interface JSAdapter {
    void cleanup();

    JSAdapter enableEventResponse(String str, boolean z) throws Exception;

    JSAdapter handleCommand(int i, int i2, Object[] objArr) throws Exception;

    boolean isEventResponseEnabled(String str);

    void setJSContext(Commands commands);

    JSAdapter triggerCustomEventResponse(String str, Object... objArr) throws Exception;
}
