package com.ngmoco.gamejs.ui;

import com.ngmoco.gamejs.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class JSViewAdapterFactory {
    private static final Class[] ARG_TYPES = {Commands.class, Integer.class};
    private static final String TAG = "JSViewAdapterFactory";
    private static HashMap<String, Method> mAdapterMethods = new HashMap<>();

    static {
        register(JSAbsoluteLayoutAdapter.class, "view");
        register(JSImageButtonAdapter.class, "button");
        register(JSTextViewAdapter.class, "label");
        register(JSScrollViewAdapter.class, "scrollview");
        register(JSListViewAdapter.class, "listview");
        register(JSListViewSection.class, "listview-section");
        register(JSGLAdapter.class, "glview");
        register(JSImageViewAdapter.class, "image");
        register(JSEditTextAdapter.class, "edittext");
        register(JSEditTextAreaAdapter.class, "edittextarea");
        register(JSCheckBoxAdapter.class, "checkbox");
        register(JSAlertDialogAdapter.class, "alertdialog");
        register(JSProgressDialogAdapter.class, "progressdialog");
        register(JSAdViewAdapter.class, "adview");
        register(JSToastViewAdapter.class, "toast");
        register(JSDocumentViewAdapter.class, "documentview");
        register(JSWebViewAdapter.class, "webview");
        register(JSCheckoutViewAdapter.class, "checkoutview");
        register(JSSpinnerAdapter.class, "spinner");
        register(JSCellViewAdapter.class, "cell");
        register(JSProgressBarAdapter.class, "progressbar");
        register(JSMapViewAdapter.class, "mapview");
        register(JSMapAnnotationAdapter.class, "mapannotation");
        register(JSWindowLayerAdapter.class, "windowlayer");
        register(JSStyleAdapter.class, "style");
        register(CutSceneViewAdapter.class, "_cutsceneview");
    }

    public static void register(Class aClass, String className) {
        try {
            mAdapterMethods.put(className, aClass.getMethod("newInstance", ARG_TYPES));
        } catch (Exception e) {
            Log.e(TAG, "Could not register name " + className + " for class " + aClass);
        }
    }

    public static JSAdapter getAdapter(Commands jsContext, Integer objId, String widgetName) throws Exception {
        Method method = mAdapterMethods.get(widgetName);
        if (method == null) {
            throw new Exception(String.format("Cannot instantiate widget of type: %s", widgetName));
        }
        try {
            return (JSAdapter) method.invoke(null, jsContext, objId);
        } catch (InvocationTargetException e) {
            Exception cause = (Exception) e.getTargetException();
            if (cause != null) {
                throw cause;
            }
            throw e;
        }
    }
}
