package com.ngmoco.gamejs.ui;

import android.os.PowerManager;
import android.view.ViewGroup;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.NgJNI;
import com.ngmoco.gamejs.activity.GameJSActivity;
import com.ngmoco.gamejs.activity.JSActivity;
import com.ngmoco.gamejs.gl.GameJSView;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;

public class JSGLAdapter extends AbstractJSViewAdapter {
    private static final String TAG = "JSGLAdapter";
    private static volatile JSGLAdapter sInstance = null;
    private boolean mInitialized = false;

    static class Properties {
        protected static final String ACTIVE = "active";

        Properties() {
        }
    }

    public static JSGLAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return getInstance(jsContext, objId);
    }

    public static JSGLAdapter getInstance(Commands jsContext, Integer objId) throws Exception {
        Log.d(TAG, "Who called me ?");
        if (sInstance != null) {
            return sInstance;
        }
        JSGLAdapter temp = new JSGLAdapter(jsContext, objId);
        temp.createView();
        Log.d(TAG, "GameJSView created");
        sInstance = temp;
        return temp;
    }

    public static JSGLAdapter getInstance() {
        if (sInstance == null) {
            Log.w(TAG, "Attempting to access a null glView");
        }
        return sInstance;
    }

    public static synchronized JSGLAdapter restartInstance() throws Exception {
        JSGLAdapter jSGLAdapter;
        synchronized (JSGLAdapter.class) {
            if (sInstance != null) {
                JSGLAdapter oldInstance = sInstance;
                clearInstance();
                sInstance = new JSGLAdapter(oldInstance.mJSContext, oldInstance.mObjId);
                sInstance.mView = new GameJSView(sInstance.activityToGameJSActivity());
                sInstance.mView.setLayoutParams(oldInstance.mView.getLayoutParams());
                sInstance.enableEventResponse(AbstractJSAdapter.Events.LOAD, true);
                sInstance.init();
                jSGLAdapter = sInstance;
            } else {
                throw new NullPointerException("Attempting to restart a null glView");
            }
        }
        return jSGLAdapter;
    }

    public static void clearInstance() throws Exception {
        Log.d(TAG, "clearing instance...");
        if (sInstance != null) {
            JSWindowLayerAdapter.removeChild(sInstance.mView);
            sInstance = null;
        }
    }

    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = activityToGameJSActivity().getGLView();
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 4:
                if (!((Boolean) args[0]).booleanValue()) {
                    ((GameJSView) this.mView).onPauseRendering();
                    return this;
                } else if (!this.mInitialized) {
                    init();
                    return this;
                } else {
                    ((GameJSView) this.mView).onResumeRendering();
                    return this;
                }
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    public void onScreenSizeChanged(int w, int h) {
        if (!NgJNI.isGamePaused() && ((PowerManager) this.mJSContext.getActivity().getSystemService("power")).isScreenOn()) {
            this.mView.setLayoutParams(new ViewGroup.LayoutParams(w, h));
            this.mView.measure(w, h);
            this.mView.layout(0, 0, w, h);
        }
    }

    private JSGLAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    private void init() throws Exception {
        if (this.mView == null) {
            throw new Exception("GameJSView not created.");
        }
        ((GameJSView) this.mView).init();
        this.mJSContext.addChildToRoot(this.mView, 0);
        this.mInitialized = true;
    }

    public void pause() {
        if (this.mView != null) {
            ((GameJSView) this.mView).onPause();
        }
    }

    public void resume() {
        if (this.mView != null) {
            ((GameJSView) this.mView).onResume();
        }
    }

    private GameJSActivity activityToGameJSActivity() throws Exception {
        JSActivity activity = this.mJSContext.getActivity();
        if (activity instanceof GameJSActivity) {
            return (GameJSActivity) activity;
        }
        throw new Exception("Using GLView in an Activity that is not an instance of GameJSActivity.");
    }
}
