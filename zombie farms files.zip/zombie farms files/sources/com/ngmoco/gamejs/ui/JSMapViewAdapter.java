package com.ngmoco.gamejs.ui;

import com.millennialmedia.android.MMAdView;
import com.mobage.ww.a465.zombiefarm_android.R;
import com.ngmoco.gamejs.Log;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIMapView;
import com.ngmoco.gamejs.ui.widgets.UIMapViewListener;

public class JSMapViewAdapter extends AbstractJSViewAdapter implements UIMapViewListener {
    private static volatile JSMapViewAdapter sInstance = null;

    private JSMapViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIMapViewListener
    public void onRegionChange(double lat, double lon, double latD, double lonD) {
        if (this.mCustomEventResponses.containsKey(AbstractJSAdapter.Events.REGION_CHANGE)) {
            try {
                triggerCustomEventResponse(AbstractJSAdapter.Events.REGION_CHANGE, MMAdView.KEY_LATITUDE, String.valueOf(lat / 1000000.0d), MMAdView.KEY_LONGITUDE, String.valueOf(lon / 1000000.0d), "latitudeDelta", String.valueOf(latD / 1000000.0d), "longitudeDelta", String.valueOf(lonD / 1000000.0d));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static JSViewAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return getInstance(jsContext, objId);
    }

    public static JSMapViewAdapter getInstance(Commands jsContext, Integer objId) throws Exception {
        if (sInstance == null) {
            JSMapViewAdapter temp = new JSMapViewAdapter(jsContext, objId);
            temp.createView();
            sInstance = temp;
            return temp;
        }
        Log.d("UImapView", "already exists, just returning instance");
        sInstance.removeFromSuperview();
        return sInstance;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [com.ngmoco.gamejs.ui.widgets.UIMapView, android.view.View] */
    /* JADX WARN: Type inference failed for: r1v1, types: [android.content.Context, com.ngmoco.gamejs.activity.JSActivity] */
    /* JADX WARNING: Unknown variable types count: 2 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIMapView(this.mJSContext.getActivity(), this.mJSContext.getActivity().getString(R.string.google_maps_api_key));
        ((UIMapView) this.mView).setMapViewListener(this);
        super.createView();
        return this;
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        if (this.mView == null) {
            throw new NullPointerException("View is not initialized for an update");
        }
        UIMapView mapView = (UIMapView) this.mView;
        switch (commandId) {
            case Commands.CommandIDs.setScrollable:
                mapView.setClickable(((Boolean) args[0]).booleanValue());
                return this;
            case Commands.CommandIDs.setZoomable:
                mapView.setZoomable(((Boolean) args[0]).booleanValue());
                return this;
            case Commands.CommandIDs.addAnnotation:
                JSMapAnnotationAdapter newAnnotation = (JSMapAnnotationAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                if (newAnnotation == null) {
                    return this;
                }
                mapView.addAnnotation(newAnnotation.getAnnotation());
                return this;
            case Commands.CommandIDs.removeAnnotation:
                JSMapAnnotationAdapter annotation = (JSMapAnnotationAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                if (annotation == null) {
                    return this;
                }
                mapView.removeAnnotation(annotation.getAnnotation());
                return this;
            case Commands.CommandIDs.selectAnnotation:
                JSMapAnnotationAdapter selectedannotation = (JSMapAnnotationAdapter) this.mJSContext.getAdapter((Integer) args[0]);
                if (selectedannotation != null) {
                    mapView.selectAnnotation(selectedannotation.getAnnotation());
                    return this;
                }
                mapView.selectAnnotation(null);
                return this;
            case Commands.CommandIDs.setRegion:
                mapView.setRegion(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue(), ((Float) args[2]).floatValue(), ((Float) args[3]).floatValue(), ((Boolean) args[4]).booleanValue());
                return this;
            case Commands.CommandIDs.setView:
            case Commands.CommandIDs.setCoordinate:
            case Commands.CommandIDs.setCalloutTitle:
            case Commands.CommandIDs.setCalloutSubtitle:
            case Commands.CommandIDs.setCalloutEnabled:
            case Commands.CommandIDs.setCalloutLeftView:
            case Commands.CommandIDs.setCalloutRightView:
            default:
                return super.handleCommand(commandId, subCommand, args);
            case Commands.CommandIDs.setCenterOffset:
                mapView.setCenter(((Float) args[0]).floatValue(), ((Float) args[1]).floatValue());
                return this;
        }
    }
}
