package com.ngmoco.gamejs.ui;

import android.widget.Toast;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.widgets.UIToastListener;
import com.ngmoco.gamejs.ui.widgets.UIToastView;

public class JSToastViewAdapter extends AbstractJSViewAdapter implements UIToastListener {
    private Toast mToast;

    public static JSAdapter newInstance(Commands jsContext, Integer objId) throws Exception {
        return new JSToastViewAdapter(jsContext, objId).createView();
    }

    public void hide() {
        this.mToast.cancel();
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [com.ngmoco.gamejs.activity.JSActivity, android.app.Activity] */
    /* JADX WARNING: Unknown variable types count: 1 */
    @Override // com.ngmoco.gamejs.ui.JSViewAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSViewAdapter createView() throws Exception {
        this.mView = new UIToastView(this.mJSContext.getActivity());
        ((UIToastView) this.mView).setToastListener(this);
        this.mToast = new Toast(this.mJSContext.getActivity().getApplicationContext());
        this.mToast.setDuration(1);
        this.mToast.setView(this.mView);
        return super.createView();
    }

    @Override // com.ngmoco.gamejs.ui.widgets.UIToastListener
    public void onHide() {
        triggerCustomEventResponse(AbstractJSAdapter.Events.DISAPPEAR, new Object[0]);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public JSAdapter handleCommand(int commandId, int subCommand, Object[] args) throws Exception {
        switch (commandId) {
            case 16:
                return this;
            case Commands.CommandIDs.setText:
                ((UIToastView) this.mView).setText((String) args[0]);
                return this;
            case Commands.CommandIDs.show:
                this.mToast.show();
                return this;
            case Commands.CommandIDs.hide:
                hide();
                return this;
            default:
                return super.handleCommand(commandId, subCommand, args);
        }
    }

    private JSToastViewAdapter(Commands jsContext, Integer objId) {
        super(jsContext, objId);
    }

    @Override // com.ngmoco.gamejs.ui.AbstractJSAdapter, com.ngmoco.gamejs.ui.JSAdapter, com.ngmoco.gamejs.ui.AbstractJSViewAdapter
    public void cleanup() {
        if (this.mToast != null) {
            this.mToast.cancel();
            this.mToast = null;
        }
        super.cleanup();
    }
}
