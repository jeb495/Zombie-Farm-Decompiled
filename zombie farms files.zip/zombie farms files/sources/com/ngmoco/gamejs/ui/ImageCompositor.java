package com.ngmoco.gamejs.ui;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import com.ngmoco.gamejs.SimpleImageObserver;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ImageCompositor implements Operation, Runnable {
    Bitmap mBitmap;
    String mCallback;
    boolean mCanceled = false;
    Canvas mCanvas;
    String mFilename;
    boolean mFinishWasCalled = false;
    private Handler mHandler = null;
    Commands mJSContext;
    Paint mPaint;
    ArrayList<PendingPlacement> mPendingPlacements = new ArrayList<>();
    private volatile boolean wroteFile = false;

    @Override // com.ngmoco.gamejs.ui.Operation
    public void cancel() {
        Iterator i$ = this.mPendingPlacements.iterator();
        while (i$.hasNext()) {
            this.mJSContext.getImageCache().removeObserver(i$.next());
        }
        this.mPendingPlacements.clear();
    }

    /* access modifiers changed from: private */
    public class PendingPlacement implements SimpleImageObserver {
        Rect mDstR = null;
        int mFit = 1;
        float[] mGravity = {0.5f, 0.5f};
        Bitmap mImage = null;
        JSONObject mInfo;
        float[] mInsets = {0.0f, 0.0f, 0.0f, 0.0f};
        volatile boolean mLoaded = false;
        volatile boolean mPlaced = false;
        Matrix mTransform = null;

        public int getFit() {
            return this.mFit;
        }

        public void setFit(int newFit) {
            this.mFit = newFit;
        }

        public float[] getInsets() {
            return this.mInsets;
        }

        public void setInsets(float t, float r, float b, float l) {
            this.mInsets[0] = t;
            this.mInsets[1] = r;
            this.mInsets[2] = b;
            this.mInsets[3] = l;
        }

        public float[] getGravity() {
            return this.mGravity;
        }

        public void setGravity(float x, float y) {
            this.mGravity[0] = x;
            this.mGravity[1] = y;
        }

        public Matrix getTransform() {
            return this.mTransform;
        }

        public void setTransform(float a, float b, float c, float d, float tx, float ty) {
            if (a == 1.0f && b == 0.0f && c == 0.0f && d == 1.0f && tx == 0.0f && ty == 0.0f) {
                this.mTransform = null;
                return;
            }
            if (this.mTransform == null) {
                this.mTransform = new Matrix();
            }
            this.mTransform.setValues(new float[]{a, c, tx, b, d, ty, 0.0f, 0.0f, 1.0f});
        }

        @Override // com.ngmoco.gamejs.SimpleImageObserver
        public void setImage(String relativeUrl, Bitmap image) {
            this.mLoaded = true;
            this.mImage = image;
            ImageCompositor.this.mJSContext.getImageCache().removeObserver(this, relativeUrl);
            ImageCompositor.this.tryComposition();
        }

        @Override // com.ngmoco.gamejs.SimpleImageObserver
        public void imageLoadFailed(String relativeUrl, int errorCode, String errorMessage) {
        }

        public void extractJSONParams() {
            try {
                if (this.mInfo.has("rect")) {
                    JSONArray rectSON = this.mInfo.getJSONArray("rect");
                    this.mDstR = new Rect();
                    this.mDstR.left = rectSON.getInt(0);
                    this.mDstR.top = rectSON.getInt(1);
                    this.mDstR.right = this.mDstR.left + rectSON.getInt(2);
                    this.mDstR.bottom = this.mDstR.top + rectSON.getInt(3);
                }
                if (this.mInfo.has("fit")) {
                    setFit(this.mInfo.getInt("fit"));
                }
                if (this.mInfo.has("gravity")) {
                    JSONArray gravitySON = this.mInfo.getJSONArray("gravity");
                    setGravity((float) gravitySON.getDouble(0), (float) gravitySON.getDouble(1));
                }
                if (this.mInfo.has("insets")) {
                    JSONArray insetSON = this.mInfo.getJSONArray("insets");
                    setInsets((float) insetSON.getDouble(0), (float) insetSON.getDouble(1), (float) insetSON.getDouble(2), (float) insetSON.getDouble(3));
                }
                if (this.mInfo.has("transform")) {
                    JSONArray transformSON = this.mInfo.getJSONArray("transform");
                    setTransform((float) transformSON.getDouble(0), (float) transformSON.getDouble(1), (float) transformSON.getDouble(2), (float) transformSON.getDouble(3), (float) transformSON.getDouble(4), (float) transformSON.getDouble(5));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void place() {
            float scaleW;
            float scaleH;
            if (!this.mPlaced && this.mInfo != null && this.mImage != null) {
                try {
                    extractJSONParams();
                    Rect srcR = new Rect(0, 0, this.mImage.getWidth(), this.mImage.getHeight());
                    if (this.mDstR == null) {
                        this.mDstR = new Rect(0, 0, ImageCompositor.this.mBitmap.getWidth(), ImageCompositor.this.mBitmap.getHeight());
                    }
                    if (this.mInsets != null) {
                        Rect rect = this.mDstR;
                        rect.top = (int) (((float) rect.top) + this.mInsets[0]);
                        Rect rect2 = this.mDstR;
                        rect2.right = (int) (((float) rect2.right) - this.mInsets[1]);
                        Rect rect3 = this.mDstR;
                        rect3.bottom = (int) (((float) rect3.bottom) - this.mInsets[2]);
                        Rect rect4 = this.mDstR;
                        rect4.left = (int) (((float) rect4.left) + this.mInsets[3]);
                    }
                    float w = (float) this.mImage.getWidth();
                    float h = (float) this.mImage.getHeight();
                    switch (this.mFit) {
                        case 0:
                            scaleH = 1.0f;
                            scaleW = 1.0f;
                            break;
                        case 1:
                            float scaleW2 = ((float) this.mDstR.width()) / w;
                            scaleH = ((float) this.mDstR.height()) / h;
                            if (scaleW2 < scaleH) {
                                scaleH = scaleW2;
                            }
                            scaleW = scaleH;
                            break;
                        case 2:
                            float scaleW3 = ((float) this.mDstR.width()) / w;
                            scaleH = ((float) this.mDstR.height()) / h;
                            if (scaleW3 > scaleH) {
                                scaleH = scaleW3;
                            }
                            scaleW = scaleH;
                            break;
                        case 3:
                            scaleW = ((float) this.mDstR.width()) / w;
                            scaleH = ((float) this.mDstR.height()) / h;
                            break;
                        case 4:
                        default:
                            scaleH = 1.0f;
                            scaleW = 1.0f;
                            break;
                        case 5:
                            scaleH = ((float) this.mDstR.width()) / w;
                            scaleW = scaleH;
                            break;
                        case 6:
                            scaleH = ((float) this.mDstR.height()) / h;
                            scaleW = scaleH;
                            break;
                        case 7:
                            scaleH = Math.min(1.0f, Math.min(((float) this.mDstR.width()) / w, ((float) this.mDstR.height()) / h));
                            scaleW = scaleH;
                            break;
                    }
                    Rect contentBounds = new Rect(0, 0, Math.round(scaleW * w), Math.round(scaleH * h));
                    Utils.applyGravity(this.mDstR, contentBounds, this.mGravity[0], this.mGravity[1]);
                    int restoreCanvasLevel = 0;
                    if (this.mTransform != null) {
                        restoreCanvasLevel = ImageCompositor.this.mCanvas.save();
                        float cX = ((float) contentBounds.width()) / 2.0f;
                        float cY = ((float) contentBounds.height()) / 2.0f;
                        this.mTransform.preTranslate(-cX, -cY);
                        this.mTransform.postTranslate(cX, cY);
                        ImageCompositor.this.mCanvas.concat(this.mTransform);
                    }
                    ImageCompositor.this.mCanvas.drawBitmap(this.mImage, srcR, contentBounds, ImageCompositor.this.mPaint);
                    if (restoreCanvasLevel > 0) {
                        ImageCompositor.this.mCanvas.restoreToCount(restoreCanvasLevel);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    this.mPlaced = true;
                }
            }
        }

        public PendingPlacement(JSONObject info) throws JSONException {
            this.mInfo = info;
            ImageCompositor.this.mJSContext.getImageCache().addObserver(this, info.getString("image"));
        }

        public PendingPlacement(JSONObject info, Bitmap image) throws JSONException {
            this.mInfo = info;
            this.mImage = image;
            this.mLoaded = true;
            ImageCompositor.this.tryComposition();
        }
    }

    private String pathJoin(String a, String b) {
        boolean aLast;
        boolean bFirst;
        if (a.length() <= 0 || a.charAt(a.length() - 1) != '/') {
            aLast = false;
        } else {
            aLast = true;
        }
        if (b.length() <= 0 || b.charAt(0) != '/') {
            bFirst = false;
        } else {
            bFirst = true;
        }
        if (aLast && bFirst) {
            return a + b.substring(1);
        }
        if (aLast != bFirst) {
            return a + b;
        }
        return a + "/" + b;
    }

    private synchronized Handler getHandler() {
        if (this.mHandler == null || this.mHandler.getLooper() == null || this.mHandler.getLooper().getThread() == null || !this.mHandler.getLooper().getThread().isAlive()) {
            HandlerThread thread = new HandlerThread(getClass().getSimpleName());
            thread.start();
            this.mHandler = new Handler(thread.getLooper());
        }
        return this.mHandler;
    }

    private synchronized void disposeHandler() {
        if (this.mHandler != null) {
            Looper l = this.mHandler.getLooper();
            if (l != null) {
                l.quit();
            }
            this.mHandler = null;
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void tryComposition() {
        if (!this.wroteFile) {
            getHandler().post(this);
        }
    }

    public synchronized void run() {
        if (!this.mCanceled && !this.wroteFile) {
            Iterator i$ = this.mPendingPlacements.iterator();
            while (true) {
                if (i$.hasNext()) {
                    PendingPlacement p = i$.next();
                    if (!p.mLoaded) {
                        break;
                    } else if (!p.mPlaced) {
                        p.place();
                    }
                } else if (this.mFinishWasCalled) {
                    if (!this.wroteFile) {
                        try {
                            FileOutputStream f = new FileOutputStream(pathJoin(this.mJSContext.getManifestRoot(), this.mFilename));
                            if (this.mFilename.toLowerCase().endsWith(".jpg")) {
                                this.wroteFile = this.mBitmap.compress(Bitmap.CompressFormat.JPEG, 75, f);
                            } else {
                                this.wroteFile = this.mBitmap.compress(Bitmap.CompressFormat.PNG, 0, f);
                            }
                            if (!this.wroteFile) {
                                throw new Exception("File Compression Failed");
                            }
                            f.flush();
                            f.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        JSONObject j = new JSONObject();
                        j.put(NgSystemBindingService.EXTRA_NAME, "callback");
                        j.put("callback_id", this.mCallback);
                        j.put("filename", this.mFilename);
                        this.mJSContext.sendEvent(j.toString());
                    } catch (JSONException e2) {
                        e2.printStackTrace();
                    } finally {
                        this.mJSContext.removeOperation(this);
                        disposeHandler();
                    }
                }
            }
        }
    }

    public synchronized void addImage(JSONObject info) throws JSONException {
        if (!this.mCanceled) {
            this.mPendingPlacements.add(new PendingPlacement(info));
        }
    }

    public synchronized void addImage(JSONObject info, Bitmap image) throws JSONException {
        if (!this.mCanceled) {
            this.mPendingPlacements.add(new PendingPlacement(info, image));
        }
    }

    public void finish() {
        if (!this.mCanceled) {
            this.mFinishWasCalled = true;
            tryComposition();
        }
    }

    public ImageCompositor(int w, int h, String filename, String callbackId, Commands jsContext) {
        this.mJSContext = jsContext;
        this.mCallback = callbackId;
        this.mFilename = filename;
        this.mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        this.mCanvas = new Canvas(this.mBitmap);
        this.mCanvas.drawColor(0);
        this.mPaint = new Paint(7);
        this.mJSContext.addOperation(this);
    }
}
