package com.ngmoco.gamejs;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import com.mobage.ww.a465.zombiefarm_android.R;
import java.io.IOException;

public class NgAudio {
    public static final String TAG = "NgAudio";
    private static NgAudio sInstance;
    private AudioManager audioManager;
    private int deviceMaxVolume;
    private int lastVolume;
    private SoundPoolAudioManager spAudioManager = null;
    private boolean suspended;

    public static native void enableOpenSLBackend(String str);

    public static native void muteOpenSLBackend(boolean z);

    public static native void playCompleted(int i);

    public static NgAudio getInstance() {
        return sInstance;
    }

    public static SoundPool getSoundPool() {
        return sInstance.spAudioManager.getSoundPool();
    }

    public NgAudio(Context context) {
        boolean useOpenSL = false;
        if (sInstance != null) {
            Log.e(TAG, "instance is already created");
            return;
        }
        this.audioManager = (AudioManager) context.getSystemService("audio");
        this.deviceMaxVolume = this.audioManager.getStreamMaxVolume(3);
        this.lastVolume = this.audioManager.getStreamVolume(3);
        this.suspended = false;
        boolean hasOpenSL = false;
        try {
            System.loadLibrary("OpenSLES");
            hasOpenSL = true;
        } catch (UnsatisfiedLinkError e) {
        }
        String useOpenSLinXML = context.getString(R.string.useOpenSL);
        if (useOpenSLinXML != null && useOpenSLinXML.equals("true")) {
            useOpenSL = true;
        }
        boolean usingOpenSL = false;
        if (hasOpenSL && useOpenSL) {
            try {
                enableOpenSLBackend(context.getApplicationInfo().dataDir + "/lib/");
                usingOpenSL = true;
            } catch (Throwable th) {
            }
        }
        if (!usingOpenSL) {
            this.spAudioManager = new SoundPoolAudioManager(context);
        }
        sInstance = this;
    }

    public void setRingerMode(int ringerMode) {
        this.audioManager.setRingerMode(ringerMode);
        if (ringerMode == 2) {
            this.audioManager.setStreamMute(3, false);
        } else {
            this.audioManager.setStreamMute(3, true);
        }
    }

    public void kill() {
        if (this.spAudioManager != null) {
            this.spAudioManager.reset();
        }
    }

    public void suspend(boolean toSuspend) {
        this.suspended = toSuspend;
        if (this.spAudioManager == null) {
            muteOpenSLBackend(toSuspend);
        } else {
            this.spAudioManager.suspend(toSuspend);
        }
    }

    public boolean isSuspend() {
        return this.suspended;
    }

    public static void reset() {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.reset();
        }
    }

    public static void update() {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.update();
        }
    }

    public static boolean isFinished(int soundID) {
        if (sInstance.spAudioManager != null) {
            return sInstance.spAudioManager.isFinished(soundID);
        }
        return false;
    }

    public static float getDeviceVolume() {
        if (sInstance == null || sInstance.audioManager == null || sInstance.deviceMaxVolume == 0) {
            return 1.0f;
        }
        return ((float) sInstance.audioManager.getStreamVolume(3)) / ((float) sInstance.deviceMaxVolume);
    }

    public static void setDeviceVolume(float volume) {
        int nextVolume = (int) (((float) sInstance.deviceMaxVolume) * volume);
        if (nextVolume == 0) {
            sInstance.audioManager.setRingerMode(0);
        } else if (sInstance.lastVolume == 0) {
            sInstance.audioManager.setRingerMode(2);
        }
        sInstance.audioManager.setStreamVolume(3, nextVolume, 0);
        sInstance.lastVolume = nextVolume;
    }

    public static int play(int soundID) {
        if (sInstance.spAudioManager != null) {
            return sInstance.spAudioManager.play(soundID);
        }
        return -1;
    }

    public static void pause(int soundID) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.pause(soundID);
        }
    }

    public static int load(String path) {
        if (sInstance.spAudioManager != null) {
            return sInstance.spAudioManager.load(NgMediaSource.createFromPath(path));
        }
        return -1;
    }

    public static int load(byte[] data) {
        if (sInstance.spAudioManager != null) {
            try {
                return sInstance.spAudioManager.load(NgMediaSource.createFromBytes(data));
            } catch (IOException e) {
                Log.e(TAG, "NgAudio: failed to load data: " + e.getMessage());
            }
        }
        return -1;
    }

    public static void unload(int streamID) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.unload(streamID);
        }
    }

    public static int createSound(int streamID) {
        if (sInstance.spAudioManager != null) {
            return sInstance.spAudioManager.createSound(streamID);
        }
        return -1;
    }

    public static void deleteSound(int soundID) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.deleteSound(soundID);
        }
    }

    public static void stop(int soundID) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.stop(soundID);
        }
    }

    public static void setSoundVolume(int soundID, float volume) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.setSoundVolume(soundID, volume);
        }
    }

    public static void setLoops(int soundID, boolean loops) {
        if (sInstance.spAudioManager != null) {
            sInstance.spAudioManager.setLoops(soundID, loops);
        }
    }

    public static boolean isPlaying(int soundID) {
        if (sInstance.spAudioManager != null) {
            return sInstance.spAudioManager.isPlaying(soundID);
        }
        return false;
    }
}
