package com.mobclix.android.sdk;

public class MobclixSimpleAdViewListener implements MobclixAdViewListener {
    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onSuccessfulLoad(MobclixAdView adView) {
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onFailedLoad(MobclixAdView adView, int errorCode) {
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onAdClick(MobclixAdView adView) {
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public void onCustomAdTouchThrough(MobclixAdView adView, String string) {
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public boolean onOpenAllocationLoad(MobclixAdView adView, int openAllocationCode) {
        return false;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public String keywords() {
        return null;
    }

    @Override // com.mobclix.android.sdk.MobclixAdViewListener
    public String query() {
        return null;
    }
}
