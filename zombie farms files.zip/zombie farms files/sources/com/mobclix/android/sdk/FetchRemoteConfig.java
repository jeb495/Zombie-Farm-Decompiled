package com.mobclix.android.sdk;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.mobclix.android.sdk.Mobclix;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import com.tapjoy.TapjoyConstants;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

/* access modifiers changed from: package-private */
/* compiled from: MobclixConfig */
public class FetchRemoteConfig extends AsyncTask<String, Integer, JSONArray> {
    private static String TAG = "MobclixConfig";
    private static boolean running = false;
    Mobclix c = Mobclix.getInstance();
    private MobclixInstrumentation instrumentation = MobclixInstrumentation.getInstance();
    private String url;

    FetchRemoteConfig() {
    }

    /* JADX WARNING: Removed duplicated region for block: B:127:0x0872 A[LOOP:1: B:23:0x0152->B:127:0x0872, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x0a45  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x0a6d  */
    /* JADX WARNING: Removed duplicated region for block: B:188:0x0166 A[EDGE_INSN: B:188:0x0166->B:25:0x0166 ?: BREAK  , SYNTHETIC] */
    public JSONArray doInBackground(String... strings) {
        BufferedReader br;
        if (running) {
            return null;
        }
        running = true;
        if (this.instrumentation == null) {
            this.instrumentation = MobclixInstrumentation.getInstance();
        }
        String instrPath = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.startGroup(MobclixInstrumentation.STARTUP), "config"), "update_session");
        this.c.updateSession();
        JSONArray appAlerts = null;
        String instrPath2 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath), AbstractJSAdapter.Events.UPDATE), "parse_cache"), "load_misc_settings");
        try {
            if (Mobclix.hasPref("deviceId")) {
                String prefDeviceId = Mobclix.getPref("deviceId");
                if (!prefDeviceId.equals(this.c.deviceId)) {
                    this.c.previousDeviceId = prefDeviceId;
                }
            } else {
                this.c.isNewUser = true;
                Mobclix.addPref("deviceId", this.c.deviceId);
            }
        } catch (Exception e) {
        }
        if (Mobclix.hasPref("idleTimeout")) {
            this.c.idleTimeout = Integer.parseInt(Mobclix.getPref("idleTimeout"));
        }
        if (Mobclix.hasPref("pollTime")) {
            this.c.pollTime = Integer.parseInt(Mobclix.getPref("pollTime"));
        }
        String instrPath3 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath2), "load_adunits");
        String[] strArr = Mobclix.MC_AD_SIZES;
        int length = strArr.length;
        for (int i = 0; i < length; i++) {
            String s = strArr[i];
            if (Mobclix.hasPref(s)) {
                String[] cs = Mobclix.getPref(s).split(",");
                try {
                    Mobclix.enabled.put(s, Boolean.valueOf(cs[0].equals("true")));
                } catch (Exception e2) {
                    Mobclix.enabled.put(s, true);
                }
                try {
                    Mobclix.refreshTime.put(s, Long.valueOf(Long.parseLong(cs[1])));
                } catch (Exception e3) {
                    Mobclix.refreshTime.put(s, 30000L);
                }
                try {
                    Mobclix.autoplay.put(s, Boolean.valueOf(cs[2].equals("true")));
                } catch (Exception e4) {
                    Mobclix.autoplay.put(s, false);
                }
                try {
                    Mobclix.autoplayInterval.put(s, Long.valueOf(Long.parseLong(cs[3])));
                } catch (Exception e5) {
                    Mobclix.autoplayInterval.put(s, 120000L);
                }
                try {
                    Mobclix.rmRequireUser.put(s, Boolean.valueOf(cs[4].equals("true")));
                } catch (Exception e6) {
                    Mobclix.rmRequireUser.put(s, true);
                }
            } else {
                Mobclix.enabled.put(s, true);
                Mobclix.refreshTime.put(s, 30000L);
                Mobclix.autoplay.put(s, false);
                Mobclix.autoplayInterval.put(s, 120000L);
                Mobclix.rmRequireUser.put(s, true);
            }
            Mobclix.customAdSet.put(s, false);
            if (Mobclix.hasPref(String.valueOf(s) + "CustomAdUrl")) {
                Mobclix.customAdUrl.put(s, Mobclix.getPref(String.valueOf(s) + "CustomAdUrl"));
            } else {
                Mobclix.customAdUrl.put(s, ASConstants.kEmptyString);
            }
        }
        String instrPath4 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath3));
        int attempt = 1;
        while (this.c.remoteConfigSet != 1) {
            String instrPath5 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(instrPath4, "attempt_" + attempt), "build_request");
            this.url = getConfigUrl(attempt == 1);
            String instrPath6 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath5), "send_request");
            String response = ASConstants.kEmptyString;
            HttpURLConnection con = null;
            try {
                HttpResponse httpResponse = new Mobclix.MobclixHttpClient(this.url).execute();
                HttpEntity httpEntity = httpResponse.getEntity();
                if (httpResponse.getStatusLine().getStatusCode() == 200) {
                    br = new BufferedReader(new InputStreamReader(httpEntity.getContent()), 8000);
                    try {
                        for (String tmp = br.readLine(); tmp != null; tmp = br.readLine()) {
                            response = String.valueOf(response) + tmp;
                        }
                        httpEntity.consumeContent();
                        instrPath6 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath6), "handle_response");
                        if (!response.equals(ASConstants.kEmptyString)) {
                            try {
                                String instrPath7 = this.instrumentation.benchmarkStart(instrPath6, "decode_json");
                                JSONObject config = new JSONObject(response);
                                String instrPath8 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath7), "save_json");
                                this.instrumentation.addInfo(response, "raw_config_json", MobclixInstrumentation.STARTUP);
                                this.instrumentation.addInfo(config, "decoded_config_json", MobclixInstrumentation.STARTUP);
                                instrPath6 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath8), "load_config");
                                JSONObject urls = config.getJSONObject("urls");
                                this.c.configServer = urls.getString("config");
                                this.c.adServer = urls.getString("ads");
                                this.c.analyticsServer = urls.getString("analytics");
                                this.c.vcServer = urls.getString("vc");
                                this.c.feedbackServer = urls.getString("feedback");
                                this.c.debugServer = urls.getString("debug");
                                this.c.idleTimeout = config.getInt("idle_timeout") * 1000;
                                try {
                                    this.c.pollTime = config.getInt("poll_time") * 1000;
                                } catch (Exception e7) {
                                }
                                this.c.pollTime = Math.min(this.c.pollTime, this.c.idleTimeout);
                                String instrPath9 = this.instrumentation.benchmarkStart(instrPath6, "set_default_values");
                                Map<String, String> rcPrefs = new HashMap<>();
                                rcPrefs.put("ConfigServer", this.c.configServer);
                                rcPrefs.put("AdServer", this.c.adServer);
                                rcPrefs.put("AnalyticsServer", this.c.analyticsServer);
                                rcPrefs.put("VcServer", this.c.vcServer);
                                rcPrefs.put("FeedbackServer", this.c.feedbackServer);
                                rcPrefs.put("idleTimeout", Integer.toString(this.c.idleTimeout));
                                rcPrefs.put("pollTime", Integer.toString(this.c.pollTime));
                                JSONArray adUnits = config.getJSONArray("ad_units");
                                for (int i2 = 0; i2 < adUnits.length(); i2++) {
                                    JSONObject a = adUnits.getJSONObject(i2);
                                    String s2 = a.getString(TapjoyConstants.TJC_DISPLAY_AD_SIZE);
                                    Mobclix.enabled.put(s2, Boolean.valueOf(a.getBoolean("enabled")));
                                    if (a.getLong("refresh") == -1) {
                                        Mobclix.refreshTime.put(s2, -1L);
                                    } else {
                                        Mobclix.refreshTime.put(s2, Long.valueOf(a.getLong("refresh") * 1000));
                                    }
                                    Mobclix.autoplay.put(s2, Boolean.valueOf(a.getBoolean("autoplay")));
                                    if (a.getLong("autoplay_interval") == -1) {
                                        Mobclix.autoplayInterval.put(s2, -1L);
                                    } else {
                                        Mobclix.autoplayInterval.put(s2, Long.valueOf(a.getLong("autoplay_interval") * 1000));
                                    }
                                    Mobclix.rmRequireUser.put(s2, Boolean.valueOf(a.getBoolean("autoplay")));
                                    rcPrefs.put(s2, String.valueOf(Boolean.toString(Mobclix.enabled.get(s2).booleanValue())) + "," + Mobclix.refreshTime.get(s2).toString() + "," + Boolean.toString(Mobclix.autoplay.get(s2).booleanValue()) + "," + Mobclix.autoplayInterval.get(s2).toString() + "," + Boolean.toString(Mobclix.rmRequireUser.get(s2).booleanValue()));
                                    try {
                                        String c2 = a.getString("customAdUrl");
                                        if (c2.equals(Mobclix.customAdUrl.get(s2))) {
                                            Mobclix.customAdUrl.put(s2, ASConstants.kEmptyString);
                                        } else {
                                            Mobclix.removePref(String.valueOf(s2) + "CustomAdUrl");
                                            Mobclix.customAdUrl.put(s2, c2);
                                        }
                                    } catch (Exception e8) {
                                        Mobclix.customAdUrl.put(s2, ASConstants.kEmptyString);
                                    }
                                }
                                try {
                                    JSONObject debug = config.getJSONObject("debug_config");
                                    String[] strArr2 = MobclixInstrumentation.MC_DEBUG_CATS;
                                    int length2 = strArr2.length;
                                    for (int i3 = 0; i3 < length2; i3++) {
                                        Mobclix.removePref("debug_" + strArr2[i3]);
                                    }
                                    Iterator d = debug.keys();
                                    while (d.hasNext()) {
                                        try {
                                            String key = d.next();
                                            String value = debug.getString(key);
                                            Mobclix.debugConfig.put(key, value);
                                            Mobclix.addPref("debug_" + key, value);
                                        } catch (Exception e1) {
                                            Log.v(TAG, "ERROR: " + e1.toString());
                                        }
                                    }
                                } catch (Exception e9) {
                                }
                                try {
                                    appAlerts = config.getJSONArray("app_alerts");
                                } catch (Exception e10) {
                                }
                                try {
                                    JSONArray nUrls = config.getJSONArray("native_urls");
                                    for (int i4 = 0; i4 < nUrls.length(); i4++) {
                                        this.c.nativeUrls.add(nUrls.getString(i4));
                                    }
                                } catch (Exception e11) {
                                }
                                if (this.c.previousDeviceId != null) {
                                    Mobclix.addPref("deviceId", this.c.deviceId);
                                }
                                rcPrefs.put("offlineSessions", "0");
                                rcPrefs.put("totalSessionTime", "0");
                                rcPrefs.put("totalIdleTime", "0");
                                Mobclix.addPref(rcPrefs);
                                if (Mobclix.hasPref("MCReferralData")) {
                                    Mobclix.removePref("MCReferralData");
                                }
                                instrPath6 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath9));
                                this.c.isOfflineSession = false;
                                this.c.remoteConfigSet = 1;
                            } catch (Exception e12) {
                                this.c.remoteConfigSet = -1;
                            }
                        }
                    } catch (Exception e13) {
                        try {
                            this.c.remoteConfigSet = -1;
                            try {
                                br.close();
                            } catch (Exception e14) {
                                this.c.remoteConfigSet = -1;
                            }
                            if (0 != 0) {
                                con.disconnect();
                            }
                            instrPath4 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath6));
                            if (attempt > 1) {
                            }
                        } catch (Throwable th) {
                            th = th;
                            try {
                                br.close();
                            } catch (Exception e15) {
                                this.c.remoteConfigSet = -1;
                            }
                            if (0 != 0) {
                                con.disconnect();
                            }
                            throw th;
                        }
                    }
                } else {
                    this.c.remoteConfigSet = -1;
                    br = null;
                }
                try {
                    br.close();
                } catch (Exception e16) {
                    this.c.remoteConfigSet = -1;
                }
                if (0 != 0) {
                    con.disconnect();
                }
            } catch (Exception e17) {
                br = null;
                this.c.remoteConfigSet = -1;
                br.close();
                if (0 != 0) {
                }
                instrPath4 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath6));
                if (attempt > 1) {
                }
            } catch (Throwable th2) {
                th = th2;
                br = null;
                br.close();
                if (0 != 0) {
                }
                throw th;
            }
            instrPath4 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath6));
            if (attempt > 1) {
                break;
            }
            attempt++;
        }
        if (this.c.remoteConfigSet != 1) {
            String instrPath10 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(instrPath4, "parse_cache"), "load_urls");
            if (Mobclix.hasPref("ConfigServer")) {
                this.c.configServer = Mobclix.getPref("ConfigServer");
            }
            if (Mobclix.hasPref("AdServer")) {
                this.c.adServer = Mobclix.getPref("AdServer");
            }
            if (Mobclix.hasPref("AnalyticsServer")) {
                this.c.analyticsServer = Mobclix.getPref("AnalyticsServer");
            }
            if (Mobclix.hasPref("VcServer")) {
                this.c.vcServer = Mobclix.getPref("VcServer");
            }
            if (Mobclix.hasPref("FeedbackServer")) {
                this.c.feedbackServer = Mobclix.getPref("FeedbackServer");
            }
            this.c.remoteConfigSet = 1;
            this.c.isOfflineSession = true;
            instrPath4 = this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath10));
        }
        this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath4)));
        this.instrumentation.finishGroup(MobclixInstrumentation.STARTUP);
        Mobclix.sync();
        running = false;
        return appAlerts;
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(JSONArray appAlerts) {
        if (appAlerts != null) {
            for (int i = 0; i < appAlerts.length(); i++) {
                try {
                    JSONObject a = appAlerts.getJSONObject(i);
                    String id = a.getString("id");
                    if (id != null && !id.equals(ASConstants.kEmptyString)) {
                        int timesShown = 0;
                        long lastTimeShown = 0;
                        String appAlertPref = Mobclix.getPref("MCAppAlert" + id);
                        if (!appAlertPref.equals(ASConstants.kEmptyString)) {
                            String[] appAlertPrefs = appAlertPref.split(",");
                            try {
                                timesShown = Integer.parseInt(appAlertPrefs[0]);
                            } catch (Exception e) {
                            }
                            try {
                                lastTimeShown = Long.parseLong(appAlertPrefs[1]);
                            } catch (Exception e2) {
                            }
                        }
                        String title = a.getString("title");
                        if (title != null && !title.equals(ASConstants.kEmptyString) && !title.equals("null")) {
                            String message = null;
                            try {
                                message = a.getString("message");
                                if (message == null || message.equals(ASConstants.kEmptyString) || message.equals("null")) {
                                    message = null;
                                }
                            } catch (Exception e3) {
                            }
                            int maxDisplays = 0;
                            try {
                                maxDisplays = a.getInt("max_displays");
                            } catch (Exception e4) {
                            }
                            if (maxDisplays == 0 || timesShown < maxDisplays) {
                                long displayInterval = 0;
                                try {
                                    displayInterval = ((long) a.getInt("display_interval")) * 1000;
                                } catch (Exception e5) {
                                }
                                if (displayInterval == 0 || lastTimeShown + displayInterval < System.currentTimeMillis()) {
                                    JSONArray versions = a.getJSONArray("target_versions");
                                    boolean targeted = false;
                                    for (int j = 0; j < versions.length(); j++) {
                                        try {
                                            String v = versions.getString(j).split("\\*")[0];
                                            if (this.c.getApplicationVersion().substring(0, v.length()).equals(v)) {
                                                targeted = true;
                                            }
                                        } catch (Exception e6) {
                                        }
                                    }
                                    if (targeted) {
                                        String actionButton = null;
                                        try {
                                            actionButton = a.getString("action_button");
                                            if (actionButton == null || actionButton.equals(ASConstants.kEmptyString) || actionButton.equals("null")) {
                                                actionButton = null;
                                            }
                                        } catch (Exception e7) {
                                        }
                                        String actionUrl = null;
                                        try {
                                            actionUrl = a.getString("action_url");
                                            if (actionUrl == null || actionUrl.equals(ASConstants.kEmptyString) || actionUrl.equals("null")) {
                                                actionUrl = null;
                                            }
                                        } catch (Exception e8) {
                                        }
                                        if (actionUrl == null || actionButton != null) {
                                            String dismissButton = null;
                                            try {
                                                dismissButton = a.getString("dismiss_button");
                                                if (dismissButton == null || dismissButton.equals(ASConstants.kEmptyString) || dismissButton.equals("null")) {
                                                    dismissButton = null;
                                                }
                                            } catch (Exception e9) {
                                            }
                                            if (actionUrl != null || dismissButton != null) {
                                                AlertDialog.Builder builder = new AlertDialog.Builder(this.c.getContext());
                                                builder.setTitle(title);
                                                builder.setCancelable(false);
                                                if (message != null) {
                                                    builder.setMessage(message);
                                                }
                                                if (actionUrl != null) {
                                                    builder.setPositiveButton(actionButton, new Mobclix.ObjectOnClickListener(actionUrl) {
                                                        /* class com.mobclix.android.sdk.FetchRemoteConfig.AnonymousClass1 */

                                                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                                                        public void onClick(DialogInterface dialog, int id) {
                                                            FetchRemoteConfig.this.c.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse((String) this.obj1)));
                                                        }
                                                    });
                                                }
                                                if (dismissButton != null) {
                                                    builder.setNegativeButton(dismissButton, new DialogInterface.OnClickListener() {
                                                        /* class com.mobclix.android.sdk.FetchRemoteConfig.AnonymousClass2 */

                                                        public void onClick(DialogInterface dialog, int id) {
                                                            dialog.cancel();
                                                        }
                                                    });
                                                }
                                                builder.create().show();
                                                Mobclix.addPref("MCAppAlert" + id, String.valueOf(Integer.toString(timesShown + 1)) + "," + Long.toString(System.currentTimeMillis()));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e10) {
                }
            }
        }
    }

    private String getConfigUrl(boolean usePref) {
        String configServer = this.c.configServer;
        StringBuffer data = new StringBuffer();
        try {
            if (Mobclix.hasPref("ConfigServer") && usePref) {
                configServer = Mobclix.getPref("ConfigServer");
            }
            data.append(configServer);
            data.append("?p=android");
            data.append("&a=").append(URLEncoder.encode(this.c.getApplicationId(), "UTF-8"));
            data.append("&m=").append(URLEncoder.encode(this.c.getMobclixVersion()));
            data.append("&v=").append(URLEncoder.encode(this.c.getApplicationVersion(), "UTF-8"));
            data.append("&d=").append(URLEncoder.encode(this.c.getDeviceId(), "UTF-8"));
            data.append("&dm=").append(URLEncoder.encode(this.c.getDeviceModel(), "UTF-8"));
            data.append("&dv=").append(URLEncoder.encode(this.c.getAndroidVersion(), "UTF-8"));
            data.append("&hwdm=").append(URLEncoder.encode(this.c.getDeviceHardwareModel(), "UTF-8"));
            data.append("&g=").append(URLEncoder.encode(this.c.getConnectionType(), "UTF-8"));
            if (!this.c.getGPS().equals("null")) {
                data.append("&ll=").append(URLEncoder.encode(this.c.getGPS(), "UTF-8"));
            }
            if (Mobclix.hasPref("offlineSessions")) {
                try {
                    data.append("&off=").append(Mobclix.getPref("offlineSessions"));
                } catch (Exception e) {
                }
            }
            if (Mobclix.hasPref("totalSessionTime")) {
                try {
                    data.append("&st=").append(Mobclix.getPref("totalSessionTime"));
                } catch (Exception e2) {
                }
            }
            if (Mobclix.hasPref("totalIdleTime")) {
                try {
                    data.append("&it=").append(Mobclix.getPref("totalIdleTime"));
                } catch (Exception e3) {
                }
            }
            if (this.c.previousDeviceId != null) {
                data.append("&pd=").append(URLEncoder.encode(this.c.previousDeviceId, "UTF-8"));
            }
            data.append("&mcc=").append(URLEncoder.encode(this.c.getMcc(), "UTF-8"));
            data.append("&mnc=").append(URLEncoder.encode(this.c.getMnc(), "UTF-8"));
            if (this.c.isNewUser) {
                data.append("&new=true");
            }
            try {
                if (Mobclix.hasPref("MCReferralData")) {
                    String referral = Mobclix.getPref("MCReferralData");
                    if (!referral.equals(ASConstants.kEmptyString)) {
                        data.append("&r=").append(referral);
                    }
                }
            } catch (Exception e4) {
            }
            return data.toString();
        } catch (Exception e5) {
            return ASConstants.kEmptyString;
        }
    }

    private void downloadCustomImages() {
        String[] strArr = Mobclix.MC_AD_SIZES;
        for (String s : strArr) {
            String customAdUrl = Mobclix.customAdUrl.get(s);
            if (!customAdUrl.equals(ASConstants.kEmptyString)) {
                try {
                    DefaultHttpClient httpClient = new DefaultHttpClient();
                    HttpGet httpGet = new HttpGet(customAdUrl);
                    httpGet.setHeader("Cookie", Mobclix.getCookieStringFromCookieManager(customAdUrl));
                    HttpEntity httpEntity = httpClient.execute(httpGet).getEntity();
                    Mobclix.syncCookiesToCookieManager(httpClient.getCookieStore(), customAdUrl);
                    Bitmap bmImg = BitmapFactory.decodeStream(httpEntity.getContent());
                    FileOutputStream fos = this.c.getContext().openFileOutput(String.valueOf(s) + "_mc_cached_custom_ad.png", 0);
                    bmImg.compress(Bitmap.CompressFormat.PNG, 90, fos);
                    fos.close();
                    Mobclix.addPref(String.valueOf(s) + "CustomAdUrl", Mobclix.customAdUrl.get(s));
                    Mobclix.customAdSet.put(s, true);
                } catch (Exception e) {
                }
            } else {
                Mobclix.customAdSet.put(s, true);
            }
        }
    }
}
