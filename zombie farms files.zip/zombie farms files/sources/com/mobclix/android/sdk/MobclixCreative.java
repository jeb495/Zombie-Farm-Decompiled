package com.mobclix.android.sdk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Camera;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.text.Html;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;
import android.webkit.CookieSyncManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.android.adsymp.core.ASConstants;
import com.google.ads.AdActivity;
import com.mobclix.android.sdk.Mobclix;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* access modifiers changed from: package-private */
public class MobclixCreative extends ViewFlipper {
    private static final String TAG = "MobclixCreative";
    private static boolean isPlaying = false;
    private Action action;
    private Stack<Thread> asyncRequestThreads = new Stack<>();
    private String creativeId = ASConstants.kEmptyString;
    private Thread customAdThread;
    final ResourceResponseHandler handler = new ResourceResponseHandler();
    private boolean hasAutoplayed = false;
    private boolean initialized = false;
    private MobclixInstrumentation instrumentation = MobclixInstrumentation.getInstance();
    private boolean loop = true;
    private int numPages = 1;
    private ArrayList<String> onLoadUrls = new ArrayList<>();
    private ArrayList<String> onTouchUrls = new ArrayList<>();
    final PageCycleHandler pageCycleHandler = new PageCycleHandler();
    private Timer pageCycleTimer = null;
    MobclixAdView parentAdView;
    boolean trackingPixelsFired = false;
    private int transitionTime = 3000;
    private String transitionType = "none";
    private String type = ASConstants.kEmptyString;
    private int visiblePage = 0;

    MobclixCreative(MobclixAdView a, JSONObject responseObject, boolean ap) {
        super(a.getContext());
        this.parentAdView = a;
        String instrPath = this.instrumentation.benchmarkStart(this.instrumentation.startGroup(this.parentAdView.instrumentationGroup, MobclixInstrumentation.ADVIEW), "handle_response");
        requestDisallowInterceptTouchEvent(true);
        if (responseObject == null) {
            try {
                addView(new CustomAdPage(this));
                this.numPages = 1;
                this.type = "customAd";
                this.initialized = true;
            } catch (JSONException e) {
                this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath)));
                this.instrumentation.finishGroup(this.parentAdView.instrumentationGroup);
            }
        } else {
            String instrPath2 = this.instrumentation.benchmarkStart(instrPath, "b_build_models");
            try {
                JSONObject eventUrls = responseObject.getJSONObject("eventUrls");
                try {
                    JSONArray t = eventUrls.getJSONArray("onShow");
                    for (int i = 0; i < t.length(); i++) {
                        this.onLoadUrls.add(t.getString(i));
                    }
                } catch (Exception e2) {
                }
                JSONArray t2 = eventUrls.getJSONArray("onTouch");
                for (int i2 = 0; i2 < t2.length(); i2++) {
                    this.onTouchUrls.add(t2.getString(i2));
                }
            } catch (Exception e3) {
            }
            String instrPath3 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath2), "c_build_creative"), "a_determine_type");
            JSONObject properties = responseObject.getJSONObject("props");
            try {
                this.creativeId = responseObject.getString("id");
            } catch (JSONException e4) {
            }
            this.type = responseObject.getString("type");
            String instrPath4 = this.instrumentation.benchmarkFinishPath(instrPath3);
            try {
                this.hasAutoplayed = ap;
                this.action = new Action(responseObject.getJSONObject("action"), this);
            } catch (Exception e5) {
                this.action = new Action(this);
            }
            String instrPath5 = this.instrumentation.benchmarkStart(instrPath4, "b_get_view");
            if (this.type.equals(AdActivity.HTML_PARAM)) {
                addView(new HTMLPage(properties.getString(AdActivity.HTML_PARAM), this));
                this.numPages = 1;
                this.initialized = true;
            } else if (this.type.equals("openallocation")) {
                addView(new OpenAllocationPage(properties, this));
                this.numPages = 1;
                this.initialized = true;
            } else {
                try {
                    this.transitionType = properties.getString("transitionType");
                } catch (JSONException e6) {
                }
                setAnimationType(this, this.transitionType);
                try {
                    this.transitionTime = (int) (properties.getDouble("transitionTime") * 1000.0d);
                } catch (JSONException e7) {
                }
                if (this.transitionTime == 0) {
                    this.transitionTime = 3000;
                }
                try {
                    this.loop = properties.getBoolean("loop");
                } catch (JSONException e8) {
                }
                if (this.type.equals("image")) {
                    JSONArray t3 = properties.getJSONArray("images");
                    this.numPages = t3.length();
                    for (int i3 = 0; i3 < t3.length(); i3++) {
                        addView(new ImagePage(t3.getString(i3), this));
                    }
                } else if (this.type.equals("text")) {
                    JSONArray t4 = properties.getJSONArray("texts");
                    this.numPages = t4.length();
                    for (int i4 = 0; i4 < t4.length(); i4++) {
                        addView(new TextPage(t4.getJSONObject(i4), this));
                    }
                }
                String instrPath6 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath5), "f_load_ad_creative");
                runNextAsyncRequest();
                this.instrumentation.benchmarkFinishPath(instrPath6);
                this.initialized = true;
            }
        }
    }

    public String getType() {
        return this.type;
    }

    public String getCreativeId() {
        return this.creativeId;
    }

    public boolean getHasAutoplayed() {
        return this.hasAutoplayed;
    }

    public boolean isInitialized() {
        return this.initialized;
    }

    /* access modifiers changed from: protected */
    public void onDetachedFromWindow() {
        try {
            if (Integer.parseInt(Build.VERSION.SDK) >= 7) {
                try {
                    super.onDetachedFromWindow();
                } catch (IllegalArgumentException e) {
                    Log.w(TAG, "Android project  issue 6191  workaround.");
                } finally {
                    super.stopFlipping();
                }
            } else {
                super.onDetachedFromWindow();
            }
        } catch (Exception e2) {
            super.onDetachedFromWindow();
        }
    }

    private int dp(int p) {
        return (int) (this.parentAdView.scale * ((float) p));
    }

    public void onPause() {
        synchronized (this) {
            if (this.pageCycleTimer != null) {
                this.pageCycleTimer.cancel();
                this.pageCycleTimer.purge();
            }
        }
        try {
            if (getCurrentView().getClass() == HTMLPage.class) {
                MobclixJavascriptInterface i = ((HTMLPage) getCurrentView()).webview.getJavascriptInterface();
                i.pauseListeners();
                if (!i.expanded) {
                    i.adWillBecomeHidden();
                }
            }
        } catch (Exception e) {
        }
    }

    public void onResume() {
        synchronized (this) {
            if (this.pageCycleTimer != null) {
                this.pageCycleTimer.cancel();
                this.pageCycleTimer.purge();
                this.pageCycleTimer = new Timer();
                this.pageCycleTimer.scheduleAtFixedRate(new PageCycleThread(), (long) this.transitionTime, (long) this.transitionTime);
            }
        }
        try {
            if (getCurrentView().getClass() == HTMLPage.class) {
                MobclixJavascriptInterface i = ((HTMLPage) getCurrentView()).webview.getJavascriptInterface();
                i.resumeListeners();
                if (!i.expanded && i.expanderActivity == null) {
                    i.adDidReturnFromHidden();
                }
                i.expanded = false;
            }
        } catch (Exception e) {
        }
    }

    public void onStop() {
        onPause();
        try {
            if (getCurrentView().getClass() == HTMLPage.class) {
                ((HTMLPage) getCurrentView()).webview.getJavascriptInterface().adWillTerminate();
            }
        } catch (Exception e) {
        }
    }

    public boolean onTouchEvent(MotionEvent e) {
        try {
            if (this.type.equals(AdActivity.HTML_PARAM) || e.getAction() != 0) {
                return false;
            }
            fireOnTouchTrackingPixels();
            return this.action.act();
        } catch (Exception e2) {
            return false;
        }
    }

    public void runNextAsyncRequest() {
        if (!this.asyncRequestThreads.isEmpty()) {
            this.asyncRequestThreads.pop().start();
            return;
        }
        String instrPath = this.instrumentation.benchmarkStart(this.instrumentation.startGroup(this.parentAdView.instrumentationGroup, MobclixInstrumentation.ADVIEW), "handle_response");
        this.visiblePage = 0;
        String instrPath2 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(instrPath, "c_build_creative"), "b_get_view"), "c_deque_view");
        while (this.parentAdView.getChildCount() > 1) {
            if (this.parentAdView.getChildAt(0) == this.parentAdView.prevAd) {
                this.parentAdView.removeViewAt(1);
            } else {
                this.parentAdView.removeViewAt(0);
            }
            System.gc();
        }
        String instrPath3 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath2)), "e_add_view");
        this.parentAdView.addView(this);
        String instrPath4 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath3)), "d_bring_onscreen");
        if (this.parentAdView.prevAd != null) {
            this.parentAdView.prevAd.onStop();
            if (this.parentAdView.rotate) {
                setAnimationType(this.parentAdView, "flipRight");
            }
        }
        this.parentAdView.showNext();
        String instrPath5 = this.instrumentation.benchmarkFinishPath(instrPath4);
        if (this.numPages > 1) {
            onPause();
            this.pageCycleTimer = new Timer();
            this.pageCycleTimer.scheduleAtFixedRate(new PageCycleThread(), (long) this.transitionTime, (long) this.transitionTime);
        }
        String instrPath6 = this.instrumentation.benchmarkStart(instrPath5, "e_trigger_events");
        if (this.parentAdView.getVisibility() == 0) {
            fireOnShowTrackingPixels();
        }
        String instrPath7 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath6), "f_notify_delegates");
        Iterator<MobclixAdViewListener> it = this.parentAdView.listeners.iterator();
        while (it.hasNext()) {
            MobclixAdViewListener listener = it.next();
            if (listener != null) {
                listener.onSuccessfulLoad(this.parentAdView);
            }
        }
        String instrPath8 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath7), "h_handle_autoplay");
        if (this.action != null && this.action.getAutoplay() && this.parentAdView.allowAutoplay() && !this.hasAutoplayed && !isPlaying && MobclixAdView.lastAutoplayTime.get(this.parentAdView.size).longValue() + Mobclix.getInstance().getAutoplayInterval(this.parentAdView.size).longValue() < System.currentTimeMillis()) {
            this.hasAutoplayed = true;
            this.action.act();
            MobclixAdView.lastAutoplayTime.put(this.parentAdView.size, Long.valueOf(System.currentTimeMillis()));
        }
        this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath8));
        this.instrumentation.finishGroup(this.parentAdView.instrumentationGroup);
    }

    /* access modifiers changed from: package-private */
    public void fireOnShowTrackingPixels() {
        Iterator<String> it = this.onLoadUrls.iterator();
        while (it.hasNext()) {
            new Thread(new Mobclix.FetchImageThread(it.next(), new Mobclix.BitmapHandler())).start();
        }
        this.trackingPixelsFired = true;
    }

    /* access modifiers changed from: package-private */
    public void fireOnTouchTrackingPixels() {
        Iterator<String> it = this.onTouchUrls.iterator();
        while (it.hasNext()) {
            new Thread(new Mobclix.FetchImageThread(it.next(), new Mobclix.BitmapHandler())).start();
        }
    }

    public void setAnimationType(ViewFlipper v, String transition) {
        Animation outAnim;
        Animation inAnim;
        if (transition != null) {
            if (transition.equals("fade")) {
                outAnim = new AlphaAnimation(1.0f, 0.0f);
                inAnim = new AlphaAnimation(0.0f, 1.0f);
            } else if (transition.equals("slideRight")) {
                outAnim = new TranslateAnimation(2, 0.0f, 2, 1.0f, 2, 0.0f, 2, 0.0f);
                inAnim = new TranslateAnimation(2, -1.0f, 2, 0.0f, 2, 0.0f, 2, 0.0f);
            } else if (transition.equals("slideLeft")) {
                outAnim = new TranslateAnimation(2, 0.0f, 2, -1.0f, 2, 0.0f, 2, 0.0f);
                inAnim = new TranslateAnimation(2, 1.0f, 2, 0.0f, 2, 0.0f, 2, 0.0f);
            } else if (transition.equals("slideUp")) {
                outAnim = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, 0.0f, 2, -1.0f);
                inAnim = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, 1.0f, 2, 0.0f);
            } else if (transition.equals("slideDown")) {
                outAnim = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, 0.0f, 2, 1.0f);
                inAnim = new TranslateAnimation(2, 0.0f, 2, 0.0f, 2, -1.0f, 2, 0.0f);
            } else if (transition.equals("flipRight")) {
                outAnim = new Rotate3dAnimation(0.0f, 90.0f, ((float) this.parentAdView.getWidth()) / 2.0f, ((float) this.parentAdView.getHeight()) / 2.0f, 0.0f, true);
                inAnim = new Rotate3dAnimation(-90.0f, 0.0f, ((float) this.parentAdView.getWidth()) / 2.0f, ((float) this.parentAdView.getHeight()) / 2.0f, 0.0f, false);
                inAnim.setStartOffset(300);
            } else if (transition.equals("flipLeft")) {
                outAnim = new Rotate3dAnimation(0.0f, -90.0f, ((float) this.parentAdView.getWidth()) / 2.0f, ((float) this.parentAdView.getHeight()) / 2.0f, 0.0f, true);
                inAnim = new Rotate3dAnimation(90.0f, 0.0f, ((float) this.parentAdView.getWidth()) / 2.0f, ((float) this.parentAdView.getHeight()) / 2.0f, 0.0f, false);
                inAnim.setStartOffset(300);
            } else {
                return;
            }
            outAnim.setDuration(300);
            inAnim.setDuration(300);
            v.setOutAnimation(outAnim);
            v.setInAnimation(inAnim);
        }
    }

    /* access modifiers changed from: package-private */
    public class ResourceResponseHandler extends Handler {
        ResourceResponseHandler() {
        }

        public void handleMessage(Message msg) {
            MobclixCreative.this.runNextAsyncRequest();
        }
    }

    class PageCycleHandler extends Handler {
        PageCycleHandler() {
        }

        public void handleMessage(Message msg) {
            int nextPage = MobclixCreative.this.visiblePage + 1;
            if (nextPage >= MobclixCreative.this.numPages) {
                if (!MobclixCreative.this.loop) {
                    MobclixCreative.this.pageCycleTimer.cancel();
                    return;
                }
                nextPage = 0;
            }
            MobclixCreative.this.visiblePage = nextPage;
            MobclixCreative.this.showNext();
        }
    }

    /* access modifiers changed from: package-private */
    public class PageCycleThread extends TimerTask {
        PageCycleThread() {
        }

        public void run() {
            MobclixCreative.this.pageCycleHandler.sendEmptyMessage(0);
        }
    }

    /* access modifiers changed from: private */
    public class CustomAdThread implements Runnable {
        private String url;

        CustomAdThread(String fetchUrl) {
            this.url = fetchUrl;
        }

        public void run() {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(this.url).openConnection();
                con.setRequestMethod("GET");
                con.setRequestProperty("User-Agent", MobclixCreative.this.parentAdView.controller.getUserAgent());
                con.connect();
            } catch (Exception e) {
            } finally {
                con.disconnect();
            }
        }
    }

    static class Page extends RelativeLayout {
        protected HashMap<String, Integer> alignmentMap = new HashMap<>();
        protected int layer;
        protected MobclixCreative parentCreative = null;
        protected int resourceId;
        protected String type;

        Page(Context c) {
            super(c);
            this.alignmentMap.put("center", 17);
            this.alignmentMap.put("left", 19);
            this.alignmentMap.put("right", 21);
        }

        Page(MobclixCreative c) {
            super(c.getContext());
            this.alignmentMap.put("center", 17);
            this.alignmentMap.put("left", 19);
            this.alignmentMap.put("right", 21);
            this.parentCreative = c;
        }

        public MobclixCreative getParentCreative() {
            return this.parentCreative;
        }

        public void setResourceId(int r) {
            this.resourceId = r;
        }

        public void setLayer(int l) {
            this.layer = l;
        }

        public void setType(String t) {
            this.type = t;
        }

        public int getResourceId() {
            return this.resourceId;
        }

        public int getLayer() {
            return this.layer;
        }

        public String getType() {
            return this.type;
        }

        public int getColorFromJSON(JSONObject c) {
            try {
                return Color.argb(c.getInt("a"), c.getInt("r"), c.getInt("g"), c.getInt("b"));
            } catch (JSONException e) {
                return 0;
            }
        }

        /* access modifiers changed from: package-private */
        public int dp(int p) {
            return (int) (this.parentCreative.parentAdView.scale * ((float) p));
        }
    }

    private static class TextPage extends Page {
        private String bAlign = "center";
        private int bColor = -16776961;
        private String bText = ASConstants.kEmptyString;
        private TextView bTextView;
        private int bgColor = -1;
        private String bgImgUrl = "null";
        private String hAlign = "center";
        private int hColor = -16776961;
        private String hText = ASConstants.kEmptyString;
        private TextView hTextView;
        private String leftIconUrl = "null";
        private ImageView leftIconView;
        private String rightIconUrl = "null";
        private ImageView rightIconView;

        TextPage(JSONObject resource, MobclixCreative p) {
            super(p);
            try {
                this.bgColor = getColorFromJSON(resource.getJSONObject("bgColor"));
            } catch (JSONException e) {
            }
            try {
                this.bgImgUrl = resource.getString("bgImg");
            } catch (JSONException e2) {
            }
            try {
                this.leftIconUrl = resource.getString("leftIcon");
            } catch (JSONException e3) {
            }
            if (this.leftIconUrl.equals(ASConstants.kEmptyString)) {
                this.leftIconUrl = "null";
            }
            try {
                this.rightIconUrl = resource.getString("rightIcon");
            } catch (JSONException e4) {
            }
            if (this.rightIconUrl.equals(ASConstants.kEmptyString)) {
                this.rightIconUrl = "null";
            }
            try {
                JSONObject text = resource.getJSONObject("headerText");
                try {
                    this.hAlign = text.getString("alignment");
                } catch (JSONException e5) {
                }
                try {
                    this.hText = text.getString("text");
                } catch (JSONException e6) {
                }
                if (this.hText.equals("null")) {
                    this.hText = ASConstants.kEmptyString;
                }
                this.hColor = getColorFromJSON(text.getJSONObject("color"));
            } catch (JSONException e7) {
            }
            try {
                JSONObject text2 = resource.getJSONObject("bodyText");
                try {
                    this.bAlign = text2.getString("alignment");
                } catch (JSONException e8) {
                }
                try {
                    this.bText = text2.getString("text");
                } catch (JSONException e9) {
                }
                if (this.bText.equals("null")) {
                    this.bText = ASConstants.kEmptyString;
                }
                this.bColor = getColorFromJSON(text2.getJSONObject("color"));
            } catch (JSONException e10) {
            }
            createLayout();
            loadIcons();
            if (!this.bgImgUrl.equals("null")) {
                loadBackgroundImage();
            }
        }

        public void createLayout() {
            RelativeLayout.LayoutParams textLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
            RelativeLayout.LayoutParams leftIconLayoutParams = new RelativeLayout.LayoutParams(dp(48), dp(48));
            leftIconLayoutParams.addRule(15);
            RelativeLayout.LayoutParams rightIconLayoutParams = new RelativeLayout.LayoutParams(dp(48), dp(48));
            rightIconLayoutParams.addRule(15);
            if (this.leftIconUrl.equals("null") && this.rightIconUrl.equals("null")) {
                textLayoutParams.setMargins(dp(5), 0, dp(5), 0);
            } else if (!this.leftIconUrl.equals("null") && this.rightIconUrl.equals("null")) {
                textLayoutParams.setMargins(dp(60), 0, dp(5), 0);
                leftIconLayoutParams.addRule(9);
                leftIconLayoutParams.setMargins(dp(5), 0, 0, 0);
            } else if (!this.leftIconUrl.equals("null") || this.rightIconUrl.equals("null")) {
                textLayoutParams.setMargins(dp(60), 0, dp(60), 0);
                leftIconLayoutParams.addRule(9);
                leftIconLayoutParams.setMargins(dp(5), 0, 0, 0);
                rightIconLayoutParams.addRule(11);
                rightIconLayoutParams.setMargins(0, 0, dp(5), 0);
            } else {
                textLayoutParams.setMargins(dp(5), 0, dp(60), 0);
                rightIconLayoutParams.addRule(11);
                rightIconLayoutParams.setMargins(0, 0, dp(5), 0);
            }
            LinearLayout textLayout = new LinearLayout(this.parentCreative.parentAdView.getContext());
            textLayout.setOrientation(1);
            textLayout.setLayoutParams(textLayoutParams);
            textLayout.setGravity(16);
            if (!this.hText.equals(ASConstants.kEmptyString)) {
                this.hTextView = new TextView(this.parentCreative.parentAdView.getContext());
                this.hTextView.setGravity(((Integer) this.alignmentMap.get(this.hAlign)).intValue());
                this.hTextView.setText(Html.fromHtml("<b>" + this.hText + "</b>"));
                this.hTextView.setTextColor(this.hColor);
                textLayout.addView(this.hTextView);
            }
            if (!this.bText.equals(ASConstants.kEmptyString)) {
                this.bTextView = new TextView(this.parentCreative.parentAdView.getContext());
                this.bTextView.setGravity(((Integer) this.alignmentMap.get(this.bAlign)).intValue());
                this.bTextView.setText(this.bText);
                this.bTextView.setTextColor(this.bColor);
                textLayout.addView(this.bTextView);
            }
            addView(textLayout);
            if (!this.leftIconUrl.equals("null")) {
                this.leftIconView = new ImageView(this.parentCreative.parentAdView.getContext());
                this.leftIconView.setLayoutParams(leftIconLayoutParams);
                addView(this.leftIconView);
            }
            if (!this.rightIconUrl.equals("null")) {
                this.rightIconView = new ImageView(this.parentCreative.parentAdView.getContext());
                this.rightIconView.setLayoutParams(rightIconLayoutParams);
                addView(this.rightIconView);
            }
            setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            setBackgroundColor(this.bgColor);
        }

        public void loadIcons() {
            if (!this.leftIconUrl.equals("null")) {
                this.parentCreative.asyncRequestThreads.push(new Thread(new Mobclix.FetchImageThread(this.leftIconUrl, new Mobclix.BitmapHandler() {
                    /* class com.mobclix.android.sdk.MobclixCreative.TextPage.AnonymousClass1 */

                    public void handleMessage(Message m) {
                        if (this.bmImg != null) {
                            TextPage.this.leftIconView.setImageBitmap(this.bmImg);
                        }
                        TextPage.this.getParentCreative().handler.sendEmptyMessage(0);
                    }
                })));
            }
            if (!this.rightIconUrl.equals("null")) {
                this.parentCreative.asyncRequestThreads.push(new Thread(new Mobclix.FetchImageThread(this.rightIconUrl, new Mobclix.BitmapHandler() {
                    /* class com.mobclix.android.sdk.MobclixCreative.TextPage.AnonymousClass2 */

                    public void handleMessage(Message m) {
                        if (this.bmImg != null) {
                            TextPage.this.rightIconView.setImageBitmap(this.bmImg);
                        }
                        TextPage.this.getParentCreative().handler.sendEmptyMessage(0);
                    }
                })));
            }
        }

        public void loadBackgroundImage() {
            this.parentCreative.asyncRequestThreads.push(new Thread(new Mobclix.FetchImageThread(this.bgImgUrl, new Mobclix.BitmapHandler() {
                /* class com.mobclix.android.sdk.MobclixCreative.TextPage.AnonymousClass3 */

                public void handleMessage(Message m) {
                    if (this.bmImg != null) {
                        TextPage.this.setBackgroundDrawable(new BitmapDrawable(this.bmImg));
                    }
                    TextPage.this.getParentCreative().handler.sendEmptyMessage(0);
                }
            })));
        }
    }

    private static class ImagePage extends Page {
        private String imgUrl;
        private ImageView imgView;

        ImagePage(String url, MobclixCreative c) {
            super(c);
            this.imgUrl = url;
            createLayout();
            loadImage();
        }

        public void createLayout() {
            RelativeLayout.LayoutParams imgLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
            imgLayoutParams.addRule(15);
            this.imgView = new ImageView(this.parentCreative.parentAdView.getContext());
            this.imgView.setLayoutParams(imgLayoutParams);
            addView(this.imgView);
            setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        }

        public void loadImage() {
            this.parentCreative.asyncRequestThreads.push(new Thread(new Mobclix.FetchImageThread(this.imgUrl, new Mobclix.BitmapHandler() {
                /* class com.mobclix.android.sdk.MobclixCreative.ImagePage.AnonymousClass1 */

                public void handleMessage(Message m) {
                    if (this.bmImg != null) {
                        ImagePage.this.imgView.setImageBitmap(this.bmImg);
                    }
                    ImagePage.this.getParentCreative().handler.sendEmptyMessage(0);
                }
            })));
        }
    }

    /* access modifiers changed from: package-private */
    public static class MobclixWebView extends WebView {
        MobclixFullScreenAdView fullScreenAdView = null;
        private String html = null;
        MobclixJavascriptInterface jsInterface = null;
        boolean loaded = false;
        MobclixAdView parentAdView = null;

        public MobclixWebView(MobclixAdView adview) {
            super(adview.getContext());
            this.parentAdView = adview;
        }

        public MobclixWebView(MobclixFullScreenAdView adview) {
            super(adview.getActivity());
            this.fullScreenAdView = adview;
        }

        public Context getTopContext() {
            Context currentActivity = getContext();
            if (this.jsInterface == null || this.jsInterface.expanderActivity == null) {
                return currentActivity;
            }
            return this.jsInterface.expanderActivity.getContext();
        }

        public void setJavascriptInterface(MobclixJavascriptInterface jsInt) {
            this.jsInterface = jsInt;
        }

        public MobclixJavascriptInterface getJavascriptInterface() {
            return this.jsInterface;
        }

        public void setAdHtml(String h) {
            this.html = h;
        }

        public void loadAd() {
            try {
                loadDataWithBaseURL(null, this.html, "text/html", "utf-8", null);
            } catch (Exception e) {
            }
        }

        public void triggerOnTouchUrls() {
            try {
                ((HTMLPage) getParent()).parentCreative.action.act();
            } catch (Exception e) {
            }
        }
    }

    /* access modifiers changed from: package-private */
    public static class HTMLPage extends Page {
        private MobclixFullScreenAdView fullScreenAdView = null;
        private String html;
        private MobclixJavascriptInterface jsInterface;
        private MobclixWebView webview;

        HTMLPage(String h, MobclixCreative c) {
            super(c);
            setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            requestDisallowInterceptTouchEvent(true);
            this.html = h;
            try {
                createLayout();
            } catch (Exception e) {
            }
        }

        HTMLPage(String h, MobclixFullScreenAdView fsAdView) {
            super(fsAdView.getActivity());
            this.html = h;
            this.fullScreenAdView = fsAdView;
            requestDisallowInterceptTouchEvent(true);
            try {
                createLayout();
            } catch (Exception e) {
            }
        }

        public void createLayout() {
            RelativeLayout.LayoutParams webviewLayoutParams;
            if (this.fullScreenAdView == null) {
                this.webview = new MobclixWebView(this.parentCreative.parentAdView);
                this.jsInterface = new MobclixJavascriptInterface(this.webview, false);
            } else {
                this.webview = new MobclixWebView(this.fullScreenAdView);
                this.jsInterface = new MobclixJavascriptInterface(this.webview, true);
            }
            this.webview.requestDisallowInterceptTouchEvent(true);
            if (this.fullScreenAdView == null) {
                webviewLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
            } else {
                webviewLayoutParams = new RelativeLayout.LayoutParams(this.fullScreenAdView.screenWidth, this.fullScreenAdView.screenHeight);
            }
            this.webview.setLayoutParams(webviewLayoutParams);
            this.webview.setScrollBarStyle(33554432);
            this.webview.addJavascriptInterface(this.jsInterface, "MOBCLIX");
            this.webview.setJavascriptInterface(this.jsInterface);
            this.webview.getSettings().setJavaScriptEnabled(true);
            this.webview.setWebViewClient(new WebViewClient() {
                /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass1 */

                @Override // android.webkit.WebViewClient
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    Uri uri = Uri.parse(url);
                    try {
                        if (uri.getScheme().equals("tel") || uri.getScheme().equals("mailto")) {
                            if (HTMLPage.this.parentCreative != null) {
                                HTMLPage.this.parentCreative.action.type = "null";
                                HTMLPage.this.parentCreative.action.act();
                            }
                            if (HTMLPage.this.webview.getJavascriptInterface().expanderActivity != null) {
                                HTMLPage.this.webview.getJavascriptInterface().expanderActivity.wasAdActivity = true;
                            }
                            HTMLPage.this.getContext().startActivity(new Intent("android.intent.action.VIEW", uri));
                            return true;
                        } else if (uri.getScheme().equals("sms")) {
                            if (HTMLPage.this.parentCreative != null) {
                                HTMLPage.this.parentCreative.action.type = "null";
                                HTMLPage.this.parentCreative.action.act();
                            }
                            if (HTMLPage.this.webview.getJavascriptInterface().expanderActivity != null) {
                                HTMLPage.this.webview.getJavascriptInterface().expanderActivity.wasAdActivity = true;
                            }
                            String[] smsUrl = url.split(":");
                            String tmp = String.valueOf(smsUrl[0]) + "://";
                            for (int i = 1; i < smsUrl.length; i++) {
                                tmp = String.valueOf(tmp) + smsUrl[i];
                            }
                            String body = Uri.parse(tmp).getQueryParameter(ASConstants.kASResponseKeyBody);
                            Intent mIntent = new Intent("android.intent.action.VIEW", Uri.parse(url.split("\\?")[0]));
                            mIntent.putExtra("sms_body", body);
                            HTMLPage.this.getContext().startActivity(mIntent);
                            return true;
                        } else {
                            String shouldOpenInNewWindow = uri.getQueryParameter("shouldOpenInNewWindow");
                            if (shouldOpenInNewWindow == null) {
                                shouldOpenInNewWindow = ASConstants.kEmptyString;
                            } else {
                                shouldOpenInNewWindow.toLowerCase();
                            }
                            if ((HTMLPage.this.webview.getJavascriptInterface().expanderActivity != null || shouldOpenInNewWindow.equals("no")) && !shouldOpenInNewWindow.equals("yes")) {
                                HTMLPage.this.webview.loadUrl(url);
                                return true;
                            }
                            if (HTMLPage.this.webview.getJavascriptInterface().expanderActivity != null) {
                                HTMLPage.this.webview.getJavascriptInterface().expanderActivity.wasAdActivity = true;
                            }
                            HTMLPage.this.getContext().startActivity(new Intent("android.intent.action.VIEW", uri));
                            if (HTMLPage.this.parentCreative == null) {
                                return true;
                            }
                            HTMLPage.this.parentCreative.action.type = "null";
                            HTMLPage.this.parentCreative.action.act();
                            return true;
                        }
                    } catch (Exception e) {
                        return false;
                    }
                }

                public void onPageFinished(WebView view, String url) {
                    CookieSyncManager.getInstance().sync();
                    if (!HTMLPage.this.webview.loaded && HTMLPage.this.parentCreative != null) {
                        HTMLPage.this.getParentCreative().handler.sendEmptyMessage(0);
                    }
                    if (!HTMLPage.this.webview.loaded && HTMLPage.this.fullScreenAdView != null) {
                        HTMLPage.this.fullScreenAdView.onPageFinished(HTMLPage.this.webview);
                    }
                    HTMLPage.this.webview.loaded = true;
                }
            });
            this.webview.setWebChromeClient(new WebChromeClient() {
                /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2 */

                public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(HTMLPage.this.webview.getTopContext());
                    builder.setMessage(message).setCancelable(false);
                    builder.setPositiveButton(17039370, new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass1 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int id) {
                            ((JsResult) this.obj1).confirm();
                        }
                    });
                    builder.create().show();
                    return true;
                }

                public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(HTMLPage.this.webview.getTopContext());
                    builder.setMessage(message).setCancelable(false);
                    builder.setPositiveButton(17039370, new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass2 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int id) {
                            ((JsResult) this.obj1).confirm();
                        }
                    });
                    builder.setNegativeButton(17039360, new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass3 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int id) {
                            ((JsResult) this.obj1).cancel();
                        }
                    });
                    builder.create().show();
                    return true;
                }

                public boolean onJsBeforeUnload(WebView view, String url, String message, JsResult result) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(HTMLPage.this.webview.getTopContext());
                    builder.setMessage(message).setTitle("Confirm Navigation").setCancelable(false);
                    builder.setPositiveButton("Leave this Page", new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass4 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int id) {
                            ((JsResult) this.obj1).confirm();
                        }
                    });
                    builder.setNegativeButton("Stay on this Page", new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass5 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int id) {
                            ((JsResult) this.obj1).cancel();
                        }
                    });
                    builder.create().show();
                    return true;
                }

                public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                    Context mContext = HTMLPage.this.webview.getTopContext();
                    AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
                    EditText editInput = new EditText(mContext);
                    if (defaultValue != null) {
                        editInput.setText(defaultValue);
                    }
                    builder.setMessage(message).setView(editInput).setCancelable(false).setPositiveButton(17039370, new Mobclix.ObjectOnClickListener(result, editInput) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass6 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int whichButton) {
                            ((JsPromptResult) this.obj1).confirm(((EditText) this.obj2).getText().toString());
                        }
                    }).setNegativeButton(17039360, new Mobclix.ObjectOnClickListener(result) {
                        /* class com.mobclix.android.sdk.MobclixCreative.HTMLPage.AnonymousClass2.AnonymousClass7 */

                        @Override // com.mobclix.android.sdk.Mobclix.ObjectOnClickListener
                        public void onClick(DialogInterface dialog, int whichButton) {
                            ((JsPromptResult) this.obj1).cancel();
                        }
                    });
                    builder.create().show();
                    return true;
                }
            });
            this.webview.setAdHtml(this.html);
            this.webview.loadAd();
            this.webview.setFocusable(true);
            addView(this.webview);
        }

        public void onDetachedFromWindow() {
            this.jsInterface.pauseListeners();
        }
    }

    private static class CustomAdPage extends Page {
        private ImageView imgView;

        CustomAdPage(MobclixCreative c) {
            super(c);
            createLayout();
        }

        public void createLayout() {
            try {
                Bitmap myBitmap = BitmapFactory.decodeStream(this.parentCreative.parentAdView.context.openFileInput(String.valueOf(this.parentCreative.parentAdView.size) + "_mc_cached_custom_ad.png"));
                RelativeLayout.LayoutParams imgLayoutParams = new RelativeLayout.LayoutParams(-1, -1);
                imgLayoutParams.addRule(15);
                this.imgView = new ImageView(this.parentCreative.parentAdView.getContext());
                this.imgView.setLayoutParams(imgLayoutParams);
                this.imgView.setImageBitmap(myBitmap);
                addView(this.imgView);
                setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
            } catch (Exception e) {
            }
            getParentCreative().handler.sendEmptyMessage(0);
        }
    }

    private static class OpenAllocationPage extends Page {
        RelativeLayout adMobAdView;
        String network = "openadmob";
        String params = null;

        OpenAllocationPage(JSONObject p, MobclixCreative c) {
            super(c);
            int openAllocationCode;
            try {
                this.network = p.getString("network");
            } catch (Exception e) {
            }
            try {
                StringBuffer paramsBuffer = new StringBuffer();
                JSONObject pp = p.getJSONObject("params");
                Iterator<?> i = pp.keys();
                while (i.hasNext()) {
                    String k = i.next().toString();
                    String v = pp.get(k).toString();
                    paramsBuffer.append("&").append(k);
                    paramsBuffer.append("=").append(v);
                }
                this.params = paramsBuffer.toString();
            } catch (Exception e2) {
            }
            boolean eventConsumed = false;
            if (this.network.equals("openadmob")) {
                openAllocationCode = MobclixAdViewListener.SUBALLOCATION_ADMOB;
            } else if (this.network.equals("opengoogle")) {
                openAllocationCode = MobclixAdViewListener.SUBALLOCATION_GOOGLE;
            } else {
                openAllocationCode = MobclixAdViewListener.SUBALLOCATION_OTHER;
            }
            Iterator<MobclixAdViewListener> it = this.parentCreative.parentAdView.listeners.iterator();
            while (it.hasNext()) {
                MobclixAdViewListener listener = it.next();
                if (listener != null) {
                    eventConsumed = eventConsumed || listener.onOpenAllocationLoad(this.parentCreative.parentAdView, openAllocationCode);
                }
            }
            if (!eventConsumed && openAllocationCode == -750) {
                adMobAllocation();
            }
        }

        /* access modifiers changed from: package-private */
        public void adMobAllocation() {
            try {
                Class<?> AdMobAdViewClass = Class.forName("com.admob.android.ads.AdView");
                this.adMobAdView = (RelativeLayout) AdMobAdViewClass.getConstructor(Activity.class).newInstance((Activity) this.parentCreative.getContext());
                Object adMobAdListener = null;
                Class<?> AdMobAdListenerClass = null;
                try {
                    AdMobAdListenerClass = Class.forName("com.admob.android.ads.AdListener");
                    InvocationHandler handler = new AdMobInvocationHandler();
                    adMobAdListener = AdMobAdListenerClass.cast(Proxy.newProxyInstance(AdMobAdListenerClass.getClassLoader(), new Class[]{AdMobAdListenerClass}, handler));
                } catch (Exception e) {
                    Log.v(MobclixCreative.TAG, e.toString());
                }
                try {
                    AdMobAdViewClass.getMethod("setAdListener", AdMobAdListenerClass).invoke(this.adMobAdView, adMobAdListener);
                    StringBuilder keywordsBuffer = new StringBuilder();
                    StringBuilder queryBuffer = new StringBuilder();
                    Iterator<MobclixAdViewListener> it = this.parentCreative.parentAdView.listeners.iterator();
                    while (it.hasNext()) {
                        MobclixAdViewListener listener = it.next();
                        if (listener != null) {
                            String keywords = listener.keywords();
                            if (keywords == null) {
                                keywords = ASConstants.kEmptyString;
                            }
                            if (!keywords.equals(ASConstants.kEmptyString)) {
                                keywordsBuffer.append(keywords).append(" ");
                            }
                            String query = listener.query();
                            if (query == null) {
                                query = ASConstants.kEmptyString;
                            }
                            if (!query.equals(ASConstants.kEmptyString)) {
                                queryBuffer.append(query).append(" ");
                            }
                        }
                    }
                    if (keywordsBuffer.length() > 0) {
                        AdMobAdViewClass.getMethod("setKeywords", String.class).invoke(this.adMobAdView, keywordsBuffer.toString());
                    }
                    if (queryBuffer.length() > 0) {
                        AdMobAdViewClass.getMethod("setSearchQuery", String.class).invoke(this.adMobAdView, queryBuffer.toString());
                    }
                } catch (Exception e2) {
                    Log.v(MobclixCreative.TAG, e2.toString());
                }
                this.adMobAdView.setOnClickListener(new View.OnClickListener() {
                    /* class com.mobclix.android.sdk.MobclixCreative.OpenAllocationPage.AnonymousClass1 */

                    public void onClick(View v) {
                        Iterator<MobclixAdViewListener> it = OpenAllocationPage.this.parentCreative.parentAdView.listeners.iterator();
                        while (it.hasNext()) {
                            MobclixAdViewListener listener = it.next();
                            if (listener != null) {
                                listener.onAdClick(OpenAllocationPage.this.parentCreative.parentAdView);
                            }
                        }
                    }
                });
                this.adMobAdView.setVisibility(4);
                this.parentCreative.parentAdView.addView(this.adMobAdView);
            } catch (Exception e3) {
            }
        }

        public class AdMobInvocationHandler implements InvocationHandler {
            public AdMobInvocationHandler() {
            }

            @Override // java.lang.reflect.InvocationHandler
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                OpenAllocationPage.this.parentCreative.parentAdView.removeView(OpenAllocationPage.this.adMobAdView);
                if (method.getName().equals("onReceiveAd")) {
                    OpenAllocationPage.this.addView(OpenAllocationPage.this.adMobAdView);
                    OpenAllocationPage.this.adMobAdView.setVisibility(0);
                    OpenAllocationPage.this.getParentCreative().handler.sendEmptyMessage(0);
                    return null;
                }
                if (OpenAllocationPage.this.params == null) {
                    OpenAllocationPage.this.params = ASConstants.kEmptyString;
                }
                OpenAllocationPage.this.parentCreative.parentAdView.getNextAd(OpenAllocationPage.this.params);
                return null;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public class Action {
        boolean autoplay = false;
        String browserType = "standard";
        String cachedHTML = ASConstants.kEmptyString;
        Bitmap cachedImageBitmap = null;
        int cachedImageHeight;
        int cachedImageWidth;
        private ArrayList<String> onShowUrls = new ArrayList<>();
        private ArrayList<String> onTouchUrls = new ArrayList<>();
        private MobclixCreative parentCreative;
        private JSONObject rawJSON;
        String type = "null";
        String url = ASConstants.kEmptyString;

        Action(MobclixCreative creative) {
            this.parentCreative = creative;
        }

        Action(JSONObject action, MobclixCreative creative) {
            try {
                this.rawJSON = action;
                this.parentCreative = creative;
                this.type = action.getString("type");
                if (action.has("autoplay")) {
                    this.autoplay = action.getBoolean("autoplay");
                }
                try {
                    JSONObject eventUrls = action.getJSONObject("eventUrls");
                    JSONArray t = eventUrls.getJSONArray("onShow");
                    for (int i = 0; i < t.length(); i++) {
                        this.onShowUrls.add(t.getString(i));
                    }
                    JSONArray t2 = eventUrls.getJSONArray("onTouch");
                    for (int i2 = 0; i2 < t2.length(); i2++) {
                        this.onTouchUrls.add(t2.getString(i2));
                    }
                } catch (Exception e) {
                }
                if (this.type.equals("url")) {
                    try {
                        this.url = action.getString("url");
                    } catch (JSONException e2) {
                    }
                    try {
                        this.browserType = action.getString("browserType");
                    } catch (JSONException e3) {
                    }
                    try {
                        if (action.getBoolean("preload")) {
                            loadPreload();
                        }
                    } catch (JSONException e4) {
                    }
                } else if (this.type.equals(AdActivity.HTML_PARAM)) {
                    try {
                        this.url = action.getString("baseUrl");
                    } catch (JSONException e5) {
                    }
                    try {
                        this.cachedHTML = action.getString(AdActivity.HTML_PARAM);
                    } catch (JSONException e6) {
                    }
                    try {
                        this.browserType = action.getString("browserType");
                    } catch (JSONException e7) {
                    }
                }
            } catch (JSONException e8) {
            }
        }

        public boolean getAutoplay() {
            return this.autoplay;
        }

        /* access modifiers changed from: package-private */
        public void loadPreload() {
            this.parentCreative.asyncRequestThreads.push(new Thread(new Mobclix.FetchResponseThread(this.url, new Handler() {
                /* class com.mobclix.android.sdk.MobclixCreative.Action.AnonymousClass1 */

                public void handleMessage(Message m) {
                    String type = m.getData().getString("type");
                    if (type.equals("success")) {
                        Action.this.cachedHTML = m.getData().getString("response");
                    } else if (type.equals("failure")) {
                        Action.this.cachedHTML = ASConstants.kEmptyString;
                    }
                    Action.this.parentCreative.handler.sendEmptyMessage(0);
                }
            })));
        }

        public boolean act() {
            try {
                Iterator<String> it = this.onShowUrls.iterator();
                while (it.hasNext()) {
                    new Thread(new Mobclix.FetchImageThread(it.next(), new Mobclix.BitmapHandler())).start();
                }
            } catch (Exception e) {
            }
            Iterator<MobclixAdViewListener> it2 = MobclixCreative.this.parentAdView.listeners.iterator();
            while (it2.hasNext()) {
                MobclixAdViewListener listener = it2.next();
                if (listener != null) {
                    listener.onAdClick(MobclixCreative.this.parentAdView);
                }
            }
            MobclixCreative.isPlaying = true;
            if (this.type.equals("url") || this.type.equals(AdActivity.HTML_PARAM)) {
                loadUrl();
            } else if (this.type.equals("video")) {
                Intent mIntent = new Intent();
                String packageName = MobclixCreative.this.parentAdView.getContext().getPackageName();
                mIntent.setClassName(packageName, MobclixBrowserActivity.class.getName()).putExtra(String.valueOf(packageName) + ".type", "video").putExtra(String.valueOf(packageName) + ".data", this.rawJSON.toString());
                MobclixCreative.this.getContext().startActivity(mIntent);
            }
            MobclixCreative.isPlaying = false;
            return true;
        }

        /* access modifiers changed from: package-private */
        public void loadUrl() {
            try {
                if (!this.url.equals(ASConstants.kEmptyString)) {
                    Uri uri = Uri.parse(this.url);
                    String[] tmp = this.url.split("mobclix://");
                    if (tmp.length <= 1) {
                        tmp = this.url.split("mobclix%3A%2F%2F");
                        if (tmp.length <= 1) {
                            for (int i = 0; i < Mobclix.getInstance().getNativeUrls().size(); i++) {
                                if (uri.getHost().equals(Mobclix.getInstance().getNativeUrls().get(i))) {
                                    MobclixCreative.this.getContext().startActivity(new Intent("android.intent.action.VIEW", uri));
                                    return;
                                }
                            }
                            if (!this.cachedHTML.equals(ASConstants.kEmptyString)) {
                                Intent mIntent = new Intent();
                                String packageName = MobclixCreative.this.parentAdView.getContext().getPackageName();
                                try {
                                    this.rawJSON.put("cachedHTML", this.cachedHTML);
                                } catch (JSONException e) {
                                }
                                mIntent.setClassName(packageName, MobclixBrowserActivity.class.getName()).putExtra(String.valueOf(packageName) + ".type", "browser").putExtra(String.valueOf(packageName) + ".data", this.rawJSON.toString());
                                MobclixCreative.this.getContext().startActivity(mIntent);
                            } else if (this.browserType.equals("minimal")) {
                                Intent mIntent2 = new Intent();
                                String packageName2 = MobclixCreative.this.parentAdView.getContext().getPackageName();
                                mIntent2.setClassName(packageName2, MobclixBrowserActivity.class.getName()).putExtra(String.valueOf(packageName2) + ".type", "browser").putExtra(String.valueOf(packageName2) + ".data", this.rawJSON.toString());
                                MobclixCreative.this.getContext().startActivity(mIntent2);
                                return;
                            } else {
                                MobclixCreative.this.getContext().startActivity(new Intent("android.intent.action.VIEW", uri));
                            }
                            CookieSyncManager.getInstance().sync();
                            return;
                        }
                    }
                    String customAdString = tmp[1];
                    MobclixCreative.this.customAdThread = new Thread(new CustomAdThread(this.url));
                    MobclixCreative.this.customAdThread.start();
                    Iterator<MobclixAdViewListener> it = MobclixCreative.this.parentAdView.listeners.iterator();
                    while (it.hasNext()) {
                        MobclixAdViewListener listener = it.next();
                        if (listener != null) {
                            listener.onCustomAdTouchThrough(MobclixCreative.this.parentAdView, customAdString);
                        }
                    }
                }
            } catch (Exception e2) {
            }
        }
    }

    /* access modifiers changed from: private */
    public class Rotate3dAnimation extends Animation {
        private Camera mCamera;
        private final float mCenterX;
        private final float mCenterY;
        private final float mDepthZ;
        private final float mFromDegrees;
        private final boolean mReverse;
        private final float mToDegrees;

        public Rotate3dAnimation(float fromDegrees, float toDegrees, float centerX, float centerY, float depthZ, boolean reverse) {
            this.mFromDegrees = fromDegrees;
            this.mToDegrees = toDegrees;
            this.mCenterX = centerX;
            this.mCenterY = centerY;
            this.mDepthZ = depthZ;
            this.mReverse = reverse;
        }

        public void initialize(int width, int height, int parentWidth, int parentHeight) {
            super.initialize(width, height, parentWidth, parentHeight);
            this.mCamera = new Camera();
        }

        /* access modifiers changed from: protected */
        public void applyTransformation(float interpolatedTime, Transformation t) {
            float fromDegrees = this.mFromDegrees;
            float degrees = fromDegrees + ((this.mToDegrees - fromDegrees) * interpolatedTime);
            float centerX = this.mCenterX;
            float centerY = this.mCenterY;
            Camera camera = this.mCamera;
            Matrix matrix = t.getMatrix();
            camera.save();
            if (this.mReverse) {
                camera.translate(0.0f, 0.0f, this.mDepthZ * interpolatedTime);
            } else {
                camera.translate(0.0f, 0.0f, this.mDepthZ * (1.0f - interpolatedTime));
            }
            camera.rotateY(degrees);
            camera.getMatrix(matrix);
            camera.restore();
            matrix.preTranslate(-centerX, -centerY);
            matrix.postTranslate(centerX, centerY);
        }
    }
}
