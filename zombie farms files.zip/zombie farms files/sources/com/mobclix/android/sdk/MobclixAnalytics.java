package com.mobclix.android.sdk;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import org.json.JSONObject;

public class MobclixAnalytics {
    private static String MC_ANALYTICS_DIRECTORY = "analytics";
    private static String MC_DIRECTORY = "mobclix";
    private static final String MC_KEY_APPLICATION_ID = "a";
    private static final String MC_KEY_APPLICATION_VERSION = "v";
    private static final String MC_KEY_DEVICE_HARDWARE_MODEL = "hwdm";
    private static final String MC_KEY_DEVICE_ID = "d";
    private static final String MC_KEY_DEVICE_MODEL = "dm";
    private static final String MC_KEY_DEVICE_SYSTEM_VERSION = "dv";
    private static final String MC_KEY_MOBCLIX_LIBRARY_VERSION = "m";
    private static final String MC_KEY_PLATFORM_ID = "p";
    private static final String MC_KEY_USER_LANGUAGE_PREFERENCE = "lg";
    private static final String MC_KEY_USER_LOCALE_PREFERENCE = "lo";
    private static int MC_MAX_ANALYTICS_FILES = 100;
    private static int MC_MAX_EVENTS_PER_FILE = 5;
    static int SYNC_ERROR = -1;
    static int SYNC_READY = 0;
    static int SYNC_RUNNING = 1;
    private static final String TAG = "MobclixAnalytics";
    private static Mobclix controller = Mobclix.getInstance();
    private static File currentFile = null;
    private static boolean fileCreated = false;
    private static boolean loggingEvent = false;
    private static int numLinesWritten = 0;
    private static String syncContents = null;
    private static int syncStatus = 0;

    static int getSyncStatus() {
        return syncStatus;
    }

    static class LogEvent implements Runnable {
        JSONObject event;

        public LogEvent(JSONObject e) {
            this.event = e;
        }

        public void run() {
            while (true) {
                try {
                    if (!MobclixAnalytics.loggingEvent && MobclixAnalytics.syncStatus == MobclixAnalytics.SYNC_READY) {
                        break;
                    }
                } catch (Exception e) {
                    MobclixAnalytics.loggingEvent = false;
                    return;
                }
            }
            MobclixAnalytics.loggingEvent = true;
            if (MobclixAnalytics.fileCreated || MobclixAnalytics.OpenAnalyticsFile()) {
                do {
                } while (!MobclixAnalytics.fileCreated);
                MobclixAnalytics.controller.updateSession();
                try {
                    FileOutputStream fos = new FileOutputStream(MobclixAnalytics.currentFile, true);
                    if (MobclixAnalytics.numLinesWritten > 1) {
                        fos.write(",".getBytes());
                    }
                    fos.write(this.event.toString().getBytes());
                    fos.close();
                    MobclixAnalytics.numLinesWritten++;
                    if (MobclixAnalytics.numLinesWritten > MobclixAnalytics.MC_MAX_EVENTS_PER_FILE) {
                        MobclixAnalytics.fileCreated = false;
                        MobclixAnalytics.OpenAnalyticsFile();
                    }
                } catch (Exception e2) {
                }
                MobclixAnalytics.loggingEvent = false;
                return;
            }
            MobclixAnalytics.loggingEvent = false;
        }
    }

    /* access modifiers changed from: private */
    public static boolean OpenAnalyticsFile() {
        numLinesWritten = 1;
        controller.updateSession();
        try {
            JSONObject header = new JSONObject(controller.session, new String[]{"ll", "g", "id"});
            header.put(MC_KEY_APPLICATION_ID, URLEncoder.encode(controller.getApplicationId(), "UTF-8"));
            header.put(MC_KEY_PLATFORM_ID, URLEncoder.encode(controller.getPlatform(), "UTF-8"));
            header.put("m", URLEncoder.encode(controller.getMobclixVersion()));
            header.put(MC_KEY_APPLICATION_VERSION, URLEncoder.encode(controller.getApplicationVersion(), "UTF-8"));
            header.put(MC_KEY_DEVICE_ID, URLEncoder.encode(controller.getDeviceId(), "UTF-8"));
            header.put(MC_KEY_DEVICE_MODEL, URLEncoder.encode(controller.getDeviceModel(), "UTF-8"));
            header.put(MC_KEY_DEVICE_SYSTEM_VERSION, URLEncoder.encode(controller.getAndroidVersion(), "UTF-8"));
            header.put(MC_KEY_DEVICE_HARDWARE_MODEL, URLEncoder.encode(controller.getDeviceHardwareModel(), "UTF-8"));
            header.put("m", URLEncoder.encode(Mobclix.MC_LIBRARY_VERSION, "UTF-8"));
            header.put(MC_KEY_USER_LANGUAGE_PREFERENCE, URLEncoder.encode(controller.getLanguage(), "UTF-8"));
            header.put(MC_KEY_USER_LOCALE_PREFERENCE, URLEncoder.encode(controller.getLocale(), "UTF-8"));
            File anDir = new File(String.valueOf(controller.getContext().getDir(MC_DIRECTORY, 0).getAbsolutePath()) + "/" + MC_ANALYTICS_DIRECTORY);
            anDir.mkdir();
            try {
                if (anDir.listFiles().length >= MC_MAX_ANALYTICS_FILES) {
                    return false;
                }
            } catch (Exception e) {
            }
            currentFile = new File(anDir.getAbsoluteFile() + "/" + System.currentTimeMillis() + ".log");
            currentFile.createNewFile();
            FileOutputStream fos = new FileOutputStream(currentFile);
            fos.write("[{\"hb\":".getBytes());
            fos.write(header.toString().getBytes());
            fos.write(",\"ev\":[".getBytes());
            fos.close();
            fileCreated = true;
            return true;
        } catch (Exception e2) {
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public static class Sync implements Runnable {
        Sync() {
        }

        /* JADX WARNING: Removed duplicated region for block: B:41:0x01bb A[LOOP:1: B:7:0x004c->B:41:0x01bb, LOOP_END] */
        /* JADX WARNING: Removed duplicated region for block: B:44:0x018f A[SYNTHETIC] */
        public synchronized void run() {
            do {
            } while (MobclixAnalytics.loggingEvent);
            MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_RUNNING;
            try {
                File anDir = new File(String.valueOf(MobclixAnalytics.controller.getContext().getDir(MobclixAnalytics.MC_DIRECTORY, 0).getAbsolutePath()) + "/" + MobclixAnalytics.MC_ANALYTICS_DIRECTORY);
                anDir.mkdir();
                File[] files = anDir.listFiles();
                int i = 0;
                while (true) {
                    if (i >= files.length) {
                        break;
                    }
                    StringBuffer data = new StringBuffer();
                    data.append("p=android");
                    data.append("&a=").append(URLEncoder.encode(MobclixAnalytics.controller.getApplicationId(), "UTF-8"));
                    data.append("&m=").append(URLEncoder.encode(MobclixAnalytics.controller.getMobclixVersion()));
                    data.append("&d=").append(URLEncoder.encode(MobclixAnalytics.controller.getDeviceId(), "UTF-8"));
                    data.append("&v=").append(URLEncoder.encode(MobclixAnalytics.controller.getApplicationVersion(), "UTF-8"));
                    data.append("&j=");
                    FileInputStream fis = new FileInputStream(files[i]);
                    BufferedInputStream bis = new BufferedInputStream(fis);
                    DataInputStream dis = new DataInputStream(bis);
                    while (dis.available() != 0) {
                        data.append(dis.readLine());
                    }
                    dis.close();
                    bis.close();
                    fis.close();
                    data.append("]}]");
                    MobclixAnalytics.syncContents = data.toString();
                    try {
                        try {
                            HttpURLConnection conn = (HttpURLConnection) new URL(MobclixAnalytics.controller.analyticsServer).openConnection();
                            conn.setDoOutput(true);
                            conn.setDoInput(true);
                            conn.setUseCaches(false);
                            conn.setRequestMethod("POST");
                            PrintWriter pw = new PrintWriter(conn.getOutputStream());
                            pw.print(MobclixAnalytics.syncContents);
                            pw.flush();
                            pw.close();
                            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            String line = null;
                            while (true) {
                                String templine = rd.readLine();
                                if (templine == null) {
                                    break;
                                } else if (line == null) {
                                    line = templine;
                                }
                            }
                            if (!line.equals("1")) {
                                MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_ERROR;
                            }
                            rd.close();
                        } catch (Exception e) {
                            MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_ERROR;
                            if (MobclixAnalytics.syncStatus == MobclixAnalytics.SYNC_ERROR) {
                            }
                        }
                    } catch (Exception e2) {
                        MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_ERROR;
                        if (MobclixAnalytics.syncStatus == MobclixAnalytics.SYNC_ERROR) {
                        }
                    }
                    if (MobclixAnalytics.syncStatus == MobclixAnalytics.SYNC_ERROR) {
                        MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_READY;
                        break;
                    } else {
                        files[i].delete();
                        i++;
                    }
                }
            } catch (Exception e3) {
            }
            MobclixAnalytics.syncContents = null;
            MobclixAnalytics.numLinesWritten = 0;
            MobclixAnalytics.fileCreated = false;
            MobclixAnalytics.syncStatus = MobclixAnalytics.SYNC_READY;
        }
    }
}
