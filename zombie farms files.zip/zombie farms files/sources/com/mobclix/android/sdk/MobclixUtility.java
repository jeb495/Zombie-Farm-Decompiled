package com.mobclix.android.sdk;

import android.app.Activity;
import android.os.Environment;
import com.mobclix.android.sdk.MobclixFeedback;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* access modifiers changed from: package-private */
public class MobclixUtility {
    private static String TAG = "MobclixUtility";

    MobclixUtility() {
    }

    public static boolean isSdPresent() {
        return Environment.getExternalStorageState().equals("mounted");
    }

    static String JSONescape(String s) {
        return s.replace("'", "\\'").replace("\\r", " ").replace("\\n", " ");
    }

    /* access modifiers changed from: package-private */
    public static class POSTThread implements Runnable {
        Activity activity;
        Mobclix controller = Mobclix.getInstance();
        MobclixFeedback.Listener listener;
        String params;
        String url;

        POSTThread(String u, String p, Activity a, MobclixFeedback.Listener l) {
            this.url = u;
            this.params = p;
            this.activity = a;
            this.listener = l;
        }

        /* JADX WARNING: Removed duplicated region for block: B:18:0x004f A[SYNTHETIC, Splitter:B:18:0x004f] */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x005b A[SYNTHETIC, Splitter:B:23:0x005b] */
        /* JADX WARNING: Removed duplicated region for block: B:34:? A[RETURN, SYNTHETIC] */
        public void run() {
            Throwable th;
            DataOutputStream ostream = null;
            try {
                HttpURLConnection con = (HttpURLConnection) new URL(this.url).openConnection();
                con.setRequestMethod("POST");
                con.setDoInput(true);
                con.setDoOutput(true);
                DataOutputStream ostream2 = new DataOutputStream(con.getOutputStream());
                try {
                    ostream2.writeBytes(this.params);
                    if (con.getResponseCode() == 200) {
                        onSuccess();
                    } else {
                        onFailure();
                    }
                    con.disconnect();
                    if (ostream2 != null) {
                        try {
                            ostream2.flush();
                            ostream2.close();
                        } catch (Exception e) {
                        }
                    }
                } catch (Exception e2) {
                    ostream = ostream2;
                    try {
                        onFailure();
                        if (ostream == null) {
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (ostream != null) {
                            try {
                                ostream.flush();
                                ostream.close();
                            } catch (Exception e3) {
                                return;
                            }
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    ostream = ostream2;
                    if (ostream != null) {
                    }
                    throw th;
                }
            } catch (Exception e4) {
                onFailure();
                if (ostream == null) {
                    try {
                        ostream.flush();
                        ostream.close();
                    } catch (Exception e5) {
                    }
                }
            }
        }

        public void onSuccess() {
            if (this.listener != null && this.activity != null) {
                try {
                    this.activity.runOnUiThread(new Runnable() {
                        /* class com.mobclix.android.sdk.MobclixUtility.POSTThread.AnonymousClass1 */

                        public void run() {
                            POSTThread.this.listener.onSuccess();
                        }
                    });
                } catch (Exception e) {
                }
            }
        }

        public void onFailure() {
            if (this.listener != null && this.activity != null) {
                try {
                    this.activity.runOnUiThread(new Runnable() {
                        /* class com.mobclix.android.sdk.MobclixUtility.POSTThread.AnonymousClass2 */

                        public void run() {
                            POSTThread.this.listener.onFailure();
                        }
                    });
                } catch (Exception e) {
                }
            }
        }
    }
}
