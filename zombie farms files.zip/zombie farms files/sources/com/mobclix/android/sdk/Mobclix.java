package com.mobclix.android.sdk;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Criteria;
import android.location.Location;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.android.adsymp.core.ASConstants;
import com.flurry.android.Constants;
import com.mobclix.android.sdk.MobclixAnalytics;
import com.mobclix.android.sdk.MobclixCreative;
import com.mobclix.android.sdk.MobclixLocation;
import com.ngmoco.gamejs.ui.Commands;
import com.ngmoco.gamejs.ui.JSWebViewAdapter;
import com.tapjoy.TapjoyConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

public final class Mobclix {
    static final boolean DEBUG = false;
    public static final int LOG_LEVEL_DEBUG = 1;
    public static final int LOG_LEVEL_ERROR = 8;
    public static final int LOG_LEVEL_FATAL = 16;
    public static final int LOG_LEVEL_INFO = 2;
    public static final int LOG_LEVEL_WARN = 4;
    static final String[] MC_AD_SIZES = {"320x50", "300x250"};
    static final String MC_CUSTOM_AD_FILENAME = "_mc_cached_custom_ad.png";
    static final String MC_CUSTOM_AD_PREF = "CustomAdUrl";
    static final String MC_KEY_CONNECTION_TYPE = "g";
    private static final String MC_KEY_EVENT_DESCRIPTION = "ed";
    private static final String MC_KEY_EVENT_LOG_LEVEL = "el";
    private static final String MC_KEY_EVENT_NAME = "en";
    private static final String MC_KEY_EVENT_PROCESS_NAME = "ep";
    private static final String MC_KEY_EVENT_STOP = "es";
    private static final String MC_KEY_EVENT_THREAD_ID = "et";
    static final String MC_KEY_LATITUDE_LONGITUDE = "ll";
    static final String MC_KEY_SESSION_ID = "id";
    private static final String MC_KEY_TIMESTAMP = "ts";
    public static final String MC_LIBRARY_VERSION = "2.3.0";
    private static final String MC_TAG = "mobclix-controller";
    static final String PREFS_CONFIG = ".MCConfig";
    static HashMap<String, Boolean> autoplay = new HashMap<>();
    static HashMap<String, Long> autoplayInterval = new HashMap<>();
    private static final Mobclix controller = new Mobclix();
    static HashMap<String, Boolean> customAdSet = new HashMap<>();
    static HashMap<String, String> customAdUrl = new HashMap<>();
    static HashMap<String, String> debugConfig = new HashMap<>();
    static HashMap<String, Boolean> enabled = new HashMap<>();
    private static boolean isInitialized = false;
    static HashMap<String, Long> refreshTime = new HashMap<>();
    static HashMap<String, Boolean> rmRequireUser = new HashMap<>();
    String adServer = "http://ads.mobclix.com/";
    String analyticsServer = "http://data.mobclix.com/post/sendData";
    private String androidId = "null";
    private String androidVersion = "null";
    private String applicationId = "null";
    private String applicationVersion = "null";
    private int batteryLevel = -1;
    MobclixCreative.MobclixWebView cameraWebview;
    String configServer = "http://data.mobclix.com/post/config";
    private String connectionType = "null";
    private Context context;
    String debugServer = "http://data.mobclix.com/post/debug";
    private String deviceHardwareModel = "null";
    String deviceId = "null";
    private String deviceModel = "null";
    String feedbackServer = "http://data.mobclix.com/post/feedback";
    private boolean haveLocationPermission = false;
    int idleTimeout = 120000;
    private MobclixInstrumentation instrumentation = MobclixInstrumentation.getInstance();
    private boolean isInSession = false;
    boolean isNewUser = false;
    boolean isOfflineSession = false;
    private boolean isTopTask = false;
    private String language = "null";
    private String latitude = "null";
    private String locale = "null";
    MobclixLocation location = new MobclixLocation();
    private Criteria locationCriteria;
    private Handler locationHandler;
    private int logLevel = 16;
    private String longitude = "null";
    private Handler mHandler;
    private String mcc = "null";
    private String mnc = "null";
    List<String> nativeUrls = new ArrayList();
    HashMap<String, Boolean> permissions = new HashMap<>();
    private String platform = "android";
    int pollTime = 30000;
    String previousDeviceId = null;
    int remoteConfigSet = 0;
    private int rooted = -1;
    JSONObject session = new JSONObject();
    private long sessionEndTime = 0;
    private Timer sessionPollingTimer = new Timer();
    private long sessionStartTime = 0;
    private SharedPreferences sharedPrefs = null;
    private long totalIdleTime = 0;
    private String userAgent = "null";
    String vcServer = "http://vc.mobclix.com";
    MobclixCreative.MobclixWebView webview;

    /* access modifiers changed from: package-private */
    public void setContext(Activity a) {
        this.context = a;
    }

    /* access modifiers changed from: package-private */
    public Context getContext() {
        return this.context;
    }

    public String getApplicationId() {
        return this.applicationId == null ? "null" : this.applicationId;
    }

    /* access modifiers changed from: package-private */
    public String getPlatform() {
        return this.platform == null ? "null" : this.platform;
    }

    /* access modifiers changed from: package-private */
    public String getAndroidVersion() {
        return this.androidVersion == null ? "null" : this.androidVersion;
    }

    /* access modifiers changed from: package-private */
    public String getApplicationVersion() {
        return this.applicationVersion == null ? "null" : this.applicationVersion;
    }

    /* access modifiers changed from: package-private */
    public String getDeviceId() {
        return this.deviceId == null ? "null" : this.deviceId;
    }

    /* access modifiers changed from: package-private */
    public String getAndroidId() {
        return this.androidId == null ? "null" : this.androidId;
    }

    /* access modifiers changed from: package-private */
    public String getDeviceModel() {
        return this.deviceModel == null ? "null" : this.deviceModel;
    }

    /* access modifiers changed from: package-private */
    public String getDeviceHardwareModel() {
        return this.deviceHardwareModel == null ? "null" : this.deviceHardwareModel;
    }

    /* access modifiers changed from: package-private */
    public String getConnectionType() {
        return this.connectionType == null ? "null" : this.connectionType;
    }

    /* access modifiers changed from: package-private */
    public String getLatitude() {
        return this.latitude == null ? "null" : this.latitude;
    }

    /* access modifiers changed from: package-private */
    public String getLongitude() {
        return this.longitude == null ? "null" : this.longitude;
    }

    /* access modifiers changed from: package-private */
    public String getGPS() {
        if (getLatitude().equals("null") || getLongitude().equals("null")) {
            return "null";
        }
        return String.valueOf(getLatitude()) + "," + getLongitude();
    }

    /* access modifiers changed from: package-private */
    public String getLocale() {
        return this.locale == null ? "null" : this.locale;
    }

    /* access modifiers changed from: package-private */
    public String getLanguage() {
        return this.language == null ? "null" : this.language;
    }

    /* access modifiers changed from: package-private */
    public String getMcc() {
        return this.mcc == null ? "null" : this.mcc;
    }

    /* access modifiers changed from: package-private */
    public String getMnc() {
        return this.mnc == null ? "null" : this.mnc;
    }

    /* access modifiers changed from: package-private */
    public int getBatteryLevel() {
        return this.batteryLevel;
    }

    /* access modifiers changed from: package-private */
    public String getMobclixVersion() {
        return MC_LIBRARY_VERSION;
    }

    /* access modifiers changed from: package-private */
    public int getLogLevel() {
        return this.logLevel;
    }

    /* access modifiers changed from: package-private */
    public boolean isTopTask() {
        return this.isTopTask;
    }

    /* access modifiers changed from: package-private */
    public boolean hasLocationPermission() {
        return this.haveLocationPermission;
    }

    /* access modifiers changed from: package-private */
    public String getDebugConfig(String tag) {
        try {
            return debugConfig.get(tag);
        } catch (Exception e) {
            return ASConstants.kEmptyString;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean isEnabled(String size) {
        try {
            return enabled.get(size).booleanValue();
        } catch (Exception e) {
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public long getRefreshTime(String size) {
        try {
            return refreshTime.get(size).longValue();
        } catch (Exception e) {
            return -1;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean shouldAutoplay(String size) {
        try {
            return autoplay.get(size).booleanValue();
        } catch (Exception e) {
            return false;
        }
    }

    /* access modifiers changed from: package-private */
    public Long getAutoplayInterval(String size) {
        try {
            return autoplayInterval.get(size);
        } catch (Exception e) {
            return 0L;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean rmRequireUserInteraction(String size) {
        try {
            return rmRequireUser.get(size).booleanValue();
        } catch (Exception e) {
            return true;
        }
    }

    /* access modifiers changed from: package-private */
    public String getCustomAdUrl(String size) {
        try {
            return customAdUrl.get(size);
        } catch (Exception e) {
            return ASConstants.kEmptyString;
        }
    }

    /* access modifiers changed from: package-private */
    public String getDebugServer() {
        return this.debugServer;
    }

    /* access modifiers changed from: package-private */
    public String getAdServer() {
        return this.adServer;
    }

    /* access modifiers changed from: package-private */
    public String getConfigServer() {
        return this.configServer;
    }

    /* access modifiers changed from: package-private */
    public String getAnalyticsServer() {
        return this.analyticsServer;
    }

    /* access modifiers changed from: package-private */
    public String getVcServer() {
        return this.vcServer;
    }

    /* access modifiers changed from: package-private */
    public String getFeedbackServer() {
        return this.feedbackServer;
    }

    /* access modifiers changed from: package-private */
    public List<String> getNativeUrls() {
        return this.nativeUrls;
    }

    /* access modifiers changed from: package-private */
    public int isRemoteConfigSet() {
        return this.remoteConfigSet;
    }

    /* access modifiers changed from: package-private */
    public String getUserAgent() {
        if (this.userAgent.equals("null") && hasPref("UserAgent")) {
            this.userAgent = getPref("UserAgent");
        }
        return this.userAgent;
    }

    /* access modifiers changed from: package-private */
    public void setUserAgent(String u) {
        this.userAgent = u;
        addPref("UserAgent", u);
    }

    /* access modifiers changed from: package-private */
    public boolean isRootedSet() {
        return this.rooted != -1;
    }

    public boolean isDeviceRooted() {
        if (this.rooted != -1) {
            return this.rooted == 1;
        }
        try {
            Runtime.getRuntime().exec("su");
            this.rooted = 1;
        } catch (Exception e) {
            this.rooted = 0;
        }
        return this.rooted == 1;
    }

    static HashMap<String, String> getAllPref() {
        try {
            return (HashMap) controller.sharedPrefs.getAll();
        } catch (Exception e) {
            return new HashMap<>();
        }
    }

    static String getPref(String k) {
        try {
            return controller.sharedPrefs.getString(k, ASConstants.kEmptyString);
        } catch (Exception e) {
            return ASConstants.kEmptyString;
        }
    }

    static boolean hasPref(String k) {
        try {
            return controller.sharedPrefs.contains(k);
        } catch (Exception e) {
            return false;
        }
    }

    static void addPref(String k, String v) {
        try {
            SharedPreferences.Editor spe = controller.sharedPrefs.edit();
            spe.putString(k, v);
            spe.commit();
        } catch (Exception e) {
        }
    }

    static void addPref(Map<String, String> m) {
        try {
            SharedPreferences.Editor spe = controller.sharedPrefs.edit();
            for (Map.Entry<String, String> pair : m.entrySet()) {
                spe.putString(pair.getKey(), pair.getValue());
            }
            spe.commit();
        } catch (Exception e) {
        }
    }

    static void removePref(String k) {
        try {
            SharedPreferences.Editor spe = controller.sharedPrefs.edit();
            spe.remove(k);
            spe.commit();
        } catch (Exception e) {
        }
    }

    static void clearPref() {
        try {
            SharedPreferences.Editor spe = controller.sharedPrefs.edit();
            spe.clear();
            spe.commit();
        } catch (Exception e) {
        }
    }

    private static String sha1(String string) {
        byte[] bArr = new byte[40];
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            md.update(string.getBytes(), 0, string.length());
            byte[] shaHash = md.digest();
            StringBuffer hexString = new StringBuffer();
            for (byte b : shaHash) {
                hexString.append(Integer.toHexString(b & Constants.UNKNOWN));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException ex) {
            throw new RuntimeException(ex);
        }
    }

    /* access modifiers changed from: package-private */
    public void updateSession() {
        updateConnectivity();
        if (this.haveLocationPermission) {
            this.locationHandler.sendEmptyMessage(0);
        }
        try {
            this.session.put(MC_KEY_TIMESTAMP, System.currentTimeMillis());
            String loc = getGPS();
            if (!loc.equals("null")) {
                this.session.put(MC_KEY_LATITUDE_LONGITUDE, loc);
            } else {
                this.session.remove(MC_KEY_LATITUDE_LONGITUDE);
            }
            this.session.put(MC_KEY_CONNECTION_TYPE, this.connectionType);
        } catch (JSONException e) {
        }
    }

    /* access modifiers changed from: package-private */
    public void updateLocation() {
        this.location.getLocation(this.context, new MobclixLocation.LocationResult() {
            /* class com.mobclix.android.sdk.Mobclix.AnonymousClass1 */

            @Override // com.mobclix.android.sdk.MobclixLocation.LocationResult
            public void gotLocation(Location location) {
                try {
                    Mobclix.this.latitude = Double.toString(location.getLatitude());
                    Mobclix.this.longitude = Double.toString(location.getLongitude());
                } catch (Exception e) {
                }
            }
        });
    }

    private void updateConnectivity() {
        NetworkInfo network_info;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) this.context.getSystemService("connectivity");
            String network_type = "u";
            if (this.permissions.get("android.permission.ACCESS_NETWORK_STATE").booleanValue() && (network_info = connectivityManager.getActiveNetworkInfo()) != null) {
                network_type = network_info.getTypeName();
            }
            if (network_type.equals("WI_FI") || network_type.equals("WIFI")) {
                this.connectionType = "wifi";
            } else if (network_type.equals("MOBILE")) {
                this.connectionType = Integer.toString(((TelephonyManager) this.context.getSystemService("phone")).getNetworkType());
            } else {
                this.connectionType = "null";
            }
            if (this.connectionType == null) {
                this.connectionType = "null";
            }
        } catch (Exception e) {
            this.connectionType = "null";
        }
    }

    private Mobclix() {
    }

    public static Mobclix getInstance() {
        return controller;
    }

    public static final synchronized void onCreateWithApplicationId(Activity a, String appId) {
        synchronized (Mobclix.class) {
            if (a == null) {
                throw new Resources.NotFoundException("Activity not provided.");
            }
            if (appId != null && !appId.equals(controller.applicationId)) {
                if (!controller.isInSession) {
                    controller.endSession();
                }
                controller.isInSession = false;
                controller.isTopTask = false;
                controller.sessionStartTime = 0;
                controller.sessionEndTime = 0;
                controller.totalIdleTime = 0;
                controller.remoteConfigSet = 0;
                isInitialized = false;
            }
            try {
                controller.context = a.getApplicationContext();
            } catch (Exception e) {
            }
            if (!isInitialized) {
                try {
                    controller.initialize(a, appId);
                } catch (MobclixPermissionException e2) {
                    throw e2;
                } catch (Exception e3) {
                }
            }
            controller.handleSessionStatus(true);
        }
    }

    public static final synchronized void onCreate(Activity a) {
        synchronized (Mobclix.class) {
            onCreateWithApplicationId(a, null);
        }
    }

    private void initialize(Activity a, String appId) {
        this.sharedPrefs = a.getSharedPreferences(String.valueOf(a.getPackageName()) + PREFS_CONFIG, 0);
        String[] strArr = MobclixInstrumentation.MC_DEBUG_CATS;
        for (String v : strArr) {
            if (hasPref("debug_" + v)) {
                debugConfig.put(v, getPref("debug_" + v));
            }
        }
        if (this.instrumentation == null) {
            this.instrumentation = MobclixInstrumentation.getInstance();
        }
        String instrPath = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.startGroup(MobclixInstrumentation.STARTUP), "init"), "environment");
        String packageName = ASConstants.kEmptyString;
        ApplicationInfo applicationInfo = null;
        try {
            packageName = a.getPackageName();
        } catch (Exception e) {
        }
        try {
            applicationInfo = a.getPackageManager().getApplicationInfo(packageName, Commands.CommandIDs.setVisibleInOrientations);
        } catch (PackageManager.NameNotFoundException e2) {
            Log.e(MC_TAG, "Application Key Started");
        }
        if (appId == null) {
            try {
                appId = applicationInfo.metaData.getString("com.mobclix.APPLICATION_ID");
                if (appId == null) {
                    throw new Resources.NotFoundException("com.mobclix.APPLICATION_ID not found in the Android Manifest xml.");
                }
            } catch (NullPointerException e3) {
                throw new Resources.NotFoundException("com.mobclix.APPLICATION_ID not found in the Android Manifest xml.");
            }
        }
        this.applicationId = appId;
        String logLevelString = null;
        try {
            logLevelString = applicationInfo.metaData.getString("com.mobclix.LOG_LEVEL");
        } catch (Exception e4) {
        }
        int logLevelSetting = 16;
        if (logLevelString != null) {
            if (logLevelString.equalsIgnoreCase("debug")) {
                logLevelSetting = 1;
            } else if (logLevelString.equalsIgnoreCase("info")) {
                logLevelSetting = 2;
            } else if (logLevelString.equalsIgnoreCase("warn")) {
                logLevelSetting = 4;
            } else if (logLevelString.equalsIgnoreCase(JSWebViewAdapter.Events.ERROR)) {
                logLevelSetting = 8;
            } else if (logLevelString.equalsIgnoreCase("fatal")) {
                logLevelSetting = 16;
            }
        }
        this.logLevel = logLevelSetting;
        this.context = a;
        if (this.applicationId == null || this.applicationId.equals(ASConstants.kEmptyString)) {
            this.applicationId = "null";
        }
        this.androidVersion = Build.VERSION.RELEASE;
        if (this.androidVersion == null || this.androidVersion.equals(ASConstants.kEmptyString)) {
            this.androidVersion = "null";
        }
        String app_name = ASConstants.kEmptyString;
        PackageManager package_manager = this.context.getPackageManager();
        try {
            app_name = this.context.getPackageName();
        } catch (Exception e5) {
        }
        if (package_manager.checkPermission("android.permission.GET_TASKS", app_name) != 0) {
            throw new MobclixPermissionException("Missing required permission GET_TASKS.");
        }
        this.permissions.put("android.permission.GET_TASKS", true);
        if (package_manager.checkPermission("android.permission.INTERNET", app_name) != 0) {
            throw new MobclixPermissionException("Missing required permission INTERNET.");
        }
        this.permissions.put("android.permission.INTERNET", true);
        if (package_manager.checkPermission("android.permission.READ_PHONE_STATE", app_name) != 0) {
            throw new MobclixPermissionException("Missing required permission READ_PHONE_STATE.");
        }
        this.permissions.put("android.permission.READ_PHONE_STATE", true);
        try {
            if (package_manager.checkPermission("android.permission.BATTERY_STATS", app_name) == 0) {
                this.context.registerReceiver(new BroadcastReceiver() {
                    /* class com.mobclix.android.sdk.Mobclix.AnonymousClass2 */

                    public void onReceive(Context context, Intent intent) {
                        Mobclix.this.batteryLevel = intent.getIntExtra("level", 0);
                    }
                }, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
            }
            this.permissions.put("android.permission.BATTERY_STATS", true);
        } catch (Exception e6) {
        }
        if (package_manager.checkPermission("android.permission.CAMERA", app_name) == 0) {
            this.permissions.put("android.permission.CAMERA", true);
        }
        if (package_manager.checkPermission("android.permission.READ_CALENDAR", app_name) == 0) {
            this.permissions.put("android.permission.READ_CALENDAR", true);
        }
        if (package_manager.checkPermission("android.permission.WRITE_CALENDAR", app_name) == 0) {
            this.permissions.put("android.permission.WRITE_CALENDAR", true);
        }
        if (package_manager.checkPermission("android.permission.READ_CONTACTS", app_name) == 0) {
            this.permissions.put("android.permission.READ_CONTACTS", true);
        }
        if (package_manager.checkPermission("android.permission.WRITE_CONTACTS", app_name) == 0) {
            this.permissions.put("android.permission.WRITE_CONTACTS", true);
        }
        if (package_manager.checkPermission("android.permission.GET_ACCOUNTS", app_name) == 0) {
            this.permissions.put("android.permission.GET_ACCOUNTS", true);
        }
        if (package_manager.checkPermission("android.permission.VIBRATE", app_name) == 0) {
            this.permissions.put("android.permission.VIBRATE", true);
        }
        try {
            if (package_manager.checkPermission("android.permission.ACCESS_FINE_LOCATION", app_name) == 0) {
                this.locationCriteria = new Criteria();
                this.locationCriteria.setAccuracy(1);
                this.haveLocationPermission = true;
                this.permissions.put("android.permission.ACCESS_FINE_LOCATION", true);
            } else if (package_manager.checkPermission("android.permission.ACCESS_COARSE_LOCATION", app_name) == 0) {
                this.locationCriteria = new Criteria();
                this.locationCriteria.setAccuracy(2);
                this.haveLocationPermission = true;
                this.permissions.put("android.permission.ACCESS_COARSE_LOCATION", true);
            } else {
                this.haveLocationPermission = false;
            }
            if (package_manager.checkPermission("android.permission.ACCESS_NETWORK_STATE", app_name) == 0) {
                this.permissions.put("android.permission.ACCESS_NETWORK_STATE", true);
            }
        } catch (Exception e7) {
        }
        TelephonyManager telephonyManager = null;
        try {
            telephonyManager = (TelephonyManager) this.context.getSystemService("phone");
        } catch (Exception e8) {
        }
        try {
            this.applicationVersion = package_manager.getPackageInfo(app_name, 0).versionName;
        } catch (Exception e9) {
        }
        if (this.applicationVersion == null || this.applicationVersion.equals(ASConstants.kEmptyString)) {
            this.applicationVersion = "null";
        }
        try {
            this.androidId = Settings.System.getString(a.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        } catch (Exception e10) {
            try {
                this.androidId = Settings.System.getString(a.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
            } catch (Exception e11) {
            }
        }
        if (this.androidId == null || this.androidId.equals(ASConstants.kEmptyString)) {
            this.androidId = "null";
        }
        try {
            this.deviceId = telephonyManager.getDeviceId();
        } catch (Exception e12) {
        }
        if (this.deviceId == null || this.deviceId.equals(ASConstants.kEmptyString)) {
            this.deviceId = this.androidId;
        }
        try {
            this.deviceModel = Build.MODEL;
        } catch (Exception e13) {
        }
        if (this.deviceModel == null || this.deviceModel.equals(ASConstants.kEmptyString)) {
            this.deviceModel = "null";
        }
        try {
            this.deviceHardwareModel = Build.DEVICE;
        } catch (Exception e14) {
        }
        if (this.deviceHardwareModel == null || this.deviceHardwareModel.equals(ASConstants.kEmptyString)) {
            this.deviceHardwareModel = "null";
        }
        try {
            String networkOperator = telephonyManager.getNetworkOperator();
            if (networkOperator != null) {
                this.mcc = networkOperator.substring(0, 3);
                this.mnc = networkOperator.substring(3);
            }
        } catch (Exception e15) {
        }
        if (this.mcc == null || this.mcc.equals(ASConstants.kEmptyString)) {
            this.mcc = "null";
        }
        if (this.mnc == null || this.mnc.equals(ASConstants.kEmptyString)) {
            this.mnc = "null";
        }
        try {
            Locale d = Locale.getDefault();
            this.locale = d.toString();
            this.language = d.getLanguage();
        } catch (Exception e16) {
        }
        if (this.locale == null || this.locale.equals(ASConstants.kEmptyString)) {
            this.locale = "null";
        }
        if (this.language == null || this.language.equals(ASConstants.kEmptyString)) {
            this.language = "null";
        }
        CookieSyncManager.createInstance(this.context);
        this.locationHandler = new Handler() {
            /* class com.mobclix.android.sdk.Mobclix.AnonymousClass3 */

            public void handleMessage(Message msg) {
                Mobclix.this.updateLocation();
            }
        };
        String instrPath2 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath), "session");
        this.mHandler = new MobclixConfigHandler();
        this.pollTime = Math.min(this.pollTime, this.idleTimeout);
        this.sessionPollingTimer.scheduleAtFixedRate(new SessionPolling(this, null), (long) this.pollTime, (long) this.pollTime);
        isInitialized = true;
        this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath2));
    }

    public static final synchronized void onStop(Activity a) {
        synchronized (Mobclix.class) {
            controller.handleSessionStatus(false);
        }
    }

    /* access modifiers changed from: package-private */
    public class MobclixConfigHandler extends Handler {
        MobclixConfigHandler() {
        }

        public void handleMessage(Message msg) {
            Mobclix.this.createNewSession();
        }
    }

    public static final void logEvent(int eventLogLevel, String processName, String eventName, String description, boolean stopProcess) {
        if (!isInitialized) {
            Log.v(MC_TAG, "logEvent failed - You must initialize Mobclix by calling Mobclix.onCreate(this).");
        } else if (eventLogLevel >= controller.logLevel) {
            String logString = String.valueOf(processName) + ", " + eventName + ": " + description;
            switch (eventLogLevel) {
                case 1:
                    Log.d("Mobclix", logString);
                    break;
                case 2:
                    Log.i("Mobclix", logString);
                    break;
                case 4:
                    Log.w("Mobclix", logString);
                    break;
                case 8:
                    Log.e("Mobclix", logString);
                    break;
                case 16:
                    Log.e("Mobclix", logString);
                    break;
            }
            try {
                JSONObject event = new JSONObject(controller.session, new String[]{MC_KEY_TIMESTAMP, MC_KEY_LATITUDE_LONGITUDE, MC_KEY_CONNECTION_TYPE, MC_KEY_SESSION_ID});
                event.put(MC_KEY_EVENT_LOG_LEVEL, Integer.toString(eventLogLevel));
                event.put(MC_KEY_EVENT_PROCESS_NAME, URLEncoder.encode(processName, "UTF-8"));
                event.put(MC_KEY_EVENT_NAME, URLEncoder.encode(eventName, "UTF-8"));
                event.put(MC_KEY_EVENT_DESCRIPTION, URLEncoder.encode(description, "UTF-8"));
                event.put(MC_KEY_EVENT_THREAD_ID, Long.toString(Thread.currentThread().getId()));
                event.put(MC_KEY_EVENT_STOP, stopProcess ? "1" : "0");
                new Thread(new MobclixAnalytics.LogEvent(event)).start();
            } catch (Exception e) {
            }
        }
    }

    public static final void sync() {
        if (!isInitialized) {
            Log.v(MC_TAG, "sync failed - You must initialize Mobclix by calling Mobclix.onCreate(this).");
        } else if (MobclixAnalytics.getSyncStatus() == MobclixAnalytics.SYNC_READY) {
            new Thread(new MobclixAnalytics.Sync()).start();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private synchronized void createNewSession() {
        String instrPath = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkStart(this.instrumentation.startGroup(MobclixInstrumentation.STARTUP), "session"), "init");
        long ts = System.currentTimeMillis();
        String sessionId = sha1(String.valueOf(this.deviceId) + ts);
        this.isTopTask = true;
        this.sessionStartTime = ts;
        this.sessionEndTime = 0;
        this.totalIdleTime = 0;
        this.isInSession = true;
        try {
            this.session.put(MC_KEY_SESSION_ID, URLEncoder.encode(sessionId, "UTF-8"));
        } catch (Exception e) {
        }
        String instrPath2 = this.instrumentation.benchmarkStart(this.instrumentation.benchmarkFinishPath(instrPath), "config");
        this.remoteConfigSet = 0;
        new FetchRemoteConfig().execute(new String[0]);
        this.instrumentation.benchmarkFinishPath(this.instrumentation.benchmarkFinishPath(instrPath2));
    }

    /* access modifiers changed from: private */
    public class SessionPolling extends TimerTask {
        private SessionPolling() {
        }

        /* synthetic */ SessionPolling(Mobclix mobclix, SessionPolling sessionPolling) {
            this();
        }

        public synchronized void run() {
            Mobclix.this.handleSessionStatus(isTopTask());
        }

        public boolean isTopTask() {
            try {
                return ((ActivityManager) Mobclix.this.context.getSystemService("activity")).getRunningTasks(1).get(0).topActivity.getPackageName().equals(Mobclix.this.context.getPackageName());
            } catch (Exception e) {
                return false;
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    private synchronized void handleSessionStatus(boolean topTask) {
        long ts = System.currentTimeMillis();
        if (topTask) {
            if (!this.isTopTask) {
                if (!this.isInSession) {
                    this.mHandler.sendEmptyMessage(0);
                } else {
                    this.totalIdleTime += ts - this.sessionEndTime;
                    this.isTopTask = true;
                }
            }
        } else if (this.isTopTask) {
            this.sessionEndTime = ts;
            this.isTopTask = false;
            this.location.stopLocation();
        } else if (ts - this.sessionEndTime > ((long) this.idleTimeout) && this.isInSession) {
            endSession();
        }
    }

    private void endSession() {
        try {
            if (this.isInSession) {
                long sessionTime = this.sessionEndTime - this.sessionStartTime;
                if (hasPref("totalSessionTime")) {
                    try {
                        sessionTime += Long.parseLong(getPref("totalSessionTime"));
                    } catch (Exception e) {
                    }
                }
                if (hasPref("totalIdleTime")) {
                    try {
                        this.totalIdleTime += Long.parseLong(getPref("totalIdleTime"));
                    } catch (Exception e2) {
                    }
                }
                HashMap<String, String> sessionStats = new HashMap<>();
                sessionStats.put("totalSessionTime", Long.toString(sessionTime));
                sessionStats.put("totalIdleTime", Long.toString(this.totalIdleTime));
                if (this.isOfflineSession) {
                    int offlineSessions = 1;
                    if (hasPref("offlineSessions")) {
                        try {
                            offlineSessions = 1 + Integer.parseInt(getPref("offlineSessions"));
                        } catch (Exception e3) {
                        }
                    }
                    sessionStats.put("offlineSessions", Long.toString((long) offlineSessions));
                }
                addPref(sessionStats);
                this.isInSession = false;
                this.isTopTask = false;
                this.sessionStartTime = 0;
                this.sessionEndTime = 0;
                this.totalIdleTime = 0;
            }
        } catch (Exception e4) {
        }
    }

    /* access modifiers changed from: protected */
    public void finalize() {
        endSession();
    }

    /* access modifiers changed from: package-private */
    public class MobclixPermissionException extends RuntimeException {
        private static final long serialVersionUID = -2362572513974509340L;

        MobclixPermissionException(String detailMessage) {
            super(detailMessage);
        }
    }

    static String getCookieStringFromCookieManager(String url) {
        try {
            return CookieManager.getInstance().getCookie(url);
        } catch (Exception e) {
            return ASConstants.kEmptyString;
        }
    }

    static void syncCookiesToCookieManager(CookieStore cs, String url) {
        try {
            CookieManager cookieManager = CookieManager.getInstance();
            List<Cookie> cookies = cs.getCookies();
            StringBuffer cookieStringBuffer = new StringBuffer();
            if (!cookies.isEmpty()) {
                for (int i = 0; i < cookies.size(); i++) {
                    Cookie c = cookies.get(i);
                    cookieStringBuffer.append(c.getName()).append("=").append(c.getValue());
                    if (c.getExpiryDate() != null) {
                        cookieStringBuffer.append("; expires=").append(new SimpleDateFormat("E, dd-MMM-yyyy HH:mm:ss").format(c.getExpiryDate())).append(" GMT");
                    }
                    if (c.getPath() != null) {
                        cookieStringBuffer.append("; path=").append(c.getPath());
                    }
                    if (c.getDomain() != null) {
                        cookieStringBuffer.append("; domain=").append(c.getDomain());
                    }
                    cookieManager.setCookie(url, cookieStringBuffer.toString());
                }
                CookieSyncManager.getInstance().sync();
                CookieSyncManager.getInstance().stopSync();
            }
        } catch (Exception e) {
        }
    }

    /* access modifiers changed from: package-private */
    public static class MobclixHttpClient extends DefaultHttpClient {
        HttpGet httpGet = new HttpGet(this.url);
        String url;

        public MobclixHttpClient(String u) {
            this.url = u;
            this.httpGet.setHeader("Cookie", Mobclix.getCookieStringFromCookieManager(this.url));
            this.httpGet.setHeader("User-Agent", Mobclix.controller.getUserAgent());
        }

        public HttpResponse execute() throws ClientProtocolException, IOException {
            try {
                HttpResponse httpResponse = Mobclix.super.execute(this.httpGet);
                Mobclix.syncCookiesToCookieManager(getCookieStore(), this.url);
                return httpResponse;
            } catch (Throwable th) {
                return null;
            }
        }
    }

    static class BitmapHandler extends Handler {
        protected Bitmap bmImg = null;
        protected Object state = null;

        BitmapHandler() {
        }

        public void setBitmap(Bitmap bm) {
            this.bmImg = bm;
        }

        public void setState(Object o) {
            this.state = o;
        }
    }

    static class FetchImageThread implements Runnable {
        private Bitmap bmImg;
        private BitmapHandler handler;
        private String imageUrl;

        FetchImageThread(String url, BitmapHandler h) {
            this.imageUrl = url;
            this.handler = h;
        }

        public void run() {
            try {
                HttpEntity httpEntity = new MobclixHttpClient(this.imageUrl).execute().getEntity();
                this.bmImg = BitmapFactory.decodeStream(httpEntity.getContent());
                httpEntity.consumeContent();
                this.handler.setBitmap(this.bmImg);
            } catch (Throwable th) {
            }
            this.handler.sendEmptyMessage(0);
        }
    }

    static class FetchResponseThread extends TimerTask implements Runnable {
        private Handler handler;
        private String url;

        FetchResponseThread(String u, Handler h) {
            this.url = u;
            this.handler = h;
        }

        public void run() {
            Throwable th;
            int errorCode;
            Mobclix.controller.updateSession();
            if (this.url.equals(ASConstants.kEmptyString)) {
                sendErrorCode(-503);
            }
            String response = ASConstants.kEmptyString;
            BufferedReader br = null;
            try {
                HttpResponse httpResponse = new MobclixHttpClient(this.url).execute();
                HttpEntity httpEntity = httpResponse.getEntity();
                int responseCode = httpResponse.getStatusLine().getStatusCode();
                if ((responseCode == 200 || responseCode == 251) && httpEntity != null) {
                    BufferedReader br2 = new BufferedReader(new InputStreamReader(httpEntity.getContent()), 8000);
                    try {
                        for (String tmp = br2.readLine(); tmp != null; tmp = br2.readLine()) {
                            response = String.valueOf(response) + tmp;
                        }
                        httpEntity.consumeContent();
                        if (!response.equals(ASConstants.kEmptyString)) {
                            Message msg = new Message();
                            Bundle bundle = new Bundle();
                            bundle.putString("type", "success");
                            bundle.putString("response", response);
                            msg.setData(bundle);
                            this.handler.sendMessage(msg);
                            br = br2;
                        } else {
                            br = br2;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        br = br2;
                        br.close();
                        throw th;
                    }
                } else {
                    switch (responseCode) {
                        case 251:
                            String sub = httpResponse.getFirstHeader("X-Mobclix-Suballocation").getValue();
                            if (sub == null) {
                                errorCode = -503;
                                break;
                            } else {
                                errorCode = Integer.parseInt(sub);
                                break;
                            }
                        default:
                            errorCode = -503;
                            break;
                    }
                    sendErrorCode(errorCode);
                }
                try {
                    br.close();
                } catch (Exception e) {
                }
            } catch (Throwable th3) {
                sendErrorCode(-503);
                br.close();
            }
        }

        /* access modifiers changed from: package-private */
        public void setUrl(String u) {
            this.url = u;
        }

        private void sendErrorCode(int errorCode) {
            Message msg = new Message();
            Bundle bundle = new Bundle();
            bundle.putString("type", "failure");
            bundle.putInt("errorCode", errorCode);
            msg.setData(bundle);
            this.handler.sendMessage(msg);
        }
    }

    static class ObjectOnClickListener implements DialogInterface.OnClickListener {
        Object obj1;
        Object obj2;
        Object obj3;

        public ObjectOnClickListener(Object o) {
            this.obj1 = o;
        }

        public ObjectOnClickListener(Object o, Object o2) {
            this.obj1 = o;
            this.obj2 = o2;
        }

        public ObjectOnClickListener(Object o, Object o2, Object o3) {
            this.obj1 = o;
            this.obj2 = o2;
            this.obj3 = o3;
        }

        public void onClick(DialogInterface dialog, int which) {
        }
    }
}
