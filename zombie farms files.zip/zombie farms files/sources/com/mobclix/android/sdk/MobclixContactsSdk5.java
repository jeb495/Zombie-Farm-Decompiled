package com.mobclix.android.sdk;

import android.accounts.AccountManager;
import android.app.Activity;
import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Entity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Build;
import android.os.RemoteException;
import android.provider.ContactsContract;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.service.NgSystemBindingService;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class MobclixContactsSdk5 extends MobclixContacts {
    private static String TAG = "MobclixContactsSdk5";
    private final String ACCOUNT_TYPE = "com.google";
    private String accountName;

    @Override // com.mobclix.android.sdk.MobclixContacts
    public Intent getPickContactIntent() {
        return new Intent("android.intent.action.PICK", ContactsContract.Contacts.CONTENT_URI);
    }

    @Override // com.mobclix.android.sdk.MobclixContacts
    public Intent getAddContactIntent(JSONObject contact) {
        String number;
        Uri uri;
        String country;
        String postalCode;
        String state;
        String city;
        String neighborhood;
        String poBox;
        String street;
        String primaryNumber = null;
        try {
            HashMap<String, String> c = parseJSONContact(contact);
            JSONArray addresses = contact.getJSONArray("addresses");
            JSONArray phoneNumbers = contact.getJSONArray("phoneNumbers");
            int j = 0;
            while (true) {
                if (j >= phoneNumbers.length()) {
                    break;
                }
                JSONObject phoneNumber = phoneNumbers.getJSONObject(j);
                if (!(!phoneNumber.has("number") || (number = phoneNumber.getString("number")) == null || number.equals(ASConstants.kEmptyString))) {
                    primaryNumber = number;
                    break;
                }
                j++;
            }
            if (primaryNumber != null) {
                uri = Uri.fromParts("tel", primaryNumber, null);
            } else if (c.get("email") == null) {
                return null;
            } else {
                uri = Uri.fromParts("mailto", c.get("email"), null);
            }
            Intent i = new Intent("com.android.contacts.action.SHOW_OR_CREATE_CONTACT", uri);
            i.putExtra(NgSystemBindingService.EXTRA_NAME, c.get("displayName"));
            i.putExtra("notes", c.get("note"));
            i.putExtra("company", c.get("organization"));
            i.putExtra("job_title", c.get("jobTitle"));
            i.putExtra("email", c.get("email"));
            i.putExtra("email_type", 1);
            i.putExtra("im_handle", c.get("im"));
            i.putExtra("im_protocol", 5);
            if (addresses.length() > 0) {
                JSONObject address = addresses.getJSONObject(0);
                StringBuilder postalAddress = new StringBuilder();
                int type = 1;
                if (address.has("label") && address.getString("label") != null && address.getString("label").equalsIgnoreCase("work")) {
                    type = 2;
                }
                if (address.has("street") && (street = address.getString("street")) != null) {
                    postalAddress.append(street);
                }
                if (address.has("poBox") && (poBox = address.getString("poBox")) != null && !poBox.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(poBox);
                }
                if (address.has("neighborhood") && (neighborhood = address.getString("neighborhood")) != null && !neighborhood.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(neighborhood);
                }
                if (address.has("city") && (city = address.getString("city")) != null && !city.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(city);
                }
                if (address.has("state") && (state = address.getString("state")) != null && !state.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(state);
                }
                if (address.has("postalCode") && (postalCode = address.getString("postalCode")) != null && !postalCode.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(postalCode);
                }
                if (address.has("country") && (country = address.getString("country")) != null && !country.equals(ASConstants.kEmptyString)) {
                    if (postalAddress.length() != 0) {
                        postalAddress.append(", ");
                    }
                    postalAddress.append(country);
                }
                if (postalAddress.length() > 0) {
                    i.putExtra("postal", postalAddress.toString());
                    i.putExtra("postal_type", type);
                }
            }
            for (int j2 = 0; j2 < phoneNumbers.length(); j2++) {
                JSONObject phoneNumber2 = phoneNumbers.getJSONObject(j2);
                int type2 = 1;
                String number2 = null;
                if (phoneNumber2.has("label") && phoneNumber2.getString("label") != null && phoneNumber2.getString("label").equalsIgnoreCase("work")) {
                    type2 = 3;
                }
                if (phoneNumber2.has("number")) {
                    number2 = phoneNumber2.getString("number");
                    if (number2.equals(ASConstants.kEmptyString)) {
                        number2 = null;
                    }
                }
                if (j2 == 0) {
                    i.putExtra("phone", number2);
                    i.putExtra("phone_type", type2);
                } else if (j2 == 1) {
                    i.putExtra("secondary_phone", number2);
                    i.putExtra("secondary_phone_type", type2);
                } else if (j2 != 2) {
                    return i;
                } else {
                    i.putExtra("tertiary_phone", number2);
                    i.putExtra("tertiary_phone_type", type2);
                }
            }
            return i;
        } catch (Exception e) {
            return null;
        }
    }

    private static Cursor setupContactCursor(ContentResolver resolver, Uri lookupUri) {
        if (lookupUri == null) {
            return null;
        }
        List<String> segments = lookupUri.getPathSegments();
        if (segments.size() != 4) {
            return null;
        }
        long uriContactId = Long.parseLong(segments.get(3));
        String uriLookupKey = Uri.encode(segments.get(2));
        Cursor cursor = resolver.query(Uri.withAppendedPath(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, uriContactId), ASConstants.kASResponseKeyData), null, null, null, null);
        if (!cursor.moveToFirst()) {
            cursor.close();
            return null;
        } else if (cursor.getString(cursor.getColumnIndex("lookup")).equals(uriLookupKey)) {
            return cursor;
        } else {
            cursor.close();
            return null;
        }
    }

    /* JADX INFO: finally extract failed */
    /* JADX WARNING: Code restructure failed: missing block: B:290:?, code lost:
        return null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00f3, code lost:
        r17.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x028a, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:0x028b, code lost:
        r17.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:89:0x028e, code lost:
        throw r2;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x028a A[ExcHandler: all (r2v8 'th' java.lang.Throwable A[CUSTOM_DECLARE]), PHI: r17 
      PHI: (r17v1 'cursor' android.database.Cursor) = (r17v0 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor), (r17v4 'cursor' android.database.Cursor) binds: [B:7:0x0039, B:19:0x009a, B:22:0x00a0, B:233:0x05c2, B:234:?, B:23:?, B:20:?, B:42:0x00fe] A[DONT_GENERATE, DONT_INLINE], Splitter:B:7:0x0039] */
    @Override // com.mobclix.android.sdk.MobclixContacts
    public JSONObject loadContact(ContentResolver contentResolver, Uri contactUri) {
        Uri mLookupUri = null;
        String authority = contactUri.getAuthority();
        if ("com.android.contacts".equals(authority)) {
            mLookupUri = contactUri;
        } else if ("contacts".equals(authority)) {
            mLookupUri = ContactsContract.RawContacts.getContactLookupUri(contentResolver, ContentUris.withAppendedId(ContactsContract.RawContacts.CONTENT_URI, ContentUris.parseId(contactUri)));
        }
        JSONObject contactInfo = new JSONObject();
        JSONArray addresses = new JSONArray();
        JSONArray phoneNumbers = new JSONArray();
        try {
            contactInfo.put("addresses", addresses);
            contactInfo.put("phoneNumbers", phoneNumbers);
        } catch (Exception e) {
        }
        Cursor cursor = null;
        String displayName = null;
        try {
            Cursor cursor2 = setupContactCursor(contentResolver, mLookupUri);
            if (cursor2 == null) {
                mLookupUri = ContactsContract.Contacts.getLookupUri(contentResolver, mLookupUri);
                cursor2 = setupContactCursor(contentResolver, mLookupUri);
            }
            long contactId = ContentUris.parseId(mLookupUri);
            cursor2.close();
            cursor = contentResolver.query(ContactsContract.RawContactsEntity.CONTENT_URI, null, "contact_id=?", new String[]{String.valueOf(contactId)}, null);
            ArrayList<Entity> newEntities = new ArrayList<>(cursor.getCount());
            Integer.parseInt(Build.VERSION.SDK);
            MobclixContactsEntityIterator iterator = newEntityIterator(cursor);
            while (iterator.hasNext()) {
                try {
                    newEntities.add((Entity) iterator.next());
                } catch (Throwable th) {
                    iterator.close();
                    throw th;
                }
            }
            iterator.close();
            Iterator<Entity> it = newEntities.iterator();
            while (it.hasNext()) {
                Entity entity = it.next();
                ContentValues entValues = entity.getEntityValues();
                String accountType = entValues.getAsString("account_type");
                long rawContactId = entValues.getAsLong("_id").longValue();
                Log.v("ACCOUNT TYPE: ", String.valueOf(accountType) + ": " + rawContactId);
                Iterator<Entity.NamedContentValues> it2 = entity.getSubValues().iterator();
                while (it2.hasNext()) {
                    Entity.NamedContentValues subValue = it2.next();
                    ContentValues entryValues = subValue.values;
                    entryValues.put("raw_contact_id", Long.valueOf(rawContactId));
                    entryValues.getAsLong("_id").longValue();
                    String mimeType = entryValues.getAsString("mimetype");
                    if (mimeType != null) {
                        if ("vnd.android.cursor.item/phone_v2".equals(mimeType)) {
                            Log.v("loadContact: ", "PHONE");
                            String number = subValue.values.getAsString("data1");
                            String type = "home";
                            if (subValue.values.getAsInteger("data2").intValue() == 3) {
                                type = "work";
                            }
                            if (number != null && !number.equals(ASConstants.kEmptyString)) {
                                JSONObject phoneNumber = new JSONObject();
                                phoneNumber.put("number", number);
                                phoneNumber.put("label", type);
                                phoneNumbers.put(phoneNumber);
                            }
                        } else if ("vnd.android.cursor.item/name".equals(mimeType)) {
                            Log.v("loadContact: ", "NAME");
                            String dName = subValue.values.getAsString("data1");
                            if (dName != null && !dName.equals(ASConstants.kEmptyString)) {
                                displayName = dName;
                            }
                            String firstName = subValue.values.getAsString("data2");
                            String lastName = subValue.values.getAsString("data3");
                            String middleName = subValue.values.getAsString("data5");
                            String prefix = subValue.values.getAsString("data4");
                            String suffix = subValue.values.getAsString("data6");
                            if (firstName != null && !firstName.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("firstName", firstName);
                            }
                            if (lastName != null && !lastName.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("lastName", lastName);
                            }
                            if (middleName != null && !middleName.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("middleName", middleName);
                            }
                            if (prefix != null && !prefix.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("prefix", prefix);
                            }
                            if (suffix != null && !suffix.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("suffix", suffix);
                            }
                        } else if ("vnd.android.cursor.item/nickname".equals(mimeType)) {
                            Log.v("loadContact: ", "NICKNAME");
                            String nickname = subValue.values.getAsString("data1");
                            if (nickname != null && !nickname.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("nickname", nickname);
                            }
                        } else if ("vnd.android.cursor.item/organization".equals(mimeType)) {
                            Log.v("loadContact: ", "ORGANIZATION");
                            String organization = subValue.values.getAsString("data1");
                            String jobTitle = subValue.values.getAsString("data4");
                            String department = subValue.values.getAsString("data5");
                            if (organization != null && !organization.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("organization", organization);
                            }
                            if (jobTitle != null && !jobTitle.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("jobTitle", jobTitle);
                            }
                            if (department != null && !department.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("department", department);
                            }
                        } else if ("vnd.android.cursor.item/email_v2".equals(mimeType)) {
                            Log.v("loadContact: ", "EMAIL");
                            String email = subValue.values.getAsString("data1");
                            if (email != null && !email.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("email", email);
                            }
                        } else if ("vnd.android.cursor.item/note".equals(mimeType)) {
                            Log.v("loadContact: ", "NOTE");
                            String note = subValue.values.getAsString("data1");
                            if (note != null && !note.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("note", note);
                            }
                        } else if ("vnd.android.cursor.item/postal-address_v2".equals(mimeType)) {
                            Log.v("loadContact: ", "POSTAL");
                            String displayPostal = subValue.values.getAsString("data1");
                            if (displayPostal == null || displayPostal.equals(ASConstants.kEmptyString)) {
                                displayPostal = null;
                            }
                            String type2 = "home";
                            if (subValue.values.getAsInteger("data2").intValue() == 2) {
                                type2 = "work";
                            }
                            String street = subValue.values.getAsString("data4");
                            if (street == null || street.equals(ASConstants.kEmptyString)) {
                                street = null;
                            }
                            String poBox = subValue.values.getAsString("data5");
                            if (poBox == null || poBox.equals(ASConstants.kEmptyString)) {
                                poBox = null;
                            }
                            String neighborhood = subValue.values.getAsString("data6");
                            if (neighborhood == null || neighborhood.equals(ASConstants.kEmptyString)) {
                                neighborhood = null;
                            }
                            String city = subValue.values.getAsString("data7");
                            if (city == null || city.equals(ASConstants.kEmptyString)) {
                                city = null;
                            }
                            String state = subValue.values.getAsString("data8");
                            if (state == null || state.equals(ASConstants.kEmptyString)) {
                                state = null;
                            }
                            String postalCode = subValue.values.getAsString("data9");
                            if (postalCode == null || postalCode.equals(ASConstants.kEmptyString)) {
                                postalCode = null;
                            }
                            String country = subValue.values.getAsString("data10");
                            if (country == null || country.equals(ASConstants.kEmptyString)) {
                                country = null;
                            }
                            if (street != null || poBox != null || neighborhood != null || city != null || state != null || postalCode != null || country != null) {
                                JSONObject address = new JSONObject();
                                if (street != null && !street.equals(ASConstants.kEmptyString)) {
                                    address.put("street", street);
                                }
                                if (poBox != null && !poBox.equals(ASConstants.kEmptyString)) {
                                    address.put("poBox", poBox);
                                }
                                if (neighborhood != null && !neighborhood.equals(ASConstants.kEmptyString)) {
                                    address.put("neighborhood", neighborhood);
                                }
                                if (city != null && !city.equals(ASConstants.kEmptyString)) {
                                    address.put("city", city);
                                }
                                if (state != null && !state.equals(ASConstants.kEmptyString)) {
                                    address.put("state", state);
                                }
                                if (postalCode != null && !postalCode.equals(ASConstants.kEmptyString)) {
                                    address.put("postalCode", postalCode);
                                }
                                if (country != null && !country.equals(ASConstants.kEmptyString)) {
                                    address.put("country", country);
                                }
                                address.put("label", type2);
                                addresses.put(address);
                            } else if (displayPostal != null) {
                                JSONObject address2 = new JSONObject();
                                address2.put("street", displayPostal);
                                addresses.put(address2);
                            }
                        } else if ("vnd.android.cursor.item/im".equals(mimeType)) {
                            Log.v("loadContact: ", "IM");
                            String im = subValue.values.getAsString("data1");
                            if (im != null && !im.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("IM", im);
                            }
                        } else if ("vnd.android.cursor.item/website".equals(mimeType)) {
                            Log.v("loadContact: ", "WEBSITE");
                            String website = subValue.values.getAsString("data1");
                            if (website != null && !website.equals(ASConstants.kEmptyString)) {
                                contactInfo.put("website", website);
                            }
                        } else if ("vnd.android.cursor.item/photo".equals(mimeType)) {
                            Log.v("loadContact: ", "PHOTO");
                            byte[] photo = subValue.values.getAsByteArray("data15");
                            if (photo != null) {
                                contactInfo.put("image", Base64.encodeBytes(photo));
                            }
                        }
                    }
                }
            }
            String firstName2 = null;
            String lastName2 = null;
            firstName2 = contactInfo.getString("firstName");
            lastName2 = contactInfo.getString("lastName");
            if (firstName2 == null || lastName2 == null || firstName2.equals(ASConstants.kEmptyString) || lastName2.equals(ASConstants.kEmptyString)) {
                if (displayName == null) {
                    cursor.close();
                    return null;
                }
                String[] names = displayName.split(" ");
                String firstName3 = null;
                String middleName2 = null;
                String lastName3 = null;
                if (names.length == 1) {
                    firstName3 = names[0];
                } else if (names.length == 2) {
                    firstName3 = names[0];
                    lastName3 = names[1];
                } else if (names.length >= 3) {
                    firstName3 = names[0];
                    middleName2 = names[1];
                    StringBuilder s = new StringBuilder(names[2]);
                    for (int i = 3; i < names.length; i++) {
                        s.append(" ").append(names[i]);
                    }
                    lastName3 = s.toString();
                }
                contactInfo.put("firstName", firstName3);
                contactInfo.put("middleName", middleName2);
                contactInfo.put("lastName", lastName3);
            }
            cursor.close();
            return contactInfo;
        } catch (Exception e2) {
            cursor.close();
            return null;
        } catch (Throwable th2) {
        }
    }

    @Override // com.mobclix.android.sdk.MobclixContacts
    public void addContact(JSONObject contact, Activity activity) throws Exception {
        this.accountName = AccountManager.get(activity).getAccountsByType("com.google")[0].name;
        ArrayList<ContentProviderOperation> ops = new ArrayList<>();
        int rawContactInsertIndex = ops.size();
        ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI).withValue("account_type", "com.google").withValue("account_name", this.accountName).build());
        Cursor tempCur = activity.managedQuery(ContactsContract.Data.CONTENT_URI, new String[]{"data1", "group_sourceid"}, "mimetype='vnd.android.cursor.item/group_membership'", null, null);
        if (tempCur.moveToFirst()) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/group_membership").withValue("group_sourceid", Integer.valueOf(tempCur.getInt(1))).build());
        }
        HashMap<String, String> c = parseJSONContact(contact);
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/name").withValue("data2", c.get("firstName")).withValue("data5", c.get("middleName")).withValue("data3", c.get("lastName")).withValue("data4", c.get("prefix")).withValue("data6", c.get("suffix")).withValue("data1", c.get("displayName")).build());
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/nickname").withValue("data1", c.get("nickname")).withValue("data2", 1).build());
        ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/organization").withValue("data1", c.get("organization")).withValue("data4", c.get("jobTitle")).withValue("data5", c.get("department")).build());
        if (c.get("email") != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/email_v2").withValue("data1", c.get("email")).withValue("data2", 3).build());
        }
        if (c.get("note") != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/note").withValue("data1", c.get("note")).build());
        }
        if (c.get("website") != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/website").withValue("data1", c.get("website")).withValue("data2", 1).build());
        }
        if (c.get("birthday") != null) {
            Date date = new SimpleDateFormat("yyyy-MM-dd'T'hh:mmZ").parse(c.get("birthday"));
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/contact_event").withValue("data1", String.valueOf(date.getMonth()) + "/" + date.getDate() + "/" + date.getYear()).withValue("data2", 3).build());
        }
        if (c.get("im") != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/im").withValue("data1", c.get("im")).withValue("data2", 1).withValue("data5", 5).build());
        }
        if (c.get("image") != null) {
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/photo").withValue("data15", Base64.decode(c.get("image"))).build());
        }
        JSONArray addresses = contact.getJSONArray("addresses");
        for (int i = 0; i < addresses.length(); i++) {
            JSONObject address = addresses.getJSONObject(i);
            int type = 1;
            String street = null;
            String city = null;
            String state = null;
            String postalCode = null;
            String country = null;
            String neighborhood = null;
            String poBox = null;
            if (address.has("label") && address.getString("label").equalsIgnoreCase("work")) {
                type = 2;
            }
            if (address.has("street") && (street = address.getString("street")) == null) {
                street = ASConstants.kEmptyString;
            }
            if (address.has("city") && (city = address.getString("city")) == null) {
                city = ASConstants.kEmptyString;
            }
            if (address.has("state") && (state = address.getString("state")) == null) {
                state = ASConstants.kEmptyString;
            }
            if (address.has("postalCode") && (postalCode = address.getString("postalCode")) == null) {
                postalCode = ASConstants.kEmptyString;
            }
            if (address.has("country") && (country = address.getString("country")) == null) {
                country = ASConstants.kEmptyString;
            }
            if (address.has("neighborhood") && (neighborhood = address.getString("neighborhood")) == null) {
                neighborhood = ASConstants.kEmptyString;
            }
            if (address.has("poBox") && (poBox = address.getString("poBox")) == null) {
                poBox = ASConstants.kEmptyString;
            }
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/postal-address_v2").withValue("data2", Integer.valueOf(type)).withValue("data4", street).withValue("data7", city).withValue("data8", state).withValue("data9", postalCode).withValue("data10", country).withValue("data6", neighborhood).withValue("data5", poBox).build());
        }
        JSONArray numbers = contact.getJSONArray("phoneNumbers");
        for (int i2 = 0; i2 < numbers.length(); i2++) {
            JSONObject phoneNumber = numbers.getJSONObject(i2);
            int type2 = 1;
            String number = null;
            if (phoneNumber.has("label") && phoneNumber.getString("label").equalsIgnoreCase("work")) {
                type2 = 3;
            }
            if (phoneNumber.has("number") && (number = phoneNumber.getString("number")) == null) {
                number = ASConstants.kEmptyString;
            }
            ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI).withValueBackReference("raw_contact_id", rawContactInsertIndex).withValue("mimetype", "vnd.android.cursor.item/phone_v2").withValue("data2", Integer.valueOf(type2)).withValue("data1", number).build());
        }
        activity.getContentResolver().applyBatch("com.android.contacts", ops);
    }

    /* access modifiers changed from: package-private */
    public HashMap<String, String> parseJSONContact(JSONObject contact) throws Exception {
        HashMap<String, String> c = new HashMap<>();
        String firstName = null;
        String lastName = null;
        String middleName = null;
        String prefix = null;
        String suffix = null;
        String nickname = null;
        StringBuilder dName = new StringBuilder();
        if (contact.has("firstName")) {
            try {
                firstName = contact.getString("firstName");
            } catch (Exception e) {
            }
            if (firstName.equals(ASConstants.kEmptyString)) {
                firstName = null;
            }
            if (firstName != null) {
                dName.append(firstName);
            }
        }
        if (contact.has("middleName")) {
            try {
                middleName = contact.getString("middleName");
            } catch (Exception e2) {
            }
            if (middleName.equals(ASConstants.kEmptyString)) {
                middleName = null;
            }
            if (middleName != null) {
                if (dName.length() != 0) {
                    dName.append(" ");
                }
                dName.append(middleName);
            }
        }
        if (contact.has("lastName")) {
            try {
                lastName = contact.getString("lastName");
            } catch (Exception e3) {
            }
            if (lastName.equals(ASConstants.kEmptyString)) {
                lastName = null;
            }
            if (lastName != null) {
                if (dName.length() != 0) {
                    dName.append(" ");
                }
                dName.append(lastName);
            }
        }
        String displayName = dName.toString();
        if (contact.has("prefix")) {
            try {
                prefix = contact.getString("prefix");
            } catch (Exception e4) {
            }
            if (prefix.equals(ASConstants.kEmptyString)) {
                prefix = null;
            }
        }
        if (contact.has("suffix")) {
            try {
                suffix = contact.getString("suffix");
            } catch (Exception e5) {
            }
            if (suffix.equals(ASConstants.kEmptyString)) {
                suffix = null;
            }
        }
        if (contact.has("nickname")) {
            try {
                nickname = contact.getString("nickname");
            } catch (Exception e6) {
            }
            if (nickname.equals(ASConstants.kEmptyString)) {
                nickname = null;
            }
        }
        if (displayName == null || displayName.equals(ASConstants.kEmptyString)) {
            throw new Exception("Adding contact failed: No name provided.");
        }
        c.put("firstName", firstName);
        c.put("lastName", lastName);
        c.put("middleName", middleName);
        c.put("prefix", prefix);
        c.put("suffix", suffix);
        c.put("displayName", displayName);
        c.put("nickname", nickname);
        String organization = null;
        String jobTitle = null;
        String department = null;
        if (contact.has("organization")) {
            try {
                organization = contact.getString("organization");
            } catch (Exception e7) {
            }
            if (organization.equals(ASConstants.kEmptyString)) {
                organization = null;
            }
        }
        if (contact.has("jobTitle")) {
            try {
                jobTitle = contact.getString("jobTitle");
            } catch (Exception e8) {
            }
            if (jobTitle.equals(ASConstants.kEmptyString)) {
                jobTitle = null;
            }
        }
        if (contact.has("department")) {
            try {
                department = contact.getString("department");
            } catch (Exception e9) {
            }
            if (department.equals(ASConstants.kEmptyString)) {
                department = null;
            }
        }
        c.put("organization", organization);
        c.put("jobTitle", jobTitle);
        c.put("department", department);
        String email = null;
        String im = null;
        String website = null;
        String note = null;
        String birthday = null;
        String photo = null;
        if (contact.has("email")) {
            try {
                email = contact.getString("email");
            } catch (Exception e10) {
            }
            if (email.equals(ASConstants.kEmptyString)) {
                email = null;
            }
        }
        if (contact.has("IM")) {
            try {
                im = contact.getString("IM");
            } catch (Exception e11) {
            }
            if (im.equals(ASConstants.kEmptyString)) {
                im = null;
            }
        }
        if (contact.has("website")) {
            try {
                website = contact.getString("website");
            } catch (Exception e12) {
            }
            if (website.equals(ASConstants.kEmptyString)) {
                website = null;
            }
        }
        if (contact.has("note")) {
            try {
                note = contact.getString("note");
            } catch (Exception e13) {
            }
            if (note.equals(ASConstants.kEmptyString)) {
                note = null;
            }
        }
        if (contact.has("birthday")) {
            try {
                birthday = contact.getString("birthday");
            } catch (Exception e14) {
            }
            if (birthday.equals(ASConstants.kEmptyString)) {
                birthday = null;
            }
        }
        if (contact.has("photo")) {
            try {
                photo = contact.getString("image");
            } catch (Exception e15) {
            }
            if (photo.equals(ASConstants.kEmptyString)) {
                photo = null;
            }
        }
        c.put("email", email);
        c.put("im", im);
        c.put("website", website);
        c.put("note", note);
        c.put("birthday", birthday);
        c.put("image", photo);
        return c;
    }

    public static MobclixContactsEntityIterator newEntityIterator(Cursor cursor) {
        return new EntityIteratorImpl(cursor);
    }

    /* access modifiers changed from: private */
    public static class EntityIteratorImpl extends MobclixContactsCursorEntityIterator {
        private static final String[] DATA_KEYS = {"data1", "data2", "data3", "data4", "data5", "data6", "data7", "data8", "data9", "data10", "data11", "data12", "data13", "data14", "data15", "data_sync1", "data_sync2", "data_sync3", "data_sync4"};

        public EntityIteratorImpl(Cursor cursor) {
            super(cursor);
        }

        @Override // com.mobclix.android.sdk.MobclixContactsCursorEntityIterator
        public Entity getEntityAndIncrementCursor(Cursor cursor) throws RemoteException {
            int columnRawContactId = cursor.getColumnIndexOrThrow("_id");
            long rawContactId = cursor.getLong(columnRawContactId);
            ContentValues cv = new ContentValues();
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "account_name");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "account_type");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "_id");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "dirty");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "version");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "sourceid");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "sync1");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "sync2");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "sync3");
            MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv, "sync4");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "deleted");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "contact_id");
            MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv, "starred");
            MobclixContactsSdk5.cursorIntToContentValuesIfPresent(cursor, cv, "is_restricted");
            Entity contact = new Entity(cv);
            while (rawContactId == cursor.getLong(columnRawContactId)) {
                ContentValues cv2 = new ContentValues();
                cv2.put("_id", Long.valueOf(cursor.getLong(cursor.getColumnIndexOrThrow("data_id"))));
                MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv2, "res_package");
                MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv2, "mimetype");
                MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv2, "is_primary");
                MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv2, "is_super_primary");
                MobclixContactsSdk5.cursorLongToContentValuesIfPresent(cursor, cv2, "data_version");
                MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv2, "group_sourceid");
                MobclixContactsSdk5.cursorStringToContentValuesIfPresent(cursor, cv2, "data_version");
                String[] strArr = DATA_KEYS;
                for (String key : strArr) {
                    int columnIndex = cursor.getColumnIndexOrThrow(key);
                    if (!cursor.isNull(columnIndex)) {
                        try {
                            cv2.put(key, cursor.getString(columnIndex));
                        } catch (SQLiteException e) {
                            cv2.put(key, cursor.getBlob(columnIndex));
                        }
                    }
                }
                contact.addSubValue(ContactsContract.Data.CONTENT_URI, cv2);
                if (!cursor.moveToNext()) {
                    break;
                }
            }
            return contact;
        }
    }

    public static void cursorStringToContentValuesIfPresent(Cursor cursor, ContentValues values, String column) {
        int index = cursor.getColumnIndexOrThrow(column);
        if (!cursor.isNull(index)) {
            values.put(column, cursor.getString(index));
        }
    }

    public static void cursorLongToContentValuesIfPresent(Cursor cursor, ContentValues values, String column) {
        int index = cursor.getColumnIndexOrThrow(column);
        if (!cursor.isNull(index)) {
            values.put(column, Long.valueOf(cursor.getLong(index)));
        }
    }

    public static void cursorIntToContentValuesIfPresent(Cursor cursor, ContentValues values, String column) {
        int index = cursor.getColumnIndexOrThrow(column);
        if (!cursor.isNull(index)) {
            values.put(column, Integer.valueOf(cursor.getInt(index)));
        }
    }
}
