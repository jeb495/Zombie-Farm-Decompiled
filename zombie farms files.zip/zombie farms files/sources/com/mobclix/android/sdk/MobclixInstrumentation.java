package com.mobclix.android.sdk;

import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.mobclix.android.sdk.MobclixUtility;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import org.json.JSONObject;

public class MobclixInstrumentation {
    static String ADVIEW = "adview";
    static final String[] MC_DEBUG_CATS = {STARTUP, ADVIEW};
    static String STARTUP = "startup";
    private static String TAG = "MobclixInstrumentation";
    private static final MobclixInstrumentation singleton = new MobclixInstrumentation();
    private ArrayList<String> autocloseGroups = new ArrayList<>();
    private Mobclix controller = Mobclix.getInstance();
    private HashMap<String, Long> currentBenchmarks = new HashMap<>();
    private JSONObject groups = new JSONObject();
    private HashMap<String, Integer> groupsStartCount = new HashMap<>();

    private MobclixInstrumentation() {
    }

    static MobclixInstrumentation getInstance() {
        return singleton;
    }

    /* access modifiers changed from: package-private */
    public void addInfo(Object object, String desc, String group) {
        if (object != null && desc != null && !desc.equals(ASConstants.kEmptyString) && group != null && !group.equals(ASConstants.kEmptyString)) {
            try {
                this.groups.getJSONObject(group).getJSONObject(ASConstants.kASResponseKeyData).put(desc, object);
            } catch (Exception e) {
            }
        }
    }

    /* access modifiers changed from: package-private */
    public String startGroup(String group) {
        return startGroup(group, null);
    }

    /* access modifiers changed from: package-private */
    public String startGroup(String group, String tag) {
        if (group == null || group.equals(ASConstants.kEmptyString)) {
            return null;
        }
        if (this.groups.has(group)) {
            return group;
        }
        if (tag == null || tag.equals(ASConstants.kEmptyString)) {
            tag = group;
        }
        try {
            this.controller = Mobclix.getInstance();
            int startCount = 0;
            try {
                startCount = this.groupsStartCount.get(tag).intValue();
            } catch (Exception e) {
            }
            if (this.controller.getDebugConfig(tag) == null) {
                return null;
            }
            int groupFreq = Integer.parseInt(this.controller.getDebugConfig(tag));
            this.groupsStartCount.put(tag, Integer.valueOf(startCount + 1));
            if (groupFreq < 0 || (groupFreq != 0 && startCount % groupFreq != 0)) {
                return null;
            }
            JSONObject skeleton = new JSONObject();
            skeleton.put("benchmarks", new JSONObject());
            skeleton.put(ASConstants.kASResponseKeyData, new JSONObject());
            skeleton.put("startDate", new SimpleDateFormat("yyyy-MM-dd'T'hh:mmZ").format(new Date(System.currentTimeMillis())));
            skeleton.put("startDateNanoTime", System.nanoTime());
            this.groups.put(group, skeleton);
            return group;
        } catch (Exception e2) {
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    public boolean hasPathStarted(String path) {
        String group;
        String[] pathComponents = path.split("/");
        if (pathComponents.length == 1) {
            group = path;
        } else {
            group = pathComponents[0];
        }
        return this.groups.has(group);
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x004f  */
    public boolean hasPathFinishedBenchmarks(String path) {
        if (path == null || path.equals(ASConstants.kEmptyString)) {
            return false;
        }
        String keyPrefix = String.valueOf(path) + "/";
        Log.v(TAG, "Current benchmarks: " + this.currentBenchmarks.keySet().toString());
        for (String key : this.currentBenchmarks.keySet()) {
            if ((key.length() >= keyPrefix.length() && key.substring(0, keyPrefix.length()).equals(keyPrefix)) || key.equals(path)) {
                return false;
            }
            while (r3.hasNext()) {
            }
        }
        return true;
    }

    /* access modifiers changed from: package-private */
    public void finishGroup(String group) {
        if (group != null && !group.equals(ASConstants.kEmptyString) && hasPathStarted(group)) {
            if (hasPathFinishedBenchmarks(group)) {
                try {
                    Long endDate = Long.valueOf(System.currentTimeMillis());
                    JSONObject data = this.groups.getJSONObject(group);
                    this.groups.remove(group);
                    data.put("endDate", new SimpleDateFormat("yyyy-MM-dd'T'hh:mmZ").format(new Date(endDate.longValue())));
                    data.put("totalElapsedTime", ((double) (System.nanoTime() - data.getLong("startDateNanoTime"))) / 1.0E9d);
                    data.remove("startDateNanoTime");
                    JSONObject envData = new JSONObject();
                    envData.put("app_id", this.controller.getApplicationId());
                    envData.put("platform", this.controller.getPlatform());
                    envData.put("sdk_ver", this.controller.getMobclixVersion());
                    envData.put("app_ver", this.controller.getApplicationVersion());
                    envData.put("udid", this.controller.getDeviceId());
                    envData.put("dev_model", this.controller.getDeviceModel());
                    envData.put("dev_vers", this.controller.getAndroidVersion());
                    envData.put("hw_dev_model", this.controller.getDeviceHardwareModel());
                    envData.put("conn", this.controller.getConnectionType());
                    data.put("environment", envData);
                    StringBuilder params = new StringBuilder("cat=");
                    params.append(group).append("&payload=");
                    params.append(URLEncoder.encode(data.toString(), "UTF-8"));
                    new Thread(new MobclixUtility.POSTThread(this.controller.getDebugServer(), params.toString(), null, null)).run();
                } catch (Exception e) {
                }
            } else if (!this.autocloseGroups.contains(group)) {
                this.autocloseGroups.add(group);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public String benchmarkStart(String path, String name) {
        if (name == null || name.equals(ASConstants.kEmptyString) || path == null || path.equals(ASConstants.kEmptyString) || !hasPathStarted(path)) {
            return null;
        }
        String newPath = String.valueOf(path) + "/" + name;
        this.currentBenchmarks.put(newPath, Long.valueOf(System.nanoTime()));
        return newPath;
    }

    /* access modifiers changed from: package-private */
    public String benchmarkFinishPath(String path) {
        if (path == null || path.equals(ASConstants.kEmptyString) || !hasPathStarted(path)) {
            return null;
        }
        try {
            String[] pathComponents = path.split("/");
            if (pathComponents.length == 1) {
                return null;
            }
            Long endDate = Long.valueOf(System.nanoTime());
            String group = pathComponents[0];
            this.groups.getJSONObject(group).getJSONObject("benchmarks").put(path, ((double) (endDate.longValue() - this.currentBenchmarks.get(path).longValue())) / 1.0E9d);
            this.currentBenchmarks.remove(path);
            if (this.autocloseGroups.contains(group)) {
                finishGroup(group);
            }
            if (pathComponents.length <= 1) {
                return null;
            }
            StringBuilder newPathBuilder = new StringBuilder(pathComponents[0]);
            for (int i = 1; i < pathComponents.length - 1; i++) {
                newPathBuilder.append("/").append(pathComponents[i]);
            }
            String newPath = newPathBuilder.toString().replace(" ", ASConstants.kEmptyString).replace("\\r", ASConstants.kEmptyString).replace("\\n", ASConstants.kEmptyString);
            if (newPath.length() == 0) {
                return null;
            }
            if (newPath.equals("/")) {
                return null;
            }
            return newPath;
        } catch (Exception e) {
            return null;
        }
    }
}
