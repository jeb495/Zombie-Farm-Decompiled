package com.mobclix.android.sdk;

import android.app.Activity;
import com.android.adsymp.core.ASConstants;
import com.mobclix.android.sdk.MobclixFeedback;
import com.mobclix.android.sdk.MobclixUtility;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MobclixDemographics {
    public static String AreaCode = "dac";
    public static String Birthdate = "dbd";
    public static String City = "dci";
    public static String Country = "dco";
    public static String DMACode = "ddc";
    public static String DatingGender = "ddg";
    public static String Education = "dec";
    public static int EducationBachelorsDegree = 4;
    public static int EducationDoctoralDegree = 6;
    public static int EducationHighSchool = 1;
    public static int EducationInCollege = 3;
    public static int EducationMastersDegree = 5;
    public static int EducationSomeCollege = 2;
    public static int EducationUnknown = 0;
    public static String Ethnicity = "den";
    public static int EthnicityAsian = 2;
    public static int EthnicityBlack = 3;
    public static int EthnicityHispanic = 4;
    public static int EthnicityMixed = 1;
    public static int EthnicityNativeAmerican = 5;
    public static int EthnicityUnknown = 0;
    public static int EthnicityWhite = 6;
    public static String Gender = "dg";
    public static int GenderBoth = 3;
    public static int GenderFemale = 2;
    public static int GenderMale = 1;
    public static int GenderUnknown = 0;
    public static String Income = "dic";
    public static int MaritalMarried = 3;
    public static int MaritalSingleAvailable = 1;
    public static int MaritalSingleUnavailable = 2;
    public static String MaritalStatus = "dms";
    public static int MaritalUnknown = 0;
    public static String MetroCode = "dmc";
    public static String PostalCode = "dpo";
    public static String Region = "drg";
    public static String Religion = "drl";
    public static int ReligionBuddhism = 1;
    public static int ReligionChristianity = 2;
    public static int ReligionHinduism = 3;
    public static int ReligionIslam = 4;
    public static int ReligionJudaism = 5;
    public static int ReligionOther = 7;
    public static int ReligionUnaffiliated = 6;
    public static int ReligionUnknown = 0;
    private static String TAG = "mobclixDemographics";
    static Mobclix controller = Mobclix.getInstance();

    public static void sendDemographics(Activity a, Map<String, Object> d) {
        sendDemographics(a, d, null);
    }

    public static void sendDemographics(Activity a, Map<String, Object> d, MobclixFeedback.Listener l) {
        if (d != null) {
            Mobclix.onCreate(a);
            HashMap<String, Boolean> keys = new HashMap<>();
            keys.put(Birthdate, true);
            keys.put(Education, true);
            keys.put(Ethnicity, true);
            keys.put(Gender, true);
            keys.put(DatingGender, true);
            keys.put(Income, true);
            keys.put(MaritalStatus, true);
            keys.put(Religion, true);
            keys.put(AreaCode, true);
            keys.put(City, true);
            keys.put(Country, true);
            keys.put(DMACode, true);
            keys.put(MetroCode, true);
            keys.put(PostalCode, true);
            keys.put(Region, true);
            HashMap<String, String> demo = new HashMap<>();
            for (String k : d.keySet()) {
                String temp = ASConstants.kEmptyString;
                boolean isValid = false;
                Object v = d.get(k);
                if (v != null) {
                    if (keys.get(k) == null) {
                        isValid = false;
                    } else if (v.getClass() == Date.class) {
                        if (k.equals(Birthdate)) {
                            temp = new SimpleDateFormat("yyyyMMdd").format((Date) v);
                            isValid = true;
                        }
                    } else if (v.getClass() == String.class) {
                        if (k.equals(City) || k.equals(Country) || k.equals(PostalCode) || k.equals(Region) || k.equals(AreaCode) || k.equals(DMACode) || k.equals(Income) || k.equals(MetroCode)) {
                            temp = ((String) v).trim();
                            isValid = !temp.equals(ASConstants.kEmptyString);
                        }
                    } else if (v.getClass() == Integer.class) {
                        if (k.equals(AreaCode) || k.equals(DMACode) || k.equals(Income) || k.equals(MetroCode)) {
                            temp = ((Integer) v).toString().trim();
                            isValid = !temp.equals(ASConstants.kEmptyString);
                        } else {
                            int max = 0;
                            if (k.equals(Gender)) {
                                max = 2;
                            } else if (k.equals(DatingGender) || k.equals(MaritalStatus)) {
                                max = 3;
                            } else if (k.equals(Education) || k.equals(Ethnicity)) {
                                max = 6;
                            } else if (k.equals(Religion)) {
                                max = 7;
                            }
                            int value = ((Integer) v).intValue();
                            if (1 <= value && value <= max) {
                                temp = v.toString();
                                isValid = true;
                            }
                        }
                    }
                }
                if (isValid) {
                    demo.put(k, temp);
                }
            }
            String url = controller.getFeedbackServer();
            StringBuffer params = new StringBuffer();
            try {
                params.append("p=android&t=demo");
                params.append("&a=").append(URLEncoder.encode(controller.getApplicationId(), "UTF-8"));
                params.append("&v=").append(URLEncoder.encode(controller.getApplicationVersion(), "UTF-8"));
                params.append("&m=").append(URLEncoder.encode(controller.getMobclixVersion(), "UTF-8"));
                params.append("&d=").append(URLEncoder.encode(controller.getDeviceId(), "UTF-8"));
                params.append("&dt=").append(URLEncoder.encode(controller.getDeviceModel(), "UTF-8"));
                params.append("&os=").append(URLEncoder.encode(controller.getAndroidVersion(), "UTF-8"));
                String gps = controller.getGPS();
                if (!gps.equals("null")) {
                    String gps2 = URLEncoder.encode(gps, "UTF-8");
                    params.append("&gps=").append(gps2.substring(0, Math.min(48, gps2.length())));
                }
                for (String k2 : demo.keySet()) {
                    params.append("&" + k2 + "=").append(URLEncoder.encode(demo.get(k2), "UTF-8"));
                }
                new Thread(new MobclixUtility.POSTThread(url, params.toString(), a, l)).run();
            } catch (UnsupportedEncodingException e) {
            }
        }
    }
}
