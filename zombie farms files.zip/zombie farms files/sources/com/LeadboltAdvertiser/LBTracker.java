package com.LeadboltAdvertiser;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import com.android.adsymp.core.ASConstants;
import com.tapjoy.TapjoyConstants;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

public class LBTracker {
    public static final String LB_LOG = "LBAdTrack";
    public static final int REQUEST_TIMEOUT = 10;
    public static final String SDK_LEVEL = "00";
    public static final String SDK_VERSION = "1";
    public static boolean requestInProgress = false;
    public Activity activity;
    private boolean dataretrieve = true;
    private String secretkey;
    private String trackingid;

    public LBTracker(Activity act, String tid, String skey) {
        this.activity = act;
        this.trackingid = tid;
        this.secretkey = skey;
    }

    public void loadTracker() {
        try {
            Boolean con = new Boolean(((ConnectivityManager) this.activity.getSystemService("connectivity")).getActiveNetworkInfo().isConnectedOrConnecting());
            boolean makeRequest = true;
            try {
                if (!this.activity.getSharedPreferences("Preference", 2).getString("SD_Advertiser_" + this.trackingid, "0").equals("0")) {
                    makeRequest = false;
                }
            } catch (Exception e) {
            }
            if (con.booleanValue() && makeRequest) {
                if (Build.VERSION.SDK_INT > 8) {
                    LBLog.d(LB_LOG, "Tracker will run in background thread - SDK Level = " + Build.VERSION.SDK_INT);
                    new LBRequest(this, null).execute(ASConstants.kEmptyString);
                    return;
                }
                LBLog.d(LB_LOG, "Tracker will run on main thread - SDK Level = " + Build.VERSION.SDK_INT);
                makeLBRequest();
            }
        } catch (Exception e2) {
            e2.printStackTrace();
            LBLog.e(LB_LOG, "Error Message No wifi - " + e2.getMessage());
            LBLog.e(LB_LOG, "No WIFI, 3G or Edge connection detected");
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x0392, code lost:
        r20 = true;
        r9 = r21.edit();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:?, code lost:
        r9.putString("SD_Advertiser_" + r42.trackingid, "1");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x03bc, code lost:
        com.LeadboltAdvertiser.LBLog.d(com.LeadboltAdvertiser.LBTracker.LB_LOG, "URL called - " + r31);
        com.LeadboltAdvertiser.LBLog.d(com.LeadboltAdvertiser.LBTracker.LB_LOG, "Pixel Success - " + false);
        com.LeadboltAdvertiser.LBTracker.requestInProgress = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:0x0412, code lost:
        r35 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x0413, code lost:
        com.LeadboltAdvertiser.LBLog.d(com.LeadboltAdvertiser.LBTracker.LB_LOG, "URL called - " + r31);
        com.LeadboltAdvertiser.LBLog.d(com.LeadboltAdvertiser.LBTracker.LB_LOG, "Pixel Success - " + r20);
        com.LeadboltAdvertiser.LBTracker.requestInProgress = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x0447, code lost:
        throw r35;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x0412 A[ExcHandler: all (r35v36 'th' java.lang.Throwable A[CUSTOM_DECLARE]), PHI: r20 
      PHI: (r20v1 'pixelSuccess' boolean) = (r20v0 'pixelSuccess' boolean), (r20v2 'pixelSuccess' boolean), (r20v2 'pixelSuccess' boolean) binds: [B:37:0x037e, B:41:0x0398, B:42:?] A[DONT_GENERATE, DONT_INLINE], Splitter:B:37:0x037e] */
    private void makeLBRequest() {
        SharedPreferences.Editor editor;
        if (!requestInProgress) {
            requestInProgress = true;
            try {
                Thread.sleep((long) (new Random().nextInt(151) + 250));
            } catch (Exception e) {
            }
            SharedPreferences pref = this.activity.getSharedPreferences("Preference", 2);
            DisplayMetrics dm = new DisplayMetrics();
            this.activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
            Rect rect = new Rect();
            this.activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
            int statusBarHeight = rect.top;
            int sWidth = dm.widthPixels;
            int sHeight = dm.heightPixels - statusBarHeight;
            HttpClient httpclient = new DefaultHttpClient();
            Calendar cal = Calendar.getInstance();
            TelephonyManager tm = (TelephonyManager) this.activity.getBaseContext().getSystemService("phone");
            String deviceId = Settings.Secure.getString(this.activity.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
            String domain = "http://ad.leadbolt.net";
            String[] urlDomains = {"http://ad.leadboltapps.net", "http://ad.leadbolt.net"};
            HttpURLConnection httpCon = null;
            boolean found = false;
            for (int i = 0; i < urlDomains.length && !found; i++) {
                try {
                    String urlToUse = urlDomains[i];
                    httpCon = (HttpURLConnection) new URL(urlToUse).openConnection();
                    httpCon.setRequestMethod("GET");
                    httpCon.setConnectTimeout(5000);
                    httpCon.connect();
                    if (httpCon.getResponseCode() == 200) {
                        domain = urlToUse;
                        found = true;
                    }
                } catch (Exception e2) {
                } finally {
                    httpCon.disconnect();
                }
            }
            String url = String.valueOf(String.valueOf(domain) + "/conv/") + this.trackingid + "?key=" + this.secretkey;
            HttpPost httppost = new HttpPost(url);
            List<NameValuePair> nameValuePairs = new ArrayList<>(2);
            try {
                nameValuePairs.add(new BasicNameValuePair("ref1", deviceId));
                nameValuePairs.add(new BasicNameValuePair("ref2", Build.VERSION.RELEASE));
                nameValuePairs.add(new BasicNameValuePair("ref3", "Android"));
                nameValuePairs.add(new BasicNameValuePair("ref4", getLocalIpAddress()));
                nameValuePairs.add(new BasicNameValuePair("ref5", new StringBuilder().append(cal.get(15)).toString()));
                nameValuePairs.add(new BasicNameValuePair("ref6", new StringBuilder().append((int) (cal.getTimeInMillis() / 1000)).toString()));
                nameValuePairs.add(new BasicNameValuePair("ref7", new StringBuilder().append(sWidth).toString()));
                nameValuePairs.add(new BasicNameValuePair("ref8", new StringBuilder().append(sHeight).toString()));
                nameValuePairs.add(new BasicNameValuePair("ref15", "1"));
                nameValuePairs.add(new BasicNameValuePair("ref16", SDK_LEVEL));
                nameValuePairs.add(new BasicNameValuePair("ref17", tm.getDeviceId()));
                nameValuePairs.add(new BasicNameValuePair("ref18", Build.MANUFACTURER));
                nameValuePairs.add(new BasicNameValuePair("ref19", Build.MODEL));
                if (this.dataretrieve) {
                    try {
                        nameValuePairs.add(new BasicNameValuePair("ref11", tm.getNetworkCountryIso()));
                        nameValuePairs.add(new BasicNameValuePair("ref12", tm.getNetworkOperator()));
                        nameValuePairs.add(new BasicNameValuePair("ref13", tm.getNetworkOperatorName()));
                        nameValuePairs.add(new BasicNameValuePair("ref14", tm.getLine1Number()));
                    } catch (Exception e3) {
                    }
                }
                try {
                    Location location = ((LocationManager) this.activity.getSystemService("location")).getLastKnownLocation("gps");
                    String longitude = String.valueOf(location.getLongitude());
                    nameValuePairs.add(new BasicNameValuePair("ref9", String.valueOf(location.getLatitude())));
                    nameValuePairs.add(new BasicNameValuePair("ref10", longitude));
                } catch (Exception e4) {
                }
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            } catch (Exception e5) {
                e5.printStackTrace();
                LBLog.e(LB_LOG, "Error Message - " + e5.getMessage());
            }
            boolean pixelSuccess = false;
            int connectionCount = 0;
            while (true) {
                if (connectionCount >= 10) {
                    break;
                }
                try {
                    if (httpclient.execute(httppost).getStatusLine().getStatusCode() == 200) {
                        break;
                    }
                    connectionCount++;
                } catch (Exception e6) {
                    editor.putString("SD_Advertiser_" + this.trackingid, "0");
                } catch (Throwable th) {
                }
            }
            LBLog.d(LB_LOG, "URL called - " + url);
            LBLog.d(LB_LOG, "Pixel Success - " + pixelSuccess);
            requestInProgress = false;
        }
        return;
        editor.commit();
        LBLog.d(LB_LOG, "URL called - " + url);
        LBLog.d(LB_LOG, "Pixel Success - " + pixelSuccess);
        requestInProgress = false;
    }

    private class LBRequest extends AsyncTask<String, Void, String> {
        private LBRequest() {
        }

        /* synthetic */ LBRequest(LBTracker lBTracker, LBRequest lBRequest) {
            this();
        }

        /* access modifiers changed from: protected */
        public String doInBackground(String... params) {
            LBTracker.this.makeLBRequest();
            return null;
        }
    }

    private String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en.hasMoreElements()) {
                Enumeration<InetAddress> enumIpAddr = en.nextElement().getInetAddresses();
                while (true) {
                    if (enumIpAddr.hasMoreElements()) {
                        InetAddress inetAddress = enumIpAddr.nextElement();
                        if (!inetAddress.isLoopbackAddress()) {
                            return inetAddress.getHostAddress().toString();
                        }
                    }
                }
            }
        } catch (SocketException e) {
        }
        return null;
    }
}
