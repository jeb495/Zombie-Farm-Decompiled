package com.LeadboltAdvertiser;

import android.util.Log;

public class LBLog {
    private static boolean doLog = false;

    public static void enableLog(boolean enable) {
        Log.i("AdLog", "enableLog: " + enable);
        doLog = enable;
    }

    public static void i(String tag, String msg) {
        if (doLog) {
            Log.i(tag, msg);
        }
    }

    public static void e(String tag, String msg) {
        if (doLog) {
            Log.e(tag, msg);
        }
    }

    public static void w(String tag, String msg) {
        if (doLog) {
            Log.w(tag, msg);
        }
    }

    public static void d(String tag, String msg) {
        if (doLog) {
            Log.d(tag, msg);
        }
    }

    public static void v(String tag, String msg) {
        if (doLog) {
            Log.v(tag, msg);
        }
    }
}
