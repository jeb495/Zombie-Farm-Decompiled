package com.millennialmedia.android;

/* access modifiers changed from: package-private */
public interface AccelerometerListener {
    void didAccelerate(float f, float f2, float f3);

    void didShake(float f);
}
