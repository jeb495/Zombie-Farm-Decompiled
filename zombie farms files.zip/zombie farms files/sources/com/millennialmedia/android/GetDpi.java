package com.millennialmedia.android;

import android.content.Context;

public final class GetDpi {
    static String getDpi(Context context) {
        return "160";
    }
}
