package com.millennialmedia.android;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.adsymp.core.ASConstants;
import com.millennialmedia.android.MMAdViewSDK;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VideoPlayer extends Activity implements Handler.Callback {
    private static final int MESSAGE_DELAYED_BUTTON = 3;
    private static final int MESSAGE_EVENTLOG_CHECK = 2;
    private static final int MESSAGE_INACTIVITY_ANIMATION = 1;
    private RelativeLayout buttonsLayout;
    private RelativeLayout controlsLayout;
    private String current;
    private int currentVideoPosition = 0;
    private Handler handler;
    private TextView hudSeconds;
    private TextView hudStaticText;
    private boolean isCachedAd;
    private int lastVideoPosition;
    private EventLogSet logSet;
    private Button mPausePlay;
    private Button mRewind;
    private Button mStop;
    private MillennialMediaView mVideoView;
    private boolean paused = false;
    private RelativeLayout relLayout;
    private boolean showBottomBar = true;
    private boolean showCountdownHud = true;
    private VideoAd videoAd;
    private boolean videoCompleted;
    private boolean videoCompletedOnce;
    protected VideoServer videoServer;

    /* JADX WARNING: Removed duplicated region for block: B:17:0x01b7  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x020a  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x021c  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0228  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x04c6  */
    /* JADX WARNING: Removed duplicated region for block: B:50:0x04ce  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x054c  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x06b4  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x06c5  */
    public void onCreate(Bundle savedInstanceState) {
        List<VideoImage> buttons;
        File cacheDir;
        Throwable th;
        SQLiteException e;
        super.onCreate(savedInstanceState);
        MMAdViewSDK.Log.d("Setting up the video player");
        if (savedInstanceState != null) {
            this.isCachedAd = savedInstanceState.getBoolean("isCachedAd");
            this.videoCompleted = savedInstanceState.getBoolean("videoCompleted");
            this.videoCompletedOnce = savedInstanceState.getBoolean("videoCompletedOnce");
            this.currentVideoPosition = savedInstanceState.getInt("videoPosition");
        } else {
            this.isCachedAd = getIntent().getBooleanExtra("cached", false);
            this.currentVideoPosition = 0;
            this.videoCompletedOnce = false;
            this.videoCompleted = false;
        }
        this.relLayout = new RelativeLayout(this);
        this.relLayout.setId(400);
        this.relLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        this.relLayout.setBackgroundColor(-16777216);
        this.relLayout.setDrawingCacheBackgroundColor(-16777216);
        RelativeLayout videoLayout = new RelativeLayout(this);
        videoLayout.setBackgroundColor(-16777216);
        videoLayout.setId(410);
        RelativeLayout.LayoutParams videoContainerLp = new RelativeLayout.LayoutParams(-1, -1);
        videoContainerLp.addRule(13);
        videoLayout.setLayoutParams(videoContainerLp);
        videoLayout.setDrawingCacheBackgroundColor(-16777216);
        RelativeLayout.LayoutParams videoLp = new RelativeLayout.LayoutParams(-1, -1);
        videoLp.addRule(13);
        this.mVideoView = new MillennialMediaView(this);
        this.mVideoView.setId(411);
        this.mVideoView.getHolder().setFormat(-2);
        videoLayout.addView(this.mVideoView, videoLp);
        this.mVideoView.setDrawingCacheBackgroundColor(-16777216);
        this.relLayout.addView(videoLayout, videoContainerLp);
        RelativeLayout.LayoutParams buttonsLp = new RelativeLayout.LayoutParams(-1, -1);
        MMAdViewSDK.Log.v("Is Cached Ad: " + this.isCachedAd);
        if (this.isCachedAd) {
            this.handler = new Handler(this);
            setRequestedOrientation(0);
            if (savedInstanceState == null) {
                String name = getIntent().getStringExtra("adName");
                AdDatabaseHelper db = null;
                try {
                    AdDatabaseHelper db2 = new AdDatabaseHelper(this);
                    try {
                        this.videoAd = db2.getVideoAd(name);
                        if (db2 != null) {
                            db2.close();
                        }
                    } catch (SQLiteException e2) {
                        e = e2;
                        db = db2;
                        try {
                            e.printStackTrace();
                            if (db != null) {
                                db.close();
                            }
                            this.logSet = new EventLogSet(this.videoAd);
                            if (this.videoAd != null) {
                            }
                            logBeginEvent(this.logSet);
                            this.buttonsLayout = new RelativeLayout(this);
                            this.buttonsLayout.setId(420);
                            if (this.showCountdownHud) {
                            }
                            buttons = null;
                            if (this.videoAd != null) {
                            }
                            if (buttons != null) {
                            }
                            if (this.showBottomBar) {
                            }
                            if (this.controlsLayout != null) {
                            }
                            if (this.buttonsLayout != null) {
                            }
                            setContentView(this.relLayout);
                        } catch (Throwable th2) {
                            th = th2;
                            if (db != null) {
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        db = db2;
                        if (db != null) {
                            db.close();
                        }
                        throw th;
                    }
                } catch (SQLiteException e3) {
                    e = e3;
                    e.printStackTrace();
                    if (db != null) {
                    }
                    this.logSet = new EventLogSet(this.videoAd);
                    if (this.videoAd != null) {
                    }
                    logBeginEvent(this.logSet);
                    this.buttonsLayout = new RelativeLayout(this);
                    this.buttonsLayout.setId(420);
                    if (this.showCountdownHud) {
                    }
                    buttons = null;
                    if (this.videoAd != null) {
                    }
                    if (buttons != null) {
                    }
                    if (this.showBottomBar) {
                    }
                    if (this.controlsLayout != null) {
                    }
                    if (this.buttonsLayout != null) {
                    }
                    setContentView(this.relLayout);
                }
                this.logSet = new EventLogSet(this.videoAd);
                if (this.videoAd != null) {
                    this.showBottomBar = this.videoAd.showControls;
                    this.showCountdownHud = this.videoAd.showCountdown;
                }
                logBeginEvent(this.logSet);
            } else {
                this.videoAd = (VideoAd) savedInstanceState.getParcelable("videoAd");
                this.logSet = (EventLogSet) savedInstanceState.getParcelable("logSet");
                this.showBottomBar = savedInstanceState.getBoolean("shouldShowBottomBar");
                this.showCountdownHud = this.videoAd.showCountdown;
            }
            this.buttonsLayout = new RelativeLayout(this);
            this.buttonsLayout.setId(420);
            if (this.showCountdownHud) {
                showHud(false);
            }
            buttons = null;
            if (this.videoAd != null) {
                buttons = this.videoAd.buttons;
            }
            if (buttons != null) {
                for (int i = 0; i < buttons.size(); i++) {
                    if (this.videoAd.storedOnSdCard) {
                        cacheDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "millennialmedia");
                    } else {
                        cacheDir = getCacheDir();
                    }
                    ImageButton newButton = new ImageButton(this);
                    buttons.get(i).button = newButton;
                    newButton.setImageURI(Uri.parse(cacheDir + "/" + this.videoAd.id + "/" + Uri.parse(buttons.get(i).imageUrl).getLastPathSegment().replaceFirst("\\.[^\\.]*$", ".dat")));
                    newButton.setPadding(0, 0, 0, 0);
                    newButton.setBackgroundColor(0);
                    setButtonAlpha(newButton, buttons.get(i).fromAlpha);
                    newButton.setId(i + 1);
                    RelativeLayout.LayoutParams newButtonLp = new RelativeLayout.LayoutParams(-2, -2);
                    MMAdViewSDK.Log.v("Array #: " + (newButton.getId() - 1) + " View ID: " + newButton.getId() + " Relative to " + buttons.get(i).anchor + " position: " + buttons.get(i).position);
                    newButtonLp.addRule(buttons.get(i).position, buttons.get(i).anchor);
                    newButtonLp.addRule(buttons.get(i).position2, buttons.get(i).anchor2);
                    newButtonLp.setMargins(buttons.get(i).paddingLeft, buttons.get(i).paddingTop, buttons.get(i).paddingRight, buttons.get(i).paddingBottom);
                    final VideoImage button = buttons.get(i);
                    if (!TextUtils.isEmpty(button.linkUrl)) {
                        newButton.setOnClickListener(new View.OnClickListener() {
                            /* class com.millennialmedia.android.VideoPlayer.AnonymousClass1 */

                            public void onClick(View view) {
                                VideoPlayer.this.dispatchButtonClick(button.linkUrl);
                                VideoPlayer.this.logButtonEvent(button);
                            }
                        });
                    }
                    if (button.appearanceDelay > 0) {
                        buttons.get(i).layoutParams = newButtonLp;
                        this.handler.sendMessageDelayed(Message.obtain(this.handler, 3, button), button.appearanceDelay);
                    } else {
                        this.buttonsLayout.addView(newButton, newButtonLp);
                    }
                    if (button.inactivityTimeout > 0) {
                        this.handler.sendMessageDelayed(Message.obtain(this.handler, 1, button), button.inactivityTimeout + button.appearanceDelay + button.fadeDuration);
                    }
                }
                this.relLayout.addView(this.buttonsLayout, buttonsLp);
            }
        }
        if (this.showBottomBar) {
            this.controlsLayout = new RelativeLayout(this);
            this.controlsLayout.setBackgroundColor(-16777216);
            RelativeLayout.LayoutParams controlsLp = new RelativeLayout.LayoutParams(-1, -2);
            this.controlsLayout.setLayoutParams(controlsLp);
            controlsLp.addRule(12);
            this.mRewind = new Button(this);
            this.mPausePlay = new Button(this);
            this.mStop = new Button(this);
            this.mRewind.setBackgroundResource(17301541);
            this.mPausePlay.setBackgroundResource(17301539);
            this.mStop.setBackgroundResource(17301560);
            RelativeLayout.LayoutParams pauseLp = new RelativeLayout.LayoutParams(-2, -2);
            RelativeLayout.LayoutParams stopLp = new RelativeLayout.LayoutParams(-2, -2);
            RelativeLayout.LayoutParams rewindLp = new RelativeLayout.LayoutParams(-2, -2);
            pauseLp.addRule(14);
            this.controlsLayout.addView(this.mPausePlay, pauseLp);
            rewindLp.addRule(0, this.mPausePlay.getId());
            this.controlsLayout.addView(this.mRewind);
            stopLp.addRule(11);
            this.controlsLayout.addView(this.mStop, stopLp);
            this.mRewind.setOnClickListener(new View.OnClickListener() {
                /* class com.millennialmedia.android.VideoPlayer.AnonymousClass2 */

                public void onClick(View view) {
                    if (VideoPlayer.this.mVideoView != null) {
                        VideoPlayer.this.mVideoView.seekTo(0);
                    }
                }
            });
            this.mPausePlay.setOnClickListener(new View.OnClickListener() {
                /* class com.millennialmedia.android.VideoPlayer.AnonymousClass3 */

                public void onClick(View view) {
                    if (VideoPlayer.this.paused) {
                        if (VideoPlayer.this.mVideoView != null) {
                            VideoPlayer.this.playVideo(VideoPlayer.this.mVideoView.getCurrentPosition());
                        }
                        VideoPlayer.this.mPausePlay.setBackgroundResource(17301539);
                        VideoPlayer.this.paused = false;
                    } else if (VideoPlayer.this.mVideoView != null) {
                        VideoPlayer.this.mVideoView.pause();
                        VideoPlayer.this.mPausePlay.setBackgroundResource(17301540);
                        VideoPlayer.this.paused = true;
                    }
                }
            });
            this.mStop.setOnClickListener(new View.OnClickListener() {
                /* class com.millennialmedia.android.VideoPlayer.AnonymousClass4 */

                public void onClick(View view) {
                    if (VideoPlayer.this.mVideoView != null) {
                        VideoPlayer.this.current = null;
                        VideoPlayer.this.mVideoView.stopPlayback();
                        VideoPlayer.this.dismiss();
                    }
                }
            });
            this.relLayout.addView(this.controlsLayout, controlsLp);
        }
        if (this.controlsLayout != null) {
            this.controlsLayout.bringToFront();
        }
        if (this.buttonsLayout != null) {
            this.relLayout.bringChildToFront(this.buttonsLayout);
        }
        setContentView(this.relLayout);
    }

    private boolean canFadeButtons() {
        if (!this.videoAd.stayInPlayer || !this.videoCompleted) {
            return true;
        }
        return false;
    }

    private void setButtonAlpha(ImageButton button, float alpha) {
        AlphaAnimation animation = new AlphaAnimation(alpha, alpha);
        animation.setDuration(0);
        animation.setFillEnabled(true);
        animation.setFillBefore(true);
        animation.setFillAfter(true);
        button.startAnimation(animation);
    }

    private class DelayedAnimationListener implements Animation.AnimationListener {
        private ImageButton button;
        private RelativeLayout.LayoutParams layoutParams;

        DelayedAnimationListener(ImageButton b, RelativeLayout.LayoutParams lp) {
            this.button = b;
            this.layoutParams = lp;
        }

        public void onAnimationStart(Animation animation) {
        }

        public void onAnimationEnd(Animation animation) {
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case 1:
                if (canFadeButtons()) {
                    VideoImage videoImage = (VideoImage) msg.obj;
                    AlphaAnimation animation = new AlphaAnimation(videoImage.fromAlpha, videoImage.toAlpha);
                    animation.setDuration(videoImage.fadeDuration);
                    animation.setFillEnabled(true);
                    animation.setFillBefore(true);
                    animation.setFillAfter(true);
                    videoImage.button.startAnimation(animation);
                    break;
                }
                break;
            case 2:
                try {
                    if (this.mVideoView.isPlaying()) {
                        int currentPosition = this.mVideoView.getCurrentPosition();
                        if (currentPosition > this.lastVideoPosition) {
                            if (this.videoAd != null) {
                                for (int i = 0; i < this.videoAd.activities.size(); i++) {
                                    VideoLogEvent videoEvent = this.videoAd.activities.get(i);
                                    if (videoEvent != null && videoEvent.position >= ((long) this.lastVideoPosition) && videoEvent.position < ((long) currentPosition)) {
                                        for (int j = 0; j < videoEvent.activities.length; j++) {
                                            try {
                                                logEvent(videoEvent.activities[j]);
                                            } catch (UnsupportedEncodingException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                }
                            }
                            this.lastVideoPosition = currentPosition;
                        }
                        if (this.showCountdownHud) {
                            long seconds = (this.videoAd.duration - ((long) currentPosition)) / 1000;
                            if (seconds <= 0) {
                                hideHud();
                            } else if (this.hudSeconds != null) {
                                this.hudSeconds.setText(String.valueOf(seconds));
                            }
                        }
                    }
                    this.handler.sendMessageDelayed(Message.obtain(this.handler, 2), 1000);
                    break;
                } catch (IllegalStateException e2) {
                    e2.printStackTrace();
                    break;
                }
            case 3:
                VideoImage videoImage2 = (VideoImage) msg.obj;
                try {
                    if (this.buttonsLayout.indexOfChild(videoImage2.button) == -1) {
                        this.buttonsLayout.addView(videoImage2.button, videoImage2.layoutParams);
                    }
                } catch (IllegalStateException e3) {
                    e3.printStackTrace();
                }
                AlphaAnimation animation2 = new AlphaAnimation(videoImage2.toAlpha, videoImage2.fromAlpha);
                animation2.setDuration(videoImage2.fadeDuration);
                animation2.setAnimationListener(new DelayedAnimationListener(videoImage2.button, videoImage2.layoutParams));
                animation2.setFillEnabled(true);
                animation2.setFillBefore(true);
                animation2.setFillAfter(true);
                MMAdViewSDK.Log.v("Beginning animation to visibility. Fade duration: " + videoImage2.fadeDuration + " Button: " + videoImage2.name + " Time: " + System.currentTimeMillis());
                videoImage2.button.startAnimation(animation2);
                break;
        }
        return true;
    }

    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (this.videoAd != null) {
            if (this.handler != null) {
                this.handler.removeMessages(1);
            }
            for (int i = 0; i < this.videoAd.buttons.size(); i++) {
                VideoImage videoImage = this.videoAd.buttons.get(i);
                setButtonAlpha(videoImage.button, videoImage.fromAlpha);
                if (videoImage.inactivityTimeout > 0) {
                    this.handler.sendMessageDelayed(Message.obtain(this.handler, 1, videoImage), videoImage.inactivityTimeout);
                } else if (ev.getAction() == 1) {
                    if (canFadeButtons()) {
                        AlphaAnimation animation = new AlphaAnimation(videoImage.fromAlpha, videoImage.toAlpha);
                        animation.setDuration(videoImage.fadeDuration);
                        animation.setFillEnabled(true);
                        animation.setFillBefore(true);
                        animation.setFillAfter(true);
                        videoImage.button.startAnimation(animation);
                    }
                } else if (ev.getAction() == 0) {
                    setButtonAlpha(videoImage.button, videoImage.fromAlpha);
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    /* access modifiers changed from: protected */
    public void logBeginEvent(EventLogSet set) {
        if (set != null && set.startActivity != null) {
            try {
                MMAdViewSDK.Log.d("Cached video begin event logged");
                for (int i = 0; i < set.startActivity.length; i++) {
                    logEvent(set.startActivity[i]);
                }
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void logEndEvent(EventLogSet set) {
        MMAdViewSDK.Log.d("Cached video end event logged");
        for (int i = 0; i < set.endActivity.length; i++) {
            try {
                logEvent(set.endActivity[i]);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void logButtonEvent(VideoImage button) {
        MMAdViewSDK.Log.d("Cached video button event logged");
        for (int i = 0; i < button.activity.length; i++) {
            try {
                logEvent(button.activity[i]);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return;
            }
        }
    }

    /* access modifiers changed from: protected */
    public void logEvent(final String activity) throws UnsupportedEncodingException {
        MMAdViewSDK.Log.d("Logging event to: " + activity);
        new Thread(new Runnable() {
            /* class com.millennialmedia.android.VideoPlayer.AnonymousClass5 */

            public void run() {
                try {
                    new HttpGetRequest().get(activity);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void showHud(boolean restart) {
        if (this.hudStaticText == null || this.hudSeconds == null) {
            RelativeLayout.LayoutParams hudLp = new RelativeLayout.LayoutParams(-2, -2);
            RelativeLayout.LayoutParams hudSecLp = new RelativeLayout.LayoutParams(-2, -2);
            this.hudStaticText = new TextView(this);
            this.hudStaticText.setText(" seconds remaining ...");
            this.hudStaticText.setTextColor(-1);
            this.hudStaticText.setPadding(0, 0, 5, 0);
            this.hudSeconds = new TextView(this);
            if (restart) {
                if (this.videoAd != null) {
                    this.hudSeconds.setText(String.valueOf(this.videoAd.duration / 1000));
                }
            } else if (this.currentVideoPosition != 0) {
                this.hudSeconds.setText(String.valueOf(this.currentVideoPosition / 1000));
            } else if (this.videoAd != null) {
                this.hudSeconds.setText(String.valueOf(this.videoAd.duration / 1000));
            }
            this.hudSeconds.setTextColor(-1);
            this.hudSeconds.setId(401);
            this.hudStaticText.setId(402);
            hudLp.addRule(10);
            hudLp.addRule(11);
            this.buttonsLayout.addView(this.hudStaticText, hudLp);
            hudSecLp.addRule(10);
            hudSecLp.addRule(0, this.hudStaticText.getId());
            this.buttonsLayout.addView(this.hudSeconds, hudSecLp);
            return;
        }
        if (restart) {
            if (this.videoAd != null) {
                this.hudSeconds.setText(String.valueOf(this.videoAd.duration / 1000));
            } else {
                this.hudSeconds.setText(ASConstants.kEmptyString);
            }
        }
        this.hudStaticText.setVisibility(0);
        this.hudSeconds.setVisibility(0);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void hideHud() {
        if (this.hudStaticText != null) {
            this.hudStaticText.setVisibility(4);
        }
        if (this.hudSeconds != null) {
            this.hudSeconds.setVisibility(4);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void playVideo(final int position) {
        try {
            String path = getIntent().getData().toString();
            MMAdViewSDK.Log.d("playVideo path: " + path);
            if (path == null || path.length() == 0) {
                Toast.makeText(this, "Sorry. There was a problem playing the video", 1).show();
                return;
            }
            SharedPreferences.Editor editor = getSharedPreferences("MillennialMediaSettings", 0).edit();
            editor.putBoolean("lastAdViewed", true);
            editor.commit();
            this.videoCompleted = false;
            if (!path.equals(this.current) || this.mVideoView == null) {
                this.current = path;
                if (this.mVideoView == null) {
                    Log.e(MMAdViewSDK.SDKLOG, "Video Player is Null");
                } else if (!this.isCachedAd) {
                    this.mVideoView.setVideoURI(Uri.parse(path));
                    this.mVideoView.requestFocus();
                    this.mVideoView.start();
                    this.mVideoView.seekTo(position);
                } else if (this.videoAd == null) {
                } else {
                    if (!this.videoAd.storedOnSdCard) {
                        MMAdViewSDK.Log.d("Cached Ad. Starting Server");
                        startServer(path, position, false);
                        return;
                    }
                    this.mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass9 */

                        public void onCompletion(MediaPlayer mp) {
                            MMAdViewSDK.Log.d("Video Playing Complete");
                            if (VideoPlayer.this.showCountdownHud) {
                                VideoPlayer.this.hideHud();
                            }
                            if (VideoPlayer.this.videoAd != null) {
                                VideoPlayer.this.videoPlayerOnCompletion(VideoPlayer.this.videoAd.onCompletionUrl);
                            }
                        }
                    });
                    this.mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass10 */

                        public void onPrepared(MediaPlayer mp) {
                            MMAdViewSDK.Log.d("Video Prepared");
                            VideoPlayer.this.mVideoView.seekTo(position);
                        }
                    });
                    this.mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass11 */

                        public boolean onError(MediaPlayer mp, int what, int extra) {
                            return false;
                        }
                    });
                    this.mVideoView.setVideoURI(Uri.parse(path));
                    this.mVideoView.requestFocus();
                    this.mVideoView.start();
                    this.mVideoView.seekTo(position);
                }
            } else if (!this.isCachedAd) {
                this.mVideoView.requestFocus();
                this.mVideoView.start();
                this.mVideoView.seekTo(position);
            } else if (this.videoAd == null) {
            } else {
                if (this.videoAd.storedOnSdCard) {
                    this.mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass6 */

                        public void onCompletion(MediaPlayer mp) {
                            MMAdViewSDK.Log.d("Video Playing Complete");
                            if (VideoPlayer.this.showCountdownHud) {
                                VideoPlayer.this.hideHud();
                            }
                            if (VideoPlayer.this.videoAd != null) {
                                VideoPlayer.this.videoPlayerOnCompletion(VideoPlayer.this.videoAd.onCompletionUrl);
                            }
                        }
                    });
                    this.mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass7 */

                        public void onPrepared(MediaPlayer mp) {
                            MMAdViewSDK.Log.d("Video Prepared");
                            VideoPlayer.this.mVideoView.seekTo(position);
                        }
                    });
                    this.mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                        /* class com.millennialmedia.android.VideoPlayer.AnonymousClass8 */

                        public boolean onError(MediaPlayer mp, int what, int extra) {
                            return false;
                        }
                    });
                    this.mVideoView.setVideoURI(Uri.parse(path));
                    this.mVideoView.requestFocus();
                    this.mVideoView.start();
                    this.mVideoView.seekTo(position);
                    return;
                }
                startServer(path, position, false);
            }
        } catch (Exception e) {
            Log.e(MMAdViewSDK.SDKLOG, "error: " + e.getMessage(), e);
            SharedPreferences.Editor editor2 = getSharedPreferences("MillennialMediaSettings", 0).edit();
            editor2.putBoolean("lastAdViewed", true);
            editor2.commit();
            Toast.makeText(this, "Sorry. There was a problem playing the video", 1).show();
            if (this.mVideoView != null) {
                this.mVideoView.stopPlayback();
            }
        }
    }

    public void onStart() {
        super.onStart();
        if (this.videoAd != null && this.videoAd.stayInPlayer && this.videoCompleted && this.videoAd.buttons != null) {
            for (int i = 0; i < this.videoAd.buttons.size(); i++) {
                VideoImage videoImage = this.videoAd.buttons.get(i);
                setButtonAlpha(videoImage.button, videoImage.fromAlpha);
                if (videoImage.button.getParent() == null) {
                    this.buttonsLayout.addView(videoImage.button, videoImage.layoutParams);
                }
                for (int j = 0; j < this.videoAd.buttons.size(); j++) {
                    this.buttonsLayout.bringChildToFront(this.videoAd.buttons.get(j).button);
                }
            }
        }
    }

    public void onResume() {
        super.onResume();
        if (!(this.mVideoView == null || this.mVideoView.isPlaying() || this.videoCompleted)) {
            if (this.isCachedAd && !this.handler.hasMessages(2)) {
                this.handler.sendMessageDelayed(Message.obtain(this.handler, 2), 1000);
                if (this.showCountdownHud) {
                    long seconds = (this.videoAd.duration - ((long) this.currentVideoPosition)) / 1000;
                    if (seconds <= 0) {
                        hideHud();
                    } else if (this.hudSeconds != null) {
                        this.hudSeconds.setText(String.valueOf(seconds));
                    }
                }
                for (int i = 0; i < this.videoAd.buttons.size(); i++) {
                    VideoImage button = this.videoAd.buttons.get(i);
                    long delay = 0;
                    if (button.appearanceDelay > 0 && this.buttonsLayout.indexOfChild(button.button) == -1) {
                        Message message = Message.obtain(this.handler, 3, button);
                        delay = button.appearanceDelay - ((long) this.currentVideoPosition);
                        if (delay < 0) {
                            delay = 500;
                        }
                        this.handler.sendMessageDelayed(message, delay);
                    }
                    if (button.inactivityTimeout > 0) {
                        this.handler.sendMessageDelayed(Message.obtain(this.handler, 1, button), button.inactivityTimeout + delay + button.fadeDuration);
                    }
                }
            }
            playVideo(this.currentVideoPosition);
        }
    }

    public void onPause() {
        super.onPause();
        if (this.mVideoView != null) {
            this.currentVideoPosition = this.mVideoView.getCurrentPosition();
        }
        if (this.isCachedAd) {
            this.handler.removeMessages(1);
            this.handler.removeMessages(2);
            this.handler.removeMessages(3);
            stopServer();
        }
    }

    public void onBackPressed() {
        if (this.videoCompletedOnce) {
            super.onBackPressed();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void dismiss() {
        MMAdViewSDK.Log.d("Video ad player closed");
        if (this.mVideoView != null) {
            this.mVideoView.stopPlayback();
        }
        finish();
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.isCachedAd) {
            stopServer();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        if (this.mVideoView != null) {
            outState.putInt("videoPosition", this.mVideoView.getCurrentPosition());
        }
        outState.putBoolean("isCachedAd", this.isCachedAd);
        outState.putBoolean("videoCompleted", this.videoCompleted);
        outState.putBoolean("videoCompletedOnce", this.videoCompletedOnce);
        outState.putParcelable("logSet", this.logSet);
        outState.putBoolean("shouldShowBottomBar", this.showBottomBar);
        outState.putParcelable("videoAd", this.videoAd);
        super.onSaveInstanceState(outState);
    }

    private void pauseVideo() {
        if (this.mVideoView != null && this.mVideoView.isPlaying()) {
            this.mVideoView.pause();
            this.paused = true;
            MMAdViewSDK.Log.v("Video paused");
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void videoPlayerOnCompletion(String url) {
        this.videoCompletedOnce = true;
        this.videoCompleted = true;
        logEndEvent(this.logSet);
        stopServer();
        MMAdViewSDK.Log.v("Video player on complete");
        if (url != null) {
            dispatchButtonClick(url);
        }
        if (this.videoAd == null) {
            return;
        }
        if (!this.videoAd.stayInPlayer) {
            dismiss();
            return;
        }
        if (this.videoAd.buttons != null) {
            for (int i = 0; i < this.videoAd.buttons.size(); i++) {
                VideoImage videoImage = this.videoAd.buttons.get(i);
                setButtonAlpha(videoImage.button, videoImage.fromAlpha);
                if (videoImage.button.getParent() == null) {
                    this.buttonsLayout.addView(videoImage.button, videoImage.layoutParams);
                }
                for (int j = 0; j < this.videoAd.buttons.size(); j++) {
                    this.buttonsLayout.bringChildToFront(this.videoAd.buttons.get(j).button);
                }
                MMAdViewSDK.Log.v("Button: " + i + " alpha: " + videoImage.fromAlpha);
            }
        }
        this.handler.removeMessages(1);
        this.handler.removeMessages(2);
        this.handler.removeMessages(3);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void dispatchButtonClick(String urlString) {
        String browserAction;
        MMAdViewSDK.Log.d("Button Clicked: " + urlString);
        if (urlString != null) {
            pauseVideo();
            if (urlString.startsWith("mmsdk")) {
                String action = urlString.substring(8);
                if (action != null) {
                    if (action.equalsIgnoreCase("restartVideo")) {
                        if (this.isCachedAd && this.videoAd != null) {
                            List<VideoImage> buttons = this.videoAd.buttons;
                            if (!(this.buttonsLayout == null || buttons == null)) {
                                this.handler.removeMessages(1);
                                this.handler.removeMessages(2);
                                this.handler.removeMessages(3);
                                this.lastVideoPosition = 0;
                                for (int i = 0; i < buttons.size(); i++) {
                                    MMAdViewSDK.Log.d("i: " + i);
                                    VideoImage buttonData = buttons.get(i);
                                    if (buttonData != null) {
                                        if (buttonData.appearanceDelay > 0) {
                                            this.buttonsLayout.removeView(buttonData.button);
                                            this.handler.sendMessageDelayed(Message.obtain(this.handler, 3, buttonData), buttonData.appearanceDelay);
                                        }
                                        if (buttonData.inactivityTimeout > 0) {
                                            this.handler.sendMessageDelayed(Message.obtain(this.handler, 1, buttonData), buttonData.inactivityTimeout + buttonData.appearanceDelay + buttonData.fadeDuration);
                                        }
                                        if (this.showCountdownHud) {
                                            showHud(true);
                                        }
                                        if (this.handler != null) {
                                            this.handler.sendMessageDelayed(Message.obtain(this.handler, 2), 1000);
                                        }
                                    }
                                }
                            }
                        }
                        if (this.mVideoView != null) {
                            playVideo(0);
                            return;
                        }
                    } else if (action.equalsIgnoreCase("endVideo")) {
                        MMAdViewSDK.Log.d("End");
                        if (this.mVideoView != null) {
                            this.current = null;
                            this.mVideoView.stopPlayback();
                            if (this.videoAd != null) {
                                dismiss();
                                return;
                            }
                            return;
                        }
                    } else {
                        MMAdViewSDK.Log.v("Unrecognized mmsdk:// URL");
                    }
                }
            } else if (urlString.startsWith("mmbrowser") && (browserAction = urlString.substring(12)) != null) {
                MMAdViewSDK.Log.v("Launch browser");
                try {
                    startActivity(new Intent("android.intent.action.VIEW", Uri.parse(browserAction)));
                    return;
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                    return;
                }
            }
            String mimeTypeString = null;
            String redirectString = urlString;
            while (redirectString != null) {
                try {
                    URL connectURL = new URL(redirectString);
                    HttpURLConnection.setFollowRedirects(false);
                    HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();
                    conn.setRequestMethod("GET");
                    conn.connect();
                    redirectString = conn.getHeaderField("Location");
                    mimeTypeString = conn.getHeaderField("Content-Type");
                    int rc = conn.getResponseCode();
                    MMAdViewSDK.Log.v("Response Code: " + conn.getResponseCode() + " Response Message: " + conn.getResponseMessage());
                    MMAdViewSDK.Log.v("urlString: " + urlString);
                    if (rc >= 300) {
                        if (rc >= 400) {
                        }
                    }
                } catch (MalformedURLException e2) {
                } catch (IOException e3) {
                    e3.printStackTrace();
                }
                MMAdViewSDK.Log.v("locationString: " + redirectString);
                if (redirectString != null) {
                    Uri destinationURI = Uri.parse(redirectString);
                    if (mimeTypeString == null) {
                        mimeTypeString = ASConstants.kEmptyString;
                    }
                    if (destinationURI.getScheme().equalsIgnoreCase("mmsdk")) {
                        if (destinationURI.getHost().equalsIgnoreCase("endVideo") && this.mVideoView != null) {
                            this.current = null;
                            this.mVideoView.stopPlayback();
                            dismiss();
                            return;
                        }
                        return;
                    } else if ((destinationURI.getScheme().equalsIgnoreCase("http") || destinationURI.getScheme().equalsIgnoreCase("https")) && mimeTypeString.equalsIgnoreCase("text/html")) {
                        Intent intent = new Intent(this, MMAdViewOverlayActivity.class);
                        intent.setData(destinationURI);
                        intent.putExtra("cachedAdView", true);
                        startActivityForResult(intent, 0);
                        return;
                    } else if (destinationURI.getScheme().equalsIgnoreCase("market")) {
                        MMAdViewSDK.Log.v("Android Market URL, launch the Market Application");
                        startActivity(new Intent("android.intent.action.VIEW", destinationURI));
                        return;
                    } else if (destinationURI.getScheme().equalsIgnoreCase("rtsp") || (destinationURI.getScheme().equalsIgnoreCase("http") && (mimeTypeString.equalsIgnoreCase("video/mp4") || mimeTypeString.equalsIgnoreCase("video/3gpp")))) {
                        playVideo(0);
                        return;
                    } else if (destinationURI.getScheme().equalsIgnoreCase("tel")) {
                        MMAdViewSDK.Log.v("Telephone Number, launch the phone");
                        startActivity(new Intent("android.intent.action.DIAL", destinationURI));
                        return;
                    } else if (destinationURI.getScheme().equalsIgnoreCase("http")) {
                        Intent intent2 = new Intent(this, MMAdViewOverlayActivity.class);
                        intent2.setData(destinationURI);
                        intent2.putExtra("cachedAdView", true);
                        startActivityForResult(intent2, 0);
                        return;
                    } else if (destinationURI.getScheme().equalsIgnoreCase("mmbrowser")) {
                        String browserAction2 = urlString.substring(12);
                        if (browserAction2 != null) {
                            MMAdViewSDK.Log.v("Launch browser");
                            try {
                                startActivity(new Intent("android.intent.action.VIEW", Uri.parse(browserAction2)));
                                return;
                            } catch (ActivityNotFoundException e4) {
                                e4.printStackTrace();
                                return;
                            }
                        } else {
                            return;
                        }
                    } else {
                        MMAdViewSDK.Log.v("Uncertain about content, launch to browser");
                        startActivity(new Intent("android.intent.action.VIEW", destinationURI));
                        return;
                    }
                } else {
                    return;
                }
            }
        }
    }

    public synchronized void startServer(String path, int position, boolean isSDCard) {
        if (this.videoServer == null) {
            this.videoServer = new VideoServer(path, isSDCard);
            Thread thread = new Thread(this.videoServer);
            thread.start();
            thread.getId();
            if (this.mVideoView != null) {
                this.mVideoView.setVideoURI(Uri.parse("http://localhost:" + this.videoServer.port + "/" + path + "/video.dat"));
                this.mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    /* class com.millennialmedia.android.VideoPlayer.AnonymousClass12 */

                    public void onCompletion(MediaPlayer mp) {
                        MMAdViewSDK.Log.d("Video Playing Complete");
                        if (VideoPlayer.this.showCountdownHud) {
                            VideoPlayer.this.hideHud();
                        }
                        if (VideoPlayer.this.videoAd != null) {
                            VideoPlayer.this.videoPlayerOnCompletion(VideoPlayer.this.videoAd.onCompletionUrl);
                        }
                    }
                });
                this.mVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    /* class com.millennialmedia.android.VideoPlayer.AnonymousClass13 */

                    public void onPrepared(MediaPlayer mp) {
                        MMAdViewSDK.Log.d("Video Prepared");
                    }
                });
                this.mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    /* class com.millennialmedia.android.VideoPlayer.AnonymousClass14 */

                    public boolean onError(MediaPlayer mp, int what, int extra) {
                        return false;
                    }
                });
                this.mVideoView.seekTo(position);
                this.mVideoView.requestFocus();
                this.mVideoView.start();
            } else {
                Log.e(MMAdViewSDK.SDKLOG, "Null Video View");
            }
        }
    }

    public synchronized void stopServer() {
        MMAdViewSDK.Log.d("Stop video server");
        if (this.videoServer != null) {
            this.videoServer.requestStop();
            this.videoServer = null;
        }
        if (this.mVideoView != null) {
            this.mVideoView.stopPlayback();
        }
    }

    /* access modifiers changed from: private */
    public class VideoServer implements Runnable {
        private String cacheDir;
        boolean done = false;
        private final String filePath;
        Integer port;
        private ServerSocket serverSocket = null;

        public VideoServer(String filePath2, boolean isSDCard) {
            this.filePath = filePath2;
            if (isSDCard) {
                this.cacheDir = Environment.getExternalStorageDirectory().getPath() + "/" + "millennialmedia" + "/";
            } else {
                this.cacheDir = VideoPlayer.this.getCacheDir() + "/";
            }
            try {
                this.serverSocket = new ServerSocket();
                this.serverSocket.bind(null);
                this.serverSocket.setSoTimeout(0);
                this.port = new Integer(this.serverSocket.getLocalPort());
                MMAdViewSDK.Log.v("Video Server Port: " + this.port);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        /* JADX WARNING: Removed duplicated region for block: B:101:0x043a A[Catch:{ IOException -> 0x0444 }] */
        /* JADX WARNING: Removed duplicated region for block: B:103:0x043f A[Catch:{ IOException -> 0x0444 }] */
        /* JADX WARNING: Removed duplicated region for block: B:115:0x04d8 A[SYNTHETIC, Splitter:B:115:0x04d8] */
        /* JADX WARNING: Removed duplicated region for block: B:118:0x04dd A[Catch:{ IOException -> 0x04e7 }] */
        /* JADX WARNING: Removed duplicated region for block: B:120:0x04e2 A[Catch:{ IOException -> 0x04e7 }] */
        /* JADX WARNING: Removed duplicated region for block: B:130:0x0512 A[SYNTHETIC, Splitter:B:130:0x0512] */
        /* JADX WARNING: Removed duplicated region for block: B:133:0x0517 A[Catch:{ IOException -> 0x0520 }] */
        /* JADX WARNING: Removed duplicated region for block: B:135:0x051c A[Catch:{ IOException -> 0x0520 }] */
        /* JADX WARNING: Removed duplicated region for block: B:150:0x000a A[SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:153:0x000a A[SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:166:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x01ad  */
        /* JADX WARNING: Removed duplicated region for block: B:40:0x01ba A[Catch:{ IOException -> 0x0525 }] */
        /* JADX WARNING: Removed duplicated region for block: B:73:0x0398 A[SYNTHETIC, Splitter:B:73:0x0398] */
        /* JADX WARNING: Removed duplicated region for block: B:77:0x03a2 A[SYNTHETIC, Splitter:B:77:0x03a2] */
        /* JADX WARNING: Removed duplicated region for block: B:80:0x03a7 A[Catch:{ IOException -> 0x03b1 }] */
        /* JADX WARNING: Removed duplicated region for block: B:82:0x03ac A[Catch:{ IOException -> 0x03b1 }] */
        /* JADX WARNING: Removed duplicated region for block: B:98:0x0435 A[SYNTHETIC, Splitter:B:98:0x0435] */
        public void run() {
            Throwable th;
            SocketTimeoutException e;
            String requestString;
            Socket clientSocket = null;
            OutputStream outputStream = null;
            FileInputStream fileInputStream = null;
            byte[] buffer = new byte[1024];
            while (true) {
                if (this.done) {
                    break;
                }
                try {
                    clientSocket = this.serverSocket.accept();
                    MMAdViewSDK.Log.v("Accepted new incoming connection");
                    InputStream inputStream = clientSocket.getInputStream();
                    outputStream = clientSocket.getOutputStream();
                    StringBuilder stringBuilder = new StringBuilder();
                    do {
                        inputStream.read(buffer);
                        stringBuilder.append(new String(buffer));
                        requestString = stringBuilder.toString();
                    } while (!requestString.contains("\r\n\r\n"));
                    MMAdViewSDK.Log.v("Request string: " + requestString);
                    MMAdViewSDK.Log.v("******************");
                    if (requestString.startsWith("HEAD /" + this.filePath + "/video.dat")) {
                        File file = new File(this.cacheDir + this.filePath + "/video.dat");
                        outputStream.write("HTTP/1.1 200 OK\r\n".getBytes());
                        outputStream.write("Content-Type: video/mp4\r\n".getBytes());
                        outputStream.write(new String("Content-Length: " + file.length() + "\r\n").getBytes());
                        outputStream.write("Cache-Control: no-cache\r\n".getBytes());
                        outputStream.write("Connection: close\r\n\r\n".getBytes());
                    } else if (requestString.startsWith("GET /" + this.filePath + "/video.dat")) {
                        File file2 = new File(this.cacheDir + this.filePath + "/video.dat");
                        if (file2 == null) {
                            MMAdViewSDK.Log.v("Closing video server socket");
                            if (clientSocket != null) {
                                try {
                                    clientSocket.close();
                                } catch (IOException e2) {
                                    e2.printStackTrace();
                                }
                            }
                            if (fileInputStream != null) {
                                fileInputStream.close();
                            }
                            if (outputStream != null) {
                                outputStream.close();
                            }
                        } else {
                            outputStream = clientSocket.getOutputStream();
                            if (requestString.contains("Range:")) {
                                MMAdViewSDK.Log.v("Range found in request string ");
                                Matcher m2 = Pattern.compile("Range: bytes=([0-9]+)-\\s").matcher(requestString);
                                long bytesStartLong = 1;
                                long bytesEndLong = 1;
                                while (m2.find()) {
                                    bytesStartLong = (long) new Integer(m2.group(1)).intValue();
                                    bytesEndLong = file2.length();
                                }
                                Matcher m1 = Pattern.compile("Range: bytes=([0-9]+)-([0-9]+)").matcher(requestString);
                                while (m1.find()) {
                                    String bytesStartString = m1.group(1);
                                    String bytesEndString = m1.group(2);
                                    bytesStartLong = (long) new Integer(bytesStartString).intValue();
                                    if (bytesEndString != null) {
                                        bytesEndLong = (long) new Integer(bytesEndString).intValue();
                                    } else {
                                        bytesEndLong = file2.length() - 1;
                                    }
                                }
                                Log.i(MMAdViewSDK.SDKLOG, "Bytes: " + bytesStartLong + "-" + bytesEndLong);
                                FileInputStream fileInputStream2 = new FileInputStream(file2);
                                try {
                                    long skippedBytes = fileInputStream2.skip(bytesStartLong);
                                    MMAdViewSDK.Log.v("Bytes skipped: " + skippedBytes);
                                    long length = (bytesEndLong - skippedBytes) + 1;
                                    outputStream.write("HTTP/1.1 206 Partial Content\r\n".getBytes());
                                    outputStream.write("Date: Thu, 17 Feb 2011 01:27:03 GMT\r\n".getBytes());
                                    outputStream.write("Etag: \"320581-329f19-235b0a40\"\r\n".getBytes());
                                    if (bytesEndLong > 1) {
                                        outputStream.write(new String("Content-Range: " + bytesStartLong + "-" + bytesEndLong + "\r\n").getBytes());
                                    } else {
                                        outputStream.write(new String("Content-Range: " + bytesStartLong + "-" + file2.length() + "\r\n").getBytes());
                                    }
                                    outputStream.write("Content-Type: video/mp4\r\n".getBytes());
                                    outputStream.write(new String("Content-Length: " + length + "\r\n").getBytes());
                                    outputStream.write("Connection: close\r\n\r\n".getBytes());
                                    while (true) {
                                        int numread = fileInputStream2.read(buffer);
                                        if (numread > 0) {
                                            if (length >= ((long) numread)) {
                                                outputStream.write(buffer, 0, numread);
                                            } else {
                                                outputStream.write(buffer, 0, (int) length);
                                            }
                                            length -= (long) numread;
                                            if (length <= 0) {
                                                break;
                                            }
                                        } else {
                                            MMAdViewSDK.Log.v("Video Did Finish");
                                            break;
                                        }
                                    }
                                    fileInputStream = fileInputStream2;
                                } catch (SocketTimeoutException e3) {
                                    e = e3;
                                    fileInputStream = fileInputStream2;
                                    try {
                                        e.printStackTrace();
                                        if (clientSocket != null) {
                                        }
                                        MMAdViewSDK.Log.v("Closing video server socket");
                                        if (clientSocket != null) {
                                        }
                                        if (fileInputStream != null) {
                                        }
                                        if (outputStream == null) {
                                        }
                                    } catch (Throwable th2) {
                                        th = th2;
                                        MMAdViewSDK.Log.v("Closing video server socket");
                                        if (clientSocket != null) {
                                            try {
                                                clientSocket.close();
                                            } catch (IOException e4) {
                                                e4.printStackTrace();
                                                throw th;
                                            }
                                        }
                                        if (fileInputStream != null) {
                                            fileInputStream.close();
                                        }
                                        if (outputStream != null) {
                                            outputStream.close();
                                        }
                                        throw th;
                                    }
                                } catch (FileNotFoundException e5) {
                                    e = e5;
                                    fileInputStream = fileInputStream2;
                                    e.printStackTrace();
                                    MMAdViewSDK.Log.v("Closing video server socket");
                                    if (clientSocket != null) {
                                    }
                                    if (fileInputStream != null) {
                                    }
                                    if (outputStream != null) {
                                    }
                                    if (this.done) {
                                    }
                                    if (this.serverSocket == null) {
                                    }
                                } catch (IOException e6) {
                                    e = e6;
                                    fileInputStream = fileInputStream2;
                                    e.printStackTrace();
                                    MMAdViewSDK.Log.v("Closing video server socket");
                                    if (clientSocket != null) {
                                    }
                                    if (fileInputStream != null) {
                                    }
                                    if (outputStream == null) {
                                    }
                                } catch (Throwable th3) {
                                    th = th3;
                                    fileInputStream = fileInputStream2;
                                    MMAdViewSDK.Log.v("Closing video server socket");
                                    if (clientSocket != null) {
                                    }
                                    if (fileInputStream != null) {
                                    }
                                    if (outputStream != null) {
                                    }
                                    throw th;
                                }
                            } else {
                                outputStream.write("HTTP/1.1 200 OK\r\n".getBytes());
                                outputStream.write("Content-Type: video/mp4\r\n".getBytes());
                                outputStream.write(new String("Content-Length: " + file2.length() + "\r\n").getBytes());
                                outputStream.write("Cache-Control: no-cache\r\n".getBytes());
                                outputStream.write("Connection: close\r\n\r\n".getBytes());
                                FileInputStream fileInputStream3 = new FileInputStream(file2);
                                while (true) {
                                    int numread2 = fileInputStream3.read(buffer);
                                    if (numread2 <= 0) {
                                        break;
                                    }
                                    outputStream.write(buffer, 0, numread2);
                                }
                                Log.i(MMAdViewSDK.SDKLOG, "Video Did Finish");
                                fileInputStream = fileInputStream3;
                            }
                            outputStream.write("\r\n".getBytes());
                            MMAdViewSDK.Log.v("200 OK");
                            this.done = true;
                        }
                    } else {
                        outputStream.write("HTTP/1.1 400 Bad Request\r\n\r\n".getBytes());
                        MMAdViewSDK.Log.v("400 Bad Request");
                    }
                    MMAdViewSDK.Log.v("Closing video server socket");
                    if (clientSocket != null) {
                        try {
                            clientSocket.close();
                        } catch (IOException e7) {
                            e7.printStackTrace();
                        }
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (outputStream != null) {
                        outputStream.close();
                    }
                } catch (SocketTimeoutException e8) {
                    e = e8;
                    e.printStackTrace();
                    if (clientSocket != null) {
                        try {
                            clientSocket.close();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    MMAdViewSDK.Log.v("Closing video server socket");
                    if (clientSocket != null) {
                        try {
                            clientSocket.close();
                        } catch (IOException e9) {
                            e9.printStackTrace();
                        }
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (outputStream == null) {
                        outputStream.close();
                    }
                } catch (FileNotFoundException e10) {
                    e = e10;
                    e.printStackTrace();
                    MMAdViewSDK.Log.v("Closing video server socket");
                    if (clientSocket != null) {
                        try {
                            clientSocket.close();
                        } catch (IOException e11) {
                            e11.printStackTrace();
                        }
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (outputStream != null) {
                        outputStream.close();
                    }
                    if (this.done) {
                    }
                    if (this.serverSocket == null) {
                        return;
                    }
                } catch (IOException e12) {
                    e = e12;
                    e.printStackTrace();
                    MMAdViewSDK.Log.v("Closing video server socket");
                    if (clientSocket != null) {
                        try {
                            clientSocket.close();
                        } catch (IOException e13) {
                            e13.printStackTrace();
                        }
                    }
                    if (fileInputStream != null) {
                        fileInputStream.close();
                    }
                    if (outputStream == null) {
                        outputStream.close();
                    }
                }
            }
            if (this.done) {
                MMAdViewSDK.Log.v("Detected stop");
            }
            try {
                if (this.serverSocket == null && this.serverSocket.isBound()) {
                    MMAdViewSDK.Log.v("Closing server socket connection");
                    this.serverSocket.close();
                }
            } catch (IOException e14) {
                e14.printStackTrace();
            }
        }

        public synchronized void requestStop() {
            this.done = true;
            MMAdViewSDK.Log.v("Requested video server stop. Done: " + this.done);
        }
    }
}
