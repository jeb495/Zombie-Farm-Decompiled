package com.millennialmedia.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.android.adsymp.core.ASConstants;
import com.millennialmedia.android.MMAdViewSDK;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;

/* access modifiers changed from: package-private */
public class MMAdViewController {
    private static final HashMap<Long, MMAdViewController> controllers = new HashMap<>();
    private WeakReference<MMAdView> adViewRef;
    private boolean appPaused;
    private Handler cacheHandler = new Handler();
    boolean canAccelerate;
    private Handler handler;
    String nextUrl;
    String overlayTitle;
    String overlayTransition;
    private boolean paused = true;
    private boolean refreshTimerOn;
    boolean requestInProgress;
    private Runnable runnable = new Runnable() {
        /* class com.millennialmedia.android.MMAdViewController.AnonymousClass5 */

        public void run() {
            MMAdViewController.this.chooseCachedAdOrAdCall();
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
            } else {
                MMAdViewController.this.handler.postDelayed(this, (long) (adView.refreshInterval * 1000));
            }
        }
    };
    boolean shouldEnableBottomBar;
    boolean shouldLaunchToOverlay;
    boolean shouldMakeOverlayTransparent;
    int shouldResizeOverlay;
    boolean shouldShowBottomBar;
    boolean shouldShowTitlebar;
    private long timeRemaining;
    private long timeResumed;
    long transitionTime;
    private String urlString;
    private WebView webView;

    private MMAdViewController(MMAdView adView) {
        resetAdViewSettings();
        this.adViewRef = new WeakReference<>(adView);
        this.webView = new WebView(adView.getContext().getApplicationContext());
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.getSettings().setCacheMode(2);
        this.webView.setBackgroundColor(0);
        this.webView.setWillNotDraw(false);
        this.webView.addJavascriptInterface(new MMJSInterface(), "interface");
        this.webView.setId(15063);
    }

    static synchronized void assignAdViewController(MMAdView adView) {
        synchronized (MMAdViewController.class) {
            boolean reassign = true;
            if (adView.controller == null) {
                if (adView.getId() == -1) {
                    Log.e(MMAdViewSDK.SDKLOG, "MMAdView found without a view id. Ad requests on this MMAdView are disabled.");
                } else {
                    MMAdViewController controller = controllers.get(adView.adViewId);
                    if (controller == null) {
                        controller = new MMAdViewController(adView);
                        controllers.put(adView.adViewId, controller);
                        reassign = false;
                    }
                    controller.adViewRef = new WeakReference<>(adView);
                    adView.controller = controller;
                    if (controller.webView.getParent() != null) {
                        ((ViewGroup) controller.webView.getParent()).removeView(controller.webView);
                    }
                    adView.addView(controller.webView, new ViewGroup.LayoutParams(-1, -1));
                    if (adView.refreshInterval >= 0 && adView.refreshInterval < 15) {
                        controller.refreshTimerOn = false;
                        MMAdViewSDK.Log.d("Refresh interval is " + adView.refreshInterval + ". Change to at least 15 to refresh ads.");
                    } else if (adView.refreshInterval < 0) {
                        controller.refreshTimerOn = false;
                        MMAdViewSDK.Log.d("Automatic ad fetching is off with " + adView.refreshInterval + ". You must manually call for ads.");
                    } else {
                        controller.refreshTimerOn = true;
                        controller.resumeTimer(false);
                    }
                    if (adView.refreshInterval >= 0 && !reassign) {
                        controller.chooseCachedAdOrAdCall();
                    }
                }
            }
        }
    }

    static synchronized void removeAdViewController(MMAdView adView, boolean isFinishing) {
        MMAdViewController controller;
        synchronized (MMAdViewController.class) {
            if (adView.controller != null) {
                if (isFinishing) {
                    controller = controllers.put(adView.adViewId, null);
                } else {
                    controller = controllers.get(adView.adViewId);
                }
                adView.controller = null;
                if (controller != null) {
                    controller.pauseTimer(false);
                    if (isFinishing) {
                        controller.handler = null;
                    }
                    adView.removeView(controller.webView);
                }
            }
        }
    }

    /* access modifiers changed from: package-private */
    public synchronized void chooseCachedAdOrAdCall() {
        MMAdView adView = this.adViewRef.get();
        if (adView == null) {
            Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
        } else {
            Context context = adView.getContext();
            if (HandShake.sharedHandShake(context).kill) {
                Log.i(MMAdViewSDK.SDKLOG, "The server is no longer allowing ads.");
            } else if (this.requestInProgress) {
                Log.i(MMAdViewSDK.SDKLOG, "There is already an ad request in progress. Defering call for new ad");
                adFailed(adView);
                adIsCaching(adView);
            } else if (HandShake.sharedHandShake(context).isAdTypeDownloading(adView.adType)) {
                adFailed(adView);
                adIsCaching(adView);
                Log.i(MMAdViewSDK.SDKLOG, "There is a download in progress. Defering call for new ad");
            } else {
                MMAdViewSDK.Log.d("No download in progress.");
                if (checkForAdNotDownloaded(adView)) {
                    Log.i(MMAdViewSDK.SDKLOG, "Last ad wasn't fully downloaded. Download again.");
                    adFailed(adView);
                    adIsCaching(adView);
                    DownloadLastAd(adView);
                } else {
                    Log.i(MMAdViewSDK.SDKLOG, "No incomplete downloads.");
                    cleanUpExpiredAds(adView);
                    SharedPreferences settings = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0);
                    String lastAdName = settings.getString("lastDownloadedAdName", null);
                    if (lastAdName == null) {
                        Log.i(MMAdViewSDK.SDKLOG, "Last ad name is null. Call for new ad.");
                        getNextAd();
                    } else if (checkIfAdExistsInDb(lastAdName, adView)) {
                        Log.i(MMAdViewSDK.SDKLOG, "Ad found in the database");
                        if (!checkIfAdExistsInFilesystem(lastAdName, adView)) {
                            Log.i(MMAdViewSDK.SDKLOG, "Last ad can't be found in the file system. Download again.");
                            DownloadLastAd(adView);
                        } else if (!checkIfExpired(lastAdName, adView)) {
                            boolean adViewed = settings.getBoolean("lastAdViewed", false);
                            Log.i(MMAdViewSDK.SDKLOG, "Last ad viewed?: " + adViewed);
                            if (adViewed) {
                                Log.i(MMAdViewSDK.SDKLOG, "Existing ad has been viewed. Call for a new ad");
                                getNextAd();
                            } else if (HandShake.sharedHandShake(context).canWatchVideoAd(context, adView.adType, lastAdName)) {
                                adSuccess(adView);
                                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return success");
                                playVideo(lastAdName, adView);
                            } else {
                                Log.i(MMAdViewSDK.SDKLOG, "Outside of the timeout window. Call for a new ad");
                                getNextAd();
                            }
                        } else {
                            Log.i(MMAdViewSDK.SDKLOG, "Existing ad is expired. Delete and call for a new ad");
                            deleteAd(lastAdName, adView);
                            SharedPreferences.Editor editor = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
                            editor.putString("lastDownloadedAdName", null);
                            editor.commit();
                            MMAdViewSDK.Log.v("Setting last ad name to NULL");
                            getNextAd();
                        }
                    } else {
                        Log.i(MMAdViewSDK.SDKLOG, "Last ad can't be found in the database. Remove any files from the filesystem and call for new ad.");
                        deleteAd(lastAdName, adView);
                        SharedPreferences.Editor editor2 = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
                        editor2.putString("lastDownloadedAdName", null);
                        editor2.commit();
                        MMAdViewSDK.Log.v("Setting last ad name to NULL");
                        getNextAd();
                    }
                }
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void resetAdViewSettings() {
        this.shouldLaunchToOverlay = false;
        this.shouldShowTitlebar = false;
        this.shouldShowBottomBar = true;
        this.shouldEnableBottomBar = true;
        this.shouldMakeOverlayTransparent = false;
        this.shouldResizeOverlay = 0;
        this.overlayTitle = "Advertisement";
        this.overlayTransition = "bottomtotop";
        this.transitionTime = 600;
        this.canAccelerate = false;
    }

    private void getNextAd() {
        this.requestInProgress = true;
        new Thread() {
            /* class com.millennialmedia.android.MMAdViewController.AnonymousClass1 */

            public void run() {
                String content;
                IOException e1;
                IllegalStateException e12;
                final MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
                if (adView == null) {
                    Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                    MMAdViewController.this.requestInProgress = false;
                } else if (adView.apid == null) {
                    MMAdViewController.this.adFailed(adView);
                    Log.e(MMAdViewSDK.SDKLOG, "MMAdView found with a null apid. New ad requests on this MMAdView are disabled until an apid has been assigned.");
                    MMAdViewController.this.requestInProgress = false;
                } else {
                    if (MMAdViewSDK.connectivityManager.getActiveNetworkInfo() == null || !MMAdViewSDK.connectivityManager.getActiveNetworkInfo().isConnected()) {
                        MMAdViewController.this.adFailed(adView);
                        Log.i(MMAdViewSDK.SDKLOG, "No network available, can't call for ads.");
                    } else {
                        String adTypeString = null;
                        String adUrl = null;
                        try {
                            String metaValues = MMAdViewController.this.getURLMetaValues(adView);
                            if (adView.testMode) {
                                Log.w(MMAdViewSDK.SDKLOG, "*********** Advertising test mode is deprecated. Refer to wiki.millennialmedia.com for testing information. ");
                            }
                            adTypeString = MMAdViewController.this.getAdType(adView.adType);
                            String ua = MMAdViewController.this.webView.getSettings().getUserAgentString() + Build.MODEL;
                            DisplayMetrics metrics = adView.getContext().getResources().getDisplayMetrics();
                            float scale = metrics.density;
                            int heightPixels = metrics.heightPixels;
                            int widthPixels = metrics.widthPixels;
                            StringBuilder adUrlBuilder = new StringBuilder("http://androidsdk.ads.mp.mydas.mobi/getAd.php5?sdkapid=" + URLEncoder.encode(adView.apid, "UTF-8"));
                            if (adView.auid != null) {
                                adUrlBuilder.append("&auid=" + URLEncoder.encode(adView.auid, "UTF-8"));
                            } else {
                                adUrlBuilder.append("&auid=UNKNOWN");
                            }
                            if (ua != null) {
                                adUrlBuilder.append("&ua=" + URLEncoder.encode(ua, "UTF-8"));
                            } else {
                                adUrlBuilder.append("&ua=UNKNOWN");
                            }
                            if (Build.MODEL != null) {
                                adUrlBuilder.append("&dm=" + URLEncoder.encode(Build.MODEL, "UTF-8"));
                            }
                            if (Build.VERSION.RELEASE != null) {
                                adUrlBuilder.append("&dv=Android" + URLEncoder.encode(Build.VERSION.RELEASE, "UTF-8"));
                            }
                            adUrlBuilder.append("&density=" + Float.toString(scale));
                            adUrlBuilder.append("&hpx=" + heightPixels);
                            adUrlBuilder.append("&wpx=" + widthPixels);
                            adUrlBuilder.append("&mmisdk=" + URLEncoder.encode(MMAdViewSDK.SDKVER, "UTF-8") + metaValues);
                            Context context = adView.getContext();
                            if (HandShake.sharedHandShake(context).canRequestVideo(context, adView.adType)) {
                                adUrlBuilder.append("&video=true");
                            } else {
                                adUrlBuilder.append("&video=false");
                            }
                            if (adView.getContext().checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == -1 || (Build.VERSION.SDK.equalsIgnoreCase("8") && !Environment.getExternalStorageState().equals("mounted"))) {
                                adUrlBuilder.append("&cachedvideo=false");
                            } else {
                                adUrlBuilder.append("&cachedvideo=true");
                            }
                            adUrl = adUrlBuilder.toString();
                        } catch (UnsupportedEncodingException e) {
                        }
                        if (adTypeString != null) {
                            adUrl = adUrl + adTypeString;
                        }
                        Log.i(MMAdViewSDK.SDKLOG, "Calling for an advertisement: " + adUrl);
                        try {
                            HttpResponse httpResponse = new HttpGetRequest().get(adUrl);
                            if (httpResponse == null) {
                                Log.e(MMAdViewSDK.SDKLOG, "HTTP response is null");
                                MMAdViewController.this.requestInProgress = false;
                                MMAdViewController.this.adFailed(adView);
                                return;
                            }
                            HttpEntity httpEntity = httpResponse.getEntity();
                            if (httpEntity == null) {
                                Log.i(MMAdViewSDK.SDKLOG, "Null HTTP entity");
                                MMAdViewController.this.requestInProgress = false;
                                MMAdViewController.this.adFailed(adView);
                                return;
                            } else if (httpEntity.getContentLength() == 0) {
                                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Zero content length returned.");
                                MMAdViewController.this.requestInProgress = false;
                                MMAdViewController.this.adFailed(adView);
                                return;
                            } else {
                                Header httpHeader = httpEntity.getContentType();
                                if (httpHeader == null) {
                                    MMAdViewController.this.adFailed(adView);
                                    Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. HTTP Header is null.");
                                } else if (httpHeader.getValue() == null) {
                                    MMAdViewController.this.adFailed(adView);
                                    Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. HTTP Header value null.");
                                } else if (httpHeader.getValue().equalsIgnoreCase("application/json")) {
                                    try {
                                        VideoAd videoAd = new VideoAd(HttpGetRequest.convertStreamToString(httpEntity.getContent()));
                                        try {
                                            Log.i(MMAdViewSDK.SDKLOG, "Current environment: " + Environment.getExternalStorageState());
                                            if (Environment.getExternalStorageState().equals("mounted")) {
                                                videoAd.storedOnSdCard = true;
                                            }
                                            if (videoAd != null) {
                                                Log.i(MMAdViewSDK.SDKLOG, "Cached video ad JSON received: " + videoAd.id);
                                                MMAdViewController.this.handleCachedAdResponse(videoAd);
                                            }
                                        } catch (IllegalStateException e2) {
                                            e12 = e2;
                                            e12.printStackTrace();
                                            Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Invalid response data.");
                                            MMAdViewController.this.requestInProgress = false;
                                            MMAdViewController.this.adFailed(adView);
                                            return;
                                        } catch (IOException e3) {
                                            e1 = e3;
                                            e1.printStackTrace();
                                            Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Invalid response data.");
                                            MMAdViewController.this.requestInProgress = false;
                                            MMAdViewController.this.adFailed(adView);
                                            return;
                                        }
                                    } catch (IllegalStateException e4) {
                                        e12 = e4;
                                        e12.printStackTrace();
                                        Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Invalid response data.");
                                        MMAdViewController.this.requestInProgress = false;
                                        MMAdViewController.this.adFailed(adView);
                                        return;
                                    } catch (IOException e5) {
                                        e1 = e5;
                                        e1.printStackTrace();
                                        Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Invalid response data.");
                                        MMAdViewController.this.requestInProgress = false;
                                        MMAdViewController.this.adFailed(adView);
                                        return;
                                    }
                                } else if (httpHeader.getValue().equalsIgnoreCase("text/html")) {
                                    Header xHeader = httpResponse.getFirstHeader("X-MM-Video");
                                    if (xHeader != null && xHeader.getValue().equalsIgnoreCase("true")) {
                                        Context context2 = adView.getContext();
                                        HandShake.sharedHandShake(context2).didReceiveVideoXHeader(context2, adView.adType);
                                    }
                                    MMAdViewController.this.webView.setWebViewClient(new WebViewClient() {
                                        /* class com.millennialmedia.android.MMAdViewController.AnonymousClass1.AnonymousClass1 */

                                        public void onPageFinished(WebView webView, String url) {
                                            webView.loadUrl("javascript:window.interface.setLoaded(true);");
                                            webView.loadUrl("javascript:window.interface.getUrl(document.links[0].href);");
                                            adView.setClickable(true);
                                            if (webView != null) {
                                                webView.clearCache(true);
                                            }
                                        }

                                        @Override // android.webkit.WebViewClient
                                        public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                            return true;
                                        }

                                        public void onScaleChanged(WebView view, float oldScale, float newScale) {
                                            Log.e(MMAdViewSDK.SDKLOG, "Scale Changed");
                                        }
                                    });
                                    try {
                                        if (adView.ignoreDensityScaling) {
                                            content = "<head><meta name=\"viewport\" content=\"target-densitydpi=device-dpi\" /></head>" + HttpGetRequest.convertStreamToString(httpEntity.getContent());
                                        } else {
                                            content = HttpGetRequest.convertStreamToString(httpEntity.getContent());
                                        }
                                        MMAdViewController.this.resetAdViewSettings();
                                        adView.setClickable(false);
                                        MMAdViewController.this.webView.loadDataWithBaseURL(adUrl.substring(0, adUrl.lastIndexOf("/") + 1), content, "text/html", "UTF-8", null);
                                    } catch (IOException ioe) {
                                        Log.e(MMAdViewSDK.SDKLOG, "Exception raised in the ad webview: ", ioe);
                                        MMAdViewController.this.adFailed(adView);
                                        Log.i(MMAdViewSDK.SDKLOG, "Millennial ad webview failed.");
                                    }
                                } else {
                                    MMAdViewController.this.adFailed(adView);
                                    Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed. Invalid mime type returned.");
                                }
                            }
                        } catch (Exception e6) {
                            Log.e(MMAdViewSDK.SDKLOG, "HTTP error: ", e6);
                            MMAdViewController.this.requestInProgress = false;
                            MMAdViewController.this.adFailed(adView);
                            return;
                        }
                    }
                    MMAdViewController.this.requestInProgress = false;
                }
            }
        }.start();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x00aa  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00d1  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d8  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00ed  */
    private void handleCachedAdResponse(final VideoAd videoAd) {
        Throwable th;
        SQLiteException e;
        MMAdView adView = this.adViewRef.get();
        if (adView == null) {
            Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
        } else if (checkIfAdExistsInDb(videoAd.id, adView)) {
            AdDatabaseHelper db = null;
            try {
                AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
                try {
                    db2.updateDeferredViewStart(videoAd.id);
                    db2.updateAdData(videoAd);
                    if (db2 != null) {
                        db2.close();
                    }
                } catch (SQLiteException e2) {
                    e = e2;
                    db = db2;
                    try {
                        e.printStackTrace();
                        if (db != null) {
                        }
                        if (!checkIfAdExistsInFilesystem(videoAd.id, adView)) {
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (db != null) {
                            db.close();
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    db = db2;
                    if (db != null) {
                    }
                    throw th;
                }
            } catch (SQLiteException e3) {
                e = e3;
                e.printStackTrace();
                if (db != null) {
                    db.close();
                }
                if (!checkIfAdExistsInFilesystem(videoAd.id, adView)) {
                }
            }
            if (!checkIfAdExistsInFilesystem(videoAd.id, adView)) {
                if (!isExpired(videoAd.expiration)) {
                    Log.i(MMAdViewSDK.SDKLOG, "Ad is valid. Saving new ad settings.");
                    adFailed(adView);
                    adIsCaching(adView);
                    this.cacheHandler.post(new Runnable() {
                        /* class com.millennialmedia.android.MMAdViewController.AnonymousClass3 */

                        public void run() {
                            new DownloadAdTask().execute(videoAd);
                        }
                    });
                    return;
                }
                Log.i(MMAdViewSDK.SDKLOG, "New ad has expiration date in the past. Not downloading ad content. Remove any expired content from the filesystem.");
                deleteAd(videoAd.id, adView);
                adFailed(adView);
            } else if (!checkIfExpired(videoAd.id, adView)) {
                Log.i(MMAdViewSDK.SDKLOG, "Cached ad is valid. Show.");
                HandShake.sharedHandShake(adView.getContext()).updateLastVideoViewedTime(adView.getContext(), adView.adType);
                adSuccess(adView);
                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return success");
                playVideo(videoAd.id, adView);
            } else {
                Log.i(MMAdViewSDK.SDKLOG, "Ad returned exists in db & filesystem but is expired. Deleting.");
                adFailed(adView);
                deleteAd(videoAd.id, adView);
            }
        } else if (checkIfAdExistsInFilesystem(videoAd.id, adView)) {
            Log.i(MMAdViewSDK.SDKLOG, "Ad received exists in filesystem but not database. Running checks . . .");
            String lastAdName = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).getString("lastDownloadedAdName", null);
            Log.i(MMAdViewSDK.SDKLOG, "Last ad name: " + lastAdName);
            if (lastAdName != null) {
                deleteAd(lastAdName, adView);
            }
            adFailed(adView);
        } else if (!isExpired(videoAd.expiration)) {
            Log.i(MMAdViewSDK.SDKLOG, "Ad is valid. Saving new ad settings. Download TRUE.");
            writeAdDataToSettings(videoAd, adView);
            adFailed(adView);
            adIsCaching(adView);
            this.cacheHandler.post(new Runnable() {
                /* class com.millennialmedia.android.MMAdViewController.AnonymousClass2 */

                public void run() {
                    new DownloadAdTask().execute(videoAd);
                }
            });
        } else {
            Log.i(MMAdViewSDK.SDKLOG, "New ad has expiration date in the past. Not downloading ad content.");
            adFailed(adView);
        }
    }

    /* access modifiers changed from: package-private */
    public void handleClick(String url) {
        this.urlString = url;
        new Thread() {
            /* class com.millennialmedia.android.MMAdViewController.AnonymousClass4 */

            public void run() {
                int rc;
                String mimeTypeString = null;
                MMAdViewSDK.Log.d("Touch occured, opening ad...");
                if (MMAdViewController.this.urlString != null) {
                    String locationString = MMAdViewController.this.urlString;
                    MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
                    if (adView == null) {
                        Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                        return;
                    }
                    Activity activity = (Activity) adView.getContext();
                    if (activity == null) {
                        Log.e(MMAdViewSDK.SDKLOG, "The ad view does not have a parent activity.");
                        return;
                    }
                    do {
                        try {
                            URL connectURL = new URL(MMAdViewController.this.urlString);
                            HttpURLConnection.setFollowRedirects(false);
                            HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();
                            conn.setRequestMethod("GET");
                            conn.connect();
                            MMAdViewController.this.urlString = conn.getHeaderField("Location");
                            mimeTypeString = conn.getHeaderField("Content-Type");
                            rc = conn.getResponseCode();
                            MMAdViewSDK.Log.d("Response: " + conn.getResponseCode() + " " + conn.getResponseMessage());
                            MMAdViewSDK.Log.d("urlString: " + MMAdViewController.this.urlString);
                            if (rc < 300) {
                                break;
                            }
                        } catch (IOException | MalformedURLException e) {
                        }
                    } while (rc < 400);
                    MMAdViewSDK.Log.d(locationString);
                    if (locationString != null) {
                        if (mimeTypeString == null) {
                            mimeTypeString = ASConstants.kEmptyString;
                        }
                        Uri destinationURI = Uri.parse(locationString);
                        if (destinationURI != null && destinationURI.getScheme() != null && mimeTypeString != null) {
                            if ((destinationURI.getScheme().equalsIgnoreCase("http") || destinationURI.getScheme().equalsIgnoreCase("https")) && mimeTypeString.equalsIgnoreCase("text/html")) {
                                Intent intent = new Intent(activity, MMAdViewOverlayActivity.class);
                                intent.setFlags(603979776);
                                intent.putExtra("canAccelerate", MMAdViewController.this.canAccelerate);
                                intent.putExtra("overlayTransition", MMAdViewController.this.overlayTransition);
                                intent.putExtra("transitionTime", MMAdViewController.this.transitionTime);
                                intent.putExtra("shouldResizeOverlay", MMAdViewController.this.shouldResizeOverlay);
                                intent.putExtra("shouldShowTitlebar", MMAdViewController.this.shouldShowTitlebar);
                                intent.putExtra("shouldShowBottomBar", MMAdViewController.this.shouldShowBottomBar);
                                intent.putExtra("shouldEnableBottomBar", MMAdViewController.this.shouldEnableBottomBar);
                                intent.putExtra("shouldMakeOverlayTransparent", MMAdViewController.this.shouldMakeOverlayTransparent);
                                intent.putExtra("overlayTitle", MMAdViewController.this.overlayTitle);
                                MMAdViewSDK.Log.v("Accelerometer on?: " + MMAdViewController.this.canAccelerate);
                                intent.setData(destinationURI);
                                activity.startActivityForResult(intent, 0);
                            } else if (destinationURI.getScheme().equalsIgnoreCase("market")) {
                                MMAdViewSDK.Log.v("Android Market URL, launch the Market Application");
                                Intent intent2 = new Intent("android.intent.action.VIEW", destinationURI);
                                intent2.setFlags(603979776);
                                activity.startActivity(intent2);
                            } else if (destinationURI.getScheme().equalsIgnoreCase("rtsp") || (destinationURI.getScheme().equalsIgnoreCase("http") && (mimeTypeString.equalsIgnoreCase("video/mp4") || mimeTypeString.equalsIgnoreCase("video/3gpp")))) {
                                MMAdViewSDK.Log.v("Video, launch the video player for video at: " + destinationURI);
                                Intent intent3 = new Intent(activity, VideoPlayer.class);
                                intent3.setFlags(603979776);
                                intent3.setData(destinationURI);
                                activity.startActivityForResult(intent3, 0);
                            } else if (destinationURI.getScheme().equalsIgnoreCase("tel")) {
                                MMAdViewSDK.Log.v("Telephone Number, launch the phone");
                                Intent intent4 = new Intent("android.intent.action.DIAL", destinationURI);
                                intent4.setFlags(603979776);
                                activity.startActivity(intent4);
                            } else if (destinationURI.getScheme().equalsIgnoreCase("geo")) {
                                MMAdViewSDK.Log.v("Google Maps");
                                Intent intent5 = new Intent("android.intent.action.VIEW", destinationURI);
                                intent5.setFlags(603979776);
                                activity.startActivity(intent5);
                            } else if (!destinationURI.getScheme().equalsIgnoreCase("http") || destinationURI.getLastPathSegment() == null) {
                                if (destinationURI.getScheme().equalsIgnoreCase("http")) {
                                    Intent intent6 = new Intent(activity, MMAdViewOverlayActivity.class);
                                    intent6.setFlags(603979776);
                                    intent6.putExtra("canAccelerate", MMAdViewController.this.canAccelerate);
                                    intent6.putExtra("overlayTransition", MMAdViewController.this.overlayTransition);
                                    intent6.putExtra("transitionTime", MMAdViewController.this.transitionTime);
                                    intent6.putExtra("shouldResizeOverlay", MMAdViewController.this.shouldResizeOverlay);
                                    intent6.putExtra("shouldShowTitlebar", MMAdViewController.this.shouldShowTitlebar);
                                    intent6.putExtra("shouldShowBottomBar", MMAdViewController.this.shouldShowBottomBar);
                                    intent6.putExtra("shouldEnableBottomBar", MMAdViewController.this.shouldEnableBottomBar);
                                    intent6.putExtra("shouldMakeOverlayTransparent", MMAdViewController.this.shouldMakeOverlayTransparent);
                                    intent6.putExtra("overlayTitle", MMAdViewController.this.overlayTitle);
                                    MMAdViewSDK.Log.v("Accelerometer on?: " + MMAdViewController.this.canAccelerate);
                                    intent6.setData(destinationURI);
                                    activity.startActivityForResult(intent6, 0);
                                    return;
                                }
                                Intent intent7 = new Intent("android.intent.action.VIEW", destinationURI);
                                intent7.setFlags(603979776);
                                activity.startActivity(intent7);
                            } else if (destinationURI.getLastPathSegment().endsWith(".mp4") || destinationURI.getLastPathSegment().endsWith(".3gp")) {
                                MMAdViewSDK.Log.v("Video, launch the video player for video at: " + destinationURI);
                                Intent intent8 = new Intent(activity, VideoPlayer.class);
                                intent8.setFlags(603979776);
                                intent8.setData(destinationURI);
                                activity.startActivityForResult(intent8, 0);
                            } else {
                                Intent intent9 = new Intent(activity, MMAdViewOverlayActivity.class);
                                intent9.setFlags(603979776);
                                intent9.putExtra("canAccelerate", MMAdViewController.this.canAccelerate);
                                intent9.putExtra("overlayTransition", MMAdViewController.this.overlayTransition);
                                intent9.putExtra("transitionTime", MMAdViewController.this.transitionTime);
                                intent9.putExtra("shouldResizeOverlay", MMAdViewController.this.shouldResizeOverlay);
                                intent9.putExtra("shouldShowTitlebar", MMAdViewController.this.shouldShowTitlebar);
                                intent9.putExtra("shouldShowBottomBar", MMAdViewController.this.shouldShowBottomBar);
                                intent9.putExtra("shouldEnableBottomBar", MMAdViewController.this.shouldEnableBottomBar);
                                intent9.putExtra("shouldMakeOverlayTransparent", MMAdViewController.this.shouldMakeOverlayTransparent);
                                intent9.putExtra("overlayTitle", MMAdViewController.this.overlayTitle);
                                MMAdViewSDK.Log.v("Accelerometer on?: " + MMAdViewController.this.canAccelerate);
                                intent9.setData(destinationURI);
                                activity.startActivityForResult(intent9, 0);
                            }
                        }
                    }
                }
            }
        }.start();
    }

    /* access modifiers changed from: package-private */
    public void pauseTimer(boolean appRequested) {
        synchronized (this) {
            if (this.refreshTimerOn) {
                if (this.paused) {
                    if (appRequested) {
                        this.appPaused = true;
                    }
                    return;
                }
                this.handler.removeCallbacks(this.runnable);
                this.timeRemaining = SystemClock.uptimeMillis() - this.timeResumed;
                this.paused = true;
                this.appPaused = appRequested;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public void resumeTimer(boolean appRequested) {
        synchronized (this) {
            if (this.refreshTimerOn) {
                if (this.paused) {
                    if (!this.appPaused || appRequested) {
                        MMAdView adView = this.adViewRef.get();
                        if (adView == null) {
                            Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                            return;
                        }
                        if (this.handler == null) {
                            this.handler = new Handler();
                        }
                        if (this.timeRemaining <= 0 || this.timeRemaining > ((long) (adView.refreshInterval * 1000))) {
                            this.timeRemaining = (long) (adView.refreshInterval * 1000);
                        }
                        this.handler.postDelayed(this.runnable, this.timeRemaining);
                        this.timeResumed = SystemClock.uptimeMillis();
                        this.appPaused = false;
                        this.paused = false;
                    }
                }
            }
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private String getURLMetaValues(MMAdView adView) throws UnsupportedEncodingException {
        StringBuilder metaString = new StringBuilder();
        Locale locale = Locale.getDefault();
        if (locale != null) {
            metaString.append("&language=" + locale.getLanguage());
            metaString.append("&country=" + locale.getCountry());
        }
        if (adView.age != null) {
            metaString.append("&age=" + URLEncoder.encode(adView.age, "UTF-8"));
        }
        if (adView.gender != null) {
            metaString.append("&gender=" + URLEncoder.encode(adView.gender, "UTF-8"));
        }
        if (adView.zip != null) {
            metaString.append("&zip=" + URLEncoder.encode(adView.zip, "UTF-8"));
        }
        if (adView.marital != null && (adView.marital.equals("single") || adView.marital.equals("married") || adView.marital.equals("divorced") || adView.marital.equals("swinger") || adView.marital.equals("relationship") || adView.marital.equals("engaged"))) {
            metaString.append("&marital=" + adView.marital);
        }
        if (adView.income != null) {
            metaString.append("&income=" + URLEncoder.encode(adView.income, "UTF-8"));
        }
        if (adView.keywords != null) {
            metaString.append("&kw=" + URLEncoder.encode(adView.keywords, "UTF-8"));
        }
        if (adView.latitude != null) {
            metaString.append("&lat=" + URLEncoder.encode(adView.latitude, "UTF-8"));
        }
        if (adView.longitude != null) {
            metaString.append("&long=" + URLEncoder.encode(adView.longitude, "UTF-8"));
        }
        if (adView.acid != null) {
            metaString.append("&acid=" + URLEncoder.encode(adView.acid, "UTF-8"));
        }
        if (adView.mxsdk != null) {
            metaString.append("&mxsdk=" + URLEncoder.encode(adView.mxsdk, "UTF-8"));
        }
        if (adView.height != null) {
            metaString.append("&hsht=" + URLEncoder.encode(adView.height, "UTF-8"));
        }
        if (adView.width != null) {
            metaString.append("&hswd=" + URLEncoder.encode(adView.width, "UTF-8"));
        }
        if (adView.ethnicity != null) {
            metaString.append("&ethnicity=" + URLEncoder.encode(adView.ethnicity, "UTF-8"));
        }
        if (adView.orientation != null && (adView.orientation.equals("straight") || adView.orientation.equals("gay") || adView.orientation.equals("bisexual") || adView.orientation.equals("notsure"))) {
            metaString.append("&orientation=" + adView.orientation);
        }
        if (adView.education != null) {
            metaString.append("&edu=" + URLEncoder.encode(adView.education, "UTF-8"));
        }
        if (adView.children != null) {
            metaString.append("&children=" + URLEncoder.encode(adView.children, "UTF-8"));
        }
        if (adView.politics != null) {
            metaString.append("&politics=" + URLEncoder.encode(adView.politics, "UTF-8"));
        }
        if (adView.vendor != null) {
            metaString.append("&vendor=" + URLEncoder.encode(adView.vendor, "UTF-8"));
        }
        if (metaString != null) {
            return metaString.toString();
        }
        return ASConstants.kEmptyString;
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private String getAdType(String adtype) {
        if (adtype != null) {
            if (adtype.equals(MMAdView.BANNER_AD_TOP)) {
                return "&adtype=" + MMAdView.BANNER_AD_TOP;
            }
            if (adtype.equals(MMAdView.BANNER_AD_BOTTOM)) {
                return "&adtype=" + MMAdView.BANNER_AD_BOTTOM;
            }
            if (adtype.equals(MMAdView.BANNER_AD_RECTANGLE)) {
                return "&adtype=" + MMAdView.BANNER_AD_RECTANGLE;
            }
            if (adtype.equals(MMAdView.FULLSCREEN_AD_LAUNCH)) {
                return "&adtype=" + MMAdView.FULLSCREEN_AD_LAUNCH;
            }
            if (adtype.equals(MMAdView.FULLSCREEN_AD_TRANSITION)) {
                return "&adtype=" + MMAdView.FULLSCREEN_AD_TRANSITION;
            }
        }
        Log.e(MMAdViewSDK.SDKLOG, "******* ERROR: INCORRECT AD TYPE IN MMADVIEW OBJECT PARAMETERS (" + adtype + ") **********");
        Log.e(MMAdViewSDK.SDKLOG, "******* SDK DEFAULTED TO MMBannerAdTop. THIS MAY AFFECT THE ADS YOU RECIEVE!!! **********");
        return "&adtype=" + MMAdView.BANNER_AD_TOP;
    }

    private class DownloadAdTask extends AsyncTask<VideoAd, Void, String> {
        DownloadAdTask() {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
            } else {
                HandShake.sharedHandShake(adView.getContext()).lockAdTypeDownload(adView.adType);
            }
        }

        /* access modifiers changed from: protected */
        public void onPreExecute() {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return;
            }
            MMAdViewSDK.Log.v("DownloadAdTask onPreExecute");
            SharedPreferences.Editor editor = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
            editor.putBoolean("pendingDownload", true);
            editor.commit();
            MMAdViewSDK.Log.v("Setting pendingDownload to TRUE");
        }

        /* access modifiers changed from: protected */
        public String doInBackground(VideoAd... ad) {
            File cacheDir;
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return null;
            } else if (ad == null || ad.length == 0) {
                return null;
            } else {
                if (!ad[0].storedOnSdCard) {
                    cacheDir = adView.getContext().getCacheDir();
                } else if (Environment.getExternalStorageState().equals("mounted")) {
                    File millennialMediaDir = new File(Environment.getExternalStorageDirectory(), "millennialmedia");
                    if (millennialMediaDir.exists()) {
                        cacheDir = millennialMediaDir;
                    } else if (millennialMediaDir.mkdirs()) {
                        cacheDir = millennialMediaDir;
                    } else {
                        cacheDir = adView.getContext().getCacheDir();
                        try {
                            AdDatabaseHelper db = new AdDatabaseHelper(adView.getContext());
                            db.updateAdOnSDCard(ad[0].id, 0);
                            db.close();
                        } catch (SQLiteException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    cacheDir = adView.getContext().getCacheDir();
                    try {
                        AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
                        db2.updateAdOnSDCard(ad[0].id, 0);
                        db2.close();
                    } catch (SQLiteException e2) {
                        e2.printStackTrace();
                    }
                }
                String newAdDirPath = cacheDir + "/" + ad[0].id + "/";
                new File(newAdDirPath).mkdir();
                MMAdViewSDK.Log.v("Downloading content to " + newAdDirPath.toString());
                if (!MMAdViewController.this.downloadComponent(ad[0].contentUrl, "video.dat", newAdDirPath)) {
                    SharedPreferences.Editor editor = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
                    editor.putBoolean("pendingDownload", true);
                    editor.commit();
                    return ad[0].id;
                }
                for (int i = 0; i < ad[0].buttons.size(); i++) {
                    String imageUrl = ad[0].buttons.get(i).imageUrl;
                    if (!MMAdViewController.this.downloadComponent(imageUrl, Uri.parse(imageUrl).getLastPathSegment().replaceFirst("\\.[^\\.]*$", ".dat"), newAdDirPath)) {
                        SharedPreferences.Editor editor2 = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
                        editor2.putBoolean("pendingDownload", true);
                        editor2.commit();
                        return ad[0].id;
                    }
                }
                SharedPreferences.Editor editor22 = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
                editor22.putBoolean("pendingDownload", false);
                editor22.commit();
                return ad[0].id;
            }
        }

        /* access modifiers changed from: protected */
        public void onProgressUpdate() {
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(String adName) {
            boolean success;
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return;
            }
            SharedPreferences settings = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0);
            SharedPreferences.Editor editor = settings.edit();
            if (adName != null) {
                editor.putString("lastDownloadedAdName", adName);
                MMAdViewSDK.Log.v("Download complete. LastDownloadedAdName: " + adName);
                if (settings.getBoolean("pendingDownload", true)) {
                    success = false;
                } else {
                    success = true;
                }
            } else {
                editor.putString("lastDownloadedAdName", null);
                success = false;
            }
            HandShake.sharedHandShake(adView.getContext()).unlockAdTypeDownload(adView.adType);
            if (success) {
                editor.putInt("downloadAttempts", 0);
                MMAdViewSDK.Log.d("Ad download completed successfully: TRUE");
                editor.putBoolean("lastAdViewed", false);
                MMAdViewSDK.Log.v("Last ad viewed: FALSE");
            } else {
                editor.putInt("downloadAttempts", settings.getInt("downloadAttempts", 0) + 1);
                MMAdViewSDK.Log.d("Ad download completed successfully: FALSE");
            }
            editor.commit();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0080, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0081, code lost:
        r5.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x00cd, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x00ce, code lost:
        r5.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x00d2, code lost:
        r6 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x00d3, code lost:
        android.util.Log.e(com.millennialmedia.android.MMAdViewSDK.SDKLOG, "Content caching error: " + r6.getMessage(), r6);
        r7.delete();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00fc, code lost:
        r5 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00fd, code lost:
        r5.printStackTrace();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:?, code lost:
        return false;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0080 A[ExcHandler: MalformedURLException (r5v3 'e' java.net.MalformedURLException A[CUSTOM_DECLARE]), Splitter:B:1:0x001a] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x00cd A[ExcHandler: FileNotFoundException (r5v2 'e' java.io.FileNotFoundException A[CUSTOM_DECLARE]), Splitter:B:1:0x001a] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00fc A[ExcHandler: IllegalStateException (r5v1 'e' java.lang.IllegalStateException A[CUSTOM_DECLARE]), Splitter:B:1:0x001a] */
    private boolean downloadComponent(String urlString2, String name, String path) {
        File file = new File(path + name);
        try {
            if (MMAdViewSDK.connectivityManager.getActiveNetworkInfo() == null || !MMAdViewSDK.connectivityManager.getActiveNetworkInfo().isConnected()) {
                Log.e(MMAdViewSDK.SDKLOG, "Not connected to the internet");
                file.delete();
                return false;
            }
            MMAdViewSDK.Log.v("Downloading Component: " + name + " from " + urlString2);
            URL connectURL = new URL(urlString2);
            HttpURLConnection.setFollowRedirects(false);
            HttpURLConnection conn = (HttpURLConnection) connectURL.openConnection();
            conn.setRequestMethod("GET");
            conn.connect();
            InputStream stream = conn.getInputStream();
            String fileSize = conn.getHeaderField("Content-Length");
            if (stream == null) {
                throw new IOException("Stream is null");
            }
            FileOutputStream out = new FileOutputStream(path + name);
            byte[] buf = new byte[1024];
            while (true) {
                int numread = stream.read(buf);
                if (numread <= 0) {
                    break;
                }
                out.write(buf, 0, numread);
            }
            stream.close();
            out.close();
            if (file != null) {
                try {
                    if (file.length() == new Long(fileSize).longValue()) {
                        return true;
                    }
                } catch (Exception e) {
                }
            }
            file.delete();
            return false;
        } catch (MalformedURLException e2) {
        } catch (FileNotFoundException e3) {
        } catch (IllegalStateException e4) {
        } catch (IOException e5) {
            e5.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void adFailed(MMAdView adView) {
        if (adView != null && adView.listener != null) {
            try {
                adView.listener.MMAdFailed(adView);
            } catch (Exception e) {
                Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
            }
        }
    }

    private void adSuccess(MMAdView adView) {
        if (adView != null && adView.listener != null) {
            try {
                adView.listener.MMAdReturned(adView);
            } catch (Exception e) {
                Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
            }
        }
    }

    private void adIsCaching(MMAdView adView) {
        if (adView != null && adView.listener != null) {
            try {
                adView.listener.MMAdRequestIsCaching(adView);
            } catch (Exception e) {
                Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
            }
        }
    }

    private void cleanUpExpiredAds(MMAdView adView) {
        try {
            AdDatabaseHelper db = new AdDatabaseHelper(adView.getContext());
            List<String> expiredAds = db.getAllExpiredAds();
            db.close();
            if (expiredAds != null && expiredAds.size() > 0) {
                MMAdViewSDK.Log.v("Some ads are expired");
                for (int i = 0; i < expiredAds.size(); i++) {
                    deleteAd(expiredAds.get(i), adView);
                }
            }
        } catch (SQLiteException e) {
            e.printStackTrace();
        }
    }

    public boolean freeMemoryOnDisk(MMAdView adView) {
        try {
            if (Environment.getExternalStorageState().equals("mounted")) {
                File sdCardFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "millennialmedia");
                if (sdCardFile.exists()) {
                    return sdCardFile.length() < 12582912;
                }
            }
            File cacheDir = adView.getContext().getCacheDir();
            if (cacheDir != null) {
                long usedMem = cacheDir.length();
                Log.i(MMAdViewSDK.SDKLOG, "Cache: " + usedMem);
                return usedMem < 12582912;
            }
        } catch (Exception e) {
        }
        return false;
    }

    public boolean checkForAdNotDownloaded(MMAdView adView) {
        adView.getContext();
        SharedPreferences settings = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0);
        boolean downloaded = settings.getBoolean("pendingDownload", false);
        MMAdViewSDK.Log.v("Pending download?: " + downloaded);
        if (settings.getInt("downloadAttempts", 0) < 3) {
            return downloaded;
        }
        MMAdViewSDK.Log.v("Cached ad download failed too many times. Purging it from the database.");
        deleteAd(settings.getString("lastDownloadedAdName", null), adView);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("downloadAttempts", 0);
        editor.commit();
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x0090  */
    public boolean checkIfAdExistsInFilesystem(String name, MMAdView adView) {
        SQLiteException e;
        File adDir;
        String[] list;
        boolean existsInFilesystem = false;
        AdDatabaseHelper db = null;
        try {
            AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
            try {
                int fileCount = db2.getButtonCountForAd(name);
                boolean onSDCard = db2.isAdOnSDCard(name);
                db2.close();
                if (!onSDCard || !Environment.getExternalStorageState().equals("mounted")) {
                    adDir = new File(adView.getContext().getCacheDir() + "/" + name);
                } else {
                    adDir = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "millennialmedia" + "/" + name);
                }
                if (adDir.exists() && (list = adDir.list()) != null && list.length >= fileCount) {
                    existsInFilesystem = true;
                }
                MMAdViewSDK.Log.v("Last ad " + name + " in filesystem?: " + existsInFilesystem);
                return existsInFilesystem;
            } catch (SQLiteException e2) {
                e = e2;
                db = db2;
                e.printStackTrace();
                if (db != null) {
                }
                MMAdViewSDK.Log.v("SQL check error. Ad filesys check cannot be completed.");
                return false;
            }
        } catch (SQLiteException e3) {
            e = e3;
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            MMAdViewSDK.Log.v("SQL check error. Ad filesys check cannot be completed.");
            return false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0043  */
    public boolean checkIfAdExistsInDb(String name, MMAdView adView) {
        Throwable th;
        SQLiteException e;
        AdDatabaseHelper db = null;
        boolean existsInDb = false;
        try {
            AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
            try {
                existsInDb = db2.checkIfAdExists(name);
                MMAdViewSDK.Log.v("Last ad " + name + " in database?: " + existsInDb);
                if (db2 != null) {
                    db2.close();
                }
            } catch (SQLiteException e2) {
                e = e2;
                db = db2;
                try {
                    e.printStackTrace();
                    if (db != null) {
                    }
                    return existsInDb;
                } catch (Throwable th2) {
                    th = th2;
                    if (db != null) {
                        db.close();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                db = db2;
                if (db != null) {
                }
                throw th;
            }
        } catch (SQLiteException e3) {
            e = e3;
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            return existsInDb;
        }
        return existsInDb;
    }

    public void DownloadLastAd(MMAdView adView) {
        String lastAdName = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).getString("lastDownloadedAdName", null);
        final VideoAd ad = null;
        MMAdViewSDK.Log.v("Downloading last ad: " + lastAdName);
        try {
            AdDatabaseHelper db = new AdDatabaseHelper(adView.getContext());
            ad = db.getVideoAd(lastAdName);
            db.close();
        } catch (SQLiteException e) {
            e.printStackTrace();
        }
        adFailed(adView);
        if (ad != null) {
            adIsCaching(adView);
            Log.i(MMAdViewSDK.SDKLOG, "Millennial restarting or finishing caching ad.");
            this.cacheHandler.post(new Runnable() {
                /* class com.millennialmedia.android.MMAdViewController.AnonymousClass6 */

                public void run() {
                    new DownloadAdTask().execute(ad);
                }
            });
            return;
        }
        MMAdViewSDK.Log.d("Can't find last ad in database, calling for new ad");
        getNextAd();
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0020  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0027  */
    private boolean checkIfExpired(String adName, MMAdView adView) {
        Throwable th;
        SQLiteException e;
        Date exp = null;
        AdDatabaseHelper db = null;
        try {
            AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
            try {
                exp = db2.getExpiration(adName);
                if (db2 != null) {
                    db2.close();
                }
            } catch (SQLiteException e2) {
                e = e2;
                db = db2;
                try {
                    e.printStackTrace();
                    if (db != null) {
                    }
                    return isExpired(exp);
                } catch (Throwable th2) {
                    th = th2;
                    if (db != null) {
                        db.close();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                db = db2;
                if (db != null) {
                }
                throw th;
            }
        } catch (SQLiteException e3) {
            e = e3;
            e.printStackTrace();
            if (db != null) {
                db.close();
            }
            return isExpired(exp);
        }
        return isExpired(exp);
    }

    private boolean isExpired(Date date) {
        if (date == null || date.getTime() > System.currentTimeMillis()) {
            return false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x001f  */
    /* JADX WARNING: Removed duplicated region for block: B:14:0x0026  */
    /* JADX WARNING: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    private void writeAdDataToSettings(VideoAd ad, MMAdView adView) {
        Throwable th;
        SQLiteException e;
        MMAdViewSDK.Log.d("Storing ad data in db");
        AdDatabaseHelper db = null;
        try {
            AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
            try {
                db2.storeAd(ad);
                if (db2 != null) {
                    db2.close();
                }
            } catch (SQLiteException e2) {
                e = e2;
                db = db2;
                try {
                    e.printStackTrace();
                    if (db == null) {
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (db != null) {
                        db.close();
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                db = db2;
                if (db != null) {
                }
                throw th;
            }
        } catch (SQLiteException e3) {
            e = e3;
            e.printStackTrace();
            if (db == null) {
                db.close();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:24:0x00df  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    public void playVideo(String name, MMAdView adView) {
        Throwable th;
        SQLiteException e;
        if (name != null) {
            SharedPreferences.Editor editor = adView.getContext().getSharedPreferences("MillennialMediaSettings", 0).edit();
            editor.putBoolean("lastAdViewed", true);
            editor.commit();
            if (adView.listener != null) {
                try {
                    adView.listener.MMAdOverlayLaunched(adView);
                } catch (Exception e2) {
                    Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e2);
                }
            }
            MMAdViewSDK.Log.d("Launch Video Player. Playing " + name);
            Intent intent = new Intent().setClass(adView.getContext(), VideoPlayer.class);
            intent.setFlags(603979776);
            intent.putExtra("cached", true);
            intent.putExtra("adName", name);
            AdDatabaseHelper db = null;
            try {
                AdDatabaseHelper db2 = new AdDatabaseHelper(adView.getContext());
                try {
                    boolean onSDCard = db2.isAdOnSDCard(name);
                    if (db2 != null) {
                        db2.close();
                    }
                    if (!onSDCard || !Environment.getExternalStorageState().equals("mounted")) {
                        intent.setData(Uri.parse(name));
                    } else {
                        intent.setData(Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "millennialmedia" + "/" + name + "/video.dat"));
                    }
                    adView.getContext().startActivity(intent);
                } catch (SQLiteException e3) {
                    e = e3;
                    db = db2;
                    try {
                        e.printStackTrace();
                        MMAdViewSDK.Log.d("A database error prevented us from playing the video: " + name);
                        if (db == null) {
                            db.close();
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        if (db != null) {
                            db.close();
                        }
                        throw th;
                    }
                } catch (Throwable th3) {
                    th = th3;
                    db = db2;
                    if (db != null) {
                    }
                    throw th;
                }
            } catch (SQLiteException e4) {
                e = e4;
                e.printStackTrace();
                MMAdViewSDK.Log.d("A database error prevented us from playing the video: " + name);
                if (db == null) {
                }
            }
        }
    }

    private void deleteAd(String adName, MMAdView adView) {
        if (adName != null) {
            if (Environment.getExternalStorageState().equals("mounted")) {
                File sdCardAd = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "millennialmedia" + "/" + adName);
                if (sdCardAd.exists()) {
                    File[] files = sdCardAd.listFiles();
                    MMAdViewSDK.Log.v("Ad directory size: " + files.length);
                    for (File file : files) {
                        file.delete();
                    }
                    sdCardAd.delete();
                    MMAdViewSDK.Log.v(adName + " directory deleted");
                }
            }
            File cacheDirAd = new File(adView.getContext().getCacheDir() + "/" + adName);
            if (cacheDirAd.exists()) {
                File[] files2 = cacheDirAd.listFiles();
                MMAdViewSDK.Log.v("Ad directory size: " + files2.length);
                for (File file2 : files2) {
                    file2.delete();
                }
                cacheDirAd.delete();
                MMAdViewSDK.Log.v(adName + " directory deleted");
            }
            AdDatabaseHelper db = new AdDatabaseHelper(adView.getContext());
            boolean purged = db.purgeAdFromDb(adName);
            db.close();
            MMAdViewSDK.Log.v("Ad deleted from database: " + adName + " with succuess? " + purged);
        }
    }

    private class MMJSInterface {
        private MMJSInterface() {
        }

        public void setLoaded(boolean success) {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return;
            }
            if (adView.listener != null) {
                if (success) {
                    try {
                        adView.listener.MMAdReturned(adView);
                    } catch (Exception e) {
                        Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
                    }
                } else {
                    try {
                        adView.listener.MMAdFailed(adView);
                    } catch (Exception e2) {
                        Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e2);
                    }
                }
            }
            if (success) {
                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return success");
            } else {
                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed");
            }
        }

        public void countImages(String size) {
            int num;
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return;
            }
            MMAdViewSDK.Log.d("size: " + size);
            if (size != null) {
                num = new Integer(size).intValue();
            } else {
                num = 0;
                Log.e(MMAdViewSDK.SDKLOG, "Image count is null");
            }
            MMAdViewSDK.Log.d("num: " + num);
            if (num > 0) {
                if (adView.listener != null) {
                    try {
                        adView.listener.MMAdReturned(adView);
                    } catch (Exception e) {
                        Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
                    }
                }
                Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return success");
                MMAdViewSDK.Log.v("View height: " + adView.getHeight());
                return;
            }
            if (adView.listener != null) {
                try {
                    adView.listener.MMAdFailed(adView);
                } catch (Exception e2) {
                    Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e2);
                }
            }
            Log.i(MMAdViewSDK.SDKLOG, "Millennial ad return failed");
        }

        public void getUrl(String url) {
            MMAdViewController.this.nextUrl = url;
            MMAdViewSDK.Log.v("nextUrl: " + MMAdViewController.this.nextUrl);
        }

        public void shouldOpen(String url) {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                Log.e(MMAdViewSDK.SDKLOG, "The reference to the ad view was broken.");
                return;
            }
            MMAdViewController.this.shouldLaunchToOverlay = true;
            MMAdViewController.this.handleClick(url);
            if (adView.listener != null) {
                try {
                    adView.listener.MMAdOverlayLaunched(adView);
                } catch (Exception e) {
                    Log.w(MMAdViewSDK.SDKLOG, "Exception raised in your MMAdListener: ", e);
                }
            }
        }

        public void shouldOverlay(boolean shouldOverlay) {
            MMAdViewController.this.shouldLaunchToOverlay = shouldOverlay;
        }

        public void overlayTitle(String title) {
            MMAdViewController.this.overlayTitle = title;
        }

        public void overlayTransition(String transition, long time) {
            MMAdViewController.this.overlayTransition = transition;
            MMAdViewController.this.transitionTime = time;
        }

        public void shouldAccelerate(boolean shouldAccelerate) {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView == null) {
                return;
            }
            if (adView.accelerate) {
                MMAdViewController.this.canAccelerate = shouldAccelerate;
            } else {
                MMAdViewController.this.canAccelerate = false;
            }
        }

        public void shouldResizeOverlay(int padding) {
            MMAdViewController.this.shouldResizeOverlay = padding;
        }

        public void shouldShowTitlebar(boolean showTitlebar) {
            MMAdViewController.this.shouldShowTitlebar = showTitlebar;
        }

        public void shouldShowBottomBar(boolean showBottomBar) {
            MMAdViewController.this.shouldShowBottomBar = showBottomBar;
        }

        public void shouldEnableBottomBar(boolean enableBottomBar) {
            MMAdViewController.this.shouldEnableBottomBar = enableBottomBar;
        }

        public void shouldMakeOverlayTransparent(boolean isTransparent) {
            MMAdViewController.this.shouldMakeOverlayTransparent = isTransparent;
        }

        public void log(String message) {
            MMAdViewSDK.Log.d(message);
        }

        public void vibrate(int time) {
            MMAdView adView = (MMAdView) MMAdViewController.this.adViewRef.get();
            if (adView != null && adView.vibrate) {
                Activity activity = (Activity) adView.getContext();
                if (activity.getPackageManager().checkPermission("android.permission.VIBRATE", activity.getPackageName()) == 0) {
                    ((Vibrator) activity.getSystemService("vibrator")).vibrate((long) time);
                } else {
                    Log.w(MMAdViewSDK.SDKLOG, "Advertisement is trying to use vibrator but permissions are missing.");
                }
            }
        }
    }
}
