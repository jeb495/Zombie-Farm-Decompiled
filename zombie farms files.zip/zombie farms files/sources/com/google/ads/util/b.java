package com.google.ads.util;

import com.flurry.android.Constants;
import java.io.UnsupportedEncodingException;

public class b {
    static final /* synthetic */ boolean a = (!b.class.desiredAssertionStatus());

    public static abstract class a {
        public byte[] a;
        public int b;
    }

    /* renamed from: com.google.ads.util.b$b  reason: collision with other inner class name */
    public static class C0000b extends a {
        static final /* synthetic */ boolean g = (!b.class.desiredAssertionStatus());
        private static final byte[] h = {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47};
        private static final byte[] i = {65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95};
        public int c = 0;
        public final boolean d = false;
        public final boolean e = false;
        public final boolean f = false;
        private final byte[] j = new byte[2];
        private int k;
        private final byte[] l = i;

        public C0000b() {
            this.a = null;
            this.k = this.e ? 19 : -1;
        }

        /* JADX INFO: Can't fix incorrect switch cases order, some code will duplicate */
        public final boolean a(byte[] bArr, int i2) {
            int i3;
            int i4;
            int i5;
            int i6;
            int i7;
            byte b;
            byte b2;
            int i8;
            byte b3;
            int i9;
            int i10;
            int i11 = 0;
            byte[] bArr2 = this.l;
            byte[] bArr3 = this.a;
            int i12 = this.k;
            int i13 = i2 + 0;
            switch (this.c) {
                case 0:
                    i3 = -1;
                    i4 = 0;
                    break;
                case 1:
                    if (2 <= i13) {
                        this.c = 0;
                        i3 = ((this.j[0] & Constants.UNKNOWN) << 16) | ((bArr[0] & Constants.UNKNOWN) << 8) | (bArr[1] & Constants.UNKNOWN);
                        i4 = 2;
                        break;
                    }
                    i3 = -1;
                    i4 = 0;
                    break;
                case 2:
                    if (i13 > 0) {
                        this.c = 0;
                        i3 = ((this.j[0] & Constants.UNKNOWN) << 16) | ((this.j[1] & Constants.UNKNOWN) << 8) | (bArr[0] & Constants.UNKNOWN);
                        i4 = 1;
                        break;
                    }
                    i3 = -1;
                    i4 = 0;
                    break;
                default:
                    i3 = -1;
                    i4 = 0;
                    break;
            }
            if (i3 != -1) {
                bArr3[0] = bArr2[(i3 >> 18) & 63];
                bArr3[1] = bArr2[(i3 >> 12) & 63];
                bArr3[2] = bArr2[(i3 >> 6) & 63];
                int i14 = 4;
                bArr3[3] = bArr2[i3 & 63];
                int i15 = i12 - 1;
                if (i15 == 0) {
                    if (this.f) {
                        i14 = 5;
                        bArr3[4] = 13;
                    }
                    i6 = i14 + 1;
                    bArr3[i14] = 10;
                    i5 = 19;
                } else {
                    i5 = i15;
                    i6 = 4;
                }
            } else {
                i5 = i12;
                i6 = 0;
            }
            while (i4 + 3 <= i13) {
                int i16 = ((bArr[i4] & Constants.UNKNOWN) << 16) | ((bArr[i4 + 1] & Constants.UNKNOWN) << 8) | (bArr[i4 + 2] & Constants.UNKNOWN);
                bArr3[i6] = bArr2[(i16 >> 18) & 63];
                bArr3[i6 + 1] = bArr2[(i16 >> 12) & 63];
                bArr3[i6 + 2] = bArr2[(i16 >> 6) & 63];
                bArr3[i6 + 3] = bArr2[i16 & 63];
                int i17 = i4 + 3;
                int i18 = i6 + 4;
                int i19 = i5 - 1;
                if (i19 == 0) {
                    if (this.f) {
                        i10 = i18 + 1;
                        bArr3[i18] = 13;
                    } else {
                        i10 = i18;
                    }
                    i6 = i10 + 1;
                    bArr3[i10] = 10;
                    i4 = i17;
                    i5 = 19;
                } else {
                    i5 = i19;
                    i6 = i18;
                    i4 = i17;
                }
            }
            if (i4 - this.c == i13 - 1) {
                if (this.c > 0) {
                    b3 = this.j[0];
                    i9 = 1;
                } else {
                    b3 = bArr[i4];
                    i4++;
                    i9 = 0;
                }
                int i20 = (b3 & Constants.UNKNOWN) << 4;
                this.c -= i9;
                int i21 = i6 + 1;
                bArr3[i6] = bArr2[(i20 >> 6) & 63];
                int i22 = i21 + 1;
                bArr3[i21] = bArr2[i20 & 63];
                if (this.d) {
                    int i23 = i22 + 1;
                    bArr3[i22] = 61;
                    i22 = i23 + 1;
                    bArr3[i23] = 61;
                }
                if (this.e) {
                    if (this.f) {
                        bArr3[i22] = 13;
                        i22++;
                    }
                    bArr3[i22] = 10;
                    i22++;
                }
                i6 = i22;
            } else if (i4 - this.c == i13 - 2) {
                if (this.c > 1) {
                    b = this.j[0];
                    i11 = 1;
                } else {
                    b = bArr[i4];
                    i4++;
                }
                int i24 = (b & Constants.UNKNOWN) << 10;
                if (this.c > 0) {
                    b2 = this.j[i11];
                    i11++;
                } else {
                    b2 = bArr[i4];
                    i4++;
                }
                int i25 = ((b2 & Constants.UNKNOWN) << 2) | i24;
                this.c -= i11;
                int i26 = i6 + 1;
                bArr3[i6] = bArr2[(i25 >> 12) & 63];
                int i27 = i26 + 1;
                bArr3[i26] = bArr2[(i25 >> 6) & 63];
                int i28 = i27 + 1;
                bArr3[i27] = bArr2[i25 & 63];
                if (this.d) {
                    i8 = i28 + 1;
                    bArr3[i28] = 61;
                } else {
                    i8 = i28;
                }
                if (this.e) {
                    if (this.f) {
                        bArr3[i8] = 13;
                        i8++;
                    }
                    bArr3[i8] = 10;
                    i8++;
                }
                i6 = i8;
            } else if (this.e && i6 > 0 && i5 != 19) {
                if (this.f) {
                    i7 = i6 + 1;
                    bArr3[i6] = 13;
                } else {
                    i7 = i6;
                }
                i6 = i7 + 1;
                bArr3[i7] = 10;
            }
            if (!g && this.c != 0) {
                throw new AssertionError();
            } else if (g || i4 == i13) {
                this.b = i6;
                this.k = i5;
                return true;
            } else {
                throw new AssertionError();
            }
        }
    }

    private b() {
    }

    public static String a(byte[] bArr) {
        int i;
        try {
            int length = bArr.length;
            C0000b bVar = new C0000b();
            int i2 = (length / 3) * 4;
            if (!bVar.d) {
                switch (length % 3) {
                    case 1:
                        i2 += 2;
                        break;
                    case 2:
                        i2 += 3;
                        break;
                }
            } else if (length % 3 > 0) {
                i2 += 4;
            }
            if (!bVar.e || length <= 0) {
                i = i2;
            } else {
                i = ((bVar.f ? 2 : 1) * (((length - 1) / 57) + 1)) + i2;
            }
            bVar.a = new byte[i];
            bVar.a(bArr, length);
            if (a || bVar.b == i) {
                return new String(bVar.a, "US-ASCII");
            }
            throw new AssertionError();
        } catch (UnsupportedEncodingException e) {
            throw new AssertionError(e);
        }
    }
}
