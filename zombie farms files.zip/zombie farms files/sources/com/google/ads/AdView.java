package com.google.ads;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.adsymp.core.ASConstants;
import com.google.ads.util.AdUtil;
import com.google.ads.util.a;

public class AdView extends RelativeLayout implements Ad {
    private d a;

    public AdView(Activity activity, AdSize adSize, String adUnitId) {
        super(activity.getApplicationContext());
        if (a(activity, adSize)) {
            a(activity, adSize, adUnitId);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d4  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0129  */
    public AdView(Context context, AttributeSet attrs) {
        super(context, attrs);
        AdSize adSize;
        String str;
        if (attrs != null) {
            String attributeValue = attrs.getAttributeValue("http://schemas.android.com/apk/lib/com.google.ads", "adSize");
            if (attributeValue == null) {
                a(context, "AdView missing required XML attribute \"adSize\".", AdSize.BANNER);
                return;
            }
            if ("BANNER".equals(attributeValue)) {
                adSize = AdSize.BANNER;
            } else if ("IAB_MRECT".equals(attributeValue)) {
                adSize = AdSize.IAB_MRECT;
            } else if ("IAB_BANNER".equals(attributeValue)) {
                adSize = AdSize.IAB_BANNER;
            } else if ("IAB_LEADERBOARD".equals(attributeValue)) {
                adSize = AdSize.IAB_LEADERBOARD;
            } else {
                a(context, "Invalid \"adSize\" value in XML layout: " + attributeValue + ".", AdSize.BANNER);
                return;
            }
            String attributeValue2 = attrs.getAttributeValue("http://schemas.android.com/apk/lib/com.google.ads", "adUnitId");
            if (attributeValue2 == null) {
                a(context, "AdView missing required XML attribute \"adUnitId\".", adSize);
            } else if (isInEditMode()) {
                a(context, "Ads by Google", -1, adSize);
            } else {
                if (attributeValue2.startsWith("@string/")) {
                    String substring = attributeValue2.substring("@string/".length());
                    String packageName = context.getPackageName();
                    TypedValue typedValue = new TypedValue();
                    try {
                        getResources().getValue(packageName + ":string/" + substring, typedValue, true);
                        if (typedValue.string != null) {
                            str = typedValue.string.toString();
                            boolean attributeBooleanValue = attrs.getAttributeBooleanValue("http://schemas.android.com/apk/lib/com.google.ads", "loadAdOnCreate", false);
                            if (!(context instanceof Activity)) {
                                Activity activity = (Activity) context;
                                if (a(context, adSize)) {
                                    a(activity, adSize, str);
                                    if (attributeBooleanValue) {
                                        loadAd(new AdRequest());
                                        return;
                                    }
                                    return;
                                }
                                return;
                            }
                            a.b("AdView was initialized with a Context that wasn't an Activity.");
                            return;
                        }
                        a(context, "\"adUnitId\" was not a string: \"" + attributeValue2 + "\".", adSize);
                    } catch (Resources.NotFoundException e) {
                        a(context, "Could not find resource for \"adUnitId\": \"" + attributeValue2 + "\".", adSize);
                        return;
                    }
                }
                str = attributeValue2;
                boolean attributeBooleanValue2 = attrs.getAttributeBooleanValue("http://schemas.android.com/apk/lib/com.google.ads", "loadAdOnCreate", false);
                if (!(context instanceof Activity)) {
                }
            }
        }
    }

    public AdView(Context context, AttributeSet attrs, int i) {
        this(context, attrs);
    }

    private void a(Activity activity, AdSize adSize, String str) {
        this.a = new d(activity, this, adSize, str);
        setGravity(17);
        setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        addView(this.a.i(), (int) TypedValue.applyDimension(1, (float) adSize.getWidth(), activity.getResources().getDisplayMetrics()), (int) TypedValue.applyDimension(1, (float) adSize.getHeight(), activity.getResources().getDisplayMetrics()));
    }

    private void a(Context context, String str, int i, AdSize adSize) {
        if (getChildCount() == 0) {
            TextView textView = new TextView(context);
            textView.setGravity(17);
            textView.setText(str);
            textView.setTextColor(i);
            textView.setBackgroundColor(-16777216);
            LinearLayout linearLayout = new LinearLayout(context);
            linearLayout.setGravity(17);
            LinearLayout linearLayout2 = new LinearLayout(context);
            linearLayout2.setGravity(17);
            linearLayout2.setBackgroundColor(i);
            int applyDimension = (int) TypedValue.applyDimension(1, (float) adSize.getWidth(), context.getResources().getDisplayMetrics());
            int applyDimension2 = (int) TypedValue.applyDimension(1, (float) adSize.getHeight(), context.getResources().getDisplayMetrics());
            linearLayout.addView(textView, applyDimension - 2, applyDimension2 - 2);
            linearLayout2.addView(linearLayout);
            addView(linearLayout2, applyDimension, applyDimension2);
        }
    }

    private void a(Context context, String str, AdSize adSize) {
        a.b(str);
        a(context, str, -65536, adSize);
        if (isInEditMode()) {
            return;
        }
        if (context instanceof Activity) {
            a((Activity) context, adSize, ASConstants.kEmptyString);
        } else {
            a.b("AdView was initialized with a Context that wasn't an Activity.");
        }
    }

    private boolean a(Context context, AdSize adSize) {
        if (AdUtil.b(context)) {
            return true;
        }
        a(context, "You must have INTERNET and ACCESS_NETWORK_STATE permissions in AndroidManifest.xml.", adSize);
        return false;
    }

    public void destroy() {
        this.a.b();
    }

    @Override // com.google.ads.Ad
    public boolean isReady() {
        if (this.a == null) {
            return false;
        }
        return this.a.o();
    }

    public boolean isRefreshing() {
        return this.a.p();
    }

    @Override // com.google.ads.Ad
    public void loadAd(AdRequest adRequest) {
        if (this.a.e() == null) {
            a.e("activity was null while checking permissions.");
            return;
        }
        if (isRefreshing()) {
            this.a.c();
        }
        this.a.a(adRequest);
    }

    @Override // com.google.ads.Ad
    public void setAdListener(AdListener adListener) {
        this.a.a(adListener);
    }

    @Override // com.google.ads.Ad
    public void stopLoading() {
        this.a.y();
    }
}
