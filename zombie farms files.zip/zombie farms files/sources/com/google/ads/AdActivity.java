package com.google.ads;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.VideoView;
import com.google.ads.util.a;

public class AdActivity extends Activity implements MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener, MediaPlayer.OnPreparedListener, View.OnClickListener {
    public static final String BASE_URL_PARAM = "baseurl";
    public static final String HTML_PARAM = "html";
    public static final String INTENT_ACTION_PARAM = "i";
    public static final String ORIENTATION_PARAM = "o";
    public static final String TYPE_PARAM = "m";
    public static final String URL_PARAM = "u";
    private static final Object a = new Object();
    private static AdActivity b = null;
    private static d c = null;
    private static AdActivity d = null;
    private static AdActivity e = null;
    private g f;
    private long g;
    private RelativeLayout h;
    private AdActivity i = null;
    private boolean j;
    private VideoView k;

    private void a(g gVar, boolean z, int i2) {
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        if (gVar.getParent() != null) {
            a("Interstitial created with an AdWebView that has a parent.");
        } else if (gVar.b() != null) {
            a("Interstitial created with an AdWebView that is already in use by another AdActivity.");
        } else {
            setRequestedOrientation(i2);
            gVar.a(this);
            ImageButton imageButton = new ImageButton(getApplicationContext());
            imageButton.setImageResource(17301527);
            imageButton.setBackgroundDrawable(null);
            int applyDimension = (int) TypedValue.applyDimension(1, 1.0f, getResources().getDisplayMetrics());
            imageButton.setPadding(applyDimension, applyDimension, 0, 0);
            imageButton.setOnClickListener(this);
            this.h.addView(gVar, new ViewGroup.LayoutParams(-1, -1));
            this.h.addView(imageButton);
            setContentView(this.h);
            if (z) {
                a.a(gVar);
            }
        }
    }

    private void a(String str) {
        a.b(str);
        finish();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0024, code lost:
        r1 = new android.content.Intent(r0.getApplicationContext(), com.google.ads.AdActivity.class);
        r1.putExtra("com.google.ads.AdOpener", r5.a());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:?, code lost:
        com.google.ads.util.a.a("Launching AdActivity.");
        r0.startActivity(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0041, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        com.google.ads.util.a.a(r0.getMessage(), r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:7:0x000a, code lost:
        r0 = r4.e();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x000e, code lost:
        if (r0 != null) goto L_0x0024;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0010, code lost:
        com.google.ads.util.a.e("activity was null while launching an AdActivity.");
     */
    public static void launchAdActivity(d adManager, e adOpener) {
        synchronized (a) {
            if (c == null) {
                c = adManager;
            } else if (c != adManager) {
                a.b("Tried to launch a new AdActivity with a different AdManager.");
            }
        }
    }

    public g getOpeningAdWebView() {
        if (this.i != null) {
            return this.i.f;
        }
        synchronized (a) {
            if (c == null) {
                a.e("currentAdManager was null while trying to get the opening AdWebView.");
                return null;
            }
            g i2 = c.i();
            if (i2 != this.f) {
                return i2;
            }
            return null;
        }
    }

    public VideoView getVideoView() {
        return this.k;
    }

    public void onClick(View view) {
        finish();
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        a.d("Video finished playing.");
        if (this.k != null) {
            this.k.setVisibility(8);
        }
        this.f.loadUrl("javascript:AFMA_ReceiveMessage('onVideoEvent', {'event': 'finish'});");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0018, code lost:
        if (r10.i != null) goto L_0x0022;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x001c, code lost:
        if (com.google.ads.AdActivity.e == null) goto L_0x0022;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001e, code lost:
        r10.i = com.google.ads.AdActivity.e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0022, code lost:
        com.google.ads.AdActivity.e = r10;
        r10.h = null;
        r10.j = false;
        r10.k = null;
        r0 = getIntent().getBundleExtra("com.google.ads.AdOpener");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0034, code lost:
        if (r0 != null) goto L_0x0046;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0036, code lost:
        a("Could not get the Bundle used to create AdActivity.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0046, code lost:
        r1 = new defpackage.e(r0);
        r0 = r1.b();
        r3 = r1.c();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x0055, code lost:
        if (r10 != com.google.ads.AdActivity.d) goto L_0x005a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0057, code lost:
        r9.s();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:0x0060, code lost:
        if (r0.equals("intent") == false) goto L_0x00e3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0062, code lost:
        r10.f = null;
        r10.g = android.os.SystemClock.elapsedRealtime();
        r10.j = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:0x006c, code lost:
        if (r3 != null) goto L_0x0074;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:30:0x006e, code lost:
        a("Could not get the paramMap in launchIntent()");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x0074, code lost:
        r0 = r3.get("u");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x007c, code lost:
        if (r0 != null) goto L_0x0084;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:33:0x007e, code lost:
        a("Could not get the URL parameter in launchIntent().");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0084, code lost:
        r1 = r3.get(com.google.ads.AdActivity.INTENT_ACTION_PARAM);
        r2 = r3.get(com.google.ads.AdActivity.TYPE_PARAM);
        r3 = android.net.Uri.parse(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0098, code lost:
        if (r1 != null) goto L_0x00cb;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x009a, code lost:
        r0 = new android.content.Intent("android.intent.action.VIEW", r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x00a1, code lost:
        r1 = com.google.ads.AdActivity.a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00a3, code lost:
        monitor-enter(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00a6, code lost:
        if (com.google.ads.AdActivity.b != null) goto L_0x00b3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00a8, code lost:
        com.google.ads.AdActivity.b = r10;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:43:0x00ac, code lost:
        if (com.google.ads.AdActivity.c == null) goto L_0x00da;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00ae, code lost:
        com.google.ads.AdActivity.c.t();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x00b3, code lost:
        monitor-exit(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:48:?, code lost:
        com.google.ads.util.a.a("Launching an intent from AdActivity.");
        startActivity(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:49:0x00be, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:50:0x00bf, code lost:
        com.google.ads.util.a.a(r0.getMessage(), r0);
        finish();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00cb, code lost:
        r0 = new android.content.Intent(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:52:0x00d0, code lost:
        if (r2 == null) goto L_0x00d6;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00d2, code lost:
        r0.setDataAndType(r3, r2);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:54:0x00d6, code lost:
        r0.setData(r3);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00da, code lost:
        com.google.ads.util.a.e("currentAdManager is null while trying to call onLeaveApplication().");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:59:0x00e3, code lost:
        r10.h = new android.widget.RelativeLayout(getApplicationContext());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:60:0x00f4, code lost:
        if (r0.equals("webapp") == false) goto L_0x016a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:61:0x00f6, code lost:
        r10.f = new defpackage.g(getApplicationContext(), null);
        r0 = new defpackage.h(r9, defpackage.a.b, true, true);
        r0.b();
        r10.f.setWebViewClient(r0);
        r0 = r3.get("u");
        r1 = r3.get(com.google.ads.AdActivity.BASE_URL_PARAM);
        r2 = r3.get(com.google.ads.AdActivity.HTML_PARAM);
        r6 = r3.get(com.google.ads.AdActivity.ORIENTATION_PARAM);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:62:0x0131, code lost:
        if (r0 == null) goto L_0x0148;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:63:0x0133, code lost:
        r10.f.loadUrl(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:65:0x013e, code lost:
        if ("p".equals(r6) == false) goto L_0x015b;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0140, code lost:
        r0 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0141, code lost:
        a(r10.f, false, r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x0148, code lost:
        if (r2 == null) goto L_0x0154;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x014a, code lost:
        r10.f.loadDataWithBaseURL(r1, r2, "text/html", "utf-8", null);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0154, code lost:
        a("Could not get the URL or HTML parameter to show a web app.");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:72:0x0161, code lost:
        if ("l".equals(r6) == false) goto L_0x0165;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x0163, code lost:
        r0 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:74:0x0165, code lost:
        r0 = r9.m();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:76:0x0170, code lost:
        if (r0.equals("interstitial") == false) goto L_0x0183;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:77:0x0172, code lost:
        r10.f = r9.i();
        a(r10.f, true, r9.m());
     */
    /* JADX WARNING: Code restructure failed: missing block: B:78:0x0183, code lost:
        a("Unknown AdOpener, <action: " + r0 + ">");
     */
    /* JADX WARNING: Code restructure failed: missing block: B:79:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:80:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:85:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:86:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:88:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:8:0x0012, code lost:
        if (com.google.ads.AdActivity.d != null) goto L_0x0016;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0014, code lost:
        com.google.ads.AdActivity.d = r10;
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        synchronized (a) {
            if (c != null) {
                d dVar = c;
            } else {
                a("Could not get currentAdManager.");
            }
        }
    }

    public void onDestroy() {
        if (this.h != null) {
            this.h.removeAllViews();
        }
        if (this.f != null) {
            a.b(this.f);
            this.f.a(null);
        }
        if (isFinishing()) {
            if (this.k != null) {
                this.k.stopPlayback();
                this.k = null;
            }
            synchronized (a) {
                if (!(c == null || this.f == null)) {
                    if (this.f == c.i()) {
                        c.a();
                    }
                    this.f.stopLoading();
                    this.f.destroy();
                }
                if (this == d) {
                    if (c != null) {
                        c.r();
                        c = null;
                    } else {
                        a.e("currentAdManager is null while trying to destroy AdActivity.");
                    }
                    d = null;
                }
            }
            if (this == b) {
                b = null;
            }
            e = this.i;
        }
        a.a("AdActivity is closing.");
        super.onDestroy();
    }

    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        a.e("Video threw error! <what:" + what + ", extra:" + extra + ">");
        finish();
        return true;
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        a.d("Video is ready to play.");
        this.f.loadUrl("javascript:AFMA_ReceiveMessage('onVideoEvent', {'event': 'load'});");
    }

    public void onWindowFocusChanged(boolean hasFocus) {
        if (this.j && hasFocus && SystemClock.elapsedRealtime() - this.g > 250) {
            a.d("Launcher AdActivity got focus and is closing.");
            finish();
        }
        super.onWindowFocusChanged(hasFocus);
    }

    public void showVideo(VideoView videoView) {
        this.k = videoView;
        if (this.f == null) {
            a("Couldn't get adWebView to show the video.");
            return;
        }
        this.f.setBackgroundColor(0);
        videoView.setOnCompletionListener(this);
        videoView.setOnPreparedListener(this);
        videoView.setOnErrorListener(this);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -1);
        LinearLayout linearLayout = new LinearLayout(getApplicationContext());
        linearLayout.setGravity(17);
        linearLayout.addView(videoView, layoutParams);
        this.h.addView(linearLayout, 0, layoutParams);
    }
}
