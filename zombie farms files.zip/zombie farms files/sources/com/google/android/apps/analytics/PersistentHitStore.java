package com.google.android.apps.analytics;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.google.android.apps.analytics.Item;
import com.google.android.apps.analytics.Transaction;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;

/* access modifiers changed from: package-private */
public class PersistentHitStore implements HitStore {
    private static final String ACCOUNT_ID = "account_id";
    private static final String ACTION = "action";
    private static final String CATEGORY = "category";
    private static final String CREATE_CUSTOM_VARIABLES_TABLE = ("CREATE TABLE custom_variables (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", CUSTOMVAR_ID) + String.format(" '%s' INTEGER NOT NULL,", EVENT_ID) + String.format(" '%s' INTEGER NOT NULL,", CUSTOMVAR_INDEX) + String.format(" '%s' CHAR(64) NOT NULL,", CUSTOMVAR_NAME) + String.format(" '%s' CHAR(64) NOT NULL,", CUSTOMVAR_VALUE) + String.format(" '%s' INTEGER NOT NULL);", CUSTOMVAR_SCOPE));
    private static final String CREATE_CUSTOM_VAR_CACHE_TABLE = ("CREATE TABLE IF NOT EXISTS custom_var_cache (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", CUSTOMVAR_ID) + String.format(" '%s' INTEGER NOT NULL,", EVENT_ID) + String.format(" '%s' INTEGER NOT NULL,", CUSTOMVAR_INDEX) + String.format(" '%s' CHAR(64) NOT NULL,", CUSTOMVAR_NAME) + String.format(" '%s' CHAR(64) NOT NULL,", CUSTOMVAR_VALUE) + String.format(" '%s' INTEGER NOT NULL);", CUSTOMVAR_SCOPE));
    private static final String CREATE_EVENTS_TABLE = ("CREATE TABLE events (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", EVENT_ID) + String.format(" '%s' INTEGER NOT NULL,", "user_id") + String.format(" '%s' CHAR(256) NOT NULL,", ACCOUNT_ID) + String.format(" '%s' INTEGER NOT NULL,", RANDOM_VAL) + String.format(" '%s' INTEGER NOT NULL,", TIMESTAMP_FIRST) + String.format(" '%s' INTEGER NOT NULL,", TIMESTAMP_PREVIOUS) + String.format(" '%s' INTEGER NOT NULL,", TIMESTAMP_CURRENT) + String.format(" '%s' INTEGER NOT NULL,", VISITS) + String.format(" '%s' CHAR(256) NOT NULL,", CATEGORY) + String.format(" '%s' CHAR(256) NOT NULL,", "action") + String.format(" '%s' CHAR(256), ", LABEL) + String.format(" '%s' INTEGER,", VALUE) + String.format(" '%s' INTEGER,", SCREEN_WIDTH) + String.format(" '%s' INTEGER);", SCREEN_HEIGHT));
    private static final String CREATE_HITS_TABLE = ("CREATE TABLE IF NOT EXISTS hits (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", HIT_ID) + String.format(" '%s' TEXT NOT NULL,", HIT_STRING) + String.format(" '%s' INTEGER NOT NULL);", HIT_TIMESTAMP));
    private static final String CREATE_INSTALL_REFERRER_TABLE = "CREATE TABLE install_referrer (referrer TEXT PRIMARY KEY NOT NULL);";
    private static final String CREATE_ITEM_EVENTS_TABLE = ("CREATE TABLE item_events (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", ITEM_ID) + String.format(" '%s' INTEGER NOT NULL,", EVENT_ID) + String.format(" '%s' TEXT NOT NULL,", ORDER_ID) + String.format(" '%s' TEXT NOT NULL,", ITEM_SKU) + String.format(" '%s' TEXT,", ITEM_NAME) + String.format(" '%s' TEXT,", ITEM_CATEGORY) + String.format(" '%s' TEXT NOT NULL,", ITEM_PRICE) + String.format(" '%s' TEXT NOT NULL);", ITEM_COUNT));
    private static final String CREATE_REFERRER_TABLE = "CREATE TABLE IF NOT EXISTS referrer (referrer TEXT PRIMARY KEY NOT NULL,timestamp_referrer INTEGER NOT NULL);";
    private static final String CREATE_SESSION_TABLE = ("CREATE TABLE IF NOT EXISTS session (" + String.format(" '%s' INTEGER PRIMARY KEY,", TIMESTAMP_FIRST) + String.format(" '%s' INTEGER NOT NULL,", TIMESTAMP_PREVIOUS) + String.format(" '%s' INTEGER NOT NULL,", TIMESTAMP_CURRENT) + String.format(" '%s' INTEGER NOT NULL,", VISITS) + String.format(" '%s' INTEGER NOT NULL);", STORE_ID));
    private static final String CREATE_TRANSACTION_EVENTS_TABLE = ("CREATE TABLE transaction_events (" + String.format(" '%s' INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,", TRANSACTION_ID) + String.format(" '%s' INTEGER NOT NULL,", EVENT_ID) + String.format(" '%s' TEXT NOT NULL,", ORDER_ID) + String.format(" '%s' TEXT,", STORE_NAME) + String.format(" '%s' TEXT NOT NULL,", TOTAL_COST) + String.format(" '%s' TEXT,", TOTAL_TAX) + String.format(" '%s' TEXT);", SHIPPING_COST));
    private static final String CUSTOMVAR_ID = "cv_id";
    private static final String CUSTOMVAR_INDEX = "cv_index";
    private static final String CUSTOMVAR_NAME = "cv_name";
    private static final String CUSTOMVAR_SCOPE = "cv_scope";
    private static final String CUSTOMVAR_VALUE = "cv_value";
    private static final String CUSTOM_VARIABLE_COLUMN_TYPE = "CHAR(64) NOT NULL";
    private static final String DATABASE_NAME = "google_analytics.db";
    private static final int DATABASE_VERSION = 4;
    private static final String EVENT_ID = "event_id";
    private static final String HIT_ID = "hit_id";
    private static final String HIT_STRING = "hit_string";
    private static final String HIT_TIMESTAMP = "hit_time";
    private static final String ITEM_CATEGORY = "item_category";
    private static final String ITEM_COUNT = "item_count";
    private static final String ITEM_ID = "item_id";
    private static final String ITEM_NAME = "item_name";
    private static final String ITEM_PRICE = "item_price";
    private static final String ITEM_SKU = "item_sku";
    private static final String LABEL = "label";
    private static final int MAX_HITS = 1000;
    private static final String ORDER_ID = "order_id";
    private static final String RANDOM_VAL = "random_val";
    private static final String REFERRER = "referrer";
    private static final String REFERRER_COLUMN = "referrer";
    private static final String SCREEN_HEIGHT = "screen_height";
    private static final String SCREEN_WIDTH = "screen_width";
    private static final String SHIPPING_COST = "tran_shippingcost";
    private static final String STORE_ID = "store_id";
    private static final String STORE_NAME = "tran_storename";
    private static final String TIMESTAMP_CURRENT = "timestamp_current";
    private static final String TIMESTAMP_FIRST = "timestamp_first";
    private static final String TIMESTAMP_PREVIOUS = "timestamp_previous";
    private static final String TIMESTAMP_REFERRER = "timestamp_referrer";
    private static final String TOTAL_COST = "tran_totalcost";
    private static final String TOTAL_TAX = "tran_totaltax";
    private static final String TRANSACTION_ID = "tran_id";
    private static final boolean UPDATE_TIMESTAMP = true;
    private static final String USER_ID = "user_id";
    private static final String VALUE = "value";
    private static final String VISITS = "visits";
    private boolean anonymizeIp;
    private DataBaseHelper databaseHelper;
    private int numStoredHits;
    private int sampleRate;
    private boolean sessionStarted;
    private int storeId;
    private long timestampCurrent;
    private long timestampFirst;
    private long timestampPrevious;
    private boolean useStoredVisitorVars;
    private int visits;

    /* access modifiers changed from: package-private */
    public static class DataBaseHelper extends SQLiteOpenHelper {
        private final int databaseVersion;
        private final PersistentHitStore store;

        public DataBaseHelper(Context context, PersistentHitStore persistentHitStore) {
            this(context, PersistentHitStore.DATABASE_NAME, 4, persistentHitStore);
        }

        DataBaseHelper(Context context, String str, int i, PersistentHitStore persistentHitStore) {
            super(context, str, (SQLiteDatabase.CursorFactory) null, i);
            this.databaseVersion = i;
            this.store = persistentHitStore;
        }

        public DataBaseHelper(Context context, String str, PersistentHitStore persistentHitStore) {
            this(context, str, 4, persistentHitStore);
        }

        private void createECommerceTables(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS transaction_events;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_TRANSACTION_EVENTS_TABLE);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS item_events;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_ITEM_EVENTS_TABLE);
        }

        private void createHitTable(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS hits;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_HITS_TABLE);
        }

        private void createReferrerTable(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS referrer;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_REFERRER_TABLE);
        }

        private void migrateEventsToHits(SQLiteDatabase sQLiteDatabase, int i) {
            Event[] peekEvents;
            this.store.loadExistingSession(sQLiteDatabase);
            for (Event event : this.store.peekEvents(PersistentHitStore.MAX_HITS, sQLiteDatabase, i)) {
                this.store.putEvent(event, sQLiteDatabase, false);
            }
            sQLiteDatabase.execSQL("DELETE from events;");
            sQLiteDatabase.execSQL("DELETE from item_events;");
            sQLiteDatabase.execSQL("DELETE from transaction_events;");
            sQLiteDatabase.execSQL("DELETE from custom_variables;");
        }

        /* JADX WARNING: Removed duplicated region for block: B:23:0x006b  */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x0070  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0079  */
        /* JADX WARNING: Removed duplicated region for block: B:31:0x007e  */
        /* JADX WARNING: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
        private void migrateOldReferrer(SQLiteDatabase sQLiteDatabase) {
            Cursor cursor;
            Cursor cursor2;
            Throwable th;
            SQLiteException e;
            Cursor cursor3 = null;
            try {
                cursor = sQLiteDatabase.query("install_referrer", new String[]{"referrer"}, null, null, null, null, null);
                try {
                    if (cursor.moveToFirst()) {
                        String string = cursor.getString(0);
                        cursor2 = sQLiteDatabase.query("session", null, null, null, null, null, null);
                        try {
                            long j = cursor2.moveToFirst() ? cursor2.getLong(0) : 0;
                            ContentValues contentValues = new ContentValues();
                            contentValues.put("referrer", string);
                            contentValues.put(PersistentHitStore.TIMESTAMP_REFERRER, Long.valueOf(j));
                            sQLiteDatabase.insert("referrer", null, contentValues);
                        } catch (SQLiteException e2) {
                            e = e2;
                            cursor3 = cursor;
                            try {
                                Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                                if (cursor3 != null) {
                                    cursor3.close();
                                }
                                if (cursor2 != null) {
                                    cursor2.close();
                                    return;
                                }
                                return;
                            } catch (Throwable th2) {
                                th = th2;
                                cursor = cursor3;
                                if (cursor != null) {
                                    cursor.close();
                                }
                                if (cursor2 != null) {
                                    cursor2.close();
                                }
                                throw th;
                            }
                        } catch (Throwable th3) {
                            th = th3;
                            if (cursor != null) {
                            }
                            if (cursor2 != null) {
                            }
                            throw th;
                        }
                    } else {
                        cursor2 = null;
                    }
                    if (cursor != null) {
                        cursor.close();
                    }
                    if (cursor2 != null) {
                        cursor2.close();
                    }
                } catch (SQLiteException e3) {
                    e = e3;
                    cursor2 = null;
                    cursor3 = cursor;
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                    if (cursor3 != null) {
                    }
                    if (cursor2 != null) {
                    }
                } catch (Throwable th4) {
                    th = th4;
                    cursor2 = null;
                    if (cursor != null) {
                    }
                    if (cursor2 != null) {
                    }
                    throw th;
                }
            } catch (SQLiteException e4) {
                e = e4;
                cursor2 = null;
                Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                if (cursor3 != null) {
                }
                if (cursor2 != null) {
                }
            } catch (Throwable th5) {
                th = th5;
                cursor2 = null;
                cursor = null;
                if (cursor != null) {
                }
                if (cursor2 != null) {
                }
                throw th;
            }
        }

        /* access modifiers changed from: package-private */
        public void createCustomVariableTables(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS custom_variables;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_CUSTOM_VARIABLES_TABLE);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS custom_var_cache;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_CUSTOM_VAR_CACHE_TABLE);
            for (int i = 1; i <= 5; i++) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(PersistentHitStore.EVENT_ID, (Integer) 0);
                contentValues.put(PersistentHitStore.CUSTOMVAR_INDEX, Integer.valueOf(i));
                contentValues.put(PersistentHitStore.CUSTOMVAR_NAME, ASConstants.kEmptyString);
                contentValues.put(PersistentHitStore.CUSTOMVAR_SCOPE, (Integer) 3);
                contentValues.put(PersistentHitStore.CUSTOMVAR_VALUE, ASConstants.kEmptyString);
                sQLiteDatabase.insert("custom_var_cache", PersistentHitStore.EVENT_ID, contentValues);
            }
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS events;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_EVENTS_TABLE);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS install_referrer;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_INSTALL_REFERRER_TABLE);
            sQLiteDatabase.execSQL("DROP TABLE IF EXISTS session;");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_SESSION_TABLE);
            if (this.databaseVersion > 1) {
                createCustomVariableTables(sQLiteDatabase);
            }
            if (this.databaseVersion > 2) {
                createECommerceTables(sQLiteDatabase);
            }
            if (this.databaseVersion > 3) {
                createHitTable(sQLiteDatabase);
                createReferrerTable(sQLiteDatabase);
            }
        }

        public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            Log.w(GoogleAnalyticsTracker.LOG_TAG, "Downgrading database version from " + i + " to " + i2 + " not recommended.");
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_REFERRER_TABLE);
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_HITS_TABLE);
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_CUSTOM_VAR_CACHE_TABLE);
            sQLiteDatabase.execSQL(PersistentHitStore.CREATE_SESSION_TABLE);
            HashSet hashSet = new HashSet();
            Cursor query = sQLiteDatabase.query("custom_var_cache", null, null, null, null, null, null, null);
            while (query.moveToNext()) {
                try {
                    hashSet.add(Integer.valueOf(query.getInt(query.getColumnIndex(PersistentHitStore.CUSTOMVAR_INDEX))));
                } catch (SQLiteException e) {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, "Error on downgrade: " + e.toString());
                } finally {
                    query.close();
                }
            }
            for (int i3 = 1; i3 <= 5; i3++) {
                try {
                    if (!hashSet.contains(Integer.valueOf(i3))) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(PersistentHitStore.EVENT_ID, (Integer) 0);
                        contentValues.put(PersistentHitStore.CUSTOMVAR_INDEX, Integer.valueOf(i3));
                        contentValues.put(PersistentHitStore.CUSTOMVAR_NAME, ASConstants.kEmptyString);
                        contentValues.put(PersistentHitStore.CUSTOMVAR_SCOPE, (Integer) 3);
                        contentValues.put(PersistentHitStore.CUSTOMVAR_VALUE, ASConstants.kEmptyString);
                        sQLiteDatabase.insert("custom_var_cache", PersistentHitStore.EVENT_ID, contentValues);
                    }
                } catch (SQLiteException e2) {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, "Error inserting custom variable on downgrade: " + e2.toString());
                }
            }
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
            if (i > i2) {
                onDowngrade(sQLiteDatabase, i, i2);
                return;
            }
            if (i < 2 && i2 > 1) {
                createCustomVariableTables(sQLiteDatabase);
            }
            if (i < 3 && i2 > 2) {
                createECommerceTables(sQLiteDatabase);
            }
            if (i < 4 && i2 > 3) {
                createHitTable(sQLiteDatabase);
                createReferrerTable(sQLiteDatabase);
                migrateEventsToHits(sQLiteDatabase, i);
                migrateOldReferrer(sQLiteDatabase);
            }
        }
    }

    PersistentHitStore(Context context) {
        this(context, DATABASE_NAME, 4);
    }

    PersistentHitStore(Context context, String str) {
        this(context, str, 4);
    }

    PersistentHitStore(Context context, String str, int i) {
        this.sampleRate = 100;
        this.databaseHelper = new DataBaseHelper(context, str, i, this);
        loadExistingSession();
    }

    PersistentHitStore(DataBaseHelper dataBaseHelper) {
        this.sampleRate = 100;
        this.databaseHelper = dataBaseHelper;
        loadExistingSession();
    }

    static String formatReferrer(String str) {
        if (str == null) {
            return null;
        }
        Map<String, String> parseURLParameters = Utils.parseURLParameters(str);
        boolean z = parseURLParameters.get("utm_campaign") != null;
        boolean z2 = parseURLParameters.get("utm_medium") != null;
        boolean z3 = parseURLParameters.get("utm_source") != null;
        if ((parseURLParameters.get("gclid") != null) || (z && z2 && z3)) {
            String[][] strArr = {new String[]{"utmcid", parseURLParameters.get("utm_id")}, new String[]{"utmcsr", parseURLParameters.get("utm_source")}, new String[]{"utmgclid", parseURLParameters.get("gclid")}, new String[]{"utmccn", parseURLParameters.get("utm_campaign")}, new String[]{"utmcmd", parseURLParameters.get("utm_medium")}, new String[]{"utmctr", parseURLParameters.get("utm_term")}, new String[]{"utmcct", parseURLParameters.get("utm_content")}};
            StringBuilder sb = new StringBuilder();
            boolean z4 = true;
            for (int i = 0; i < strArr.length; i++) {
                if (strArr[i][1] != null) {
                    String replace = strArr[i][1].replace("+", "%20").replace(" ", "%20");
                    if (z4) {
                        z4 = false;
                    } else {
                        sb.append("|");
                    }
                    sb.append(strArr[i][0]).append("=").append(replace);
                }
            }
            return sb.toString();
        }
        Log.w(GoogleAnalyticsTracker.LOG_TAG, "Badly formatted referrer missing campaign, medium and source or click ID");
        return null;
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void clearReferrer() {
        try {
            this.databaseHelper.getWritableDatabase().delete("referrer", null, null);
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void deleteHit(long j) {
        try {
            this.databaseHelper.getWritableDatabase().delete("hits", "hit_id = ?", new String[]{Long.toString(j)});
            this.numStoredHits--;
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0060  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x006e  */
    public CustomVariableBuffer getCustomVariables(long j, SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        Throwable th;
        CustomVariableBuffer customVariableBuffer = new CustomVariableBuffer();
        try {
            cursor = sQLiteDatabase.query("custom_variables", null, "event_id= ?", new String[]{Long.toString(j)}, null, null, null);
            while (cursor.moveToNext()) {
                try {
                    customVariableBuffer.setCustomVariable(new CustomVariable(cursor.getInt(cursor.getColumnIndex(CUSTOMVAR_INDEX)), cursor.getString(cursor.getColumnIndex(CUSTOMVAR_NAME)), cursor.getString(cursor.getColumnIndex(CUSTOMVAR_VALUE)), cursor.getInt(cursor.getColumnIndex(CUSTOMVAR_SCOPE))));
                } catch (SQLiteException e) {
                    e = e;
                    try {
                        Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                        if (cursor != null) {
                        }
                        return customVariableBuffer;
                    } catch (Throwable th2) {
                        th = th2;
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
            }
            if (cursor != null) {
                cursor.close();
            }
        } catch (SQLiteException e2) {
            e = e2;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor != null) {
                cursor.close();
            }
            return customVariableBuffer;
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            if (cursor != null) {
            }
            throw th;
        }
        return customVariableBuffer;
    }

    /* access modifiers changed from: package-private */
    public DataBaseHelper getDatabaseHelper() {
        return this.databaseHelper;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x008d  */
    public Item getItem(long j, SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        Throwable th;
        Cursor cursor2;
        SQLiteException e;
        try {
            cursor = sQLiteDatabase.query("item_events", null, "event_id= ?", new String[]{Long.toString(j)}, null, null, null);
            try {
                if (cursor.moveToFirst()) {
                    Item build = new Item.Builder(cursor.getString(cursor.getColumnIndex(ORDER_ID)), cursor.getString(cursor.getColumnIndex(ITEM_SKU)), cursor.getDouble(cursor.getColumnIndex(ITEM_PRICE)), cursor.getLong(cursor.getColumnIndex(ITEM_COUNT))).setItemName(cursor.getString(cursor.getColumnIndex(ITEM_NAME))).setItemCategory(cursor.getString(cursor.getColumnIndex(ITEM_CATEGORY))).build();
                    if (cursor == null) {
                        return build;
                    }
                    cursor.close();
                    return build;
                }
                if (cursor != null) {
                    cursor.close();
                }
                return null;
            } catch (SQLiteException e2) {
                e = e2;
                cursor2 = cursor;
                try {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                    if (cursor2 != null) {
                    }
                    return null;
                } catch (Throwable th2) {
                    th = th2;
                    cursor = cursor2;
                    if (cursor != null) {
                    }
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                if (cursor != null) {
                }
                throw th;
            }
        } catch (SQLiteException e3) {
            e = e3;
            cursor2 = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor2 != null) {
                cursor2.close();
            }
            return null;
        } catch (Throwable th4) {
            th = th4;
            cursor = null;
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public int getNumStoredHits() {
        Cursor cursor = null;
        int i = 0;
        try {
            Cursor rawQuery = this.databaseHelper.getReadableDatabase().rawQuery("SELECT COUNT(*) from hits", null);
            if (rawQuery.moveToFirst()) {
                i = (int) rawQuery.getLong(0);
            }
            if (rawQuery != null) {
                rawQuery.close();
            }
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (0 != 0) {
                cursor.close();
            }
        } catch (Throwable th) {
            if (0 != 0) {
                cursor.close();
            }
            throw th;
        }
        return i;
    }

    @Override // com.google.android.apps.analytics.HitStore
    public Referrer getReferrer() {
        try {
            return getReferrer(this.databaseHelper.getReadableDatabase(), false);
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            return null;
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0067  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x006f  */
    public Referrer getReferrer(SQLiteDatabase sQLiteDatabase, boolean z) {
        Throwable th;
        Cursor cursor;
        SQLiteException e;
        Referrer referrer;
        long j;
        Cursor cursor2 = null;
        try {
            Cursor query = sQLiteDatabase.query("referrer", new String[]{"referrer", TIMESTAMP_REFERRER}, null, null, null, null, null);
            try {
                if (query.moveToFirst()) {
                    long j2 = query.getLong(1);
                    String string = query.getString(0);
                    if (j2 != 0 || !z) {
                        j = j2;
                        cursor = query;
                    } else {
                        long j3 = this.timestampCurrent;
                        query.close();
                        ContentValues contentValues = new ContentValues();
                        contentValues.put(TIMESTAMP_REFERRER, Long.valueOf(j3));
                        sQLiteDatabase.update("referrer", contentValues, null, null);
                        j = j3;
                        cursor = null;
                    }
                    try {
                        referrer = new Referrer(string, j);
                    } catch (SQLiteException e2) {
                        e = e2;
                        try {
                            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                            if (cursor != null) {
                            }
                            return null;
                        } catch (Throwable th2) {
                            th = th2;
                            cursor2 = cursor;
                            if (cursor2 != null) {
                                cursor2.close();
                            }
                            throw th;
                        }
                    }
                } else {
                    cursor = query;
                    referrer = null;
                }
                if (cursor == null) {
                    return referrer;
                }
                cursor.close();
                return referrer;
            } catch (SQLiteException e3) {
                cursor = query;
                e = e3;
                Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                if (cursor != null) {
                    cursor.close();
                }
                return null;
            } catch (Throwable th3) {
                cursor2 = query;
                th = th3;
                if (cursor2 != null) {
                }
                throw th;
            }
        } catch (SQLiteException e4) {
            e = e4;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor != null) {
            }
            return null;
        } catch (Throwable th4) {
            th = th4;
            if (cursor2 != null) {
            }
            throw th;
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public int getStoreId() {
        return this.storeId;
    }

    /* access modifiers changed from: package-private */
    public long getTimestampCurrent() {
        return this.timestampCurrent;
    }

    /* access modifiers changed from: package-private */
    public long getTimestampFirst() {
        return this.timestampFirst;
    }

    /* access modifiers changed from: package-private */
    public long getTimestampPrevious() {
        return this.timestampPrevious;
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0087  */
    public Transaction getTransaction(long j, SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        Throwable th;
        SQLiteException e;
        try {
            cursor = sQLiteDatabase.query("transaction_events", null, "event_id= ?", new String[]{Long.toString(j)}, null, null, null);
            try {
                if (cursor.moveToFirst()) {
                    Transaction build = new Transaction.Builder(cursor.getString(cursor.getColumnIndex(ORDER_ID)), cursor.getDouble(cursor.getColumnIndex(TOTAL_COST))).setStoreName(cursor.getString(cursor.getColumnIndex(STORE_NAME))).setTotalTax(cursor.getDouble(cursor.getColumnIndex(TOTAL_TAX))).setShippingCost(cursor.getDouble(cursor.getColumnIndex(SHIPPING_COST))).build();
                    if (cursor == null) {
                        return build;
                    }
                    cursor.close();
                    return build;
                }
                if (cursor != null) {
                    cursor.close();
                }
                return null;
            } catch (SQLiteException e2) {
                e = e2;
                try {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                    if (cursor != null) {
                    }
                    return null;
                } catch (Throwable th2) {
                    th = th2;
                    if (cursor != null) {
                    }
                    throw th;
                }
            }
        } catch (SQLiteException e3) {
            e = e3;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor != null) {
                cursor.close();
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x004d  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0055  */
    @Override // com.google.android.apps.analytics.HitStore
    public String getVisitorCustomVar(int i) {
        Throwable th;
        Cursor cursor;
        SQLiteException e;
        String str;
        Cursor cursor2 = null;
        try {
            cursor = this.databaseHelper.getReadableDatabase().query("custom_var_cache", null, "cv_scope = ? AND cv_index = ?", new String[]{Integer.toString(1), Integer.toString(i)}, null, null, null);
            try {
                if (cursor.getCount() > 0) {
                    cursor.moveToFirst();
                    str = cursor.getString(cursor.getColumnIndex(CUSTOMVAR_VALUE));
                } else {
                    str = null;
                }
                if (cursor == null) {
                    return str;
                }
                cursor.close();
                return str;
            } catch (SQLiteException e2) {
                e = e2;
                try {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                    if (cursor != null) {
                        cursor.close();
                    }
                    return null;
                } catch (Throwable th2) {
                    th = th2;
                    cursor2 = cursor;
                    if (cursor2 != null) {
                        cursor2.close();
                    }
                    throw th;
                }
            }
        } catch (SQLiteException e3) {
            e = e3;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor != null) {
            }
            return null;
        } catch (Throwable th3) {
            th = th3;
            if (cursor2 != null) {
            }
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0066  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0074  */
    public CustomVariableBuffer getVisitorVarBuffer() {
        Cursor cursor;
        Throwable th;
        CustomVariableBuffer customVariableBuffer = new CustomVariableBuffer();
        try {
            cursor = this.databaseHelper.getReadableDatabase().query("custom_var_cache", null, "cv_scope= ?", new String[]{Integer.toString(1)}, null, null, null);
            while (cursor.moveToNext()) {
                try {
                    customVariableBuffer.setCustomVariable(new CustomVariable(cursor.getInt(cursor.getColumnIndex(CUSTOMVAR_INDEX)), cursor.getString(cursor.getColumnIndex(CUSTOMVAR_NAME)), cursor.getString(cursor.getColumnIndex(CUSTOMVAR_VALUE)), cursor.getInt(cursor.getColumnIndex(CUSTOMVAR_SCOPE))));
                } catch (SQLiteException e) {
                    e = e;
                    try {
                        Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                        if (cursor != null) {
                            cursor.close();
                        }
                        return customVariableBuffer;
                    } catch (Throwable th2) {
                        th = th2;
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
            }
            if (cursor != null) {
                cursor.close();
            }
        } catch (SQLiteException e2) {
            e = e2;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor != null) {
            }
            return customVariableBuffer;
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            if (cursor != null) {
            }
            throw th;
        }
        return customVariableBuffer;
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void loadExistingSession() {
        try {
            loadExistingSession(this.databaseHelper.getWritableDatabase());
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x00c3  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00cb  */
    /* JADX WARNING: Removed duplicated region for block: B:33:? A[RETURN, SYNTHETIC] */
    public void loadExistingSession(SQLiteDatabase sQLiteDatabase) {
        Cursor cursor;
        Throwable th;
        SQLiteException e;
        try {
            cursor = sQLiteDatabase.query("session", null, null, null, null, null, null);
            try {
                if (cursor.moveToFirst()) {
                    this.timestampFirst = cursor.getLong(0);
                    this.timestampPrevious = cursor.getLong(1);
                    this.timestampCurrent = cursor.getLong(2);
                    this.visits = cursor.getInt(3);
                    this.storeId = cursor.getInt(4);
                    Referrer referrer = getReferrer(sQLiteDatabase, false);
                    this.sessionStarted = this.timestampFirst != 0 && (referrer == null || referrer.getTimeStamp() != 0);
                } else {
                    this.sessionStarted = false;
                    this.useStoredVisitorVars = true;
                    this.storeId = new SecureRandom().nextInt() & Integer.MAX_VALUE;
                    cursor.close();
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(TIMESTAMP_FIRST, (Long) 0L);
                    contentValues.put(TIMESTAMP_PREVIOUS, (Long) 0L);
                    contentValues.put(TIMESTAMP_CURRENT, (Long) 0L);
                    contentValues.put(VISITS, (Integer) 0);
                    contentValues.put(STORE_ID, Integer.valueOf(this.storeId));
                    sQLiteDatabase.insert("session", null, contentValues);
                    cursor = null;
                }
                if (cursor != null) {
                    cursor.close();
                }
            } catch (SQLiteException e2) {
                e = e2;
                try {
                    Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                    if (cursor == null) {
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (cursor != null) {
                    }
                    throw th;
                }
            }
        } catch (SQLiteException e3) {
            e = e3;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (cursor == null) {
                cursor.close();
            }
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            if (cursor != null) {
                cursor.close();
            }
            throw th;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x00e6  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x011d  */
    /* JADX WARNING: Removed duplicated region for block: B:49:? A[RETURN, SYNTHETIC] */
    public Event[] peekEvents(int i, SQLiteDatabase sQLiteDatabase, int i2) {
        Cursor cursor;
        Cursor cursor2;
        ArrayList arrayList = new ArrayList();
        try {
            cursor2 = sQLiteDatabase.query("events", null, null, null, null, null, EVENT_ID, Integer.toString(i));
            while (cursor2.moveToNext()) {
                try {
                    Event event = new Event(cursor2.getLong(0), cursor2.getString(2), cursor2.getInt(3), cursor2.getInt(4), cursor2.getInt(5), cursor2.getInt(6), cursor2.getInt(7), cursor2.getString(8), cursor2.getString(9), cursor2.getString(10), cursor2.getInt(11), cursor2.getInt(12), cursor2.getInt(13));
                    event.setUserId(cursor2.getInt(1));
                    long j = cursor2.getLong(cursor2.getColumnIndex(EVENT_ID));
                    if ("__##GOOGLETRANSACTION##__".equals(event.category)) {
                        Transaction transaction = getTransaction(j, sQLiteDatabase);
                        if (transaction == null) {
                            Log.w(GoogleAnalyticsTracker.LOG_TAG, "missing expected transaction for event " + j);
                        }
                        event.setTransaction(transaction);
                    } else if ("__##GOOGLEITEM##__".equals(event.category)) {
                        Item item = getItem(j, sQLiteDatabase);
                        if (item == null) {
                            Log.w(GoogleAnalyticsTracker.LOG_TAG, "missing expected item for event " + j);
                        }
                        event.setItem(item);
                    } else {
                        event.setCustomVariableBuffer(i2 > 1 ? getCustomVariables(j, sQLiteDatabase) : new CustomVariableBuffer());
                    }
                    arrayList.add(event);
                } catch (SQLiteException e) {
                    e = e;
                    cursor = cursor2;
                    try {
                        Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                        Event[] eventArr = new Event[0];
                        if (cursor != null) {
                        }
                    } catch (Throwable th) {
                        th = th;
                        cursor2 = cursor;
                        if (cursor2 != null) {
                            cursor2.close();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (cursor2 != null) {
                    }
                    throw th;
                }
            }
            if (cursor2 != null) {
                cursor2.close();
            }
            return (Event[]) arrayList.toArray(new Event[arrayList.size()]);
        } catch (SQLiteException e2) {
            e = e2;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            Event[] eventArr2 = new Event[0];
            if (cursor != null) {
                return eventArr2;
            }
            cursor.close();
            return eventArr2;
        } catch (Throwable th3) {
            th = th3;
            cursor2 = null;
            if (cursor2 != null) {
            }
            throw th;
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public Hit[] peekHits() {
        return peekHits(MAX_HITS);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x005f  */
    /* JADX WARNING: Removed duplicated region for block: B:26:? A[RETURN, SYNTHETIC] */
    @Override // com.google.android.apps.analytics.HitStore
    public Hit[] peekHits(int i) {
        Cursor cursor;
        Throwable th;
        ArrayList arrayList = new ArrayList();
        try {
            cursor = this.databaseHelper.getReadableDatabase().query("hits", null, null, null, null, null, HIT_ID, Integer.toString(i));
            while (cursor.moveToNext()) {
                try {
                    arrayList.add(new Hit(cursor.getString(1), cursor.getLong(0)));
                } catch (SQLiteException e) {
                    e = e;
                    try {
                        Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
                        Hit[] hitArr = new Hit[0];
                        if (cursor != null) {
                            return hitArr;
                        }
                        cursor.close();
                        return hitArr;
                    } catch (Throwable th2) {
                        th = th2;
                        if (cursor != null) {
                            cursor.close();
                        }
                        throw th;
                    }
                }
            }
            if (cursor != null) {
                cursor.close();
            }
            return (Hit[]) arrayList.toArray(new Hit[arrayList.size()]);
        } catch (SQLiteException e2) {
            e = e2;
            cursor = null;
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            Hit[] hitArr2 = new Hit[0];
            if (cursor != null) {
            }
        } catch (Throwable th3) {
            th = th3;
            cursor = null;
            if (cursor != null) {
            }
            throw th;
        }
    }

    /* access modifiers changed from: package-private */
    public void putCustomVariables(Event event, SQLiteDatabase sQLiteDatabase) {
        if (!"__##GOOGLEITEM##__".equals(event.category) && !"__##GOOGLETRANSACTION##__".equals(event.category)) {
            try {
                CustomVariableBuffer customVariableBuffer = event.getCustomVariableBuffer();
                if (this.useStoredVisitorVars) {
                    if (customVariableBuffer == null) {
                        customVariableBuffer = new CustomVariableBuffer();
                        event.setCustomVariableBuffer(customVariableBuffer);
                    }
                    CustomVariableBuffer visitorVarBuffer = getVisitorVarBuffer();
                    for (int i = 1; i <= 5; i++) {
                        CustomVariable customVariableAt = visitorVarBuffer.getCustomVariableAt(i);
                        CustomVariable customVariableAt2 = customVariableBuffer.getCustomVariableAt(i);
                        if (customVariableAt != null && customVariableAt2 == null) {
                            customVariableBuffer.setCustomVariable(customVariableAt);
                        }
                    }
                    this.useStoredVisitorVars = false;
                }
                if (customVariableBuffer != null) {
                    for (int i2 = 1; i2 <= 5; i2++) {
                        if (!customVariableBuffer.isIndexAvailable(i2)) {
                            CustomVariable customVariableAt3 = customVariableBuffer.getCustomVariableAt(i2);
                            ContentValues contentValues = new ContentValues();
                            contentValues.put(EVENT_ID, (Integer) 0);
                            contentValues.put(CUSTOMVAR_INDEX, Integer.valueOf(customVariableAt3.getIndex()));
                            contentValues.put(CUSTOMVAR_NAME, customVariableAt3.getName());
                            contentValues.put(CUSTOMVAR_SCOPE, Integer.valueOf(customVariableAt3.getScope()));
                            contentValues.put(CUSTOMVAR_VALUE, customVariableAt3.getValue());
                            sQLiteDatabase.update("custom_var_cache", contentValues, "cv_index = ?", new String[]{Integer.toString(customVariableAt3.getIndex())});
                        }
                    }
                }
            } catch (SQLiteException e) {
                Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            }
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void putEvent(Event event) {
        if (this.numStoredHits >= MAX_HITS) {
            Log.w(GoogleAnalyticsTracker.LOG_TAG, "Store full. Not storing last event.");
            return;
        }
        if (this.sampleRate != 100) {
            if ((event.getUserId() == -1 ? this.storeId : event.getUserId()) % 10000 >= this.sampleRate * 100) {
                if (GoogleAnalyticsTracker.getInstance().getDebug()) {
                    Log.v(GoogleAnalyticsTracker.LOG_TAG, "User has been sampled out. Aborting hit.");
                    return;
                }
                return;
            }
        }
        if (!this.sessionStarted) {
            storeUpdatedSession();
        }
        try {
            putEvent(event, this.databaseHelper.getWritableDatabase(), true);
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, "putEventOuter:" + e.toString());
        }
    }

    /* access modifiers changed from: package-private */
    public void putEvent(Event event, SQLiteDatabase sQLiteDatabase, boolean z) {
        try {
            if (!event.isSessionInitialized()) {
                event.setRandomVal((int) (Math.random() * 2.147483647E9d));
                event.setTimestampFirst((int) this.timestampFirst);
                event.setTimestampPrevious((int) this.timestampPrevious);
                event.setTimestampCurrent((int) this.timestampCurrent);
                event.setVisits(this.visits);
            }
            event.setAnonymizeIp(this.anonymizeIp);
            if (event.getUserId() == -1) {
                event.setUserId(this.storeId);
            }
            sQLiteDatabase.beginTransaction();
            putCustomVariables(event, sQLiteDatabase);
            ContentValues contentValues = new ContentValues();
            contentValues.put(HIT_STRING, HitBuilder.constructHitRequestPath(event, getReferrer(sQLiteDatabase, true)));
            contentValues.put(HIT_TIMESTAMP, Long.valueOf(z ? System.currentTimeMillis() : 0));
            sQLiteDatabase.insert("hits", null, contentValues);
            this.numStoredHits++;
            sQLiteDatabase.setTransactionSuccessful();
            if (sQLiteDatabase != null) {
                sQLiteDatabase.endTransaction();
            }
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, "putEventInner:" + e.toString());
            if (sQLiteDatabase != null) {
                sQLiteDatabase.endTransaction();
            }
        } catch (Throwable th) {
            if (sQLiteDatabase != null) {
                sQLiteDatabase.endTransaction();
            }
            throw th;
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void setAnonymizeIp(boolean z) {
        this.anonymizeIp = z;
    }

    @Override // com.google.android.apps.analytics.HitStore
    public boolean setReferrer(String str) {
        SQLiteDatabase sQLiteDatabase = null;
        String formatReferrer = formatReferrer(str);
        if (formatReferrer == null) {
            return false;
        }
        try {
            sQLiteDatabase = this.databaseHelper.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put("referrer", formatReferrer);
            contentValues.put(TIMESTAMP_REFERRER, (Long) 0L);
            sQLiteDatabase.beginTransaction();
            sQLiteDatabase.delete("referrer", null, null);
            sQLiteDatabase.insert("referrer", null, contentValues);
            sQLiteDatabase.setTransactionSuccessful();
            startNewVisit();
            if (sQLiteDatabase != null) {
                sQLiteDatabase.endTransaction();
            }
            return true;
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (sQLiteDatabase == null) {
                return false;
            }
            sQLiteDatabase.endTransaction();
            return false;
        } catch (Throwable th) {
            if (sQLiteDatabase != null) {
                sQLiteDatabase.endTransaction();
            }
            throw th;
        }
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void setSampleRate(int i) {
        this.sampleRate = i;
    }

    @Override // com.google.android.apps.analytics.HitStore
    public void startNewVisit() {
        this.sessionStarted = false;
        this.useStoredVisitorVars = true;
        this.numStoredHits = getNumStoredHits();
    }

    /* access modifiers changed from: package-private */
    public void storeUpdatedSession() {
        SQLiteDatabase sQLiteDatabase = null;
        try {
            SQLiteDatabase writableDatabase = this.databaseHelper.getWritableDatabase();
            writableDatabase.beginTransaction();
            writableDatabase.delete("session", null, null);
            if (this.timestampFirst == 0) {
                long currentTimeMillis = System.currentTimeMillis() / 1000;
                this.timestampFirst = currentTimeMillis;
                this.timestampPrevious = currentTimeMillis;
                this.timestampCurrent = currentTimeMillis;
                this.visits = 1;
            } else {
                this.timestampPrevious = this.timestampCurrent;
                this.timestampCurrent = System.currentTimeMillis() / 1000;
                this.visits++;
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put(TIMESTAMP_FIRST, Long.valueOf(this.timestampFirst));
            contentValues.put(TIMESTAMP_PREVIOUS, Long.valueOf(this.timestampPrevious));
            contentValues.put(TIMESTAMP_CURRENT, Long.valueOf(this.timestampCurrent));
            contentValues.put(VISITS, Integer.valueOf(this.visits));
            contentValues.put(STORE_ID, Integer.valueOf(this.storeId));
            writableDatabase.insert("session", null, contentValues);
            writableDatabase.setTransactionSuccessful();
            this.sessionStarted = true;
            if (writableDatabase != null) {
                writableDatabase.endTransaction();
            }
        } catch (SQLiteException e) {
            Log.e(GoogleAnalyticsTracker.LOG_TAG, e.toString());
            if (0 != 0) {
                sQLiteDatabase.endTransaction();
            }
        } catch (Throwable th) {
            if (0 != 0) {
                sQLiteDatabase.endTransaction();
            }
            throw th;
        }
    }
}
