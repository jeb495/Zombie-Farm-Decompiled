package com.bestcoolfungames.adsclient;

public interface BCFGAdsListener {
    void adNotReceived();

    void adReceived();
}
