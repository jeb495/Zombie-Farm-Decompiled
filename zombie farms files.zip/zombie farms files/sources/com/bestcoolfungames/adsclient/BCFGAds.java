package com.bestcoolfungames.adsclient;

import android.accounts.AccountManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import com.android.adsymp.core.ASConstants;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Date;
import java.util.Locale;

public class BCFGAds {
    private static final String serverURL = "http://androidsdk.bestcoolfungames.com";
    private String adURL;
    private boolean isReady = false;
    public BCFGAdsListener listener;
    private Context mContext;

    public enum gender {
        MALE,
        FEMALE
    }

    public BCFGAds(Context context) {
        this.mContext = context;
    }

    public BCFGAds(Context context, BCFGAdsListener l) {
        this.mContext = context;
        this.listener = l;
    }

    public boolean isReady() {
        return this.isReady;
    }

    public static void setBirthYear(Context c, int age) {
        if (age < 0) {
            throw new IllegalStateException("Age must be >= 0");
        }
        SharedPreferences.Editor editor = c.getSharedPreferences("BCFGADSData", 1).edit();
        editor.putInt("age-" + c.getApplicationInfo().packageName, age);
        editor.commit();
    }

    public static void setGender(Context c, gender g) {
        if (g == gender.MALE || g == gender.FEMALE) {
            String key = "gender-" + c.getApplicationInfo().packageName;
            SharedPreferences.Editor editor = c.getSharedPreferences("BCFGADSData", 1).edit();
            editor.putString(key, g == gender.MALE ? "Male" : "Female");
            editor.commit();
            return;
        }
        throw new IllegalStateException("Invalid Gender");
    }

    public static void setUserData(Context c, int age, gender g) {
        setBirthYear(c, age);
        setGender(c, g);
    }

    private class LoadAd extends AsyncTask<Void, Void, Boolean> {
        private LoadAd() {
        }

        /* synthetic */ LoadAd(BCFGAds bCFGAds, LoadAd loadAd) {
            this();
        }

        /* access modifiers changed from: protected */
        public Boolean doInBackground(Void... param) {
            try {
                String appID = BCFGAds.this.mContext.getPackageName().toLowerCase();
                String deviceID = BCFGAds.getUserID(BCFGAds.this.mContext);
                String locale = Locale.getDefault().getLanguage();
                SharedPreferences settings = BCFGAds.this.mContext.getSharedPreferences("BCFGADSData", 1);
                int age = settings.getInt("age-" + BCFGAds.this.mContext.getApplicationInfo().packageName, 0);
                String gender = settings.getString("gender-" + BCFGAds.this.mContext.getApplicationInfo().packageName, "Both");
                if (age != 0) {
                    age = (new Date().getYear() - age) + 1900;
                }
                String receivedData = new BufferedReader(new InputStreamReader(new URL("http://androidsdk.bestcoolfungames.com/pushnotification/requestAd/requestAdLinkV2/request?app=" + appID + "&device=" + deviceID + "&country=" + locale + "&gender=" + gender + "&age=" + age).openStream())).readLine();
                if (!receivedData.equals("NULL")) {
                    BCFGAds.this.isReady = true;
                    BCFGAds.this.adURL = receivedData;
                    return true;
                }
                BCFGAds.this.isReady = false;
                return false;
            } catch (Throwable th) {
                return false;
            }
        }

        /* access modifiers changed from: protected */
        public void onPostExecute(Boolean param) {
            if (param.booleanValue()) {
                if (BCFGAds.this.listener != null) {
                    BCFGAds.this.listener.adReceived();
                }
            } else if (BCFGAds.this.listener != null) {
                BCFGAds.this.listener.adNotReceived();
            }
        }
    }

    public void requestAd() {
        try {
            new LoadAd(this, null).execute(null);
        } catch (Exception e) {
        }
    }

    public void showAd(Context c) {
        if (this.isReady) {
            new AlertDialog.Builder(c).setTitle(this.adURL.substring(this.adURL.lastIndexOf("&") + 1, this.adURL.length() - 1)).setPositiveButton("No, thanks.", new DialogInterface.OnClickListener() {
                /* class com.bestcoolfungames.adsclient.BCFGAds.AnonymousClass1 */

                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }).setNegativeButton("Yes, sure!", new DialogInterface.OnClickListener() {
                /* class com.bestcoolfungames.adsclient.BCFGAds.AnonymousClass2 */

                public void onClick(DialogInterface dialog, int which) {
                    BCFGAds.this.isReady = false;
                    try {
                        BCFGAds.this.mContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(BCFGAds.this.adURL.substring(0, BCFGAds.this.adURL.lastIndexOf("&") + 1))));
                    } catch (Throwable th) {
                    }
                    dialog.dismiss();
                }
            }).show();
        }
    }

    public String message() {
        if (this.isReady) {
            return this.adURL.substring(this.adURL.lastIndexOf("&") + 1, this.adURL.length() - 1);
        }
        return ASConstants.kEmptyString;
    }

    public void yesPressed() {
        if (this.isReady) {
            this.isReady = false;
            try {
                this.mContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(this.adURL.substring(0, this.adURL.lastIndexOf("&") + 1))));
            } catch (Throwable th) {
            }
        }
    }

    public static void registerInstall(final Context c) {
        new Thread(new Runnable() {
            /* class com.bestcoolfungames.adsclient.BCFGAds.AnonymousClass3 */

            public void run() {
                try {
                    String appID = c.getPackageName();
                    new BufferedReader(new InputStreamReader(new URL("http://androidsdk.bestcoolfungames.com/pushnotification/requestAd/registerAdInstall/" + appID + "&" + BCFGAds.getUserID(c) + "/").openStream())).readLine();
                } catch (Throwable th) {
                }
            }
        }).start();
    }

    /* access modifiers changed from: private */
    public static String getUserID(Context c) {
        try {
            return AccountManager.get(c).getAccounts()[0].name;
        } catch (Throwable th) {
            return "null";
        }
    }
}
