package com.android.adsymp.ad;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.android.adsymp.core.ASConstants;
import com.android.adsymp.core.ASPartnerInfo;
import com.android.adsymp.core.ASResponse;
import com.android.adsymp.net.ASNetDownloadServices;
import com.android.adsymp.net.ASNetServices;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ASAdBannerView extends WebView {
    private HashMap<String, String> adData = null;
    private ASNetDownloadServices downloadServices;
    private boolean fetchingAd;
    private ASNetServices netServices;
    private Context parentContext;
    private Runnable r = new Runnable() {
        /* class com.android.adsymp.ad.ASAdBannerView.AnonymousClass2 */

        public void run() {
            ASAdBannerView.this.postAdRequest();
        }
    };
    private Handler refreshHandler = new Handler();
    private Integer refreshRate = 60;
    private ASResponse serverResponse;
    private WebViewClient webClient = new WebViewClient() {
        /* class com.android.adsymp.ad.ASAdBannerView.AnonymousClass1 */

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            ASAdBannerView.this.reportClick(view.getContext());
            Intent i = new Intent(view.getContext(), ASAdActivity.class);
            if (url.contains("a_video_tmpl")) {
                Intent i2 = new Intent("android.intent.action.VIEW");
                i2.setDataAndType(Uri.parse((String) ASAdBannerView.this.serverResponse.fields().get("{adVideoURL}")), "video/*");
                view.getContext().startActivity(i2);
            } else if (url.startsWith(ASConstants.kASProtocolPrefix) && !url.contains("http")) {
                String data = null;
                try {
                    data = ASAdBannerView.readFileAsString(view.getContext().getCacheDir() + "/" + url.substring(url.indexOf("=") + 1, url.length()));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String data2 = ASAdBannerView.this.replaceFieldsFromResponse(data);
                i.putExtra("baseURL", "file://" + view.getContext().getCacheDir() + "/");
                i.putExtra(ASConstants.kASResponseKeyData, data2);
                view.getContext().startActivity(i);
            } else if (!url.startsWith(ASConstants.kASProtocolPrefix) || !url.contains("http")) {
                Intent i3 = new Intent("android.intent.action.VIEW");
                i3.setData(Uri.parse(url));
                view.getContext().startActivity(i3);
            } else {
                i.putExtra("baseURL", url.split("=")[1]);
                i.putExtra(ASConstants.kASResponseKeyData, ASConstants.kEmptyString);
                view.getContext().startActivity(i);
            }
            return true;
        }
    };

    public ASAdBannerView(Context context) {
        super(context);
        this.parentContext = context;
        this.netServices = new ASNetServices();
        this.netServices.userAgent = getSettings().getUserAgentString();
        this.downloadServices = new ASNetDownloadServices();
        this.fetchingAd = false;
        getSettings().setSupportZoom(false);
        getSettings().setJavaScriptEnabled(true);
        getSettings().setAllowFileAccess(true);
        getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        setWebViewClient(this.webClient);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void reportClick(final Context context) {
        final String clickURL = (String) this.serverResponse.fields().get("{adClickURL}");
        new Thread(new Runnable() {
            /* class com.android.adsymp.ad.ASAdBannerView.AnonymousClass3 */

            public void run() {
                ASAdBannerView.this.netServices.postRequestTo(context, clickURL);
            }
        }).start();
    }

    public void setRefreshRate(int seconds) {
        this.refreshRate = Integer.valueOf(seconds);
    }

    public void stopAdRefresh() {
        this.refreshHandler.removeCallbacks(this.r);
    }

    public void fetchAd(HashMap data) {
        if (this.adData == null) {
            this.adData = new HashMap<>();
        }
        this.adData.clear();
        this.adData.putAll(ASPartnerInfo.partnerInfo());
        this.adData.putAll(data);
        postAdRequest();
    }

    public void postAdRequest() {
        if (!this.fetchingAd) {
            this.fetchingAd = true;
            new Thread(new Runnable() {
                /* class com.android.adsymp.ad.ASAdBannerView.AnonymousClass4 */

                public void run() {
                    ASResponse response = ASAdBannerView.this.netServices.postRequestTo(ASAdBannerView.this.getContext(), ASConstants.kASAdServerUrl, ASAdBannerView.this.adData);
                    if (response != null) {
                        ASAdBannerView.this.connectionDidFinishWithResponse(response);
                    } else {
                        Log.i("Asdymp", "Please check your internet connection");
                    }
                    ASAdBannerView.this.refreshHandler.postDelayed(ASAdBannerView.this.r, (long) (ASAdBannerView.this.refreshRate.intValue() * 1000));
                }
            }).start();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void connectionDidFinishWithResponse(ASResponse response) {
        try {
            this.fetchingAd = false;
            this.serverResponse = response;
            if (this.serverResponse.status().intValue() == 0) {
                prepareAd();
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Log.e("ASAdBannerView", "Bad Request or Missing args");
        }
    }

    private void prepareAd() {
        this.downloadServices.parseFields = this.serverResponse.fields();
        clearCache(true);
        for (Map.Entry entry : this.serverResponse.assets().entrySet()) {
            String assetName = (String) entry.getKey();
            String assetValue = (String) entry.getValue();
            Log.i("Asset Name ", assetName);
            Log.i("Asset Value ", assetValue);
            this.downloadServices.addFileToDownload(assetValue, getContext().getCacheDir() + "/" + assetName.replace(ASConstants.kBraceOpen, ASConstants.kEmptyString).replace(ASConstants.kBraceClose, ASConstants.kEmptyString) + "." + assetValue.substring(assetValue.lastIndexOf(".") + 1, assetValue.length()));
        }
        this.downloadServices.addFileToDownload(this.serverResponse.AStemplate(), getContext().getCacheDir() + "/" + this.serverResponse.AStemplate().substring(this.serverResponse.AStemplate().lastIndexOf("/") + 1, this.serverResponse.AStemplate().length()));
        this.downloadServices.startDownload();
        String data = null;
        try {
            data = readFileAsString(getContext().getCacheDir() + "/sb_plain.html");
        } catch (IOException e) {
            e.printStackTrace();
        }
        String data2 = replaceFieldsFromResponse(data);
        loadDataWithBaseURL("file://" + getContext().getCacheDir() + "/", data2, "text/html", "utf-8", null);
        Log.i(ASConstants.kASResponseKeyData, data2);
        this.fetchingAd = false;
    }

    /* access modifiers changed from: private */
    public static String readFileAsString(String filePath) throws IOException {
        byte[] buffer = new byte[((int) new File(filePath).length())];
        new FileInputStream(filePath).read(buffer);
        return new String(buffer);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private String replaceFieldsFromResponse(String data) {
        for (Map.Entry entry : this.serverResponse.fields().entrySet()) {
            data = data.replace((String) entry.getKey(), ((String) entry.getValue()).replaceAll("\\{", ASConstants.kEmptyString).replaceAll("\\}", ASConstants.kEmptyString));
        }
        return data;
    }
}
