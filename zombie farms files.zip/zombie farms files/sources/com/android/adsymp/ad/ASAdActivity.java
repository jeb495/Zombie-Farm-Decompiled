package com.android.adsymp.ad;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import com.android.adsymp.core.ASConstants;

public class ASAdActivity extends Activity {
    WebView adView;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(1);
        try {
            Bundle extras = getIntent().getExtras();
            String baseURL = extras.getString("baseURL");
            String data = extras.getString(ASConstants.kASResponseKeyData);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -1);
            this.adView = new WebView(this);
            LinearLayout webLayout = new LinearLayout(this);
            webLayout.addView(this.adView, lp);
            this.adView.getSettings().setJavaScriptEnabled(true);
            this.adView.getSettings().setAllowFileAccess(true);
            this.adView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
            this.adView.getSettings().setAppCacheEnabled(true);
            this.adView.getSettings().setBuiltInZoomControls(true);
            this.adView.getSettings().setDatabaseEnabled(true);
            this.adView.getSettings().setSupportZoom(true);
            this.adView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.CLOSE);
            if (baseURL.contains("http")) {
                this.adView.loadUrl(baseURL);
            } else {
                this.adView.loadDataWithBaseURL(baseURL, data, "text/html", "utf-8", null);
            }
            setContentView(webLayout);
        } catch (Exception e) {
        }
    }

    /* access modifiers changed from: protected */
    public void onStart() {
        super.onStart();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        this.adView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);
        super.onDestroy();
    }
}
