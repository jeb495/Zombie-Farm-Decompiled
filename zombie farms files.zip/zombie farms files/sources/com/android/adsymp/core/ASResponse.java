package com.android.adsymp.core;

import java.util.HashMap;
import java.util.Map;

public class ASResponse {
    HashMap data_;

    public ASResponse(int statusCode) {
        this.data_ = new HashMap();
        this.data_.put(ASConstants.kASResponseKeyStatusCode, Integer.toString(statusCode));
    }

    public ASResponse(HashMap data) {
        this.data_ = data;
        try {
            for (Map.Entry entry : fields().entrySet()) {
                fields().put(entry.getKey(), processTemplateDocument((String) entry.getValue(), fields()));
            }
        } catch (NullPointerException e) {
        }
    }

    public Integer status() {
        return (Integer) this.data_.get(ASConstants.kASResponseKeyStatusCode);
    }

    public String uuid() {
        try {
            return (String) ((HashMap) ((HashMap) this.data_.get(ASConstants.kASResponseKeyData)).get(ASConstants.kASResponseKeyBody)).get("uuid");
        } catch (NullPointerException e) {
            return null;
        }
    }

    public String AStemplate() {
        return (String) ((HashMap) ((HashMap) this.data_.get(ASConstants.kASResponseKeyData)).get(ASConstants.kASResponseKeyBody)).get(ASConstants.kASResponseKeyTmpl);
    }

    public HashMap fields() {
        return (HashMap) ((HashMap) ((HashMap) this.data_.get(ASConstants.kASResponseKeyData)).get(ASConstants.kASResponseKeyBody)).get(ASConstants.kASResponseKeyFields);
    }

    public HashMap assets() {
        HashMap items = null;
        for (Map.Entry entry : fields().entrySet()) {
            if (((String) entry.getKey()).startsWith(ASConstants.kASPrefixAssetTag)) {
                if (items == null) {
                    items = new HashMap();
                }
                items.put(ASUtils.stripBraces((String) entry.getKey()), entry.getValue());
            }
        }
        return items;
    }

    public static String processTemplateData(String data, HashMap fields) {
        return processTemplateDocument(data, fields);
    }

    public static String processTemplateDocument(String content, HashMap fields) {
        for (Map.Entry entry : fields.entrySet()) {
            String fieldKey = (String) entry.getKey();
            String fieldValue = (String) entry.getValue();
            if (fieldKey.startsWith(ASConstants.kASPrefixAssetTag)) {
                fieldValue = String.valueOf(ASUtils.stripBraces(fieldKey)) + "." + fieldValue.substring(fieldValue.lastIndexOf(".") + 1, fieldValue.length());
            }
            content = content.replace(fieldKey, fieldValue);
        }
        return content;
    }
}
