package com.android.adsymp.core;

import com.g6pay.sdk.G6Pay;
import java.util.HashMap;

public class ASPartnerInfo {
    public static HashMap partnerInfo() {
        HashMap<String, String> info = new HashMap<>();
        info.put(ASConstants.kASPostFieldPublisherId, "1000");
        info.put(ASConstants.kASPostFieldPublisherSignature, "8532daba8ac9c9a9a1781efc46d6b331");
        info.put(ASConstants.kASPostFieldAppId, "XXXXX");
        info.put(ASConstants.kASPostFieldSDKVersion, G6Pay.VERSION);
        return info;
    }
}
