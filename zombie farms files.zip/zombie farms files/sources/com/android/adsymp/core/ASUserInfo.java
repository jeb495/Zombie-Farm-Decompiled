package com.android.adsymp.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import com.flurry.android.Constants;
import com.tapjoy.TapjoyConstants;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

public class ASUserInfo {
    private static final String INSTALLATION = "INSTALLATION";
    private static final String PREFS_NAME = "UserUUID";
    private static String sID = null;

    public static String getUUID(Context context) {
        return context.getSharedPreferences(PREFS_NAME, 0).getString("uuid", null);
    }

    public static void setUUID(String uuid, Context context) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS_NAME, 0).edit();
        editor.putString("uuid", uuid);
        editor.commit();
    }

    public static String deviceHash(Context context) {
        try {
            return hash(String.valueOf(Settings.System.getString(context.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID)) + "." + ASConstants.kASUDIDSalt, "MD5");
        } catch (NullPointerException e) {
            return "android";
        }
    }

    public static HashMap userInfo(Context context) {
        HashMap info = new HashMap();
        info.put(ASConstants.kASPostFieldUUID, getUUID(context));
        info.put(ASConstants.kASPostFieldDeviceHash, deviceHash(context));
        return info;
    }

    public static String hash(String data, String algorithm) {
        try {
            MessageDigest md = MessageDigest.getInstance(algorithm);
            byte[] bytes = data.getBytes();
            md.reset();
            md.update(bytes);
            byte[] digest = md.digest();
            StringBuilder hexVal = new StringBuilder(32);
            for (byte b : digest) {
                String hex = Integer.toHexString(b & Constants.UNKNOWN);
                if (hex.length() == 1) {
                    hexVal.append('0');
                }
                hexVal.append(hex);
            }
            return hexVal.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }
}
