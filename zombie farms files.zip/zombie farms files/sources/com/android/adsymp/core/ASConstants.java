package com.android.adsymp.core;

public class ASConstants {
    public static final String KASVerbClose = "close";
    public static final String kASAdServerUrl = "http://ads.adsymptotic.com/a/sdk";
    public static final String kASConversionTrackingUrl = "https://api.adsymptotic.com/api/s/trackconversion";
    public static final String kASDataServerUrl = "http://p.adsymptotic.com/d/";
    public static final String kASDefaultLabel = "CT";
    public static final String kASDefaultSDKVersion = "1";
    public static final String kASIsConversionTracking = "AdsympConversionTracking";
    public static final int kASOverlayDefaultHeight = 480;
    public static final int kASOverlayDefaultWidth = 320;
    public static final String kASParamCloseButton = "closeButton";
    public static final String kASParamHeight = "h";
    public static final String kASParamUrl = "u";
    public static final String kASParamWidth = "w";
    public static final int kASPhoneBannerHeight = 50;
    public static final int kASPhoneBannerWidth = 300;
    public static final String kASPostFieldAppId = "_aid";
    public static final String kASPostFieldDPID = "_dpid";
    public static final String kASPostFieldDeviceHash = "_udid";
    public static final String kASPostFieldLabel = "_lbl";
    public static final String kASPostFieldPublisherId = "_pid";
    public static final String kASPostFieldPublisherSignature = "_psign";
    public static final String kASPostFieldSDKVersion = "_sv";
    public static final String kASPostFieldUUID = "_uuid";
    public static final String kASPostFieldUserAgent = "_ua";
    public static final String kASPrefKeyUUID = "uuid";
    public static final String kASPrefixAssetTag = "{a_";
    public static final String kASProtocolPrefix = "adsymp://";
    public static final String kASResponseKeyBody = "body";
    public static final String kASResponseKeyData = "data";
    public static final String kASResponseKeyFields = "fields";
    public static final String kASResponseKeyStatusCode = "code";
    public static final String kASResponseKeyTmpl = "tmpl";
    public static final String kASResponseKeyType = "type";
    public static final String kASResponseKeyUUID = "uuid";
    public static final boolean kASToHashUDID = true;
    public static final String kASUDIDSalt = "adsymp09192010";
    public static final String kASVerbOpen = "open";
    public static final String kBraceClose = "}";
    public static final String kBraceOpen = "{";
    public static final String kEmptyString = "";

    public enum ASStatus {
        OK,
        ErrorGeneral
    }
}
