package com.android.adsymp.core;

public class ASUtils {
    ASUtils() {
    }

    public static String stripBraces(String word) {
        if (!word.startsWith(ASConstants.kBraceOpen) || !word.startsWith(ASConstants.kBraceClose)) {
            return word;
        }
        return word.replace(ASConstants.kBraceOpen, ASConstants.kEmptyString).replace(ASConstants.kBraceClose, ASConstants.kBraceOpen);
    }
}
