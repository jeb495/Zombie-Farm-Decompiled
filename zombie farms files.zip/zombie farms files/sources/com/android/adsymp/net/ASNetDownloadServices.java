package com.android.adsymp.net;

import android.util.Log;
import com.android.adsymp.core.ASResponse;
import com.google.ads.AdActivity;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.util.ByteArrayBuffer;

public class ASNetDownloadServices {
    public HashMap parseFields = null;
    public HashMap queueFiles = null;

    public void addFileToDownload(String file, String path) {
        if (this.queueFiles == null) {
            this.queueFiles = new HashMap();
        }
        this.queueFiles.put(file, path);
    }

    public void startDownload() {
        if (this.queueFiles != null && this.queueFiles.size() != 0) {
            Map.Entry entry = (Map.Entry) this.queueFiles.entrySet().iterator().next();
            String file = (String) entry.getKey();
            String path = (String) entry.getValue();
            Log.i("ASNetDownloadServices:StartDownload", String.valueOf(file) + " , " + path);
            try {
                BufferedInputStream bis = new BufferedInputStream(new URL(file).openConnection().getInputStream());
                ByteArrayBuffer bab = new ByteArrayBuffer(64);
                while (true) {
                    int current = bis.read();
                    if (current == -1) {
                        break;
                    }
                    bab.append((byte) current);
                }
                File f = new File(path);
                try {
                    f.createNewFile();
                    FileOutputStream fos = new FileOutputStream(f);
                    fos.write(bab.toByteArray());
                    fos.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                connectionDidFinishLoading(file, path, new String(bab.toByteArray()));
            } catch (Exception e2) {
                Log.i("ASNetDownloadServices:StartDownload", "startDownload Failed! can't download " + file);
            }
        }
    }

    private void connectionDidFinishLoading(String file, String path, String data) {
        String[] parsedDocuments = {AdActivity.HTML_PARAM, "js", "css"};
        String pathExtension = path.substring(path.lastIndexOf("."), path.length());
        for (int i = 0; i < 3; i++) {
            if (parsedDocuments[i].trim() == pathExtension.trim()) {
                data = ASResponse.processTemplateData(data, this.parseFields);
            }
        }
        this.queueFiles.remove(file);
        startDownload();
    }
}
