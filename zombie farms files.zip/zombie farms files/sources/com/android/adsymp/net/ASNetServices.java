package com.android.adsymp.net;

import android.content.Context;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.android.adsymp.core.ASResponse;
import com.android.adsymp.core.ASUserInfo;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ASNetServices {
    private static int requestCounter = 0;
    public String userAgent = ASConstants.kEmptyString;

    public ASResponse postRequestTo(Context context, String hostURL, HashMap requestData) {
        List<NameValuePair> postData = new ArrayList<>(7);
        for (Map.Entry entry : requestData.entrySet()) {
            postData.add(new BasicNameValuePair((String) entry.getKey(), (String) entry.getValue()));
        }
        for (Map.Entry entry2 : ASUserInfo.userInfo(context).entrySet()) {
            postData.add(new BasicNameValuePair((String) entry2.getKey(), (String) entry2.getValue()));
        }
        postData.add(new BasicNameValuePair("_cnt", Integer.toString(requestCounter)));
        return sendHTTPRequest(context, postData, hostURL);
    }

    public void postRequestTo(final Context context, final String hostURL) {
        new Thread() {
            /* class com.android.adsymp.net.ASNetServices.AnonymousClass1 */

            public void run() {
                ASNetServices.this.sendHTTPRequest(context, null, hostURL);
            }
        }.start();
    }

    private void gotHTTPResponse(Context context, String response) {
        try {
            Log.i("ASResponse ", response);
            ASUserInfo.setUUID((String) ((JSONObject) new JSONObject(response).get(ASConstants.kASResponseKeyData)).getJSONObject(ASConstants.kASResponseKeyBody).get("uuid"), context);
        } catch (JSONException e) {
            Log.e("AdSymptotic:ASNetServices", e.getMessage());
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private ASResponse sendHTTPRequest(Context context, List<NameValuePair> postData, String hostURL) {
        HttpClient httpclient = new DefaultHttpClient();
        HttpPost httppost = new HttpPost(hostURL);
        httppost.setHeader("User-Agent", this.userAgent);
        httppost.setHeader("Content-Type", "application/x-www-form-urlencoded");
        if (postData != null) {
            try {
                httppost.setEntity(new UrlEncodedFormEntity(postData));
            } catch (ClientProtocolException e) {
                Log.e("AdSymptotic:ASNetServices", e.getMessage());
                return null;
            } catch (IOException e2) {
                Log.e("AdSymptotic:ASNetServices", e2.getMessage());
                return null;
            } catch (ParseException e3) {
                e3.printStackTrace();
                return null;
            }
        }
        String responseString = EntityUtils.toString(httpclient.execute(httppost).getEntity());
        Log.i("ASNetServices", "AdSymp Request Completed");
        Log.i("ASNETServices", "Response = " + responseString);
        requestCounter++;
        ASResponse as_response = new ASResponse(getHashMap(responseString));
        if (as_response.uuid() == null) {
            return as_response;
        }
        gotHTTPResponse(context, responseString);
        return as_response;
    }

    private HashMap getHashMap(String response) {
        HashMap map = new HashMap();
        try {
            JSONObject obj = new JSONObject(response);
            JSONObject data = obj.getJSONObject(ASConstants.kASResponseKeyData);
            int code = obj.getInt(ASConstants.kASResponseKeyStatusCode);
            String type = data.getString("type");
            JSONObject body = data.getJSONObject(ASConstants.kASResponseKeyBody);
            String tmpl = body.getString(ASConstants.kASResponseKeyTmpl);
            JSONObject fields = body.getJSONObject(ASConstants.kASResponseKeyFields);
            JSONArray field_names = fields.names();
            HashMap fields_map = new HashMap();
            for (int i = 0; i < fields.length(); i++) {
                fields_map.put(field_names.getString(i), fields.getString(field_names.getString(i)));
            }
            HashMap body_map = new HashMap();
            body_map.put(ASConstants.kASResponseKeyTmpl, tmpl);
            body_map.put(ASConstants.kASResponseKeyFields, fields_map);
            HashMap data_map = new HashMap();
            data_map.put("type", type);
            data_map.put(ASConstants.kASResponseKeyBody, body_map);
            map.put(ASConstants.kASResponseKeyData, data_map);
            map.put(ASConstants.kASResponseKeyStatusCode, Integer.valueOf(code));
        } catch (Exception e) {
        }
        return map;
    }
}
