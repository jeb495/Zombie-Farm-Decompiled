package com.android.adsymp.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.android.adsymp.core.ASConstants;
import com.android.adsymp.core.ASPartnerInfo;
import com.android.adsymp.core.ASUserInfo;
import com.android.adsymp.net.ASNetServices;
import java.util.HashMap;
import java.util.Map;

public class ASConversionTracking {
    public static final String PREFS_NAME = "AdsympPrefsFile";
    private ASNetServices netServices = new ASNetServices();
    private HashMap postData = new HashMap();

    public ASConversionTracking() {
        this.postData.putAll(ASPartnerInfo.partnerInfo());
    }

    public void addPostDataWithKey(String key, String value) {
        Log.i("ASConversionTracking", "adding post data with key");
        this.postData.put(key, value);
    }

    public void addPostData(HashMap data) {
        for (Map.Entry entry : data.entrySet()) {
            this.postData.put(entry.getKey(), entry.getValue());
        }
    }

    public void post(Context context) {
        WebSettings webSettings = new WebView(context).getSettings();
        this.netServices.userAgent = webSettings.getUserAgentString();
        this.postData.put(ASConstants.kASPostFieldUserAgent, webSettings.getUserAgentString());
        this.postData.put(ASConstants.kASPostFieldLabel, ASConstants.kASDefaultLabel);
        this.postData.put(ASConstants.kASPostFieldDPID, ASUserInfo.deviceHash(context));
        this.postData.put(ASConstants.kASPostFieldSDKVersion, "1");
        SharedPreferences settings = context.getSharedPreferences(PREFS_NAME, 0);
        if (settings.getInt(ASConstants.kASIsConversionTracking, 0) == 0) {
            SharedPreferences.Editor editor = settings.edit();
            editor.putInt(ASConstants.kASIsConversionTracking, 1);
            editor.commit();
            this.netServices.postRequestTo(context, ASConstants.kASConversionTrackingUrl, this.postData);
        }
    }
}
