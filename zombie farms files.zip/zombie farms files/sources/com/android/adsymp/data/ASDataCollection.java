package com.android.adsymp.data;

import android.content.Context;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.android.adsymp.core.ASConstants;
import com.android.adsymp.core.ASPartnerInfo;
import com.android.adsymp.net.ASNetServices;
import java.util.HashMap;
import java.util.Map;

public class ASDataCollection {
    private ASNetServices netServices = new ASNetServices();
    private HashMap postData = new HashMap();

    public ASDataCollection() {
        this.postData.putAll(ASPartnerInfo.partnerInfo());
    }

    public void addPostDataWithKey(String key, String value) {
        this.postData.put(key, value);
    }

    public void addPostData(HashMap data) {
        for (Map.Entry entry : data.entrySet()) {
            this.postData.put(entry.getKey(), entry.getValue());
        }
    }

    public void post(Context context) {
        WebSettings webSettings = new WebView(context).getSettings();
        this.netServices.userAgent = webSettings.getUserAgentString();
        this.netServices.postRequestTo(context, ASConstants.kASDataServerUrl, this.postData);
        HashMap partnerInfo = new HashMap();
        partnerInfo.put(ASConstants.kASPostFieldPublisherId, this.postData.get(ASConstants.kASPostFieldPublisherId));
        partnerInfo.put(ASConstants.kASPostFieldPublisherSignature, this.postData.get(ASConstants.kASPostFieldPublisherSignature));
        partnerInfo.put(ASConstants.kASPostFieldAppId, this.postData.get(ASConstants.kASPostFieldAppId));
        partnerInfo.put(ASConstants.kASPostFieldSDKVersion, this.postData.get(ASConstants.kASPostFieldSDKVersion));
        this.postData.clear();
        this.postData.putAll(partnerInfo);
    }
}
