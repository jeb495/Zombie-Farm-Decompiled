package com.g6pay.listener;

import com.g6pay.dto.OfferDTO;

public abstract class G6OfferListener {
    public void offerWasCompleted(OfferDTO offer) {
    }
}
