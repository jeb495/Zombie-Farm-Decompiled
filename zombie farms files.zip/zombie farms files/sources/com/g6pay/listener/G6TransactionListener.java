package com.g6pay.listener;

import com.g6pay.dto.TransactionDTO;
import java.util.ArrayList;

public abstract class G6TransactionListener {
    public void getAllTransactionsSuccess(String userId, ArrayList<TransactionDTO> arrayList) {
    }

    public void getAllTransactionsFail(String userId) {
    }
}
