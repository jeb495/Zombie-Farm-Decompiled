package com.g6pay.util;

import com.g6pay.dto.OfferDTO;
import com.g6pay.dto.TransactionDTO;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class ResponseParser {
    private static final String DTO_DATE = "date";
    private static final String DTO_DESC = "description";
    private static final String DTO_NET_PAYOUT = "net_payout";
    private static final String DTO_OFFER_ID = "offer_id";
    private static final String DTO_OFFER_NAME = "offer_name";
    private static final String DTO_SIGNATURE = "signature";
    private static final String DTO_USER_BALANCE = "user_balance";
    private static final String DTO_USER_ID = "user_id";
    private static final String DTO_VIR_CUR_AMT = "virtual_currency_amount";
    private static String sdfs = "yyyy-MM-dd' 'HH:mm:ss";

    private static SimpleDateFormat getSdf() {
        return new SimpleDateFormat(sdfs);
    }

    private static Date parseDate(String dateString) {
        try {
            return getSdf().parse(dateString);
        } catch (Exception e) {
            return null;
        }
    }

    public static OfferDTO offerFromMap(HashMap<String, String> map) {
        OfferDTO dto = new OfferDTO();
        if (map.get("user_id") != null) {
            dto.setUserId(map.get("user_id"));
        }
        if (map.get("offer_id") != null) {
            dto.setOfferId(map.get("offer_id"));
        }
        if (map.get("offer_name") != null) {
            dto.setOfferName(map.get("offer_name"));
        }
        if (map.get("net_payout") != null) {
            try {
                dto.setNetPayout(Float.parseFloat(map.get("net_payout")));
            } catch (Exception e) {
            }
        }
        if (map.get("virtual_currency_amount") != null) {
            try {
                dto.setVirtualCurrencyAmount(Float.parseFloat(map.get("virtual_currency_amount")));
            } catch (Exception e2) {
            }
        }
        if (map.get("signature") != null) {
            dto.setSignature(map.get("signature"));
        }
        if (map.get("user_balance") != null) {
            try {
                dto.setUserBalance(Float.parseFloat(map.get("user_balance")));
            } catch (Exception e3) {
            }
        }
        return dto;
    }

    public static TransactionDTO transactionFromMap(HashMap<String, String> map) {
        TransactionDTO dto = new TransactionDTO();
        if (map.get("user_id") != null) {
            dto.setUserId(map.get("user_id"));
        }
        if (map.get("offer_id") != null) {
            dto.setOfferId(map.get("offer_id"));
        }
        if (map.get("offer_name") != null) {
            dto.setOfferName(map.get("offer_name"));
        }
        if (map.get("net_payout") != null) {
            try {
                dto.setNetPayout(Float.parseFloat(map.get("net_payout")));
            } catch (Exception e) {
            }
        }
        if (map.get("virtual_currency_amount") != null) {
            try {
                dto.setVirtualCurrencyAmount(Float.parseFloat(map.get("virtual_currency_amount")));
            } catch (Exception e2) {
            }
        }
        if (map.get("date") != null) {
            dto.setDate(parseDate(map.get("date")));
        }
        if (map.get("description") != null) {
            dto.setDescription(map.get("description"));
        }
        return dto;
    }

    public static ArrayList<TransactionDTO> parseTransactions(String response) {
        try {
            ArrayList<TransactionDTO> result = new ArrayList<>();
            String response2 = response.trim();
            String listOfDicts = response2.substring(1, response2.length());
            StringBuffer keyBuf = new StringBuffer();
            StringBuffer valBuf = new StringBuffer();
            boolean valueIsNum = false;
            boolean valueIsNull = false;
            String key = null;
            int state = 0;
            int oldState = 0;
            char oldC = '0';
            HashMap<String, String> dict = new HashMap<>();
            int i = 0;
            while (i < listOfDicts.length()) {
                char c = listOfDicts.charAt(i);
                if (oldState != state) {
                }
                oldState = state;
                switch (state) {
                    case 0:
                        valueIsNum = false;
                        valueIsNull = false;
                        keyBuf = new StringBuffer();
                        valBuf = new StringBuffer();
                        key = null;
                        dict = new HashMap<>();
                        if (c != '{') {
                            break;
                        } else {
                            state++;
                            break;
                        }
                    case 1:
                        if (c != '\"') {
                            break;
                        } else {
                            state++;
                            break;
                        }
                    case 2:
                        if (c != '\"') {
                            keyBuf.append(c);
                            break;
                        } else {
                            state++;
                            key = keyBuf.toString();
                            break;
                        }
                    case 3:
                        if (c != ':') {
                            break;
                        } else {
                            state++;
                            break;
                        }
                    case 4:
                        if ((c >= '0' && c <= '9') || c == '-' || c == '.') {
                            valueIsNum = true;
                            valBuf.append(c);
                            state++;
                        }
                        if (c == 'n') {
                            valueIsNull = true;
                            state++;
                        }
                        if (c != '\"') {
                            break;
                        } else {
                            valueIsNum = false;
                            valueIsNull = false;
                            state++;
                            break;
                        }
                    case 5:
                        boolean nextState = false;
                        if (valueIsNum) {
                            if ((c >= '0' && c <= '9') || c == '-' || c == '.') {
                                valBuf.append(c);
                            } else {
                                i--;
                                nextState = true;
                            }
                        } else if (valueIsNull) {
                            if (!(c == 'n' || c == 'u' || c == 'l')) {
                                i--;
                                nextState = true;
                            }
                        } else if (c != '\"' || oldC == '\\') {
                            valBuf.append(c);
                        } else {
                            nextState = true;
                        }
                        if (nextState) {
                            if (!valueIsNull) {
                                dict.put(key.trim(), valBuf.toString().trim());
                            }
                            state++;
                            keyBuf = new StringBuffer();
                            valBuf = new StringBuffer();
                            break;
                        } else {
                            break;
                        }
                    case 6:
                        if (c == ',') {
                            state = 1;
                        }
                        if (c != '}') {
                            break;
                        } else {
                            result.add(transactionFromMap(dict));
                            state = 0;
                            break;
                        }
                }
                oldC = c;
                i++;
            }
            return result;
        } catch (Exception e) {
            return null;
        }
    }

    public static OfferDTO parseOffer(String body) {
        try {
            HashMap<String, String> dict = new HashMap<>();
            for (String keyVal : body.trim().split(":")) {
                String[] keyValList = keyVal.split("=", 2);
                dict.put(keyValList[0], keyValList[1]);
            }
            OfferDTO offer = offerFromMap(dict);
            if (offer.getOfferId() == null) {
                return null;
            }
            return offer;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public static float balanceFromResponse(String body) throws Exception {
        try {
            String balance = body.trim().split(":", 2)[1].trim();
            if (balance.startsWith("\"")) {
                balance = balance.substring(1, balance.length() - 1);
            }
            return Float.parseFloat(balance);
        } catch (Exception e) {
            throw new Exception();
        }
    }
}
