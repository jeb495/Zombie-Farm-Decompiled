package com.g6pay.util;

import com.g6pay.constants.G6Params;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;

public class URLUtil {
    private static final String HEXES = "0123456789abcdef";
    private static final String checksumType = "SHA-256";

    public static String constructG6URL(String baseURL, LinkedHashMap<String, String> sigParams, Map<String, String> nonSigParams, String checksumKey) {
        String sig;
        StringBuffer b = new StringBuffer(baseURL);
        boolean hasSigKey = false;
        boolean first = true;
        if (sigParams != null && sigParams.size() > 0) {
            for (Map.Entry<String, String> entry : sigParams.entrySet()) {
                if (first) {
                    b.append("?");
                    first = false;
                } else {
                    b.append("&");
                }
                b.append(entry.getKey());
                b.append("=");
                b.append(URLEncoder.encode(entry.getValue()));
                if (entry.getKey().equals(G6Params.G6_PARAM_SIGNATURE)) {
                    hasSigKey = true;
                }
            }
            if (!(checksumType == 0 || checksumKey == null || (sig = constructSignature(sigParams, checksumKey)) == null)) {
                if (hasSigKey) {
                    b.append("&signature2=");
                } else {
                    b.append("&signature=");
                }
                b.append(URLEncoder.encode(sig));
            }
        }
        if (nonSigParams != null && nonSigParams.size() > 0) {
            for (Map.Entry<String, String> entry2 : nonSigParams.entrySet()) {
                if (first) {
                    b.append("?");
                    first = false;
                } else {
                    b.append("&");
                }
                b.append(entry2.getKey());
                b.append("=");
                b.append(URLEncoder.encode(entry2.getValue()));
            }
        }
        return b.toString();
    }

    public static String getHex(byte[] raw) {
        if (raw == null) {
            return null;
        }
        StringBuilder hex = new StringBuilder(raw.length * 2);
        for (byte b : raw) {
            hex.append(HEXES.charAt((b & 240) >> 4)).append(HEXES.charAt(b & 15));
        }
        return hex.toString();
    }

    public static String constructSignature(LinkedHashMap<String, String> params, String checksumKey) {
        try {
            MessageDigest md = MessageDigest.getInstance(checksumType);
            if (md != null) {
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    md.update(entry.getValue().getBytes());
                }
                md.update(checksumKey.getBytes());
            }
            return getHex(md.digest());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
