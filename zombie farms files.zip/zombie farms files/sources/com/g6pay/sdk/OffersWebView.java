package com.g6pay.sdk;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.adsymp.core.ASConstants;
import com.g6pay.constants.G6Params;
import com.g6pay.util.URLUtil;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class OffersWebView extends Activity {
    private ProgressBar progressBar;
    private TextView progressText;
    private String signature;
    private RelativeLayout webviewLayout;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extras = getIntent().getExtras();
        requestWindowFeature(1);
        RelativeLayout r = new RelativeLayout(this);
        ViewGroup.LayoutParams rp = new ViewGroup.LayoutParams(-1, -1);
        r.setLayoutParams(rp);
        r.setGravity(17);
        setContentView(r);
        this.progressBar = new ProgressBar(this);
        this.progressBar.setId(1000);
        RelativeLayout.LayoutParams progressLp = new RelativeLayout.LayoutParams(-2, -2);
        progressLp.addRule(14);
        r.addView(this.progressBar, progressLp);
        this.progressText = new TextView(this);
        this.progressText.setText("0%");
        this.progressText.setId(1001);
        RelativeLayout.LayoutParams progressTextLp = new RelativeLayout.LayoutParams(-2, -2);
        progressTextLp.addRule(14);
        progressTextLp.addRule(3, 1000);
        r.addView(this.progressText, progressTextLp);
        TextView tv = new TextView(this);
        tv.setText("Loading offers.. ");
        tv.setId(1002);
        tv.setGravity(17);
        RelativeLayout.LayoutParams tvLp = new RelativeLayout.LayoutParams(-2, -2);
        tvLp.addRule(14);
        tvLp.addRule(3, 1001);
        r.addView(tv, tvLp);
        Button cancelButton = new Button(this);
        cancelButton.setText("Cancel");
        cancelButton.setOnClickListener(new View.OnClickListener() {
            /* class com.g6pay.sdk.OffersWebView.AnonymousClass1 */

            public void onClick(View v) {
                OffersWebView.this.returnToApp();
            }
        });
        RelativeLayout.LayoutParams cancelButtonLp = new RelativeLayout.LayoutParams(-2, -2);
        cancelButtonLp.addRule(14);
        cancelButtonLp.addRule(3, 1002);
        cancelButton.setLayoutParams(cancelButtonLp);
        WebView webview = new WebView(this);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebChromeClient(new WebChromeClient() {
            /* class com.g6pay.sdk.OffersWebView.AnonymousClass2 */

            public void onProgressChanged(WebView view, int progress) {
                OffersWebView.this.updateProgress(progress);
            }
        });
        webview.setWebViewClient(new WebViewClient() {
            /* class com.g6pay.sdk.OffersWebView.AnonymousClass3 */

            public void onPageFinished(WebView view, String url) {
                OffersWebView.this.pageFinished();
            }

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null || !url.startsWith("market:")) {
                    return true;
                }
                OffersWebView.this.didClickOffer(url);
                return true;
            }
        });
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("app_id", extras.getString("app_id"));
        params.put(G6Params.G6_PARAM_USER_ID, extras.getString(G6Params.G6_PARAM_USER_ID));
        params.put("timestamp", ASConstants.kEmptyString + (System.currentTimeMillis() / 1000));
        HashMap hashMap = new HashMap();
        hashMap.put(G6Params.G6_PARAM_PHONE_ID, ((Map) extras.get(G6Params.UDID_MAP)).get(UDID.UDID_TELEPHONY_ID));
        hashMap.put("platform", "android");
        String secretKey = extras.getString(G6Params.G6_PARAM_SECRET_KEY);
        this.signature = URLUtil.constructSignature(params, secretKey);
        webview.loadUrl(URLUtil.constructG6URL(G6Params.G6_API_URL_OFFERWALL, params, hashMap, secretKey));
        this.webviewLayout = new RelativeLayout(this);
        this.webviewLayout.setLayoutParams(rp);
        this.webviewLayout.addView(webview);
        Button closeButton = new Button(this);
        closeButton.setText("Return to app");
        closeButton.setOnClickListener(new View.OnClickListener() {
            /* class com.g6pay.sdk.OffersWebView.AnonymousClass4 */

            public void onClick(View v) {
                OffersWebView.this.returnToApp();
            }
        });
        RelativeLayout.LayoutParams closeButtonLp = new RelativeLayout.LayoutParams(-2, -2);
        closeButtonLp.addRule(11);
        closeButtonLp.addRule(10);
        closeButton.setLayoutParams(closeButtonLp);
    }

    /* access modifiers changed from: protected */
    public void returnToApp() {
        G6Pay.getG6PayInstance(getApplicationContext()).didCloseOffers();
        finish();
    }

    /* access modifiers changed from: protected */
    public void didClickOffer(String uri) {
        try {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(uri));
            startActivity(intent);
            G6Pay.getG6PayInstance(getApplicationContext()).didSelectOffer(this.signature);
            finish();
        } catch (Exception e) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Android Market not found");
            builder.setMessage("You need to install Android Market to complete this offer.");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                /* class com.g6pay.sdk.OffersWebView.AnonymousClass5 */

                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                    OffersWebView.this.returnToApp();
                }
            }).create();
            try {
                builder.show();
            } catch (Exception e2) {
            }
        }
    }

    /* access modifiers changed from: protected */
    public void pageFinished() {
    }

    /* access modifiers changed from: protected */
    public void updateProgress(int progress) {
        this.progressBar.setProgress(progress);
        this.progressText.setText(ASConstants.kEmptyString + progress + "%");
        if (progress >= 100) {
            setContentView(this.webviewLayout);
        }
    }
}
