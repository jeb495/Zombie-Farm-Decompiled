package com.g6pay.sdk;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.g6pay.constants.G6Params;
import com.g6pay.dto.OfferDTO;
import com.g6pay.dto.TransactionDTO;
import com.g6pay.listener.G6OfferListener;
import com.g6pay.listener.G6TransactionListener;
import com.g6pay.listener.G6UserAccountListener;
import com.g6pay.net.SimpleAsyncHTTPTask;
import com.g6pay.net.SimpleHTTPRequest;
import com.g6pay.util.ResponseParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class G6Pay implements G6AdvertiserIF, G6PublisherIF {
    public static final String VERSION = "1.0";
    private static G6Pay _theInstance = null;
    private static final String mLogStr = "G6Pay";
    private String APP_ID = null;
    private String SECRET_KEY = null;
    private G6OfferListener offerListener;
    private boolean setupCompleted = false;
    private HashMap<String, String> udids = null;

    public static G6Pay getG6PayInstance(Context ctx, String appId, String secretKey) {
        if (_theInstance == null) {
            _theInstance = new G6Pay(ctx, appId, secretKey);
        }
        return _theInstance;
    }

    public static G6Pay getG6PayInstance(Context ctx) {
        return _theInstance;
    }

    private G6Pay(Context ctx, String appId, String secretKey) {
        boolean z = false;
        this.APP_ID = appId;
        this.SECRET_KEY = secretKey;
        boolean failed = false;
        try {
            this.udids = UDID.getDeviceId(ctx);
        } catch (SecurityException e) {
            Log.e(mLogStr, "Error reading state from device.  Please add proper permission to the android manifest in the <manifest> tag:\n  <uses-permission android:name=\"android.permission.READ_PHONE_STATE\" />");
            failed = true;
        }
        if (ctx.getPackageManager().checkPermission("android.permission.ACCESS_NETWORK_STATE", ctx.getPackageName()) != 0) {
            Log.e(mLogStr, "Network state unavailable.  Please add proper permission to the android manifest in the <manifest> tag:\n  <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />");
            failed = true;
        }
        if (ctx.getPackageManager().checkPermission("android.permission.INTERNET", ctx.getPackageName()) != 0) {
            Log.e(mLogStr, "Internet unavailable.  Please add proper permission to the android manifest in the <manifest> tag:\n  <uses-permission android:name=\"android.permission.INTERNET\" />");
            failed = true;
        }
        this.setupCompleted = !failed ? true : z;
    }

    @Override // com.g6pay.sdk.G6PublisherIF
    public void showOffers(Context ctx, String userId, G6OfferListener listener) {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        try {
            Intent intent = new Intent(ctx, OffersWebView.class);
            intent.putExtra("app_id", this.APP_ID);
            intent.putExtra(G6Params.G6_PARAM_USER_ID, userId);
            intent.putExtra(G6Params.UDID_MAP, this.udids);
            intent.putExtra(G6Params.G6_PARAM_SECRET_KEY, this.SECRET_KEY);
            intent.setFlags(268435456);
            ctx.startActivity(intent);
            this.offerListener = listener;
        } catch (ActivityNotFoundException e) {
            Log.e(mLogStr, "Error launching offer webview.  Please add activity to the android manifest in the <application> tag:\n  <activity android:name=\"com.g6pay.sdk.OffersWebView\" android:configChanges=\"keyboardHidden|orientation\" />");
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void retryIsCompleted(final SimpleHTTPRequest request) {
        new Handler().postDelayed(new Runnable() {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass1 */

            public void run() {
                new SimpleAsyncHTTPTask().execute(request);
            }
        }, 5000);
    }

    private void isCompleted(String signature, final G6OfferListener listener) {
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put(G6Params.G6_PARAM_SIGNATURE, signature);
        HashMap<String, String> nonSigParams = new HashMap<>();
        nonSigParams.put("platform", "android");
        nonSigParams.put("app_id", this.APP_ID);
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_ISCOMPLETED, params, nonSigParams, this.SECRET_KEY) {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass2 */

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void resultBody(String body) {
                OfferDTO offer;
                if (listener != null) {
                    if (body == null || (offer = ResponseParser.parseOffer(body)) == null) {
                        G6Pay.this.retryIsCompleted(this);
                    } else {
                        listener.offerWasCompleted(offer);
                    }
                }
            }

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void requestFailed(int statusCode) {
                if (listener != null) {
                    G6Pay.this.retryIsCompleted(this);
                }
            }
        };
        new SimpleAsyncHTTPTask().execute(request);
    }

    @Override // com.g6pay.sdk.G6PublisherIF
    public void creditUser(final String transactionId, final String userId, final float amount, final G6UserAccountListener listener) {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put(G6Params.G6_PARAM_AMOUNT, ASConstants.kEmptyString + amount);
        params.put(G6Params.G6_PARAM_CREDIT_TRANSACTION_ID, transactionId);
        params.put("app_id", this.APP_ID);
        params.put(G6Params.G6_PARAM_USER_ID, userId);
        params.put("timestamp", ASConstants.kEmptyString + (System.currentTimeMillis() / 1000));
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_CREDIT, params, null, this.SECRET_KEY) {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass3 */

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void resultBody(String body) {
                if (listener != null) {
                    if (body == null || !body.trim().equalsIgnoreCase("success")) {
                        listener.creditUserFailure(userId, transactionId, amount);
                    } else {
                        listener.creditUserSuccess(userId, transactionId, amount);
                    }
                }
            }

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void requestFailed(int statusCode) {
                if (listener != null) {
                    listener.creditUserFailure(userId, transactionId, amount);
                }
            }
        };
        new SimpleAsyncHTTPTask().execute(request);
    }

    @Override // com.g6pay.sdk.G6PublisherIF
    public void debitUser(final String transactionId, final String userId, final float amount, final G6UserAccountListener listener) {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put(G6Params.G6_PARAM_AMOUNT, ASConstants.kEmptyString + amount);
        params.put(G6Params.G6_PARAM_DEBIT_TRANSACTION_ID, transactionId);
        params.put("app_id", this.APP_ID);
        params.put(G6Params.G6_PARAM_USER_ID, userId);
        params.put("timestamp", ASConstants.kEmptyString + (System.currentTimeMillis() / 1000));
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_DEBIT, params, null, this.SECRET_KEY) {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass4 */

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void resultBody(String body) {
                if (listener != null) {
                    if (body == null || !body.trim().equalsIgnoreCase("success")) {
                        listener.debitUserFailure(userId, transactionId, amount);
                    } else {
                        listener.debitUserSuccess(userId, transactionId, amount);
                    }
                }
            }

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void requestFailed(int statusCode) {
                if (listener != null) {
                    listener.debitUserFailure(userId, transactionId, amount);
                }
            }
        };
        new SimpleAsyncHTTPTask().execute(request);
    }

    @Override // com.g6pay.sdk.G6PublisherIF
    public void getAllTransactions(final String userId, final G6TransactionListener listener) {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("app_id", this.APP_ID);
        params.put(G6Params.G6_PARAM_USER_ID, userId);
        params.put("timestamp", ASConstants.kEmptyString + (System.currentTimeMillis() / 1000));
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_TRANSACTIONS, params, null, this.SECRET_KEY) {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass5 */

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void resultBody(String body) {
                ArrayList<TransactionDTO> transactions;
                if (listener != null) {
                    if (body == null || (transactions = ResponseParser.parseTransactions(body)) == null) {
                        listener.getAllTransactionsFail(userId);
                    } else {
                        listener.getAllTransactionsSuccess(userId, transactions);
                    }
                }
            }

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void requestFailed(int statusCode) {
                if (listener != null) {
                    listener.getAllTransactionsFail(userId);
                }
            }
        };
        new SimpleAsyncHTTPTask().execute(request);
    }

    @Override // com.g6pay.sdk.G6PublisherIF
    public void getUserBalance(final String userId, final G6UserAccountListener listener) {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("app_id", this.APP_ID);
        params.put(G6Params.G6_PARAM_USER_ID, userId);
        params.put("timestamp", ASConstants.kEmptyString + (System.currentTimeMillis() / 1000));
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_BALANCE, params, null, this.SECRET_KEY) {
            /* class com.g6pay.sdk.G6Pay.AnonymousClass6 */

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void resultBody(String body) {
                if (listener != null) {
                    if (body != null) {
                        try {
                            listener.getUserBalanceSuccess(userId, ResponseParser.balanceFromResponse(body));
                            return;
                        } catch (Exception e) {
                        }
                    }
                    listener.getUserBalanceFail(userId);
                }
            }

            @Override // com.g6pay.net.SimpleHTTPRequest, com.g6pay.net.SimpleHTTPListener
            public void requestFailed(int statusCode) {
                if (listener != null) {
                    listener.getUserBalanceFail(userId);
                }
            }
        };
        new SimpleAsyncHTTPTask().execute(request);
    }

    @Override // com.g6pay.sdk.G6AdvertiserIF
    public void installConfirm() {
        if (!this.setupCompleted) {
            Log.e(mLogStr, "SDK setup incomplete.. bailing.  Please fix previous errors");
            return;
        }
        LinkedHashMap<String, String> params = new LinkedHashMap<>();
        params.put("app_id", this.APP_ID);
        params.put(G6Params.G6_PARAM_PHONE_ID, this.udids.get(UDID.UDID_TELEPHONY_ID));
        HashMap<String, String> nonSigParams = new HashMap<>();
        nonSigParams.put("platform", "android");
        SimpleHTTPRequest request = new SimpleHTTPRequest(G6Params.G6_API_URL_INSTALLCONFIRM, params, nonSigParams, this.SECRET_KEY);
        new SimpleAsyncHTTPTask().execute(request);
    }

    /* access modifiers changed from: protected */
    public void didCloseOffers() {
        this.offerListener = null;
    }

    /* access modifiers changed from: protected */
    public void didSelectOffer(String signature) {
        if (this.offerListener != null) {
            isCompleted(signature, this.offerListener);
        }
    }
}
