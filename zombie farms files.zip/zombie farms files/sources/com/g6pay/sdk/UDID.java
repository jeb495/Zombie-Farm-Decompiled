package com.g6pay.sdk;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import com.android.adsymp.core.ASConstants;
import com.tapjoy.TapjoyConstants;
import java.util.HashMap;
import java.util.UUID;

public class UDID {
    public static final String UDID_ANDROID_ID = "androidId";
    public static final String UDID_HASH = "udid";
    public static final String UDID_SERIAL_NUMBER = "serialNumber";
    public static final String UDID_TELEPHONY_ID = "telephonyId";

    public static HashMap<String, String> getDeviceId(Context ctx) throws SecurityException {
        String serialNumber = ASConstants.kEmptyString;
        String telephonyId = ASConstants.kEmptyString;
        String androidId = ASConstants.kEmptyString;
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            serialNumber = (String) c.getMethod("get", String.class).invoke(c, "ro.serialno");
        } catch (Exception e) {
        }
        TelephonyManager tm = (TelephonyManager) ctx.getSystemService("phone");
        if (tm.getDeviceId() != null) {
            telephonyId = tm.getDeviceId();
        }
        String aId = Settings.Secure.getString(ctx.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        if (aId != null) {
            androidId = aId;
        }
        String deviceId = new UUID((long) androidId.hashCode(), (((long) telephonyId.hashCode()) << 32) | ((long) serialNumber.hashCode())).toString();
        HashMap<String, String> udids = new HashMap<>();
        udids.put("udid", deviceId);
        udids.put(UDID_ANDROID_ID, androidId);
        udids.put(UDID_TELEPHONY_ID, telephonyId);
        udids.put(UDID_SERIAL_NUMBER, serialNumber);
        if (Build.PRODUCT.equalsIgnoreCase("sdk") || Build.PRODUCT.equalsIgnoreCase("google_sdk")) {
        }
        return udids;
    }
}
