package com.g6pay.sdk;

import android.content.Context;
import com.g6pay.listener.G6OfferListener;
import com.g6pay.listener.G6TransactionListener;
import com.g6pay.listener.G6UserAccountListener;

public interface G6PublisherIF {
    void creditUser(String str, String str2, float f, G6UserAccountListener g6UserAccountListener);

    void debitUser(String str, String str2, float f, G6UserAccountListener g6UserAccountListener);

    void getAllTransactions(String str, G6TransactionListener g6TransactionListener);

    void getUserBalance(String str, G6UserAccountListener g6UserAccountListener);

    void showOffers(Context context, String str, G6OfferListener g6OfferListener);
}
