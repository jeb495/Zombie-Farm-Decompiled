package com.g6pay.sdk;

public interface G6AdvertiserIF {
    void installConfirm();
}
