package com.g6pay.net;

import android.os.AsyncTask;
import com.android.adsymp.core.ASConstants;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

public class SimpleAsyncHTTPTask extends AsyncTask<SimpleHTTPRequest, Void, SimpleHTTPResult> {
    private SimpleHTTPRequest request;

    /* access modifiers changed from: protected */
    public SimpleHTTPResult doInBackground(SimpleHTTPRequest... requests) {
        Throwable th;
        IOException e;
        ProtocolException e2;
        MalformedURLException e3;
        StringBuilder sb;
        if (requests.length <= 0) {
            return null;
        }
        this.request = requests[0];
        HttpURLConnection connection = null;
        try {
            connection = null;
            try {
                connection = (HttpURLConnection) new URL(this.request.getURLString()).openConnection();
                connection.setRequestMethod("GET");
                connection.setDoOutput(true);
                connection.setReadTimeout(10000);
                connection.connect();
                sb = new StringBuilder(ASConstants.kEmptyString);
                try {
                    BufferedReader rd = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    while (true) {
                        try {
                            String line = rd.readLine();
                            if (line == null) {
                                break;
                            }
                            sb.append(line);
                        } catch (FileNotFoundException e4) {
                        } catch (MalformedURLException e5) {
                            e3 = e5;
                            try {
                                e3.printStackTrace();
                                connection.disconnect();
                                return null;
                            } catch (Throwable th2) {
                                th = th2;
                                connection.disconnect();
                                throw th;
                            }
                        } catch (ProtocolException e6) {
                            e2 = e6;
                            e2.printStackTrace();
                            connection.disconnect();
                            return null;
                        } catch (IOException e7) {
                            e = e7;
                            e.printStackTrace();
                            connection.disconnect();
                            return null;
                        } catch (Throwable th3) {
                            th = th3;
                            connection.disconnect();
                            throw th;
                        }
                    }
                } catch (FileNotFoundException e8) {
                }
            } catch (MalformedURLException e9) {
                e3 = e9;
                e3.printStackTrace();
                connection.disconnect();
                return null;
            } catch (ProtocolException e10) {
                e2 = e10;
                e2.printStackTrace();
                connection.disconnect();
                return null;
            } catch (IOException e11) {
                e = e11;
                e.printStackTrace();
                connection.disconnect();
                return null;
            } catch (Throwable th4) {
                th = th4;
                connection.disconnect();
                throw th;
            }
            try {
                SimpleHTTPResult result = new SimpleHTTPResult();
                result.setResponseCode(connection.getResponseCode());
                result.setResponseMessage(connection.getResponseMessage());
                result.setResponseBody(sb.toString());
                connection.disconnect();
                return result;
            } catch (MalformedURLException e12) {
                e3 = e12;
                e3.printStackTrace();
                connection.disconnect();
                return null;
            } catch (ProtocolException e13) {
                e2 = e13;
                e2.printStackTrace();
                connection.disconnect();
                return null;
            } catch (IOException e14) {
                e = e14;
                e.printStackTrace();
                connection.disconnect();
                return null;
            } catch (Throwable th5) {
                th = th5;
                connection.disconnect();
                throw th;
            }
        } catch (MalformedURLException e15) {
            e3 = e15;
            e3.printStackTrace();
            connection.disconnect();
            return null;
        } catch (ProtocolException e16) {
            e2 = e16;
            e2.printStackTrace();
            connection.disconnect();
            return null;
        } catch (IOException e17) {
            e = e17;
            e.printStackTrace();
            connection.disconnect();
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(SimpleHTTPResult result) {
        if (result == null) {
            this.request.requestFailed(0);
        } else if (result.getResponseCode() < 200 || result.getResponseCode() >= 300) {
            this.request.requestFailed(result.getResponseCode());
        } else {
            this.request.resultBody(result.getResponseBody());
        }
    }
}
