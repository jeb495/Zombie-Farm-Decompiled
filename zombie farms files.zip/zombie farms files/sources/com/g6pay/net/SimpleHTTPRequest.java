package com.g6pay.net;

import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.g6pay.util.URLUtil;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class SimpleHTTPRequest implements SimpleHTTPListener {
    private String baseURL;
    private String checksumKey;
    private HashMap<String, String> nonSigParams;
    private LinkedHashMap<String, String> params;

    public SimpleHTTPRequest(String baseURL2, LinkedHashMap<String, String> params2, HashMap<String, String> nonSigParams2, String checksumKey2) {
        this.baseURL = baseURL2;
        this.params = params2;
        this.nonSigParams = nonSigParams2;
        this.checksumKey = checksumKey2;
    }

    public String getURLString() {
        return URLUtil.constructG6URL(this.baseURL, this.params, this.nonSigParams, this.checksumKey);
    }

    @Override // com.g6pay.net.SimpleHTTPListener
    public void resultBody(String body) {
        Log.e("DEBUG resultBody", body);
    }

    @Override // com.g6pay.net.SimpleHTTPListener
    public void requestFailed(int statusCode) {
        Log.e("DEBUG requestFailed", ASConstants.kEmptyString + statusCode);
    }
}
