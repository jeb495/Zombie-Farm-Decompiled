package com.g6pay.net;

public class SimpleHTTPResult {
    private String responseBody;
    private int responseCode;
    private String responseMessage;

    public int getResponseCode() {
        return this.responseCode;
    }

    public void setResponseCode(int responseCode2) {
        this.responseCode = responseCode2;
    }

    public String getResponseBody() {
        return this.responseBody;
    }

    public void setResponseBody(String responseBody2) {
        this.responseBody = responseBody2;
    }

    public String getResponseMessage() {
        return this.responseMessage;
    }

    public void setResponseMessage(String responseMessage2) {
        this.responseMessage = responseMessage2;
    }
}
