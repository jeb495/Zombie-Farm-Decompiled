package com.g6pay.net;

public interface SimpleHTTPListener {
    void requestFailed(int i);

    void resultBody(String str);
}
