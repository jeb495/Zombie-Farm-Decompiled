package com.g6pay.dto;

import java.util.Date;

public class TransactionDTO {
    private Date date;
    private String description;
    private float netPayout;
    private String offerId;
    private String offerName;
    private String userId;
    private float virtualCurrencyAmount;

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId2) {
        this.userId = userId2;
    }

    public String getOfferId() {
        return this.offerId;
    }

    public void setOfferId(String offerId2) {
        this.offerId = offerId2;
    }

    public String getOfferName() {
        return this.offerName;
    }

    public void setOfferName(String offerName2) {
        this.offerName = offerName2;
    }

    public float getNetPayout() {
        return this.netPayout;
    }

    public void setNetPayout(float netPayout2) {
        this.netPayout = netPayout2;
    }

    public float getVirtualCurrencyAmount() {
        return this.virtualCurrencyAmount;
    }

    public void setVirtualCurrencyAmount(float virtualCurrencyAmount2) {
        this.virtualCurrencyAmount = virtualCurrencyAmount2;
    }

    public Date getDate() {
        return this.date;
    }

    public void setDate(Date date2) {
        this.date = date2;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description2) {
        this.description = description2;
    }

    public String toString() {
        return "TransactionDTO [userId=" + this.userId + ", offerId=" + this.offerId + ", offerName=" + this.offerName + ", netPayout=" + this.netPayout + ", virtualCurrencyAmount=" + this.virtualCurrencyAmount + ", date=" + this.date + ", description=" + this.description + "]";
    }
}
