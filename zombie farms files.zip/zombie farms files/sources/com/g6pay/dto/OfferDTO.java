package com.g6pay.dto;

public class OfferDTO {
    private float netPayout;
    private String offerId;
    private String offerName;
    private String signature;
    private float userBalance;
    private String userId;
    private float virtualCurrencyAmount;

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId2) {
        this.userId = userId2;
    }

    public String getOfferId() {
        return this.offerId;
    }

    public void setOfferId(String offerId2) {
        this.offerId = offerId2;
    }

    public String getOfferName() {
        return this.offerName;
    }

    public void setOfferName(String offerName2) {
        this.offerName = offerName2;
    }

    public float getNetPayout() {
        return this.netPayout;
    }

    public void setNetPayout(float netPayout2) {
        this.netPayout = netPayout2;
    }

    public float getVirtualCurrencyAmount() {
        return this.virtualCurrencyAmount;
    }

    public void setVirtualCurrencyAmount(float virtualCurrencyAmount2) {
        this.virtualCurrencyAmount = virtualCurrencyAmount2;
    }

    public float getUserBalance() {
        return this.userBalance;
    }

    public void setUserBalance(float userBalance2) {
        this.userBalance = userBalance2;
    }

    public String getSignature() {
        return this.signature;
    }

    public void setSignature(String signature2) {
        this.signature = signature2;
    }

    public String toString() {
        return "OfferDTO [userId=" + this.userId + ", offerId=" + this.offerId + ", offerName=" + this.offerName + ", netPayout=" + this.netPayout + ", virtualCurrencyAmount=" + this.virtualCurrencyAmount + ", userBalance=" + this.userBalance + ", signature=" + this.signature + "]";
    }
}
