package com.chartboost.sdk;

public class CBMissingInformationException extends Exception {
    private static final long serialVersionUID = 1;
}
