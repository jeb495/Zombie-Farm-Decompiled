package com.chartboost.sdk;

final class CBConstants {
    public static final String CB_SDK_VERSION = "2.0";

    CBConstants() {
    }
}
