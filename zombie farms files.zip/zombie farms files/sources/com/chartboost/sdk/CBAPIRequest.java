package com.chartboost.sdk;

import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.view.Display;
import android.view.WindowManager;
import com.android.adsymp.core.ASConstants;
import com.flurry.android.Constants;
import com.g6pay.constants.G6Params;
import com.ngmoco.gamejs.ui.Commands;
import com.tapjoy.TapjoyConstants;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;

public class CBAPIRequest {
    private static final String CB_PARAM_COUNTRY = "country";
    private static final String CB_PARAM_HEIGHT = "h";
    private static final String CB_PARAM_LANGUAGE = "language";
    private static final String CB_PARAM_MODEL = "model";
    private static final String CB_PARAM_OS = "os";
    private static final String CB_PARAM_SCALE = "scale";
    private static final String CB_PARAM_SDK = "sdk";
    private static final String CB_PARAM_UUID = "uuid";
    private static final String CB_PARAM_VERSION = "bundle";
    private static final String CB_PARAM_WIDTH = "w";
    private String action;
    private Map<String, String> body;
    private Context context;
    private Object contextInfoObject;
    private String controller;
    private List<String> params;
    private Map<String, String> query;

    public CBAPIRequest(Context context2, String controller2, String action2) {
        this.context = context2;
        this.controller = controller2;
        this.action = action2;
    }

    public void appendBodyArgument(String key, String value) {
        if (this.body == null) {
            this.body = new HashMap();
        }
        this.body.put(key, value);
    }

    public void appendQueryArgument(String key, String value) {
        if (this.query == null) {
            this.query = new HashMap();
        }
        this.query.put(key, value);
    }

    public void appendDeviceInfoParams() throws CBMissingInformationException {
        if (this.context == null) {
            throw new CBMissingInformationException();
        }
        if (Build.PRODUCT.equals(CB_PARAM_SDK)) {
            appendBodyArgument(CB_PARAM_MODEL, "Android Simulator");
            appendBodyArgument("uuid", "ffff");
        } else {
            appendBodyArgument(CB_PARAM_MODEL, Build.MODEL);
            appendBodyArgument("uuid", Settings.Secure.getString(this.context.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID));
        }
        appendBodyArgument(CB_PARAM_OS, "Android " + Build.VERSION.RELEASE);
        appendBodyArgument(CB_PARAM_COUNTRY, Locale.getDefault().getCountry());
        appendBodyArgument(CB_PARAM_LANGUAGE, Locale.getDefault().getDisplayLanguage());
        appendBodyArgument(CB_PARAM_SDK, CBConstants.CB_SDK_VERSION);
        Display display = ((WindowManager) this.context.getSystemService("window")).getDefaultDisplay();
        appendBodyArgument("w", new StringBuilder().append(display.getWidth()).toString());
        appendBodyArgument("h", new StringBuilder().append(display.getHeight()).toString());
        appendBodyArgument(CB_PARAM_SCALE, new StringBuilder().append(this.context.getResources().getDisplayMetrics().density).toString());
        try {
            appendBodyArgument(CB_PARAM_VERSION, this.context.getPackageManager().getPackageInfo(this.context.getPackageName(), Commands.CommandIDs.setVisibleInOrientations).versionName);
        } catch (Exception e) {
        }
    }

    public void sign(String appId, String appSignature) throws Exception {
        String string = "controller:" + this.controller + ";action:" + this.action + ";";
        if (this.query != null) {
            string = String.valueOf(string) + serializeDictionaryToString(this.query);
        }
        if (this.body != null) {
            string = String.valueOf(string) + serializeDictionaryToString(this.body);
        }
        if (this.params != null) {
            int count = 0;
            Iterator<String> it = this.params.iterator();
            while (it.hasNext()) {
                string = String.valueOf(string) + count + ":" + it.next() + ";";
                count++;
            }
        }
        byte[] hashBinary = MessageDigest.getInstance("MD5").digest((String.valueOf(string) + "app:" + appId + ";signature:" + appSignature + ";").getBytes("US-ASCII"));
        String hash = ASConstants.kEmptyString;
        for (int i = 0; i < hashBinary.length; i++) {
            hash = String.valueOf(hash) + String.format("%02x", Integer.valueOf(hashBinary[i] & Constants.UNKNOWN));
        }
        appendBodyArgument("app", appId);
        appendBodyArgument(G6Params.G6_PARAM_SIGNATURE, hash);
    }

    public String getController() {
        return this.controller;
    }

    public void setController(String controller2) {
        this.controller = controller2;
    }

    public String getAction() {
        return this.action;
    }

    public void setAction(String action2) {
        this.action = action2;
    }

    public Map<String, String> getBody() {
        return this.body;
    }

    public void setBody(Map<String, String> body2) {
        this.body = body2;
    }

    public Map<String, String> getQuery() {
        return this.query;
    }

    public void setQuery(Map<String, String> query2) {
        this.query = query2;
    }

    public List<String> getParams() {
        return this.params;
    }

    public void setParams(List<String> params2) {
        this.params = params2;
    }

    public Object getContextInfoObject() {
        return this.contextInfoObject;
    }

    public void setContextInfoObject(Object contextInfoObject2) {
        this.contextInfoObject = contextInfoObject2;
    }

    private String serializeDictionaryToString(Map<String, String> dictionary) {
        String string = ASConstants.kEmptyString;
        Iterator<String> it = new TreeSet<>(dictionary.keySet()).iterator();
        while (it.hasNext()) {
            String key = it.next();
            if (!key.equals("app") && !key.equals(G6Params.G6_PARAM_SIGNATURE)) {
                string = String.valueOf(string) + key + ":" + dictionary.get(key) + ";";
            }
        }
        return string;
    }
}
