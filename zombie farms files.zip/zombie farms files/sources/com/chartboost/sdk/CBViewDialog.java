package com.chartboost.sdk;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.widget.RelativeLayout;
import com.mobage.ww.a465.zombiefarm_android.R;

public class CBViewDialog extends Dialog {
    private Context context;
    private CBView view;

    public CBViewDialog(Context _context, CBView _view) {
        super(_context, R.string.NgStartingServer);
        this.context = _context;
        this.view = _view;
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        RelativeLayout container = new RelativeLayout(this.context);
        container.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        container.addView(this.view);
        setContentView(container);
    }

    /* access modifiers changed from: protected */
    public void onStop() {
        Log.d(ChartBoost.TAG, "View dismissed, not sure if by back button");
    }
}
