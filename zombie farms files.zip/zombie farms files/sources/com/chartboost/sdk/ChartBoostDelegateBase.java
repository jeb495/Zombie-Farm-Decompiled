package com.chartboost.sdk;

import android.view.View;

public abstract class ChartBoostDelegateBase implements ChartBoostDelegate {
    @Override // com.chartboost.sdk.ChartBoostDelegate
    public boolean shouldRequestInterstitial() {
        return true;
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public boolean shouldDisplayInterstitial(View interstitialView) {
        return true;
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didDismissInterstitial(View interstitialView) {
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didCloseInterstitial(View interstitialView) {
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didClickInterstitial(View interstitialView) {
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public boolean shouldDisplayMoreApps(View moreAppsView) {
        return true;
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didDismissMoreApps(View moreAppsView) {
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didCloseMoreApps(View moreAppsView) {
    }

    @Override // com.chartboost.sdk.ChartBoostDelegate
    public void didClickMoreApps(View moreAppsView) {
    }
}
