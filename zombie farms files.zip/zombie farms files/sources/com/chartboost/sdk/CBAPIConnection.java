package com.chartboost.sdk;

import android.os.Handler;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.json.JSONObject;
import org.json.JSONTokener;

public class CBAPIConnection {
    private static final String CB_DEFAULT_ENDPOINT = "https://www.chartboost.com/";
    private CBAPIConnectionDelegate delegate;
    private String endpoint;
    private HttpClient httpClient = createHttpClient();

    public CBAPIConnection(CBAPIConnectionDelegate delegate2) {
        setEndpoint(CB_DEFAULT_ENDPOINT);
        setDelegate(delegate2);
    }

    private HttpClient createHttpClient() {
        try {
            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);
            SSLSocketFactory sf = new TrustingSocketFactory(trustStore);
            sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
            HttpParams params = new BasicHttpParams();
            HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(params, "UTF-8");
            SchemeRegistry registry = new SchemeRegistry();
            registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            registry.register(new Scheme("https", sf, 443));
            return new DefaultHttpClient(new ThreadSafeClientConnManager(params, registry), params);
        } catch (Exception e) {
            return new DefaultHttpClient();
        }
    }

    public void sendRequest(final CBAPIRequest request) {
        String urlString = String.valueOf(getEndpoint()) + request.getController() + "/" + request.getAction() + ".json";
        Map<String, String> query = request.getQuery();
        if (query != null) {
            String queryString = ASConstants.kEmptyString;
            for (String key : query.keySet()) {
                queryString = String.valueOf(queryString) + URLEncoder.encode(key) + "=" + URLEncoder.encode(query.get(key)) + "&";
            }
            urlString = String.valueOf(urlString) + "?" + queryString;
        }
        final HttpPost httpRequest = new HttpPost(urlString);
        Map<String, String> body = request.getBody();
        if (body != null) {
            List<NameValuePair> postPairs = new ArrayList<>();
            for (String key2 : body.keySet()) {
                postPairs.add(new BasicNameValuePair(key2, body.get(key2)));
            }
            try {
                httpRequest.setEntity(new UrlEncodedFormEntity(postPairs));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }
        final HttpClient finalHttpClient = this.httpClient;
        final Handler finalHandler = new Handler();
        final CBAPIConnectionDelegate finalDelegate = this.delegate;
        new Thread() {
            /* class com.chartboost.sdk.CBAPIConnection.AnonymousClass1 */

            public void run() {
                try {
                    HttpResponse response = finalHttpClient.execute(httpRequest);
                    int status = response.getStatusLine().getStatusCode();
                    if (status >= 300 || status < 200) {
                        Log.w(ChartBoost.TAG, "Request failed: " + response);
                        Handler handler = finalHandler;
                        final CBAPIConnectionDelegate cBAPIConnectionDelegate = finalDelegate;
                        final CBAPIRequest cBAPIRequest = request;
                        handler.post(new Runnable() {
                            /* class com.chartboost.sdk.CBAPIConnection.AnonymousClass1.AnonymousClass2 */

                            public void run() {
                                cBAPIConnectionDelegate.didFailToReceiveAPIResponse(cBAPIRequest);
                            }
                        });
                        return;
                    }
                    BufferedReader reader = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8"));
                    StringBuilder builder = new StringBuilder();
                    while (true) {
                        String line = reader.readLine();
                        if (line == null) {
                            final JSONObject jsonObject = new JSONObject(new JSONTokener(builder.toString()));
                            Log.i(ChartBoost.TAG, "Request response received: " + jsonObject.optString("message"));
                            Handler handler2 = finalHandler;
                            final CBAPIConnectionDelegate cBAPIConnectionDelegate2 = finalDelegate;
                            final CBAPIRequest cBAPIRequest2 = request;
                            handler2.post(new Runnable() {
                                /* class com.chartboost.sdk.CBAPIConnection.AnonymousClass1.AnonymousClass1 */

                                public void run() {
                                    cBAPIConnectionDelegate2.didReceiveAPIResponse(jsonObject, cBAPIRequest2);
                                }
                            });
                            return;
                        }
                        builder.append(line).append("\n");
                    }
                } catch (Exception e) {
                    Log.e(ChartBoost.TAG, "Exception on http request: " + e.getLocalizedMessage());
                }
            }
        }.start();
    }

    public CBAPIConnectionDelegate getDelegate() {
        return this.delegate;
    }

    public void setDelegate(CBAPIConnectionDelegate delegate2) {
        this.delegate = delegate2;
    }

    public String getEndpoint() {
        return this.endpoint;
    }

    public void setEndpoint(String endpoint2) {
        this.endpoint = endpoint2;
    }

    /* access modifiers changed from: private */
    public class TrustingSocketFactory extends SSLSocketFactory {
        SSLContext sslContext = SSLContext.getInstance("TLS");

        public TrustingSocketFactory(KeyStore truststore) throws Exception {
            super(truststore);
            TrustManager tm = new X509TrustManager() {
                /* class com.chartboost.sdk.CBAPIConnection.TrustingSocketFactory.AnonymousClass1 */

                @Override // javax.net.ssl.X509TrustManager
                public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                @Override // javax.net.ssl.X509TrustManager
                public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                }

                public X509Certificate[] getAcceptedIssuers() {
                    return null;
                }
            };
            this.sslContext.init(null, new TrustManager[]{tm}, null);
        }

        @Override // org.apache.http.conn.scheme.LayeredSocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
        public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException, UnknownHostException {
            return this.sslContext.getSocketFactory().createSocket(socket, host, port, autoClose);
        }

        @Override // org.apache.http.conn.scheme.SocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
        public Socket createSocket() throws IOException {
            return this.sslContext.getSocketFactory().createSocket();
        }
    }
}
