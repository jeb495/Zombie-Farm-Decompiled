package com.chartboost.sdk;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.RelativeLayout;
import com.chartboost.sdk.CBView;
import com.google.ads.AdActivity;
import java.net.URI;
import org.json.JSONException;
import org.json.JSONObject;

public class CBDialogActivity extends Activity {
    public static final String BUNDLE_KEY_CONFIGOBJECT = "bk_cfgo";
    public static final String BUNDLE_KEY_TYPE = "bk_type";
    public static final boolean DEBUG_MODE = false;
    public static final int OVERLAY_OPACITY = 75;
    public static final String TAG = "CBDialogActivity";
    protected static Context ctx;
    protected JSONObject cbConfiguration;
    protected RelativeLayout cbContainer;
    protected ChartBoost cbObject;
    protected int cbViewType;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.cbContainer = new RelativeLayout(this);
        this.cbContainer.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        this.cbContainer.setBackgroundColor(-16777216);
        this.cbContainer.getBackground().setAlpha(75);
        this.cbContainer.setGravity(49);
        if (!getIntent().hasExtra(BUNDLE_KEY_TYPE)) {
            finish();
        }
        this.cbViewType = getIntent().getExtras().getInt(BUNDLE_KEY_TYPE);
        try {
            this.cbConfiguration = new JSONObject(getIntent().getExtras().getString(BUNDLE_KEY_CONFIGOBJECT));
        } catch (JSONException e) {
        }
        ctx = this;
        this.cbContainer.post(new Runnable() {
            /* class com.chartboost.sdk.CBDialogActivity.AnonymousClass1 */

            public void run() {
                CBDialogActivity.this.display();
            }
        });
        setContentView(this.cbContainer);
    }

    public void close() {
        finish();
    }

    public static Context getContext() {
        return ctx;
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        this.cbContainer.removeAllViews();
        this.cbContainer = null;
        super.onDestroy();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void display() {
        CBView chartBoostView = null;
        if (this.cbViewType == CBView.CBViewType.CBViewTypeInterstitial.ordinal()) {
            chartBoostView = new CBView(this, CBView.CBViewType.CBViewTypeInterstitial);
        } else if (this.cbViewType == CBView.CBViewType.CBViewTypeMoreApps.ordinal()) {
            chartBoostView = new CBView(this, CBView.CBViewType.CBViewTypeMoreApps);
        }
        this.cbObject = ChartBoost.getSharedChartBoost();
        if (chartBoostView == null || this.cbObject == null) {
            finish();
        }
        chartBoostView.setState(CBView.CBViewState.CBViewStateWaitingForDisplay);
        chartBoostView.setResponseContext(this.cbConfiguration);
        chartBoostView.setWebViewClient(new MyAdview(this, null));
        try {
            chartBoostView.loadDataWithBaseURL("file:///android_asset/", this.cbConfiguration.getString(AdActivity.HTML_PARAM), null, "utf-8", null);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    public class MyAdview extends WebViewClient {
        private MyAdview() {
        }

        /* synthetic */ MyAdview(CBDialogActivity cBDialogActivity, MyAdview myAdview) {
            this();
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            CBView chartBoostView = (CBView) view;
            if (chartBoostView.getState() == CBView.CBViewState.CBViewStateWaitingForDisplay) {
                chartBoostView.setState(CBView.CBViewState.CBViewStateOther);
                if (chartBoostView.getType() == CBView.CBViewType.CBViewTypeInterstitial) {
                    if (CBDialogActivity.this.cbObject.getDelegate() != null && !CBDialogActivity.this.cbObject.getDelegate().shouldDisplayInterstitial(null)) {
                        return;
                    }
                    if (CBDialogActivity.this.cbContainer != null) {
                        Log.i(CBDialogActivity.TAG, "Got an interstitial, adding to view!");
                        CBDialogActivity.this.cbContainer.removeAllViews();
                        CBDialogActivity.this.cbContainer.addView(chartBoostView);
                        CBDialogActivity.this.cbContainer.invalidate();
                    }
                } else if (chartBoostView.getType() == CBView.CBViewType.CBViewTypeMoreApps) {
                    if (CBDialogActivity.this.cbObject.getDelegate() != null && !CBDialogActivity.this.cbObject.getDelegate().shouldDisplayMoreApps(null)) {
                        return;
                    }
                    if (CBDialogActivity.this.cbContainer != null) {
                        Log.i(CBDialogActivity.TAG, "Got More Apps, adding to view!");
                        CBDialogActivity.this.cbContainer.removeAllViews();
                        CBDialogActivity.this.cbContainer.addView(chartBoostView);
                        CBDialogActivity.this.cbContainer.invalidate();
                    }
                }
                chartBoostView.setState(CBView.CBViewState.CBViewStateDisplayedByDefaultController);
            }
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, String url) {
            CBView view = (CBView) webView;
            try {
                URI uri = new URI(url);
                if (uri.getScheme().equals("file") || !uri.getScheme().equals("chartboost")) {
                    return false;
                }
                CBDialogActivity.this.cbObject.handleChartBoostRequest(url, view);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
