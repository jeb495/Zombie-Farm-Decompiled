package com.chartboost.sdk;

import android.content.Context;

public class CBDefaultViewController {
    private static CBDefaultViewController sharedController = null;
    private Context context;
    private boolean viewIsVisible;

    public static synchronized CBDefaultViewController getSharedController() {
        CBDefaultViewController cBDefaultViewController;
        synchronized (CBDefaultViewController.class) {
            if (sharedController == null) {
                sharedController = new CBDefaultViewController();
            }
            cBDefaultViewController = sharedController;
        }
        return cBDefaultViewController;
    }

    public void displayInterstitial(CBView interstitial) {
        displayChartBoostView(interstitial);
    }

    public void displayMoreAppsView(CBView moreAppsView) {
        displayChartBoostView(moreAppsView);
    }

    private void displayChartBoostView(CBView chartBoostView) {
        CBViewDialog dialog = new CBViewDialog(this.context, chartBoostView);
        chartBoostView.setDialog(dialog);
        dialog.show();
    }

    public void dismissInterstitial(CBView interstitial) {
        interstitial.getDialog().cancel();
    }

    public void dismissMoreAppsView(CBView moreAppsView) {
        moreAppsView.getDialog().cancel();
    }

    public void displayLoadingView() {
    }

    public void dismissLoadingView() {
    }

    public boolean isViewIsVisible() {
        return this.viewIsVisible;
    }

    public Context getContext() {
        return this.context;
    }

    public void setContext(Context context2) {
        this.context = context2;
    }
}
