package com.chartboost.sdk;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import org.json.JSONObject;

public class CBView extends WebView {
    private CBViewDialog dialog;
    private JSONObject responseContext;
    private CBViewState state;
    private CBViewType type;

    public enum CBViewState {
        CBViewStateOther,
        CBViewStateWaitingForDisplay,
        CBViewStateDisplayedByDefaultController,
        CBViewStateWaitingForDismissal
    }

    public enum CBViewType {
        CBViewTypeInterstitial,
        CBViewTypeMoreApps
    }

    public CBView(Context context, CBViewType type2) {
        super(context);
        setBackgroundColor(0);
        getSettings().setJavaScriptEnabled(true);
        this.type = type2;
        if (type2 == CBViewType.CBViewTypeInterstitial) {
            setOnTouchListener(new View.OnTouchListener() {
                /* class com.chartboost.sdk.CBView.AnonymousClass1 */

                public boolean onTouch(View v, MotionEvent event) {
                    return event.getAction() == 2;
                }
            });
        }
    }

    public JSONObject getResponseContext() {
        return this.responseContext;
    }

    public void setResponseContext(JSONObject responseContext2) {
        this.responseContext = responseContext2;
    }

    public CBViewState getState() {
        return this.state;
    }

    public void setState(CBViewState state2) {
        this.state = state2;
    }

    public CBViewDialog getDialog() {
        return this.dialog;
    }

    public void setDialog(CBViewDialog dialog2) {
        this.dialog = dialog2;
    }

    public CBViewType getType() {
        return this.type;
    }

    public void setType(CBViewType type2) {
        this.type = type2;
    }
}
