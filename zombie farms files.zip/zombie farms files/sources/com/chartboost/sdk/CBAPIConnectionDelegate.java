package com.chartboost.sdk;

import org.json.JSONObject;

public interface CBAPIConnectionDelegate {
    void didFailToReceiveAPIResponse(CBAPIRequest cBAPIRequest);

    void didReceiveAPIResponse(JSONObject jSONObject, CBAPIRequest cBAPIRequest);
}
