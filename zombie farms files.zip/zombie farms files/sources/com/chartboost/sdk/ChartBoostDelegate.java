package com.chartboost.sdk;

import android.view.View;

public interface ChartBoostDelegate {
    void didClickInterstitial(View view);

    void didClickMoreApps(View view);

    void didCloseInterstitial(View view);

    void didCloseMoreApps(View view);

    void didDismissInterstitial(View view);

    void didDismissMoreApps(View view);

    boolean shouldDisplayInterstitial(View view);

    boolean shouldDisplayMoreApps(View view);

    boolean shouldRequestInterstitial();
}
