package com.chartboost.sdk;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.android.adsymp.core.ASConstants;
import com.chartboost.sdk.CBView;
import com.ngmoco.gamejs.ui.AbstractJSAdapter;
import java.net.URLDecoder;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class ChartBoost implements CBAPIConnectionDelegate {
    public static final String TAG = "ChartBoost";
    private static ChartBoost sharedChartBoost = null;
    private String appId;
    private String appSignature;
    private CBAPIConnection connection = new CBAPIConnection(this);
    private Context context;
    private ChartBoostDelegate delegate;

    public String getAppId() {
        return this.appId;
    }

    public void setAppId(String appId2) {
        this.appId = appId2;
    }

    public String getAppSignature() {
        return this.appSignature;
    }

    public void setAppSignature(String appSignature2) {
        this.appSignature = appSignature2;
    }

    public ChartBoostDelegate getDelegate() {
        return this.delegate;
    }

    public void setDelegate(ChartBoostDelegate delegate2) {
        this.delegate = delegate2;
    }

    public static synchronized ChartBoost getSharedChartBoost() {
        ChartBoost chartBoost;
        synchronized (ChartBoost.class) {
            if (sharedChartBoost == null) {
                sharedChartBoost = new ChartBoost();
            }
            chartBoost = sharedChartBoost;
        }
        return chartBoost;
    }

    private ChartBoost() {
    }

    public void install() {
        try {
            CBAPIRequest request = new CBAPIRequest(this.context, "api", "install");
            request.appendDeviceInfoParams();
            request.sign(this.appId, this.appSignature);
            this.connection.sendRequest(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadInterstitial() {
        loadInterstitial("Default");
    }

    public void loadInterstitial(String location) {
        if (this.delegate == null || this.delegate.shouldRequestInterstitial()) {
            try {
                CBAPIRequest request = new CBAPIRequest(this.context, "api", "get");
                request.appendDeviceInfoParams();
                request.appendBodyArgument("location", location);
                request.sign(this.appId, this.appSignature);
                request.setContextInfoObject(new CBRunnable() {
                    /* class com.chartboost.sdk.ChartBoost.AnonymousClass1 */

                    @Override // com.chartboost.sdk.CBRunnable
                    public void run(Object... objects) {
                        if (objects.length == 1 && (objects[0] instanceof JSONObject)) {
                            try {
                                if (((JSONObject) objects[0]).getInt("status") == 200) {
                                    this.loadChartBoostView((JSONObject) objects[0], CBView.CBViewType.CBViewTypeInterstitial);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
                this.connection.sendRequest(request);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void loadMoreApps() {
        try {
            CBAPIRequest request = new CBAPIRequest(this.context, "api", "more");
            request.appendDeviceInfoParams();
            request.sign(this.appId, this.appSignature);
            request.setContextInfoObject(new CBRunnable() {
                /* class com.chartboost.sdk.ChartBoost.AnonymousClass2 */

                @Override // com.chartboost.sdk.CBRunnable
                public void run(Object... objects) {
                    if (objects.length == 1 && (objects[0] instanceof JSONObject)) {
                        try {
                            if (((JSONObject) objects[0]).getInt("status") == 200) {
                                this.loadChartBoostView((JSONObject) objects[0], CBView.CBViewType.CBViewTypeMoreApps);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });
            this.connection.sendRequest(request);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void loadChartBoostView(JSONObject response, CBView.CBViewType type) {
        Intent i = new Intent(this.context, CBDialogActivity.class);
        i.putExtra(CBDialogActivity.BUNDLE_KEY_TYPE, type.ordinal());
        i.putExtra(CBDialogActivity.BUNDLE_KEY_CONFIGOBJECT, response.toString());
        this.context.startActivity(i);
    }

    /* access modifiers changed from: protected */
    public void handleChartBoostRequest(String url, CBView view) {
        Log.i(TAG, "Handling chartboost:// request: " + url);
        if (view.getType() == CBView.CBViewType.CBViewTypeInterstitial) {
            handleChartBoostRequestForInterstitial(url, view);
        } else if (view.getType() == CBView.CBViewType.CBViewTypeMoreApps) {
            handleChartBoostRequestForMoreApps(url, view);
        }
    }

    private void handleChartBoostRequestForMoreApps(String url, CBView moreAppsView) {
        String[] items = url.split("/");
        String function = items[2];
        if (this.delegate != null) {
            this.delegate.didDismissMoreApps(moreAppsView);
        }
        if (function.equals(ASConstants.KASVerbClose)) {
            if (this.delegate != null) {
                this.delegate.didCloseMoreApps(moreAppsView);
            }
            ((CBDialogActivity) CBDialogActivity.getContext()).close();
        } else if (function.equals("link")) {
            if (this.delegate != null) {
                this.delegate.didClickMoreApps(moreAppsView);
            }
            if (moreAppsView.getState() == CBView.CBViewState.CBViewStateDisplayedByDefaultController) {
                ((CBDialogActivity) CBDialogActivity.getContext()).close();
            }
            try {
                CBAPIRequest request = new CBAPIRequest(this.context, "api", AbstractJSAdapter.Events.CLICK);
                request.appendDeviceInfoParams();
                JSONObject embeddedData = new JSONObject(new JSONTokener(URLDecoder.decode(items[4])));
                try {
                    request.appendBodyArgument("to", embeddedData.getString("to"));
                } catch (JSONException e) {
                }
                try {
                    request.appendBodyArgument("cgn", embeddedData.getString("cgn"));
                } catch (JSONException e2) {
                }
                try {
                    request.appendBodyArgument("creative", embeddedData.getString("creative"));
                } catch (JSONException e3) {
                }
                try {
                    request.appendBodyArgument("type", embeddedData.getString("type"));
                } catch (JSONException e4) {
                }
                try {
                    request.appendBodyArgument("more_type", embeddedData.getString("more_type"));
                } catch (JSONException e5) {
                }
                request.sign(this.appId, this.appSignature);
                final String finalRedirectUrl = URLDecoder.decode(items[3]);
                request.setContextInfoObject(new CBRunnable() {
                    /* class com.chartboost.sdk.ChartBoost.AnonymousClass3 */

                    @Override // com.chartboost.sdk.CBRunnable
                    public void run(Object... objects) {
                        this.openUrl(finalRedirectUrl);
                    }
                });
                this.connection.sendRequest(request);
            } catch (Exception e6) {
                e6.printStackTrace();
            }
        }
    }

    private void handleChartBoostRequestForInterstitial(String url, CBView interstitialView) {
        Log.w("cb", "handleChartBoostRequestForInterstitial");
        String[] items = url.split("/");
        String function = items[2];
        if (this.delegate != null) {
            this.delegate.didDismissInterstitial(interstitialView);
        }
        Log.w("cb", "function: " + function);
        if (function.equals(ASConstants.KASVerbClose)) {
            if (this.delegate != null) {
                this.delegate.didCloseInterstitial(interstitialView);
            }
            ((CBDialogActivity) CBDialogActivity.getContext()).close();
        } else if (function.equals("link")) {
            if (this.delegate != null) {
                this.delegate.didClickInterstitial(interstitialView);
            }
            if (interstitialView.getState() == CBView.CBViewState.CBViewStateDisplayedByDefaultController) {
                Log.w("cb", "closing interstitial ad");
                ((CBDialogActivity) CBDialogActivity.getContext()).close();
            }
            try {
                CBAPIRequest request = new CBAPIRequest(this.context, "api", AbstractJSAdapter.Events.CLICK);
                request.appendDeviceInfoParams();
                request.appendBodyArgument("to", interstitialView.getResponseContext().getString("to"));
                request.appendBodyArgument("cgn", interstitialView.getResponseContext().getString("cgn"));
                request.appendBodyArgument("creative", interstitialView.getResponseContext().getString("creative"));
                request.sign(this.appId, this.appSignature);
                Log.w("cb", "decoding: " + items[3]);
                final String finalRedirectUrl = URLDecoder.decode(items[3]);
                request.setContextInfoObject(new CBRunnable() {
                    /* class com.chartboost.sdk.ChartBoost.AnonymousClass4 */

                    @Override // com.chartboost.sdk.CBRunnable
                    public void run(Object... objects) {
                        this.openUrl(finalRedirectUrl);
                    }
                });
                Log.w("cb", "sending request click request");
                this.connection.sendRequest(request);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public Context getContext() {
        return this.context;
    }

    public void setContext(Context context2) {
        this.context = context2;
        CBDefaultViewController.getSharedController().setContext(context2);
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void openUrl(String url) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(url));
        Log.i(TAG, "Sideloading URL: " + url);
        this.context.startActivity(intent);
    }

    @Override // com.chartboost.sdk.CBAPIConnectionDelegate
    public void didReceiveAPIResponse(JSONObject response, CBAPIRequest request) {
        Log.i(TAG, "API response received!");
        if (request.getContextInfoObject() instanceof CBRunnable) {
            ((CBRunnable) request.getContextInfoObject()).run(response);
        }
    }

    @Override // com.chartboost.sdk.CBAPIConnectionDelegate
    public void didFailToReceiveAPIResponse(CBAPIRequest request) {
        Log.w(TAG, "API response failed!");
    }
}
