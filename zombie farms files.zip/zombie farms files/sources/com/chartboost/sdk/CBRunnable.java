package com.chartboost.sdk;

public interface CBRunnable {
    void run(Object... objArr);
}
