package com.flurry.android;

import java.io.DataOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* access modifiers changed from: package-private */
public final class p {
    final String a;
    int b;
    w c;
    long d;
    List e;
    private byte f;
    private AtomicInteger g;

    p(p pVar, long j) {
        this(pVar.a, pVar.f, j);
        this.c = pVar.c;
        this.d = pVar.d;
    }

    p(String str, byte b2, long j) {
        this.e = new ArrayList();
        this.g = new AtomicInteger(0);
        this.b = this.g.incrementAndGet();
        this.a = str;
        this.f = b2;
        this.e.add(new f((byte) 1, j));
    }

    /* access modifiers changed from: package-private */
    public final void a(f fVar) {
        this.e.add(fVar);
    }

    /* access modifiers changed from: package-private */
    public final long a() {
        return ((f) this.e.get(0)).b;
    }

    /* access modifiers changed from: package-private */
    public final void a(DataOutput dataOutput) {
        dataOutput.writeShort(this.b);
        dataOutput.writeUTF(this.a);
        dataOutput.writeByte(this.f);
        if (this.c == null) {
            dataOutput.writeLong(0);
            dataOutput.writeLong(0);
            dataOutput.writeByte(0);
        } else {
            dataOutput.writeLong(this.c.a);
            dataOutput.writeLong(this.c.e);
            byte[] bArr = this.c.g;
            dataOutput.writeByte(bArr.length);
            dataOutput.write(bArr);
        }
        dataOutput.writeShort(this.e.size());
        for (f fVar : this.e) {
            dataOutput.writeByte(fVar.a);
            dataOutput.writeLong(fVar.b);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{hook: " + this.a + ", ad: " + this.c.d + ", transitions: [");
        for (f fVar : this.e) {
            sb.append(fVar);
            sb.append(",");
        }
        sb.append("]}");
        return sb.toString();
    }
}
