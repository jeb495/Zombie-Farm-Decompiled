package com.flurry.android;

/* access modifiers changed from: package-private */
public final class ae implements Runnable {
    private /* synthetic */ int a;
    private /* synthetic */ v b;

    ae(v vVar, int i) {
        this.b = vVar;
        this.a = i;
    }

    public final void run() {
        this.b.z.onAdsUpdated(new CallbackEvent(this.a));
    }
}
