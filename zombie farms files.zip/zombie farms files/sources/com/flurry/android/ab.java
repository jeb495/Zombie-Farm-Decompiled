package com.flurry.android;

final class ab {
    int a = FlurryAgent.g();
    long b;
    String c;
    String d;
    String e;

    ab() {
    }
}
