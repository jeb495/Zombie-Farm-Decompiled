package com.flurry.android;

import android.os.Handler;

final class a {
    String a;
    long b;
    String c;
    String d;
    Handler e;

    a() {
    }
}
