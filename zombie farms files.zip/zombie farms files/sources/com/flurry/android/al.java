package com.flurry.android;

import android.content.Context;
import android.os.Handler;

/* access modifiers changed from: package-private */
public final class al implements Runnable {
    final /* synthetic */ String a;
    final /* synthetic */ Context b;
    final /* synthetic */ p c;
    final /* synthetic */ v d;

    al(v vVar, String str, Context context, p pVar) {
        this.d = vVar;
        this.a = str;
        this.b = context;
        this.c = pVar;
    }

    public final void run() {
        new Handler().post(new m(this, this.d.d(this.a)));
    }
}
