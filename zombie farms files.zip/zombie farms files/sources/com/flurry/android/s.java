package com.flurry.android;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.widget.LinearLayout;

/* access modifiers changed from: package-private */
public final class s extends LinearLayout {
    public s(CatalogActivity catalogActivity, Context context) {
        super(context);
        setBackgroundColor(-1);
        AdImage l = catalogActivity.e.l();
        if (l != null) {
            ImageView imageView = new ImageView(context);
            imageView.setId(10000);
            byte[] bArr = l.e;
            if (bArr != null) {
                imageView.setImageBitmap(BitmapFactory.decodeByteArray(bArr, 0, bArr.length));
            }
            r.a(context, imageView, r.a(context, l.b), r.a(context, l.c));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.setMargins(0, 0, 0, -3);
            setGravity(3);
            addView(imageView, layoutParams);
        }
    }
}
