package com.flurry.android;

final class k implements Runnable {
    private /* synthetic */ ah a;

    k(ah ahVar) {
        this.a = ahVar;
    }

    public final void run() {
        ah.a(this.a);
    }
}
