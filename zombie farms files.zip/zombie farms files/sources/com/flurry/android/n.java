package com.flurry.android;

import java.security.cert.X509Certificate;
import javax.net.ssl.X509TrustManager;

/* access modifiers changed from: package-private */
public final class n implements X509TrustManager {
    n() {
    }

    @Override // javax.net.ssl.X509TrustManager
    public final void checkClientTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    @Override // javax.net.ssl.X509TrustManager
    public final void checkServerTrusted(X509Certificate[] x509CertificateArr, String str) {
    }

    public final X509Certificate[] getAcceptedIssuers() {
        return null;
    }
}
