package com.flurry.android;

import java.util.List;

/* access modifiers changed from: package-private */
public final class y {
    String a;
    List b;

    y() {
    }
}
