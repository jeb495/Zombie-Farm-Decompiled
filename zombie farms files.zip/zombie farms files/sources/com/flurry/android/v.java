package com.flurry.android;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import com.android.adsymp.core.ASConstants;
import com.google.ads.AdActivity;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

/* access modifiers changed from: package-private */
public final class v implements View.OnClickListener {
    private static volatile long A = 0;
    static String a = "FlurryAgent";
    static String b = ASConstants.kEmptyString;
    private static volatile String c = "market://";
    private static volatile String d = "market://details?id=";
    private static volatile String e = "https://market.android.com/details?id=";
    private static String f = "com.flurry.android.ACTION_CATALOG";
    private static int g = 5000;
    private String h;
    private String i;
    private String j;
    private long k;
    private long l;
    private long m;
    private long n;
    private aa o = new aa();
    private boolean p = true;
    private volatile boolean q;
    private String r;
    private Map s = new HashMap();
    private Handler t;
    private boolean u;
    private transient Map v = new HashMap();
    private ah w;
    private List x = new ArrayList();
    private Map y = new HashMap();
    private AppCircleCallback z;

    static /* synthetic */ void a(v vVar, Context context, String str) {
        if (str.startsWith(d)) {
            String substring = str.substring(d.length());
            if (vVar.p) {
                try {
                    ai.a(a, "Launching Android Market for app " + substring);
                    context.startActivity(new Intent("android.intent.action.VIEW").setData(Uri.parse(str)));
                } catch (Exception e2) {
                    ai.c(a, "Cannot launch Marketplace url " + str, e2);
                }
            } else {
                ai.a(a, "Launching Android Market website for app " + substring);
                context.startActivity(new Intent("android.intent.action.VIEW").setData(Uri.parse(e + substring)));
            }
        } else {
            ai.d(a, "Unexpected android market url scheme: " + str);
        }
    }

    static {
        new Random(System.currentTimeMillis());
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Context context, a aVar) {
        boolean z2 = true;
        synchronized (this) {
            if (!this.q) {
                this.h = aVar.c;
                this.i = aVar.d;
                this.j = aVar.a;
                this.k = aVar.b;
                this.t = aVar.e;
                this.w = new ah(this.t, g);
                context.getResources().getDisplayMetrics();
                this.y.clear();
                this.v.clear();
                this.o.a(context, this, aVar);
                this.s.clear();
                PackageManager packageManager = context.getPackageManager();
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse(d + context.getPackageName()));
                if (packageManager.queryIntentActivities(intent, 65536).size() <= 0) {
                    z2 = false;
                }
                this.p = z2;
                this.q = true;
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(long j2, long j3) {
        this.l = j2;
        this.m = j3;
        this.n = 0;
        this.x.clear();
    }

    /* access modifiers changed from: package-private */
    public final boolean a() {
        return this.q;
    }

    /* access modifiers changed from: package-private */
    public final void a(String str) {
        this.r = str;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void b() {
        if (p()) {
            this.o.d();
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void c() {
        if (p()) {
            this.o.e();
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Map map, Map map2, Map map3, Map map4, Map map5, Map map6) {
        if (p()) {
            this.o.a(map, map2, map3, map4, map5, map6);
            Log.i("FlurryAgent", this.o.toString());
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized long d() {
        long c2;
        if (!p()) {
            c2 = 0;
        } else {
            c2 = this.o.c();
        }
        return c2;
    }

    /* access modifiers changed from: package-private */
    public final synchronized Set e() {
        Set a2;
        if (!p()) {
            a2 = Collections.emptySet();
        } else {
            a2 = this.o.a();
        }
        return a2;
    }

    /* access modifiers changed from: package-private */
    public final synchronized AdImage a(long j2) {
        AdImage b2;
        if (!p()) {
            b2 = null;
        } else {
            b2 = this.o.b(j2);
        }
        return b2;
    }

    private synchronized AdImage n() {
        AdImage a2;
        if (!p()) {
            a2 = null;
        } else {
            a2 = this.o.a((short) 1);
        }
        return a2;
    }

    /* access modifiers changed from: package-private */
    public final synchronized List f() {
        return this.x;
    }

    /* access modifiers changed from: package-private */
    public final synchronized p b(long j2) {
        return (p) this.v.get(Long.valueOf(j2));
    }

    /* access modifiers changed from: package-private */
    public final synchronized void g() {
        this.v.clear();
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Context context, String str) {
        if (p()) {
            try {
                List a2 = a(Arrays.asList(str), (Long) null);
                if (a2 == null || a2.isEmpty()) {
                    Intent intent = new Intent(o());
                    intent.addCategory("android.intent.category.DEFAULT");
                    context.startActivity(intent);
                } else {
                    p pVar = new p(str, (byte) 2, j());
                    pVar.c = (w) a2.get(0);
                    c(pVar);
                    b(context, pVar, this.h + a(pVar));
                }
            } catch (Exception e2) {
                ai.d(a, "Failed to launch promotional canvas for hook: " + str, e2);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final void a(AppCircleCallback appCircleCallback) {
        this.z = appCircleCallback;
    }

    /* access modifiers changed from: package-private */
    public final void a(boolean z2) {
        this.u = z2;
    }

    /* access modifiers changed from: package-private */
    public final boolean h() {
        return this.u;
    }

    /* access modifiers changed from: package-private */
    public final String i() {
        return this.h;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Context context, p pVar, String str) {
        if (p()) {
            this.t.post(new al(this, str, context, pVar));
        }
    }

    /* access modifiers changed from: private */
    public String d(String str) {
        try {
            if (str.startsWith(c)) {
                return str;
            }
            HttpResponse execute = new DefaultHttpClient().execute(new HttpGet(str));
            int statusCode = execute.getStatusLine().getStatusCode();
            if (statusCode == 200) {
                String entityUtils = EntityUtils.toString(execute.getEntity());
                if (!entityUtils.startsWith(c)) {
                    return d(entityUtils);
                }
                return entityUtils;
            }
            ai.c(a, "Cannot process with responseCode " + statusCode);
            e("Error when fetching application's android market ID, responseCode " + statusCode);
            return str;
        } catch (UnknownHostException e2) {
            ai.c(a, "Unknown host: " + e2.getMessage());
            if (this.z != null) {
                e("Unknown host: " + e2.getMessage());
            }
            return null;
        } catch (Exception e3) {
            ai.c(a, "Failed on url: " + str, e3);
            return null;
        }
    }

    /* access modifiers changed from: private */
    public void e(String str) {
        a(new af(this, str));
    }

    /* access modifiers changed from: package-private */
    public final synchronized Offer b(String str) {
        Offer offer = null;
        synchronized (this) {
            if (p()) {
                List a2 = a(Arrays.asList(str), (Long) null);
                if (a2 != null && !a2.isEmpty()) {
                    offer = a(str, (w) a2.get(0));
                    ai.a(a, "Impression for offer with ID " + offer.getId());
                }
            }
        }
        return offer;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Context context, long j2) {
        if (p()) {
            u uVar = (u) this.y.get(Long.valueOf(j2));
            if (uVar == null) {
                ai.b(a, "Cannot find offer " + j2);
            } else {
                p b2 = b(uVar.b);
                uVar.b = b2;
                ai.a(a, "Offer " + uVar.a + " accepted. Sent with cookies: " + this.s);
                a(context, b2, FlurryAgent.c() + a(b2));
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized List c(String str) {
        List arrayList;
        if (!p()) {
            arrayList = Collections.emptyList();
        } else if (!this.o.b()) {
            arrayList = Collections.emptyList();
        } else {
            w[] a2 = this.o.a(str);
            arrayList = new ArrayList();
            if (a2 != null && a2.length > 0) {
                for (w wVar : a2) {
                    arrayList.add(a(str, wVar));
                }
            }
            ai.a(a, "Impressions for " + arrayList.size() + " offers.");
        }
        return arrayList;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(List list) {
        if (p()) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                this.y.remove((Long) it.next());
            }
        }
    }

    private Offer a(String str, w wVar) {
        p pVar = new p(str, (byte) 3, j());
        c(pVar);
        pVar.a(new f((byte) 2, j()));
        pVar.c = wVar;
        am a2 = this.o.a(wVar.a);
        String str2 = a2 == null ? ASConstants.kEmptyString : a2.a;
        int i2 = a2 == null ? 0 : a2.c;
        long j2 = A + 1;
        A = j2;
        u uVar = new u(j2, pVar, wVar.h, wVar.d, str2, i2);
        this.y.put(Long.valueOf(uVar.a), uVar);
        return new Offer(uVar.a, uVar.f, uVar.c, uVar.d, uVar.e);
    }

    /* access modifiers changed from: package-private */
    public final synchronized List a(Context context, List list, Long l2, int i2, boolean z2) {
        List emptyList;
        if (!p()) {
            emptyList = Collections.emptyList();
        } else if (!this.o.b() || list == null) {
            emptyList = Collections.emptyList();
        } else {
            List a2 = a(list, l2);
            int min = Math.min(list.size(), a2.size());
            ArrayList arrayList = new ArrayList();
            for (int i3 = 0; i3 < min; i3++) {
                String str = (String) list.get(i3);
                e b2 = this.o.b(str);
                if (b2 != null) {
                    p pVar = new p((String) list.get(i3), (byte) 1, j());
                    c(pVar);
                    if (i3 < a2.size()) {
                        pVar.c = (w) a2.get(i3);
                        pVar.a(new f((byte) 2, j()));
                        arrayList.add(new z(context, this, pVar, b2, i2, z2));
                    }
                } else {
                    ai.d(a, "Cannot find hook: " + str);
                }
            }
            emptyList = arrayList;
        }
        return emptyList;
    }

    /* access modifiers changed from: package-private */
    public final synchronized View a(Context context, String str, int i2) {
        o oVar;
        if (!p()) {
            oVar = null;
        } else {
            oVar = new o(this, context, str, i2);
            this.w.a(oVar);
        }
        return oVar;
    }

    private void c(p pVar) {
        if (this.x.size() < 32767) {
            this.x.add(pVar);
            this.v.put(Long.valueOf(pVar.a()), pVar);
        }
    }

    private List a(List list, Long l2) {
        if (list == null || list.isEmpty() || !this.o.b()) {
            return Collections.emptyList();
        }
        w[] a2 = this.o.a((String) list.get(0));
        if (a2 == null || a2.length <= 0) {
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList(Arrays.asList(a2));
        Collections.shuffle(arrayList);
        if (l2 != null) {
            Iterator it = arrayList.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (((w) it.next()).a == l2.longValue()) {
                        it.remove();
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        return arrayList.subList(0, Math.min(arrayList.size(), list.size()));
    }

    /* access modifiers changed from: package-private */
    public final synchronized long j() {
        long elapsedRealtime = SystemClock.elapsedRealtime() - this.m;
        if (elapsedRealtime <= this.n) {
            elapsedRealtime = this.n + 1;
            this.n = elapsedRealtime;
        }
        this.n = elapsedRealtime;
        return this.n;
    }

    public final synchronized void onClick(View view) {
        z zVar = (z) view;
        p b2 = b(zVar.a());
        zVar.a(b2);
        String a2 = a(b2);
        if (this.u) {
            b(view.getContext(), b2, this.h + a2);
        } else {
            a(view.getContext(), b2, this.i + a2);
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(String str, String str2) {
        this.s.put(str, str2);
    }

    /* access modifiers changed from: package-private */
    public final synchronized void k() {
        this.s.clear();
    }

    private void b(Context context, p pVar, String str) {
        Intent intent = new Intent(o());
        intent.addCategory("android.intent.category.DEFAULT");
        intent.putExtra("u", str);
        if (pVar != null) {
            intent.putExtra(AdActivity.ORIENTATION_PARAM, pVar.a());
        }
        context.startActivity(intent);
    }

    private static String o() {
        return FlurryAgent.a != null ? FlurryAgent.a : f;
    }

    /* access modifiers changed from: package-private */
    public final synchronized String a(p pVar) {
        StringBuilder append;
        w wVar = pVar.c;
        append = new StringBuilder().append("?apik=").append(this.j).append("&cid=").append(wVar.e).append("&adid=").append(wVar.a).append("&pid=").append(this.r).append("&iid=").append(this.k).append("&sid=").append(this.l).append("&lid=").append(pVar.b).append("&aso=").append(((f) pVar.e.get(pVar.e.size() - 1)).b).append("&hid=").append(r.a(pVar.a)).append("&ac=").append(a(wVar.g));
        if (this.s != null && !this.s.isEmpty()) {
            for (Map.Entry entry : this.s.entrySet()) {
                append.append("&").append("c_" + r.a((String) entry.getKey())).append("=").append(r.a((String) entry.getValue()));
            }
        }
        append.append("&ats=").append(System.currentTimeMillis());
        return append.toString();
    }

    private static String a(byte[] bArr) {
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < bArr.length; i2++) {
            int i3 = (bArr[i2] >> 4) & 15;
            if (i3 < 10) {
                sb.append((char) (i3 + 48));
            } else {
                sb.append((char) ((i3 + 65) - 10));
            }
            int i4 = bArr[i2] & 15;
            if (i4 < 10) {
                sb.append((char) (i4 + 48));
            } else {
                sb.append((char) ((i4 + 65) - 10));
            }
        }
        return sb.toString();
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[adLogs=").append(this.x).append("]");
        return sb.toString();
    }

    /* access modifiers changed from: package-private */
    public final synchronized AdImage l() {
        AdImage n2;
        if (!p()) {
            n2 = null;
        } else {
            n2 = n();
        }
        return n2;
    }

    /* access modifiers changed from: package-private */
    public final synchronized p b(p pVar) {
        if (!this.x.contains(pVar)) {
            p pVar2 = new p(pVar, j());
            this.x.add(pVar2);
            pVar = pVar2;
        }
        pVar.a(new f((byte) 4, j()));
        return pVar;
    }

    private static void a(Runnable runnable) {
        new Handler().post(runnable);
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(int i2) {
        if (this.z != null) {
            a(new ae(this, i2));
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized boolean m() {
        boolean b2;
        if (!p()) {
            b2 = false;
        } else {
            b2 = this.o.b();
        }
        return b2;
    }

    private boolean p() {
        if (!this.q) {
            ai.d(a, "AppCircle is not initialized");
        }
        if (this.r == null) {
            ai.d(a, "Cannot identify UDID.");
        }
        return this.q;
    }
}
