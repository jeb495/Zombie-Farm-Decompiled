package com.flurry.android;

public interface Constants {
    public static final byte FEMALE = 0;
    public static final byte MALE = 1;
    public static final int MODE_LANDSCAPE = 2;
    public static final int MODE_PORTRAIT = 1;
    public static final byte UNKNOWN = -1;
}
