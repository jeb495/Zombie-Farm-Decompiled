package com.flurry.android;

import com.android.adsymp.core.ASConstants;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;

final class t implements Runnable {
    private /* synthetic */ Map a;
    private /* synthetic */ InstallReceiver b;

    t(InstallReceiver installReceiver, Map map) {
        this.b = installReceiver;
        this.a = map;
    }

    public final void run() {
        Throwable th;
        DataOutputStream dataOutputStream = null;
        try {
            File parentFile = InstallReceiver.a(this.b).getParentFile();
            if (parentFile.mkdirs() || parentFile.exists()) {
                DataOutputStream dataOutputStream2 = new DataOutputStream(new FileOutputStream(InstallReceiver.a(this.b)));
                try {
                    boolean z = true;
                    for (Map.Entry entry : this.a.entrySet()) {
                        if (z) {
                            z = false;
                        } else {
                            dataOutputStream2.writeUTF("&");
                        }
                        dataOutputStream2.writeUTF((String) entry.getKey());
                        dataOutputStream2.writeUTF("=");
                        dataOutputStream2.writeUTF((String) entry.getValue());
                    }
                    dataOutputStream2.writeShort(0);
                    r.a(dataOutputStream2);
                } catch (Throwable th2) {
                    th = th2;
                    dataOutputStream = dataOutputStream2;
                    r.a(dataOutputStream);
                    throw th;
                }
            } else {
                ai.b("InstallReceiver", "Unable to create persistent dir: " + parentFile);
                r.a((Closeable) null);
            }
        } catch (Throwable th3) {
            th = th3;
            ai.b("InstallReceiver", ASConstants.kEmptyString, th);
            r.a(dataOutputStream);
        }
    }
}
