package com.flurry.android;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.View;
import com.android.adsymp.core.ASConstants;
import com.ngmoco.gamejs.ui.Commands;
import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import com.tapjoy.TapjoyConstants;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.Thread;
import java.security.DigestOutputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public final class FlurryAgent implements LocationListener {
    static String a;
    private static final String[] b = {"9774d56d682e549c", "dead00beef"};
    private static volatile String c = null;
    private static volatile String d = null;
    private static volatile String e = "http://ad.flurry.com/getCanvas.do";
    private static volatile String f = null;
    private static volatile String g = "http://ad.flurry.com/getAndroidApp.do";
    private static final FlurryAgent h = new FlurryAgent();
    private static long i = TapjoyConstants.TIMER_INCREMENT;
    private static boolean j = true;
    private static boolean k = false;
    private static volatile String kInsecureReportUrl = "http://data.flurry.com/aap.do";
    private static volatile String kSecureReportUrl = "https://data.flurry.com/aap.do";
    private static boolean l = false;
    private static boolean m = true;
    private static Criteria n = null;
    private static boolean o = false;
    private static AppCircle p = new AppCircle();
    private static AtomicInteger q = new AtomicInteger(0);
    private static AtomicInteger r = new AtomicInteger(0);
    private String A;
    private String B;
    private boolean C = true;
    private List D;
    private LocationManager E;
    private String F;
    private boolean G;
    private long H;
    private byte[] I;
    private List J = new ArrayList();
    private long K;
    private long L;
    private long M;
    private String N = ASConstants.kEmptyString;
    private String O = ASConstants.kEmptyString;
    private byte P = -1;
    private String Q = ASConstants.kEmptyString;
    private byte R = -1;
    private Long S;
    private int T;
    private Location U;
    private Map V = new HashMap();
    private List W = new ArrayList();
    private boolean X;
    private int Y;
    private List Z = new ArrayList();
    private int aa;
    private v ab = new v();
    private final Handler s;
    private File t;
    private File u = null;
    private volatile boolean v = false;
    private volatile boolean w = false;
    private long x;
    private Map y = new WeakHashMap();
    private String z;

    static /* synthetic */ void a(FlurryAgent flurryAgent, Context context, boolean z2) {
        Location location = null;
        if (z2) {
            try {
                location = flurryAgent.d(context);
            } catch (Throwable th) {
                ai.b("FlurryAgent", ASConstants.kEmptyString, th);
                return;
            }
        }
        synchronized (flurryAgent) {
            flurryAgent.U = location;
        }
        if (o) {
            flurryAgent.ab.b();
        }
        flurryAgent.I = e(context);
        ai.c("FlurryAgent", "Fetching IMEI: " + flurryAgent.I);
        flurryAgent.c(true);
    }

    static /* synthetic */ void b(FlurryAgent flurryAgent, Context context) {
        boolean z2 = false;
        try {
            synchronized (flurryAgent) {
                long elapsedRealtime = SystemClock.elapsedRealtime() - flurryAgent.x;
                if (!flurryAgent.v && elapsedRealtime > i && flurryAgent.J.size() > 0) {
                    z2 = true;
                }
            }
            if (z2) {
                flurryAgent.c(false);
            }
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public class FlurryDefaultExceptionHandler implements Thread.UncaughtExceptionHandler {
        private Thread.UncaughtExceptionHandler a = Thread.getDefaultUncaughtExceptionHandler();

        FlurryDefaultExceptionHandler() {
        }

        public void uncaughtException(Thread thread, Throwable th) {
            try {
                FlurryAgent.h.a(th);
            } catch (Throwable th2) {
                ai.b("FlurryAgent", ASConstants.kEmptyString, th2);
            }
            if (this.a != null) {
                this.a.uncaughtException(thread, th);
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final void a(Throwable th) {
        th.printStackTrace();
        String str = ASConstants.kEmptyString;
        StackTraceElement[] stackTrace = th.getStackTrace();
        if (stackTrace != null && stackTrace.length > 0) {
            StackTraceElement stackTraceElement = stackTrace[0];
            StringBuilder sb = new StringBuilder();
            sb.append(stackTraceElement.getClassName()).append(".").append(stackTraceElement.getMethodName()).append(":").append(stackTraceElement.getLineNumber());
            if (th.getMessage() != null) {
                sb.append(" (" + th.getMessage() + ")");
            }
            str = sb.toString();
        } else if (th.getMessage() != null) {
            str = th.getMessage();
        }
        onError("uncaught", str, th.getClass().toString());
        this.y.clear();
        a((Context) null, true);
    }

    private FlurryAgent() {
        HandlerThread handlerThread = new HandlerThread("FlurryAgent");
        handlerThread.start();
        this.s = new Handler(handlerThread.getLooper());
    }

    public static void setCatalogIntentName(String str) {
        a = str;
    }

    public static void enableAppCircle() {
        o = true;
    }

    public static AppCircle getAppCircle() {
        return p;
    }

    static View a(Context context, String str, int i2) {
        if (!o) {
            return null;
        }
        try {
            return h.ab.a(context, str, i2);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
            return null;
        }
    }

    static void a(Context context, String str) {
        if (o) {
            h.ab.a(context, str);
        }
    }

    static Offer a(String str) {
        if (!o) {
            return null;
        }
        return h.ab.b(str);
    }

    static List b(String str) {
        if (!o) {
            return null;
        }
        return h.ab.c(str);
    }

    static void a(Context context, long j2) {
        if (!o) {
            ai.d("FlurryAgent", "Cannot accept Offer. AppCircle is not enabled");
        }
        h.ab.a(context, j2);
    }

    static void a(List list) {
        if (o) {
            h.ab.a(list);
        }
    }

    static void a(boolean z2) {
        if (o) {
            h.ab.a(z2);
        }
    }

    static boolean a() {
        return h.ab.h();
    }

    public static void setDefaultNoAdsMessage(String str) {
        if (o) {
            if (str == null) {
                str = ASConstants.kEmptyString;
            }
            v.b = str;
        }
    }

    static void a(AppCircleCallback appCircleCallback) {
        h.ab.a(appCircleCallback);
    }

    public static void addUserCookie(String str, String str2) {
        if (o) {
            h.ab.a(str, str2);
        }
    }

    public static void clearUserCookies() {
        if (o) {
            h.ab.k();
        }
    }

    public static void setVersionName(String str) {
        synchronized (h) {
            h.B = str;
        }
    }

    public static int getAgentVersion() {
        return Commands.CommandIDs.setScrollIndicatorsVisible;
    }

    public static void setReportLocation(boolean z2) {
        synchronized (h) {
            h.C = z2;
        }
    }

    public static void setLogEnabled(boolean z2) {
        synchronized (h) {
            if (z2) {
                ai.b();
            } else {
                ai.a();
            }
        }
    }

    public static void setLogLevel(int i2) {
        synchronized (h) {
            ai.a(i2);
        }
    }

    public static void setContinueSessionMillis(long j2) {
        if (j2 < 5000) {
            ai.b("FlurryAgent", "Invalid time set for session resumption: " + j2);
            return;
        }
        synchronized (h) {
            i = j2;
        }
    }

    public static void setLogEvents(boolean z2) {
        synchronized (h) {
            j = z2;
        }
    }

    public static void setUseHttps(boolean z2) {
        k = z2;
    }

    public static void setCaptureUncaughtExceptions(boolean z2) {
        synchronized (h) {
            if (h.v) {
                ai.b("FlurryAgent", "Cannot setCaptureUncaughtExceptions after onSessionStart");
            } else {
                m = z2;
            }
        }
    }

    public static void onStartSession(Context context, String str) {
        if (context == null) {
            throw new NullPointerException("Null context");
        } else if (str == null || str.length() == 0) {
            throw new IllegalArgumentException("Api key not specified");
        } else {
            try {
                h.b(context, str);
            } catch (Throwable th) {
                ai.b("FlurryAgent", ASConstants.kEmptyString, th);
            }
        }
    }

    public static void onEndSession(Context context) {
        if (context == null) {
            throw new NullPointerException("Null context");
        }
        try {
            h.a(context, false);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public static void logEvent(String str) {
        try {
            h.a(str, (Map) null, false);
        } catch (Throwable th) {
            ai.b("FlurryAgent", "Failed to log event: " + str, th);
        }
    }

    public static void logEvent(String str, Map map) {
        try {
            h.a(str, map, false);
        } catch (Throwable th) {
            ai.b("FlurryAgent", "Failed to log event: " + str, th);
        }
    }

    public static void logEvent(String str, boolean z2) {
        try {
            h.a(str, (Map) null, z2);
        } catch (Throwable th) {
            ai.b("FlurryAgent", "Failed to log event: " + str, th);
        }
    }

    public static void logEvent(String str, Map map, boolean z2) {
        try {
            h.a(str, map, z2);
        } catch (Throwable th) {
            ai.b("FlurryAgent", "Failed to log event: " + str, th);
        }
    }

    public static void endTimedEvent(String str) {
        try {
            h.c(str);
        } catch (Throwable th) {
            ai.b("FlurryAgent", "Failed to signify the end of event: " + str, th);
        }
    }

    public static void onError(String str, String str2, String str3) {
        try {
            h.a(str, str2, str3);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public static void onEvent(String str) {
        try {
            h.a(str, (Map) null, false);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public static void onEvent(String str, Map map) {
        try {
            h.a(str, map, false);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public static void onPageView() {
        try {
            h.l();
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    public static void setReportUrl(String str) {
        c = str;
    }

    public static void setCanvasUrl(String str) {
        d = str;
    }

    public static void setGetAppUrl(String str) {
        f = str;
    }

    public static void setLocationCriteria(Criteria criteria) {
        synchronized (h) {
            n = criteria;
        }
    }

    public static void setAge(int i2) {
        if (i2 > 0 && i2 < 110) {
            Date date = new Date(new Date(System.currentTimeMillis() - (((long) i2) * 31449600000L)).getYear(), 1, 1);
            h.S = Long.valueOf(date.getTime());
        }
    }

    public static void setGender(byte b2) {
        switch (b2) {
            case 0:
            case 1:
                h.R = b2;
                return;
            default:
                h.R = -1;
                return;
        }
    }

    public static void setUserId(String str) {
        synchronized (h) {
            h.Q = r.a(str, (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
        }
    }

    public static boolean getForbidPlaintextFallback() {
        return false;
    }

    protected static boolean isCaptureUncaughtExceptions() {
        return m;
    }

    static v b() {
        return h.ab;
    }

    private synchronized void b(Context context, String str) {
        if (this.z != null && !this.z.equals(str)) {
            ai.b("FlurryAgent", "onStartSession called with different api keys: " + this.z + " and " + str);
        }
        if (((Context) this.y.put(context, context)) != null) {
            ai.d("FlurryAgent", "onStartSession called with duplicate context, use a specific Activity or Service as context instead of using a global context");
        }
        if (!this.v) {
            ai.a("FlurryAgent", "Initializing Flurry session");
            q.set(0);
            r.set(0);
            this.z = str;
            this.u = context.getFileStreamPath(".flurryagent." + Integer.toString(this.z.hashCode(), 16));
            this.t = context.getFileStreamPath(".flurryb.");
            if (m) {
                Thread.setDefaultUncaughtExceptionHandler(new FlurryDefaultExceptionHandler());
            }
            Context applicationContext = context.getApplicationContext();
            if (this.B == null) {
                this.B = c(applicationContext);
            }
            String packageName = applicationContext.getPackageName();
            if (this.A != null && !this.A.equals(packageName)) {
                ai.b("FlurryAgent", "onStartSession called from different application packages: " + this.A + " and " + packageName);
            }
            this.A = packageName;
            long elapsedRealtime = SystemClock.elapsedRealtime();
            if (elapsedRealtime - this.x > i) {
                ai.a("FlurryAgent", "New session");
                this.K = System.currentTimeMillis();
                this.L = elapsedRealtime;
                this.M = -1;
                this.Q = ASConstants.kEmptyString;
                this.T = 0;
                this.U = null;
                this.O = TimeZone.getDefault().getID();
                this.N = Locale.getDefault().getLanguage() + "_" + Locale.getDefault().getCountry();
                this.V = new HashMap();
                this.W = new ArrayList();
                this.X = true;
                this.Z = new ArrayList();
                this.Y = 0;
                this.aa = 0;
                if (o) {
                    if (!this.ab.a()) {
                        ai.a("FlurryAgent", "Initializing AppCircle");
                        a aVar = new a();
                        aVar.a = this.z;
                        aVar.b = this.H;
                        aVar.c = d != null ? d : e;
                        aVar.d = c();
                        aVar.e = this.s;
                        this.ab.a(context, aVar);
                        ai.a("FlurryAgent", "AppCircle initialized");
                    }
                    this.ab.a(this.K, this.L);
                }
                a(new d(this, applicationContext, this.C));
            } else {
                ai.a("FlurryAgent", "Continuing previous session");
                if (!this.J.isEmpty()) {
                    this.J.remove(this.J.size() - 1);
                }
            }
            this.v = true;
        }
    }

    private synchronized void a(Context context, boolean z2) {
        if (context != null) {
            if (((Context) this.y.remove(context)) == null) {
                ai.d("FlurryAgent", "onEndSession called without context from corresponding onStartSession");
            }
        }
        if (this.v && this.y.isEmpty()) {
            ai.a("FlurryAgent", "Ending session");
            o();
            Context applicationContext = context == null ? null : context.getApplicationContext();
            if (context != null) {
                String packageName = applicationContext.getPackageName();
                if (!this.A.equals(packageName)) {
                    ai.b("FlurryAgent", "onEndSession called from different application package, expected: " + this.A + " actual: " + packageName);
                }
            }
            long elapsedRealtime = SystemClock.elapsedRealtime();
            this.x = elapsedRealtime;
            this.M = elapsedRealtime - this.L;
            if (this.F == null) {
                ai.b("FlurryAgent", "Not creating report because of bad Android ID or generated ID is null");
            }
            a(new b(this, z2, applicationContext));
            this.v = false;
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private synchronized void k() {
        DataOutputStream dataOutputStream;
        DataOutputStream dataOutputStream2 = null;
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            dataOutputStream = new DataOutputStream(byteArrayOutputStream);
            try {
                dataOutputStream.writeShort(1);
                dataOutputStream.writeUTF(this.B);
                dataOutputStream.writeLong(this.K);
                dataOutputStream.writeLong(this.M);
                dataOutputStream.writeLong(0);
                dataOutputStream.writeUTF(this.N);
                dataOutputStream.writeUTF(this.O);
                dataOutputStream.writeByte(this.P);
                dataOutputStream.writeUTF(this.Q == null ? ASConstants.kEmptyString : this.Q);
                if (this.U == null) {
                    dataOutputStream.writeBoolean(false);
                } else {
                    dataOutputStream.writeBoolean(true);
                    dataOutputStream.writeDouble(a(this.U.getLatitude()));
                    dataOutputStream.writeDouble(a(this.U.getLongitude()));
                    dataOutputStream.writeFloat(this.U.getAccuracy());
                }
                dataOutputStream.writeInt(this.aa);
                dataOutputStream.writeByte(-1);
                dataOutputStream.writeByte(-1);
                dataOutputStream.writeByte(this.R);
                if (this.S == null) {
                    dataOutputStream.writeBoolean(false);
                } else {
                    dataOutputStream.writeBoolean(true);
                    dataOutputStream.writeLong(this.S.longValue());
                }
                dataOutputStream.writeShort(this.V.size());
                for (Map.Entry entry : this.V.entrySet()) {
                    dataOutputStream.writeUTF((String) entry.getKey());
                    dataOutputStream.writeInt(((g) entry.getValue()).a);
                }
                dataOutputStream.writeShort(this.W.size());
                for (i iVar : this.W) {
                    dataOutputStream.write(iVar.a());
                }
                dataOutputStream.writeBoolean(this.X);
                dataOutputStream.writeInt(this.T);
                dataOutputStream.writeShort(this.Z.size());
                for (ab abVar : this.Z) {
                    dataOutputStream.writeShort(abVar.a);
                    dataOutputStream.writeLong(abVar.b);
                    dataOutputStream.writeUTF(abVar.c);
                    dataOutputStream.writeUTF(abVar.d);
                    dataOutputStream.writeUTF(abVar.e);
                }
                if (o) {
                    List<p> f2 = this.ab.f();
                    dataOutputStream.writeShort(f2.size());
                    for (p pVar : f2) {
                        pVar.a(dataOutputStream);
                    }
                } else {
                    dataOutputStream.writeShort(0);
                }
                dataOutputStream.writeShort(0);
                this.J.add(byteArrayOutputStream.toByteArray());
                r.a(dataOutputStream);
            } catch (IOException e2) {
                e = e2;
                dataOutputStream2 = dataOutputStream;
                try {
                    ai.b("FlurryAgent", ASConstants.kEmptyString, e);
                    r.a(dataOutputStream2);
                } catch (Throwable th) {
                    th = th;
                    dataOutputStream = dataOutputStream2;
                    r.a(dataOutputStream);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
                r.a(dataOutputStream);
                throw th;
            }
        } catch (IOException e3) {
            e = e3;
            ai.b("FlurryAgent", ASConstants.kEmptyString, e);
            r.a(dataOutputStream2);
        } catch (Throwable th3) {
            th = th3;
            dataOutputStream = null;
            r.a(dataOutputStream);
            throw th;
        }
    }

    private static double a(double d2) {
        return ((double) Math.round(d2 * 1000.0d)) / 1000.0d;
    }

    private void a(Runnable runnable) {
        this.s.post(runnable);
    }

    private synchronized void l() {
        this.aa++;
    }

    private synchronized void a(String str, Map map, boolean z2) {
        Map map2;
        if (this.W == null) {
            ai.b("FlurryAgent", "onEvent called before onStartSession.  Event: " + str);
        } else {
            long elapsedRealtime = SystemClock.elapsedRealtime() - this.L;
            String a2 = r.a(str, (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
            if (a2.length() != 0) {
                g gVar = (g) this.V.get(a2);
                if (gVar != null) {
                    gVar.a++;
                    ai.a("FlurryAgent", "Event count incremented: " + a2);
                } else if (this.V.size() < 100) {
                    g gVar2 = new g();
                    gVar2.a = 1;
                    this.V.put(a2, gVar2);
                    ai.a("FlurryAgent", "Event count incremented: " + a2);
                } else if (ai.a("FlurryAgent")) {
                    ai.a("FlurryAgent", "Too many different events. Event not counted: " + a2);
                }
                if (!j || this.W.size() >= 200 || this.Y >= 16000) {
                    this.X = false;
                } else {
                    if (map == null) {
                        map2 = Collections.emptyMap();
                    } else {
                        map2 = map;
                    }
                    if (map2.size() <= 10) {
                        i iVar = new i(a2, map2, elapsedRealtime, z2);
                        if (iVar.a().length + this.Y <= 16000) {
                            this.W.add(iVar);
                            this.Y = iVar.a().length + this.Y;
                            ai.a("FlurryAgent", "Logged event: " + a2);
                        } else {
                            this.Y = 16000;
                            this.X = false;
                            ai.a("FlurryAgent", "Event Log size exceeded. No more event details logged.");
                        }
                    } else if (ai.a("FlurryAgent")) {
                        ai.a("FlurryAgent", "MaxEventParams exceeded: " + map2.size());
                    }
                }
            }
        }
    }

    private synchronized void c(String str) {
        Iterator it = this.W.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            i iVar = (i) it.next();
            if (iVar.a(str)) {
                iVar.a(SystemClock.elapsedRealtime() - this.L);
                break;
            }
        }
    }

    private synchronized void a(String str, String str2, String str3) {
        if (this.Z == null) {
            ai.b("FlurryAgent", "onError called before onStartSession.  Error: " + str);
        } else {
            this.T++;
            if (this.Z.size() < 10) {
                ab abVar = new ab();
                abVar.b = System.currentTimeMillis();
                abVar.c = r.a(str, (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
                abVar.d = r.a(str2, 512);
                abVar.e = r.a(str3, (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE);
                this.Z.add(abVar);
                ai.a("FlurryAgent", "Error logged: " + abVar.c);
            } else {
                ai.a("FlurryAgent", "Max errors logged. No more errors logged.");
            }
        }
    }

    private synchronized byte[] b(boolean z2) {
        DataOutputStream dataOutputStream;
        byte[] bArr;
        synchronized (this) {
            try {
                CrcMessageDigest crcMessageDigest = new CrcMessageDigest();
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                DigestOutputStream digestOutputStream = new DigestOutputStream(byteArrayOutputStream, crcMessageDigest);
                dataOutputStream = new DataOutputStream(digestOutputStream);
                try {
                    dataOutputStream.writeShort(22);
                    if (!o || !z2) {
                        dataOutputStream.writeShort(0);
                    } else {
                        dataOutputStream.writeShort(1);
                    }
                    if (o) {
                        dataOutputStream.writeLong(this.ab.d());
                        Set<Long> e2 = this.ab.e();
                        dataOutputStream.writeShort(e2.size());
                        for (Long l2 : e2) {
                            long longValue = l2.longValue();
                            dataOutputStream.writeByte(1);
                            dataOutputStream.writeLong(longValue);
                        }
                    } else {
                        dataOutputStream.writeLong(0);
                        dataOutputStream.writeShort(0);
                    }
                    dataOutputStream.writeShort(3);
                    dataOutputStream.writeShort(Commands.CommandIDs.setScrollIndicatorsVisible);
                    dataOutputStream.writeLong(System.currentTimeMillis());
                    dataOutputStream.writeUTF(this.z);
                    dataOutputStream.writeUTF(this.B);
                    int i2 = this.I == null ? 1 : 2;
                    dataOutputStream.writeShort(i2);
                    dataOutputStream.writeShort(0);
                    dataOutputStream.writeUTF(this.F);
                    if (i2 > 1) {
                        dataOutputStream.writeShort(5);
                        dataOutputStream.writeShort(this.I.length);
                        dataOutputStream.write(this.I);
                        ai.c("FlurryAgent", "Sent IMEI: " + Arrays.toString(this.I));
                    }
                    dataOutputStream.write(0);
                    dataOutputStream.writeLong(this.H);
                    dataOutputStream.writeLong(this.K);
                    dataOutputStream.writeShort(6);
                    dataOutputStream.writeUTF("device.model");
                    dataOutputStream.writeUTF(Build.MODEL);
                    dataOutputStream.writeUTF("build.brand");
                    dataOutputStream.writeUTF(Build.BRAND);
                    dataOutputStream.writeUTF("build.id");
                    dataOutputStream.writeUTF(Build.ID);
                    dataOutputStream.writeUTF("version.release");
                    dataOutputStream.writeUTF(Build.VERSION.RELEASE);
                    dataOutputStream.writeUTF("build.device");
                    dataOutputStream.writeUTF(Build.DEVICE);
                    dataOutputStream.writeUTF("build.product");
                    dataOutputStream.writeUTF(Build.PRODUCT);
                    int size = this.J.size();
                    dataOutputStream.writeShort(size);
                    for (int i3 = 0; i3 < size; i3++) {
                        dataOutputStream.write((byte[]) this.J.get(i3));
                    }
                    this.D = new ArrayList(this.J);
                    digestOutputStream.on(false);
                    dataOutputStream.write(crcMessageDigest.getDigest());
                    dataOutputStream.close();
                    bArr = byteArrayOutputStream.toByteArray();
                    r.a(dataOutputStream);
                } catch (Throwable th) {
                    th = th;
                    try {
                        ai.b("FlurryAgent", "Error when generating report", th);
                        r.a(dataOutputStream);
                        bArr = null;
                        return bArr;
                    } catch (Throwable th2) {
                        th = th2;
                        r.a(dataOutputStream);
                        throw th;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                dataOutputStream = null;
                r.a(dataOutputStream);
                throw th;
            }
        }
        return bArr;
    }

    private static String m() {
        if (c != null) {
            return c;
        }
        if (l) {
            return kInsecureReportUrl;
        }
        if (k) {
            return kSecureReportUrl;
        }
        return kInsecureReportUrl;
    }

    static String c() {
        return f != null ? f : g;
    }

    static boolean d() {
        if (!o) {
            return false;
        }
        return h.ab.m();
    }

    private boolean a(byte[] bArr) {
        boolean z2;
        String m2 = m();
        if (m2 == null) {
            return false;
        }
        try {
            z2 = a(bArr, m2);
        } catch (Exception e2) {
            ai.a("FlurryAgent", "Sending report exception: " + e2.getMessage());
            z2 = false;
        }
        if (z2 || c != null || !k || l) {
            return z2;
        }
        synchronized (h) {
            l = true;
            String m3 = m();
            if (m3 == null) {
                return false;
            }
            try {
                return a(bArr, m3);
            } catch (Exception e3) {
                return z2;
            }
        }
    }

    private boolean a(byte[] bArr, String str) {
        boolean z2 = true;
        if (!"local".equals(str)) {
            ai.a("FlurryAgent", "Sending report to: " + str);
            ByteArrayEntity byteArrayEntity = new ByteArrayEntity(bArr);
            byteArrayEntity.setContentType("application/octet-stream");
            HttpPost httpPost = new HttpPost(str);
            httpPost.setEntity(byteArrayEntity);
            BasicHttpParams basicHttpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(basicHttpParams, 10000);
            HttpConnectionParams.setSoTimeout(basicHttpParams, 15000);
            httpPost.getParams().setBooleanParameter("http.protocol.expect-continue", false);
            HttpResponse execute = a((HttpParams) basicHttpParams).execute(httpPost);
            int statusCode = execute.getStatusLine().getStatusCode();
            synchronized (this) {
                if (statusCode == 200) {
                    ai.a("FlurryAgent", "Report successful");
                    this.G = true;
                    this.J.removeAll(this.D);
                    HttpEntity entity = execute.getEntity();
                    ai.a("FlurryAgent", "Processing report response");
                    if (!(entity == null || entity.getContentLength() == 0)) {
                        try {
                            a(new DataInputStream(entity.getContent()));
                        } finally {
                            entity.consumeContent();
                        }
                    }
                } else {
                    ai.a("FlurryAgent", "Report failed. HTTP response: " + statusCode);
                    z2 = false;
                }
                this.D = null;
            }
        }
        return z2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v13, types: [int] */
    /* JADX WARNING: Unknown variable types count: 1 */
    private void a(DataInputStream dataInputStream) {
        int readUnsignedShort;
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = new HashMap();
        HashMap hashMap5 = new HashMap();
        HashMap hashMap6 = new HashMap();
        do {
            readUnsignedShort = dataInputStream.readUnsignedShort();
            int readInt = dataInputStream.readInt();
            switch (readUnsignedShort) {
                case 258:
                    dataInputStream.readInt();
                    break;
                case 259:
                    byte readByte = dataInputStream.readByte();
                    int readUnsignedShort2 = dataInputStream.readUnsignedShort();
                    w[] wVarArr = new w[readUnsignedShort2];
                    for (int i2 = 0; i2 < readUnsignedShort2; i2++) {
                        wVarArr[i2] = new w(dataInputStream);
                    }
                    hashMap.put(Byte.valueOf(readByte), wVarArr);
                    break;
                case 260:
                case 261:
                case 265:
                case 267:
                default:
                    ai.a("FlurryAgent", "Unknown chunkType: " + readUnsignedShort);
                    dataInputStream.skipBytes(readInt);
                    break;
                case 262:
                    int readUnsignedShort3 = dataInputStream.readUnsignedShort();
                    for (int i3 = 0; i3 < readUnsignedShort3; i3++) {
                        AdImage adImage = new AdImage(dataInputStream);
                        hashMap2.put(Long.valueOf(adImage.a), adImage);
                    }
                    break;
                case 263:
                    int readInt2 = dataInputStream.readInt();
                    for (int i4 = 0; i4 < readInt2; i4++) {
                        e eVar = new e(dataInputStream);
                        hashMap4.put(eVar.a, eVar);
                        ai.a("FlurryAgent", "Parsed hook: " + eVar);
                    }
                    break;
                case 264:
                    break;
                case 266:
                    byte readByte2 = dataInputStream.readByte();
                    for (int i5 = 0; i5 < readByte2; i5++) {
                        c cVar = new c(dataInputStream);
                        hashMap5.put(Byte.valueOf(cVar.a), cVar);
                    }
                    break;
                case 268:
                    int readInt3 = dataInputStream.readInt();
                    for (int i6 = 0; i6 < readInt3; i6++) {
                        hashMap6.put(Short.valueOf(dataInputStream.readShort()), Long.valueOf(dataInputStream.readLong()));
                    }
                    break;
                case 269:
                    dataInputStream.skipBytes(readInt);
                    break;
                case 270:
                    dataInputStream.skipBytes(readInt);
                    break;
                case 271:
                    byte readByte3 = dataInputStream.readByte();
                    for (byte b2 = 0; b2 < readByte3; b2++) {
                        c cVar2 = (c) hashMap5.get(Byte.valueOf(dataInputStream.readByte()));
                        if (cVar2 != null) {
                            cVar2.a(dataInputStream);
                        }
                    }
                    break;
                case 272:
                    long readLong = dataInputStream.readLong();
                    am amVar = (am) hashMap3.get(Long.valueOf(readLong));
                    if (amVar == null) {
                        amVar = new am();
                    }
                    amVar.a = dataInputStream.readUTF();
                    amVar.c = dataInputStream.readInt();
                    hashMap3.put(Long.valueOf(readLong), amVar);
                    break;
                case 273:
                    dataInputStream.skipBytes(readInt);
                    break;
            }
        } while (readUnsignedShort != 264);
        if (o) {
            if (hashMap.isEmpty()) {
                ai.a("FlurryAgent", "No ads from server");
            }
            this.ab.a(hashMap, hashMap4, hashMap5, hashMap2, hashMap3, hashMap6);
        }
    }

    private void c(boolean z2) {
        try {
            ai.a("FlurryAgent", "generating report");
            byte[] b2 = b(z2);
            if (b2 == null) {
                ai.a("FlurryAgent", "Error generating report");
            } else if (a(b2)) {
                ai.a("FlurryAgent", "Done sending " + (this.v ? "initial " : ASConstants.kEmptyString) + "agent report");
                n();
            }
        } catch (IOException e2) {
            ai.a("FlurryAgent", ASConstants.kEmptyString, e2);
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x004d A[Catch:{ Throwable -> 0x00f2 }] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0060  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x006e  */
    private synchronized void a(Context context) {
        DataInputStream dataInputStream;
        Throwable th;
        this.F = b(context);
        if (this.u.exists()) {
            ai.c("FlurryAgent", "loading persistent data: " + this.u.getAbsolutePath());
            try {
                dataInputStream = new DataInputStream(new FileInputStream(this.u));
                try {
                    if (dataInputStream.readUnsignedShort() == 46586) {
                        b(dataInputStream);
                    } else {
                        ai.a("FlurryAgent", "Unexpected file type");
                    }
                    r.a(dataInputStream);
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        ai.b("FlurryAgent", "Error when loading persistent file", th);
                        r.a(dataInputStream);
                        if (!this.w) {
                        }
                        if (!this.w) {
                        }
                        if (this.F == null) {
                        }
                        this.ab.a(this.F);
                        c(context, this.F);
                    } catch (Throwable th3) {
                        th = th3;
                        r.a(dataInputStream);
                        throw th;
                    }
                }
            } catch (Throwable th4) {
                th = th4;
                dataInputStream = null;
                r.a(dataInputStream);
                throw th;
            }
            try {
                if (!this.w) {
                    if (this.u.delete()) {
                        ai.a("FlurryAgent", "Deleted persistence file");
                    } else {
                        ai.b("FlurryAgent", "Cannot delete persistence file");
                    }
                }
            } catch (Throwable th5) {
                ai.b("FlurryAgent", ASConstants.kEmptyString, th5);
            }
        } else {
            ai.c("FlurryAgent", "Agent cache file doesn't exist.");
        }
        if (!this.w) {
            this.G = false;
            this.H = this.K;
            this.w = true;
        }
        if (this.F == null) {
            this.F = "ID" + Long.toString(Double.doubleToLongBits(Math.random()) + (37 * (System.nanoTime() + ((long) (this.z.hashCode() * 37)))), 16);
            ai.c("FlurryAgent", "Generated id");
        }
        this.ab.a(this.F);
        if (!this.F.startsWith("AND") && !this.t.exists()) {
            c(context, this.F);
        }
    }

    private synchronized void b(DataInputStream dataInputStream) {
        int i2 = 0;
        synchronized (this) {
            int readUnsignedShort = dataInputStream.readUnsignedShort();
            if (readUnsignedShort > 2) {
                ai.b("FlurryAgent", "Unknown agent file version: " + readUnsignedShort);
                throw new IOException("Unknown agent file version: " + readUnsignedShort);
            } else if (readUnsignedShort >= 2) {
                String readUTF = dataInputStream.readUTF();
                ai.a("FlurryAgent", "Loading API key: " + d(this.z));
                if (readUTF.equals(this.z)) {
                    String readUTF2 = dataInputStream.readUTF();
                    if (this.F == null) {
                        ai.a("FlurryAgent", "Loading phoneId: " + readUTF2);
                    }
                    this.F = readUTF2;
                    this.G = dataInputStream.readBoolean();
                    this.H = dataInputStream.readLong();
                    ai.a("FlurryAgent", "Loading session reports");
                    while (true) {
                        int readUnsignedShort2 = dataInputStream.readUnsignedShort();
                        if (readUnsignedShort2 == 0) {
                            break;
                        }
                        byte[] bArr = new byte[readUnsignedShort2];
                        dataInputStream.readFully(bArr);
                        this.J.add(0, bArr);
                        i2++;
                        ai.a("FlurryAgent", "Session report added: " + i2);
                    }
                    ai.a("FlurryAgent", "Persistent file loaded");
                    this.w = true;
                } else {
                    ai.a("FlurryAgent", "Api keys do not match, old: " + d(readUTF) + ", new: " + d(this.z));
                }
            } else {
                ai.d("FlurryAgent", "Deleting old file version: " + readUnsignedShort);
            }
        }
    }

    private static String d(String str) {
        if (str == null || str.length() <= 4) {
            return str;
        }
        StringBuilder sb = new StringBuilder();
        for (int i2 = 0; i2 < str.length() - 4; i2++) {
            sb.append('*');
        }
        sb.append(str.substring(str.length() - 4));
        return sb.toString();
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private synchronized void n() {
        DataOutputStream dataOutputStream;
        Throwable th;
        Throwable th2;
        try {
            if (!a(this.u)) {
                r.a((Closeable) null);
            } else {
                dataOutputStream = new DataOutputStream(new FileOutputStream(this.u));
                try {
                    dataOutputStream.writeShort(46586);
                    dataOutputStream.writeShort(2);
                    dataOutputStream.writeUTF(this.z);
                    dataOutputStream.writeUTF(this.F);
                    dataOutputStream.writeBoolean(this.G);
                    dataOutputStream.writeLong(this.H);
                    int size = this.J.size() - 1;
                    while (true) {
                        if (size < 0) {
                            break;
                        }
                        byte[] bArr = (byte[]) this.J.get(size);
                        int length = bArr.length;
                        if (length + 2 + dataOutputStream.size() > 50000) {
                            ai.a("FlurryAgent", "discarded sessions: " + size);
                            break;
                        }
                        dataOutputStream.writeShort(length);
                        dataOutputStream.write(bArr);
                        size--;
                    }
                    dataOutputStream.writeShort(0);
                    r.a(dataOutputStream);
                } catch (Throwable th3) {
                    th2 = th3;
                    try {
                        ai.b("FlurryAgent", ASConstants.kEmptyString, th2);
                        r.a(dataOutputStream);
                    } catch (Throwable th4) {
                        th = th4;
                        r.a(dataOutputStream);
                        throw th;
                    }
                }
            }
        } catch (Throwable th5) {
            th = th5;
            dataOutputStream = null;
            r.a(dataOutputStream);
            throw th;
        }
    }

    private static boolean a(File file) {
        File parentFile = file.getParentFile();
        if (parentFile.mkdirs() || parentFile.exists()) {
            return true;
        }
        ai.b("FlurryAgent", "Unable to create persistent dir: " + parentFile);
        return false;
    }

    private synchronized void c(Context context, String str) {
        DataOutputStream dataOutputStream;
        Throwable th;
        Throwable th2;
        this.t = context.getFileStreamPath(".flurryb.");
        if (a(this.t)) {
            try {
                dataOutputStream = new DataOutputStream(new FileOutputStream(this.t));
                try {
                    dataOutputStream.writeInt(1);
                    dataOutputStream.writeUTF(str);
                    r.a(dataOutputStream);
                } catch (Throwable th3) {
                    th2 = th3;
                    try {
                        ai.b("FlurryAgent", "Error when saving b file", th2);
                        r.a(dataOutputStream);
                    } catch (Throwable th4) {
                        th = th4;
                        r.a(dataOutputStream);
                        throw th;
                    }
                }
            } catch (Throwable th5) {
                th = th5;
                dataOutputStream = null;
                r.a(dataOutputStream);
                throw th;
            }
        }
    }

    private String b(Context context) {
        DataInputStream dataInputStream;
        Throwable th;
        Throwable th2;
        boolean z2 = false;
        if (this.F != null) {
            return this.F;
        }
        String string = Settings.System.getString(context.getContentResolver(), TapjoyConstants.TJC_ANDROID_ID);
        if (string != null && string.length() > 0 && !string.equals("null")) {
            String[] strArr = b;
            int length = strArr.length;
            int i2 = 0;
            while (true) {
                if (i2 < length) {
                    if (string.equals(strArr[i2])) {
                        break;
                    }
                    i2++;
                } else {
                    z2 = true;
                    break;
                }
            }
        }
        if (z2) {
            return "AND" + string;
        }
        File fileStreamPath = context.getFileStreamPath(".flurryb.");
        if (!fileStreamPath.exists()) {
            return null;
        }
        try {
            dataInputStream = new DataInputStream(new FileInputStream(fileStreamPath));
            try {
                dataInputStream.readInt();
                String readUTF = dataInputStream.readUTF();
                r.a(dataInputStream);
                return readUTF;
            } catch (Throwable th3) {
                th2 = th3;
                try {
                    ai.b("FlurryAgent", "Error when loading b file", th2);
                    r.a(dataInputStream);
                    return null;
                } catch (Throwable th4) {
                    th = th4;
                    r.a(dataInputStream);
                    throw th;
                }
            }
        } catch (Throwable th5) {
            dataInputStream = null;
            th = th5;
            r.a(dataInputStream);
            throw th;
        }
    }

    private static String c(Context context) {
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            if (packageInfo.versionName != null) {
                return packageInfo.versionName;
            }
            if (packageInfo.versionCode != 0) {
                return Integer.toString(packageInfo.versionCode);
            }
            return "Unknown";
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
    }

    private Location d(Context context) {
        if (context.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 || context.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
            LocationManager locationManager = (LocationManager) context.getSystemService("location");
            synchronized (this) {
                if (this.E == null) {
                    this.E = locationManager;
                } else {
                    locationManager = this.E;
                }
            }
            Criteria criteria = n;
            if (criteria == null) {
                criteria = new Criteria();
            }
            String bestProvider = locationManager.getBestProvider(criteria, true);
            if (bestProvider != null) {
                locationManager.requestLocationUpdates(bestProvider, 0, 0.0f, this, Looper.getMainLooper());
                return locationManager.getLastKnownLocation(bestProvider);
            }
        }
        return null;
    }

    private static byte[] e(Context context) {
        TelephonyManager telephonyManager;
        String deviceId;
        if (!(context.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") != 0 || (telephonyManager = (TelephonyManager) context.getSystemService("phone")) == null || (deviceId = telephonyManager.getDeviceId()) == null)) {
            try {
                byte[] b2 = r.b(deviceId);
                if (b2 != null && b2.length == 20) {
                    return b2;
                }
                ai.b("FlurryAgent", "sha1 is not 20 bytes long: " + Arrays.toString(b2));
            } catch (Exception e2) {
            }
        }
        return null;
    }

    private synchronized void o() {
        if (this.E != null) {
            this.E.removeUpdates(this);
        }
    }

    static String e() {
        return h.z;
    }

    private synchronized String p() {
        return this.F;
    }

    public static String getPhoneId() {
        return h.p();
    }

    public final synchronized void onLocationChanged(Location location) {
        try {
            this.U = location;
            o();
        } catch (Throwable th) {
            ai.b("FlurryAgent", ASConstants.kEmptyString, th);
        }
        return;
    }

    public final void onProviderDisabled(String str) {
    }

    public final void onProviderEnabled(String str) {
    }

    public final void onStatusChanged(String str, int i2, Bundle bundle) {
    }

    private HttpClient a(HttpParams httpParams) {
        try {
            KeyStore instance = KeyStore.getInstance(KeyStore.getDefaultType());
            instance.load(null, null);
            aj ajVar = new aj(this, instance);
            SchemeRegistry schemeRegistry = new SchemeRegistry();
            schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            schemeRegistry.register(new Scheme("https", ajVar, 443));
            return new DefaultHttpClient(new ThreadSafeClientConnManager(httpParams, schemeRegistry), httpParams);
        } catch (Exception e2) {
            return new DefaultHttpClient(httpParams);
        }
    }

    static int f() {
        return q.incrementAndGet();
    }

    static int g() {
        return r.incrementAndGet();
    }
}
