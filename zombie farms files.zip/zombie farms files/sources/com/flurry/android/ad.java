package com.flurry.android;

import android.view.View;
import android.widget.TextView;

/* access modifiers changed from: package-private */
public final class ad implements View.OnFocusChangeListener {
    private /* synthetic */ TextView a;
    private /* synthetic */ ac b;

    ad(ac acVar, TextView textView) {
        this.b = acVar;
        this.a = textView;
    }

    public final void onFocusChange(View view, boolean z) {
        this.a.setText(z ? this.b.b : this.b.a);
    }
}
