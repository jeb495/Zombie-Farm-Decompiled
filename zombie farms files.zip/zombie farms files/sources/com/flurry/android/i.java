package com.flurry.android;

import com.sponsorpay.sdk.android.publisher.SponsorPayPublisher;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Map;

final class i {
    private int a = FlurryAgent.f();
    private String b;
    private Map c;
    private long d;
    private boolean e;
    private long f;

    public i(String str, Map map, long j, boolean z) {
        this.b = str;
        this.c = map;
        this.d = j;
        this.e = z;
    }

    public final boolean a(String str) {
        return this.e && this.f == 0 && this.b.equals(str);
    }

    public final void a(long j) {
        this.f = j - this.d;
        ai.a("FlurryAgent", "Ended event '" + this.b + "' (" + this.d + ") after " + this.f + "ms");
    }

    public final byte[] a() {
        DataOutputStream dataOutputStream;
        DataOutputStream dataOutputStream2;
        Throwable th;
        byte[] bArr;
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            dataOutputStream2 = new DataOutputStream(byteArrayOutputStream);
            try {
                dataOutputStream2.writeShort(this.a);
                dataOutputStream2.writeUTF(this.b);
                if (this.c == null) {
                    dataOutputStream2.writeShort(0);
                } else {
                    dataOutputStream2.writeShort(this.c.size());
                    for (Map.Entry entry : this.c.entrySet()) {
                        dataOutputStream2.writeUTF(r.a((String) entry.getKey(), (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE));
                        dataOutputStream2.writeUTF(r.a((String) entry.getValue(), (int) SponsorPayPublisher.DEFAULT_OFFERWALL_REQUEST_CODE));
                    }
                }
                dataOutputStream2.writeLong(this.d);
                dataOutputStream2.writeLong(this.f);
                dataOutputStream2.flush();
                bArr = byteArrayOutputStream.toByteArray();
                r.a(dataOutputStream2);
            } catch (IOException e2) {
                dataOutputStream = dataOutputStream2;
                try {
                    bArr = new byte[0];
                    r.a(dataOutputStream);
                    return bArr;
                } catch (Throwable th2) {
                    th = th2;
                    dataOutputStream2 = dataOutputStream;
                    r.a(dataOutputStream2);
                    throw th;
                }
            } catch (Throwable th3) {
                th = th3;
                r.a(dataOutputStream2);
                throw th;
            }
        } catch (IOException e3) {
            dataOutputStream = null;
            bArr = new byte[0];
            r.a(dataOutputStream);
            return bArr;
        } catch (Throwable th4) {
            dataOutputStream2 = null;
            th = th4;
            r.a(dataOutputStream2);
            throw th;
        }
        return bArr;
    }
}
