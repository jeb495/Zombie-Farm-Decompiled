package com.flurry.android;

/* access modifiers changed from: package-private */
public final class af implements Runnable {
    private /* synthetic */ String a;
    private /* synthetic */ v b;

    af(v vVar, String str) {
        this.b = vVar;
        this.a = str;
    }

    public final void run() {
        CallbackEvent callbackEvent = new CallbackEvent(101);
        callbackEvent.setMessage(this.a);
        if (this.b.z != null) {
            this.b.z.onMarketAppLaunchError(callbackEvent);
        }
    }
}
