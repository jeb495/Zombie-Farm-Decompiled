package com.flurry.android;

import java.util.LinkedHashMap;
import java.util.Map;

/* access modifiers changed from: package-private */
public final class h extends LinkedHashMap {
    private /* synthetic */ ag a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    h(ag agVar, int i, float f) {
        super(i, f, true);
        this.a = agVar;
    }

    /* access modifiers changed from: protected */
    @Override // java.util.LinkedHashMap
    public final boolean removeEldestEntry(Map.Entry entry) {
        return size() > this.a.b;
    }
}
