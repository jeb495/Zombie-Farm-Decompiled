package com.flurry.android;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.zip.CRC32;

public class CrcMessageDigest extends MessageDigest {
    private CRC32 a = new CRC32();

    public CrcMessageDigest() {
        super("CRC");
    }

    /* access modifiers changed from: protected */
    public void engineReset() {
        this.a.reset();
    }

    /* access modifiers changed from: protected */
    @Override // java.security.MessageDigestSpi
    public void engineUpdate(byte b) {
        this.a.update(b);
    }

    /* access modifiers changed from: protected */
    public void engineUpdate(byte[] bArr, int i, int i2) {
        this.a.update(bArr, i, i2);
    }

    /* access modifiers changed from: protected */
    public byte[] engineDigest() {
        long value = this.a.getValue();
        return new byte[]{(byte) ((int) ((-16777216 & value) >> 24)), (byte) ((int) ((16711680 & value) >> 16)), (byte) ((int) ((65280 & value) >> 8)), (byte) ((int) (value & 255))};
    }

    public byte[] getDigest() {
        return engineDigest();
    }

    public int getChecksum() {
        return ByteBuffer.wrap(engineDigest()).getInt();
    }
}
