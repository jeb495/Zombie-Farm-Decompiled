package com.flurry.android;

final class g {
    int a;

    /* synthetic */ g() {
        this((byte) 0);
    }

    private g(byte b) {
    }
}
