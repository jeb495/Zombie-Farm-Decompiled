package com.flurry.android;

final class am extends ak {
    String a;
    String b;
    int c;

    am() {
    }
}
