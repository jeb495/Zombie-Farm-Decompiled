package com.flurry.android;

import android.content.Context;
import com.android.adsymp.core.ASConstants;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* access modifiers changed from: package-private */
public final class aa {
    private Context a;
    private v b;
    private a c;
    private volatile long d;
    private ag e = new ag(100);
    private ag f = new ag(100);
    private Map g = new HashMap();
    private Map h = new HashMap();
    private Map i = new HashMap();
    private Map j = new HashMap();
    private volatile boolean k;

    aa() {
    }

    /* access modifiers changed from: package-private */
    public final void a(Context context, v vVar, a aVar) {
        this.a = context;
        this.b = vVar;
        this.c = aVar;
    }

    /* access modifiers changed from: package-private */
    public final synchronized w[] a(String str) {
        w[] wVarArr;
        wVarArr = (w[]) this.g.get(str);
        if (wVarArr == null) {
            wVarArr = (w[]) this.g.get(ASConstants.kEmptyString);
        }
        return wVarArr;
    }

    /* access modifiers changed from: package-private */
    public final synchronized am a(long j2) {
        return (am) this.f.a(Long.valueOf(j2));
    }

    /* access modifiers changed from: package-private */
    public final synchronized Set a() {
        return this.e.c();
    }

    /* access modifiers changed from: package-private */
    public final synchronized AdImage b(long j2) {
        return (AdImage) this.e.a(Long.valueOf(j2));
    }

    /* access modifiers changed from: package-private */
    public final synchronized AdImage a(short s) {
        Long l;
        l = (Long) this.j.get((short) 1);
        return l == null ? null : b(l.longValue());
    }

    /* access modifiers changed from: package-private */
    public final synchronized e b(String str) {
        e eVar;
        eVar = (e) this.h.get(str);
        if (eVar == null) {
            eVar = (e) this.h.get(ASConstants.kEmptyString);
        }
        return eVar;
    }

    /* access modifiers changed from: package-private */
    public final boolean b() {
        return this.k;
    }

    private synchronized c a(byte b2) {
        return (c) this.i.get(Byte.valueOf(b2));
    }

    /* access modifiers changed from: package-private */
    public final synchronized void a(Map map, Map map2, Map map3, Map map4, Map map5, Map map6) {
        this.d = System.currentTimeMillis();
        for (Map.Entry entry : map4.entrySet()) {
            if (entry.getValue() != null) {
                this.e.a(entry.getKey(), entry.getValue());
            }
        }
        for (Map.Entry entry2 : map5.entrySet()) {
            if (entry2.getValue() != null) {
                this.f.a(entry2.getKey(), entry2.getValue());
            }
        }
        if (map2 != null && !map2.isEmpty()) {
            this.h = map2;
        }
        if (map3 != null && !map3.isEmpty()) {
            this.i = map3;
        }
        if (map6 != null && !map6.isEmpty()) {
            this.j = map6;
        }
        this.g = new HashMap();
        for (Map.Entry entry3 : map2.entrySet()) {
            e eVar = (e) entry3.getValue();
            w[] wVarArr = (w[]) map.get(Byte.valueOf(eVar.b));
            if (wVarArr != null) {
                this.g.put(entry3.getKey(), wVarArr);
            }
            c cVar = (c) map3.get(Byte.valueOf(eVar.c));
            if (cVar != null) {
                eVar.d = cVar;
            }
        }
        f();
        a(CallbackEvent.ADS_UPDATED);
    }

    /* access modifiers changed from: package-private */
    public final long c() {
        return this.d;
    }

    /* access modifiers changed from: package-private */
    public final synchronized void d() {
        DataInputStream dataInputStream;
        Throwable th;
        File fileStreamPath = this.a.getFileStreamPath(g());
        if (fileStreamPath.exists()) {
            try {
                dataInputStream = new DataInputStream(new FileInputStream(fileStreamPath));
                try {
                    if (dataInputStream.readUnsignedShort() == 46587) {
                        a(dataInputStream);
                        a(CallbackEvent.ADS_LOADED_FROM_CACHE);
                    } else {
                        a(fileStreamPath);
                    }
                    r.a(dataInputStream);
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        ai.a("FlurryAgent", "Discarding cache", th);
                        a(fileStreamPath);
                        r.a(dataInputStream);
                    } catch (Throwable th3) {
                        th = th3;
                        r.a(dataInputStream);
                        throw th;
                    }
                }
            } catch (Throwable th4) {
                th = th4;
                dataInputStream = null;
                r.a(dataInputStream);
                throw th;
            }
        } else {
            ai.c("FlurryAgent", "cache file does not exist, path=" + fileStreamPath.getAbsolutePath());
        }
    }

    private static void a(File file) {
        if (!file.delete()) {
            ai.b("FlurryAgent", "Cannot delete cached ads");
        }
    }

    private void f() {
        Iterator it = this.i.values().iterator();
        while (it.hasNext()) {
            it.next();
        }
        for (w[] wVarArr : this.g.values()) {
            if (wVarArr != null) {
                for (w wVar : wVarArr) {
                    wVar.h = b(wVar.f.longValue());
                    if (wVar.h == null) {
                        ai.b("FlurryAgent", "Ad " + wVar.d + " has no image");
                    }
                    if (a(wVar.a) == null) {
                        ai.b("FlurryAgent", "Ad " + wVar.d + " has no pricing");
                    }
                }
            }
        }
        for (e eVar : this.h.values()) {
            eVar.d = a(eVar.c);
            if (eVar.d == null) {
                ai.d("FlurryAgent", "No ad theme found for " + ((int) eVar.c));
            }
        }
    }

    /* access modifiers changed from: package-private */
    public final synchronized void e() {
        Throwable th;
        Throwable th2;
        DataOutputStream dataOutputStream = null;
        synchronized (this) {
            try {
                File fileStreamPath = this.a.getFileStreamPath(g());
                File parentFile = fileStreamPath.getParentFile();
                if (parentFile.mkdirs() || parentFile.exists()) {
                    DataOutputStream dataOutputStream2 = new DataOutputStream(new FileOutputStream(fileStreamPath));
                    try {
                        dataOutputStream2.writeShort(46587);
                        a(dataOutputStream2);
                        r.a(dataOutputStream2);
                    } catch (Throwable th3) {
                        th = th3;
                        dataOutputStream = dataOutputStream2;
                        r.a(dataOutputStream);
                        throw th;
                    }
                } else {
                    ai.b("FlurryAgent", "Unable to create persistent dir: " + parentFile);
                    r.a((Closeable) null);
                }
            } catch (Throwable th4) {
                th2 = th4;
                ai.b("FlurryAgent", ASConstants.kEmptyString, th2);
                r.a(dataOutputStream);
            }
        }
    }

    private void a(DataInputStream dataInputStream) {
        ai.a("FlurryAgent", "Reading cache");
        if (dataInputStream.readUnsignedShort() == 2) {
            this.d = dataInputStream.readLong();
            int readUnsignedShort = dataInputStream.readUnsignedShort();
            this.e = new ag(100);
            for (int i2 = 0; i2 < readUnsignedShort; i2++) {
                long readLong = dataInputStream.readLong();
                AdImage adImage = new AdImage();
                adImage.a(dataInputStream);
                this.e.a(Long.valueOf(readLong), adImage);
            }
            int readUnsignedShort2 = dataInputStream.readUnsignedShort();
            this.f = new ag(100);
            for (int i3 = 0; i3 < readUnsignedShort2; i3++) {
                long readLong2 = dataInputStream.readLong();
                am amVar = new am();
                if (dataInputStream.readBoolean()) {
                    amVar.a = dataInputStream.readUTF();
                }
                if (dataInputStream.readBoolean()) {
                    amVar.b = dataInputStream.readUTF();
                }
                amVar.c = dataInputStream.readInt();
                this.f.a(Long.valueOf(readLong2), amVar);
            }
            int readUnsignedShort3 = dataInputStream.readUnsignedShort();
            this.h = new HashMap(readUnsignedShort3);
            for (int i4 = 0; i4 < readUnsignedShort3; i4++) {
                this.h.put(dataInputStream.readUTF(), new e(dataInputStream));
            }
            int readUnsignedShort4 = dataInputStream.readUnsignedShort();
            this.g = new HashMap(readUnsignedShort4);
            for (int i5 = 0; i5 < readUnsignedShort4; i5++) {
                String readUTF = dataInputStream.readUTF();
                int readUnsignedShort5 = dataInputStream.readUnsignedShort();
                w[] wVarArr = new w[readUnsignedShort5];
                for (int i6 = 0; i6 < readUnsignedShort5; i6++) {
                    w wVar = new w();
                    wVar.a(dataInputStream);
                    wVarArr[i6] = wVar;
                }
                this.g.put(readUTF, wVarArr);
            }
            int readUnsignedShort6 = dataInputStream.readUnsignedShort();
            this.i = new HashMap();
            for (int i7 = 0; i7 < readUnsignedShort6; i7++) {
                byte readByte = dataInputStream.readByte();
                c cVar = new c();
                cVar.b(dataInputStream);
                this.i.put(Byte.valueOf(readByte), cVar);
            }
            int readUnsignedShort7 = dataInputStream.readUnsignedShort();
            this.j = new HashMap(readUnsignedShort7);
            for (int i8 = 0; i8 < readUnsignedShort7; i8++) {
                this.j.put(Short.valueOf(dataInputStream.readShort()), Long.valueOf(dataInputStream.readLong()));
            }
            f();
            ai.a("FlurryAgent", "Cache read, num images: " + this.e.a());
        }
    }

    private void a(DataOutputStream dataOutputStream) {
        dataOutputStream.writeShort(2);
        dataOutputStream.writeLong(this.d);
        List<Map.Entry> b2 = this.e.b();
        dataOutputStream.writeShort(b2.size());
        for (Map.Entry entry : b2) {
            dataOutputStream.writeLong(((Long) entry.getKey()).longValue());
            AdImage adImage = (AdImage) entry.getValue();
            dataOutputStream.writeLong(adImage.a);
            dataOutputStream.writeInt(adImage.b);
            dataOutputStream.writeInt(adImage.c);
            dataOutputStream.writeUTF(adImage.d);
            dataOutputStream.writeInt(adImage.e.length);
            dataOutputStream.write(adImage.e);
        }
        List<Map.Entry> b3 = this.f.b();
        dataOutputStream.writeShort(b3.size());
        for (Map.Entry entry2 : b3) {
            dataOutputStream.writeLong(((Long) entry2.getKey()).longValue());
            am amVar = (am) entry2.getValue();
            boolean z = amVar.a != null;
            dataOutputStream.writeBoolean(z);
            if (z) {
                dataOutputStream.writeUTF(amVar.a);
            }
            boolean z2 = amVar.b != null;
            dataOutputStream.writeBoolean(z2);
            if (z2) {
                dataOutputStream.writeUTF(amVar.b);
            }
            dataOutputStream.writeInt(amVar.c);
        }
        dataOutputStream.writeShort(this.h.size());
        for (Map.Entry entry3 : this.h.entrySet()) {
            dataOutputStream.writeUTF((String) entry3.getKey());
            e eVar = (e) entry3.getValue();
            dataOutputStream.writeUTF(eVar.a);
            dataOutputStream.writeByte(eVar.b);
            dataOutputStream.writeByte(eVar.c);
        }
        dataOutputStream.writeShort(this.g.size());
        for (Map.Entry entry4 : this.g.entrySet()) {
            dataOutputStream.writeUTF((String) entry4.getKey());
            w[] wVarArr = (w[]) entry4.getValue();
            int length = wVarArr == null ? 0 : wVarArr.length;
            dataOutputStream.writeShort(length);
            for (int i2 = 0; i2 < length; i2++) {
                w wVar = wVarArr[i2];
                dataOutputStream.writeLong(wVar.a);
                dataOutputStream.writeLong(wVar.b);
                dataOutputStream.writeUTF(wVar.d);
                dataOutputStream.writeUTF(wVar.c);
                dataOutputStream.writeLong(wVar.e);
                dataOutputStream.writeLong(wVar.f.longValue());
                dataOutputStream.writeByte(wVar.g.length);
                dataOutputStream.write(wVar.g);
            }
        }
        dataOutputStream.writeShort(this.i.size());
        for (Map.Entry entry5 : this.i.entrySet()) {
            dataOutputStream.writeByte(((Byte) entry5.getKey()).byteValue());
            ((c) entry5.getValue()).a(dataOutputStream);
        }
        dataOutputStream.writeShort(this.j.size());
        for (Map.Entry entry6 : this.j.entrySet()) {
            dataOutputStream.writeShort(((Short) entry6.getKey()).shortValue());
            dataOutputStream.writeLong(((Long) entry6.getValue()).longValue());
        }
    }

    private String g() {
        return ".flurryappcircle." + Integer.toString(this.c.a.hashCode(), 16);
    }

    private void a(int i2) {
        this.k = !this.g.isEmpty();
        if (this.k) {
            this.b.a(i2);
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(ASConstants.kBraceOpen);
        sb.append("adImages (" + this.e.b().size() + "),\n");
        sb.append("adBlock (" + this.g.size() + "):").append(",\n");
        for (Map.Entry entry : this.g.entrySet()) {
            sb.append("\t" + ((String) entry.getKey()) + ": " + Arrays.toString((Object[]) entry.getValue()));
        }
        sb.append("adHooks (" + this.h.size() + "):" + this.h).append(",\n");
        sb.append("adThemes (" + this.i.size() + "):" + this.i).append(",\n");
        sb.append("auxMap (" + this.j.size() + "):" + this.j).append(",\n");
        sb.append(ASConstants.kBraceClose);
        return sb.toString();
    }
}
