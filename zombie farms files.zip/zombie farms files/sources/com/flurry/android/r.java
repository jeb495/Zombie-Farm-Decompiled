package com.flurry.android;

import android.content.Context;
import android.widget.ImageView;
import com.android.adsymp.core.ASConstants;
import java.io.Closeable;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/* access modifiers changed from: package-private */
public final class r {
    r() {
    }

    static String a(String str, int i) {
        if (str == null) {
            return ASConstants.kEmptyString;
        }
        return str.length() > i ? str.substring(0, i) : str;
    }

    static String a(String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            ai.d("FlurryAgent", "Cannot encode '" + str + "'");
            return ASConstants.kEmptyString;
        }
    }

    static void a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (Throwable th) {
            }
        }
    }

    static void a(Context context, ImageView imageView, int i, int i2) {
        imageView.setAdjustViewBounds(true);
        imageView.setMinimumWidth(a(context, i));
        imageView.setMinimumHeight(a(context, i2));
        imageView.setMaxWidth(a(context, i));
        imageView.setMaxHeight(a(context, i2));
    }

    static int a(Context context, int i) {
        return (int) ((context.getResources().getDisplayMetrics().density * ((float) i)) + 0.5f);
    }

    static byte[] b(String str) {
        try {
            MessageDigest instance = MessageDigest.getInstance("SHA-1");
            instance.update(str.getBytes(), 0, str.length());
            return instance.digest();
        } catch (NoSuchAlgorithmException e) {
            ai.b("FlurryAgent", "Unsupported SHA1: " + e.getMessage());
            return null;
        }
    }
}
