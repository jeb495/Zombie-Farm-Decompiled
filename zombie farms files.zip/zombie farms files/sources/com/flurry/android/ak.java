package com.flurry.android;

abstract class ak {
    ak() {
    }
}
