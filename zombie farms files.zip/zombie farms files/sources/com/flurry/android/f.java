package com.flurry.android;

/* access modifiers changed from: package-private */
public final class f {
    final byte a;
    final long b;

    f(byte b2, long j) {
        this.a = b2;
        this.b = j;
    }

    public final String toString() {
        return "[" + this.b + "] " + ((int) this.a);
    }
}
