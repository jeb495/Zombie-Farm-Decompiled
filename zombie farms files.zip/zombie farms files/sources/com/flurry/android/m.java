package com.flurry.android;

final class m implements Runnable {
    private /* synthetic */ String a;
    private /* synthetic */ al b;

    m(al alVar, String str) {
        this.b = alVar;
        this.a = str;
    }

    public final void run() {
        if (this.a != null) {
            v.a(this.b.d, this.b.b, this.a);
            this.b.c.a(new f((byte) 8, this.b.d.j()));
            return;
        }
        String str = "Unable to launch in app market: " + this.b.a;
        ai.d(v.a, str);
        this.b.d.e(str);
    }
}
