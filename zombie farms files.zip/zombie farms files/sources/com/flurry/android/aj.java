package com.flurry.android;

import java.net.Socket;
import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import org.apache.http.conn.ssl.SSLSocketFactory;

final class aj extends SSLSocketFactory {
    private SSLContext a = SSLContext.getInstance("TLS");

    public aj(FlurryAgent flurryAgent, KeyStore keyStore) {
        super(keyStore);
        n nVar = new n();
        this.a.init(null, new TrustManager[]{nVar}, null);
    }

    @Override // org.apache.http.conn.scheme.LayeredSocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
    public final Socket createSocket(Socket socket, String str, int i, boolean z) {
        return this.a.getSocketFactory().createSocket(socket, str, i, z);
    }

    @Override // org.apache.http.conn.scheme.SocketFactory, org.apache.http.conn.ssl.SSLSocketFactory
    public final Socket createSocket() {
        return this.a.getSocketFactory().createSocket();
    }
}
