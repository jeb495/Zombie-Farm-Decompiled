package com.fiksu.asotracking;

import android.app.ActivityManager;
import android.app.Application;
import android.os.Process;
import android.util.Log;
import java.util.List;

class ForegroundTester implements Runnable {
    private static boolean sStarted = false;
    private final Application mApplication;
    private final LaunchEventTracker mLaunchEventTracker;
    private boolean mPostedLaunch = false;
    private boolean mWasInForeground = false;

    ForegroundTester(Application application, LaunchEventTracker launchEventTracker) {
        this.mApplication = application;
        this.mLaunchEventTracker = launchEventTracker;
        synchronized (ForegroundTester.class) {
            if (sStarted) {
                Log.e("FiksuTracking", "Already initialized!. Only call FiksuTrackingManager.initialize() once.");
                return;
            }
            sStarted = true;
            new Thread(this).start();
        }
    }

    private boolean inForeground() {
        List<ActivityManager.RunningAppProcessInfo> appProcesses = ((ActivityManager) this.mApplication.getSystemService("activity")).getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess != null && appProcess.importance == 100 && this.mApplication.getPackageName().equals(appProcess.processName)) {
                return true;
            }
        }
        return false;
    }

    /* access modifiers changed from: protected */
    public void postEvent() {
        if (!this.mPostedLaunch) {
            this.mPostedLaunch = true;
            this.mLaunchEventTracker.uploadEvent();
            return;
        }
        new ResumeEventTracker(this.mApplication).uploadEvent();
    }

    public void run() {
        try {
            Log.d("FiksuTracking", "ForegroundTester thread started, process: " + Process.myPid());
            Thread.sleep(6000);
            while (true) {
                Thread.sleep(5000);
                if (!this.mWasInForeground && inForeground()) {
                    postEvent();
                    this.mWasInForeground = true;
                } else if (this.mWasInForeground && !inForeground()) {
                    this.mWasInForeground = false;
                }
            }
        } catch (InterruptedException e) {
            Log.i("FiksuTracking", "Sleep interrupted");
        }
    }
}
