package com.fiksu.asotracking;

import android.content.Context;

class RegistrationEventTracker extends EventTracker {
    RegistrationEventTracker(Context context, String username) {
        super(context, "Registration");
        addParameter("username", username);
    }
}
