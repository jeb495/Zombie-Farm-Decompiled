package com.fiksu.asotracking;

import android.content.Context;

class ConversionEventTracker extends EventTracker {
    ConversionEventTracker(Context context, String referrer) {
        super(context, "Conversion");
        addParameter("tvalue", referrer);
    }
}
