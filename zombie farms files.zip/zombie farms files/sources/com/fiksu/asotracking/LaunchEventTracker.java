package com.fiksu.asotracking;

import android.app.Application;

class LaunchEventTracker extends EventTracker {
    LaunchEventTracker(Application application) {
        this(application, false);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    LaunchEventTracker(Application application, boolean notification) {
        super(application, notification ? "NotificationLaunch" : "Launch");
    }
}
