package com.fiksu.asotracking;

import android.content.Context;

/* access modifiers changed from: package-private */
public class ResumeEventTracker extends EventTracker {
    ResumeEventTracker(Context context) {
        this(context, false);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    ResumeEventTracker(Context context, boolean notification) {
        super(context, notification ? "NotificationResume" : "Resume");
    }
}
