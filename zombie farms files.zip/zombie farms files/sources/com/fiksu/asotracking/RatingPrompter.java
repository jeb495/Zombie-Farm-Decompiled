package com.fiksu.asotracking;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import java.util.Date;

class RatingPrompter {
    private static final int NUMBER_OF_DAYS_BEFORE_RATING_IN_MILLIS = 432000000;
    private static final int NUMBER_OF_LAUNCHES_BEFORE_RATING = 5;
    private static final String PREFERENCES_ALREADY_RATED_KEY = "Fiksu.alreadyRated";
    private static final String PREFERENCES_FIRST_LAUNCHED_KEY = "Fiksu.firstLaunchedAt";
    private static final String PREFERENCES_NAME_KEY = "Fiksu.ratingsDictionary";
    private static final String PREFERENCES_NUMBER_OF_LAUNCHES_KEY = "Fiksu.numberOfLaunches";
    private final Activity mActivity;
    private final String mAppName;
    private final RatingClickListener mNoRatingButtonListener;
    private final RatingClickListener mPostponeRatingButtonListener;
    private final RatingClickListener mRatingButtonListener;

    public RatingPrompter(Activity activity) {
        this.mRatingButtonListener = new RatingClickListener(PromptResult.USER_RATED, activity);
        this.mNoRatingButtonListener = new RatingClickListener(PromptResult.USER_DID_NOT_RATE, activity);
        this.mPostponeRatingButtonListener = new RatingClickListener(PromptResult.USER_POSTPONED_RATING, activity);
        this.mActivity = activity;
        PackageManager packageManager = this.mActivity.getPackageManager();
        String packageName = this.mActivity.getPackageName();
        String appName = null;
        try {
            appName = packageManager.getApplicationInfo(packageName, 0).loadLabel(packageManager).toString();
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("FiksuTracking", "Could not access package: " + packageName);
        }
        this.mAppName = appName;
    }

    private enum PromptResult {
        USER_RATED(1),
        USER_DID_NOT_RATE(2),
        USER_POSTPONED_RATING(3);

        private PromptResult(int value) {
        }
    }

    /* access modifiers changed from: private */
    /* access modifiers changed from: public */
    private void setUserRated() {
        SharedPreferences.Editor editor = this.mActivity.getSharedPreferences(PREFERENCES_NAME_KEY, 0).edit();
        editor.putBoolean(PREFERENCES_ALREADY_RATED_KEY, true);
        editor.commit();
    }

    private class RatingClickListener implements DialogInterface.OnClickListener {
        private PromptResult mPromptResult;

        RatingClickListener(PromptResult userRated, Activity activity) {
            this.mPromptResult = userRated;
        }

        public void onClick(DialogInterface dialog, int which) {
            switch (this.mPromptResult) {
                case USER_RATED:
                    new RatingEventTracker(RatingPrompter.this.mActivity, "rated", 5).uploadEvent();
                    Log.e("FiksuTracking", RatingPrompter.this.mActivity.getPackageName());
                    RatingPrompter.this.setUserRated();
                    RatingPrompter.this.mActivity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + RatingPrompter.this.mActivity.getPackageName())));
                    return;
                case USER_DID_NOT_RATE:
                    new RatingEventTracker(RatingPrompter.this.mActivity, "did_not_rate", 5).uploadEvent();
                    RatingPrompter.this.setUserRated();
                    return;
                case USER_POSTPONED_RATING:
                    new RatingEventTracker(RatingPrompter.this.mActivity, "deferred_rating", 5).uploadEvent();
                    return;
                default:
                    return;
            }
        }
    }

    private boolean connectedToNetwork() {
        NetworkInfo networkInfo = ((ConnectivityManager) this.mActivity.getSystemService("connectivity")).getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isAvailable() && networkInfo.isConnected();
    }

    private int getNumberOfLaunches(SharedPreferences preferences, SharedPreferences.Editor editor) {
        int numberOfLaunches = preferences.getInt(PREFERENCES_NUMBER_OF_LAUNCHES_KEY, 0) + 1;
        editor.putInt(PREFERENCES_NUMBER_OF_LAUNCHES_KEY, numberOfLaunches);
        return numberOfLaunches;
    }

    private boolean enoughTimeSinceFirstLaunch(SharedPreferences preferences, SharedPreferences.Editor editor) {
        Date now = new Date();
        long firstLaunchedAtMillis = preferences.getLong(PREFERENCES_FIRST_LAUNCHED_KEY, now.getTime());
        boolean enoughTimeHasPassed = now.getTime() - firstLaunchedAtMillis > 432000000;
        if (now.getTime() == firstLaunchedAtMillis) {
            editor.putLong(PREFERENCES_FIRST_LAUNCHED_KEY, now.getTime());
        }
        return enoughTimeHasPassed;
    }

    private boolean shouldPrompt() {
        if (this.mAppName == null || !connectedToNetwork()) {
            return false;
        }
        SharedPreferences preferences = this.mActivity.getSharedPreferences(PREFERENCES_NAME_KEY, 0);
        if (preferences.getBoolean(PREFERENCES_ALREADY_RATED_KEY, false)) {
            return false;
        }
        SharedPreferences.Editor editor = preferences.edit();
        int numberOfLaunches = getNumberOfLaunches(preferences, editor);
        boolean enoughTimeHasPassed = enoughTimeSinceFirstLaunch(preferences, editor);
        editor.commit();
        if (numberOfLaunches < 5 || !enoughTimeHasPassed) {
            return false;
        }
        return true;
    }

    public void maybeShowPrompt() {
        if (shouldPrompt()) {
            AlertDialog.Builder ratingDialogBuilder = new AlertDialog.Builder(this.mActivity);
            ratingDialogBuilder.setTitle("Enjoying " + this.mAppName + "?");
            ratingDialogBuilder.setMessage("If so, please rate it in the Android Marketplace.  It takes less than a minute and we appreciate your support!");
            ratingDialogBuilder.setPositiveButton("Rate " + this.mAppName, this.mRatingButtonListener);
            ratingDialogBuilder.setNegativeButton("No thanks", this.mNoRatingButtonListener);
            ratingDialogBuilder.setNeutralButton("Remind me later", this.mPostponeRatingButtonListener);
            ratingDialogBuilder.show();
        }
    }
}
