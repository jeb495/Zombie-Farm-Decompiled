/**
 * Copyright 2010 ngmoco:)
 * 
 * @author Kelly Johnson (kjohnson@ngmoco.com)
 */

XMLHttpRequest = XHR;
